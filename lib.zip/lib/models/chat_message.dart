// models/chat_message.dart
// models/chat_message.dart
class ChatMessage {
  final String id;
  final String postId;
  final String senderId;
  final String receiverId;
  final String senderName;
  final String receiverName; // ADD THIS FIELD
  final String message;
  final DateTime createdAt;
  final bool seen;

  ChatMessage({
    required this.id,
    required this.postId,
    required this.senderId,
    required this.receiverId,
    required this.senderName,
    required this.receiverName, // ADD THIS
    required this.message,
    required this.createdAt,
    required this.seen,
  });

  factory ChatMessage.fromJson(Map<String, dynamic> json) {
    // Parse timestamp - handle both string and int
    DateTime parseDateTime(dynamic value) {
      if (value is String) {
        return DateTime.tryParse(value) ?? DateTime.now();
      } else if (value is int) {
        return DateTime.fromMillisecondsSinceEpoch(value);
      }
      return DateTime.now();
    }

    return ChatMessage(
      id: json['id']?.toString() ?? json['_id']?.toString() ?? '',
      postId: json['postId']?.toString() ?? json['post_id']?.toString() ?? '',
      senderId:
          json['senderId']?.toString() ?? json['sender_id']?.toString() ?? '',
      receiverId:
          json['receiverId']?.toString() ??
          json['receiver_id']?.toString() ??
          '',
      senderName:
          json['senderName']?.toString() ??
          json['sender_name']?.toString() ??
          'Unknown',
      receiverName: // ADD THIS PARSING
          json['receiverName']?.toString() ??
          json['receiver_name']?.toString() ??
          'Unknown',
      message: json['message']?.toString() ?? '',
      createdAt: parseDateTime(json['createdAt'] ?? json['created_at']),
      seen: json['seen'] is bool
          ? json['seen']
          : (json['seen']?.toString() == 'true'),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'postId': postId,
      'senderId': senderId,
      'receiverId': receiverId,
      'senderName': senderName,
      'receiverName': receiverName, // ADD THIS
      'message': message,
      'createdAt': createdAt.toIso8601String(),
      'seen': seen,
    };
  }

  // Helper to check if message is from current user
  bool isFromUser(String currentUserId) {
    return senderId == currentUserId;
  }

  // Helper to check if message is for current user
  bool isForUser(String currentUserId) {
    return receiverId == currentUserId;
  }

  // Format time for display
  String get formattedTime {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final messageDate = DateTime(
      createdAt.year,
      createdAt.month,
      createdAt.day,
    );

    if (messageDate.isAtSameMomentAs(today)) {
      return '${createdAt.hour.toString().padLeft(2, '0')}:${createdAt.minute.toString().padLeft(2, '0')}';
    } else {
      return '${createdAt.day}/${createdAt.month} ${createdAt.hour.toString().padLeft(2, '0')}:${createdAt.minute.toString().padLeft(2, '0')}';
    }
  }
}
