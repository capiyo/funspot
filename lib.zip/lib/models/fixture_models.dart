import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// ========== SUB-FIXTURE MODELS ==========
enum SubFixtureType { firstYellowCard, firstGoal, firstCorner, firstOffside }

enum SubFixtureFormat { teamVsTeam, threeWay }

// ============================================================================
// BET MODEL (Single collection - matches backend)
// ============================================================================
// In fixture_models.dart - update the Bet class:

class Bet {
  final String id;
  final String fixtureId;
  final String starterId;
  final String starterName;
  final String starterSelection;
  final double starterAmount;
  final String? finisherId;
  final String? finisherName;
  final String? finisherSelection;
  final double? finisherAmount;
  final String channelId;
  final String status;
  final String? winnerId;
  final String? starterResult;
  final String? finisherResult;
  final DateTime createdAt;
  final DateTime? matchedAt;
  final DateTime? settledAt;

  Bet({
    required this.id,
    required this.fixtureId,
    required this.starterId,
    required this.starterName,
    required this.starterSelection,
    required this.starterAmount,
    this.finisherId,
    this.finisherName,
    this.finisherSelection,
    this.finisherAmount,
    required this.channelId,
    required this.status,
    this.winnerId,
    this.starterResult,
    this.finisherResult,
    required this.createdAt,
    this.matchedAt,
    this.settledAt,
  });

  // Helper to parse dates safely
  static DateTime _parseDate(dynamic dateValue) {
    if (dateValue == null) return DateTime.now();

    try {
      // Handle BSON date format: {"$date": {"$numberLong": "timestamp"}}
      if (dateValue is Map && dateValue['\$date'] != null) {
        final dateObj = dateValue['\$date'];
        if (dateObj is Map && dateObj['\$numberLong'] != null) {
          final timestamp = int.tryParse(dateObj['\$numberLong'].toString());
          if (timestamp != null) {
            return DateTime.fromMillisecondsSinceEpoch(timestamp);
          }
        }
        if (dateObj is String) {
          return DateTime.parse(dateObj);
        }
      }

      // Handle ISO string
      if (dateValue is String) {
        return DateTime.parse(dateValue);
      }

      return DateTime.now();
    } catch (e) {
      debugPrint('⚠️ Date parse error: $e for value: $dateValue');
      return DateTime.now();
    }
  }

  factory Bet.fromJson(Map<String, dynamic> json) {
    return Bet(
      id: json['_id']?['\$oid']?.toString() ?? json['id']?.toString() ?? '',
      fixtureId: json['fixture_id']?.toString() ?? '',
      starterId: json['starter_id']?.toString() ?? '',
      starterName: json['starter_name']?.toString() ?? '',
      starterSelection: json['starter_selection']?.toString() ?? '',
      starterAmount: (json['starter_amount'] ?? 0.0).toDouble(),
      finisherId: json['finisher_id']?.toString(),
      finisherName: json['finisher_name']?.toString(),
      finisherSelection: json['finisher_selection']?.toString(),
      finisherAmount: (json['finisher_amount'] as num?)?.toDouble(),
      channelId: json['channel_id']?.toString() ?? '',
      status: json['status']?.toString() ?? 'open',
      winnerId: json['winner_id']?.toString(),
      starterResult: json['starter_result']?.toString(),
      finisherResult: json['finisher_result']?.toString(),
      createdAt: _parseDate(json['created_at']),
      matchedAt:
          json['matched_at'] != null ? _parseDate(json['matched_at']) : null,
      settledAt:
          json['settled_at'] != null ? _parseDate(json['settled_at']) : null,
    );
  }

  bool get isOpen => status == 'open';
  bool get isMatched => status == 'matched';
  bool get isSettled => status == 'settled';

  // ✅ ADD THIS GETTER
  bool get isActive => status == 'open' || status == 'matched';

  double get totalPot => starterAmount + (finisherAmount ?? 0.0);
}

// ============================================================================
// BETTOR MODEL - Unified model for all bets (pledges + matched bets)
// ============================================================================
class Bettor {
  final String userId;
  final String userName;
  final String selection;
  final double amount;
  final String? opponentId;
  final String? opponentName;
  final String? opponentSelection;
  final double? opponentAmount;
  final double? totalPot;
  final String betId;
  final String? status;
  final bool? winner;
  final double? payout;
  final DateTime matchedAt;
  final DateTime? resolvedAt;
  final DateTime? createdAt;

  Bettor({
    required this.userId,
    required this.userName,
    required this.selection,
    required this.amount,
    this.opponentId,
    this.opponentName,
    this.opponentSelection,
    this.opponentAmount,
    this.totalPot,
    required this.betId,
    this.status,
    this.winner,
    this.payout,
    required this.matchedAt,
    this.resolvedAt,
    this.createdAt,
  });

  // Helper to parse dates safely
  static DateTime _parseDate(dynamic dateValue) {
    if (dateValue == null) return DateTime.now();

    try {
      // Handle BSON date format: {"$date": {"$numberLong": "timestamp"}}
      if (dateValue is Map && dateValue['\$date'] != null) {
        final dateObj = dateValue['\$date'];
        if (dateObj is Map && dateObj['\$numberLong'] != null) {
          final timestamp = int.tryParse(dateObj['\$numberLong'].toString());
          if (timestamp != null) {
            return DateTime.fromMillisecondsSinceEpoch(timestamp);
          }
        }
        if (dateObj is String) {
          return DateTime.parse(dateObj);
        }
      }

      // Handle ISO string
      if (dateValue is String) {
        return DateTime.parse(dateValue);
      }

      return DateTime.now();
    } catch (e) {
      debugPrint('⚠️ Date parse error: $e for value: $dateValue');
      return DateTime.now();
    }
  }

  static String _mapSelection(String selection) {
    switch (selection) {
      case 'home':
        return 'home_team';
      case 'away':
        return 'away_team';
      case 'draw':
        return 'draw';
      default:
        return selection;
    }
  }

  // ✅ FACTORY FOR OPEN BETS (Pledges)
  // ✅ FACTORY FOR OPEN BETS (Pledges)
  factory Bettor.fromOpenBet(Map<String, dynamic> json) {
    // ✅ Handle both ObjectId format and direct string
    String betId = '';
    final idValue = json['_id'];
    if (idValue is String) {
      betId = idValue;
    } else if (idValue is Map && idValue['\$oid'] != null) {
      betId = idValue['\$oid'].toString();
    } else if (json['id'] != null) {
      betId = json['id'].toString();
    }

    return Bettor(
      userId: json['starter_id']?.toString() ?? '',
      userName: json['starter_name']?.toString() ?? 'Anonymous',
      selection: _mapSelection(json['starter_selection']?.toString() ?? ''),
      amount: (json['starter_amount'] as num?)?.toDouble() ?? 0.0,
      opponentId: null,
      opponentName: null,
      opponentSelection: null,
      opponentAmount: null,
      totalPot: null,
      betId: betId, // ✅ Now correctly populated
      status: 'open',
      winner: null,
      payout: null,
      matchedAt: _parseDate(json['created_at']),
      resolvedAt: null,
      createdAt: _parseDate(json['created_at']),
    );
  }
  // ✅ FACTORY FOR MATCHED BETS
  factory Bettor.fromMatchedBet(Map<String, dynamic> json, String userId) {
    final isStarter = json['starter_id']?.toString() == userId;
    final starterAmount = (json['starter_amount'] as num?)?.toDouble() ?? 0.0;
    final finisherAmount = (json['finisher_amount'] as num?)?.toDouble() ?? 0.0;
    final totalPot = starterAmount + finisherAmount;

    // ✅ Handle both ObjectId format and direct string
    String betId = '';
    final idValue = json['_id'];
    if (idValue is String) {
      betId = idValue;
    } else if (idValue is Map && idValue['\$oid'] != null) {
      betId = idValue['\$oid'].toString();
    } else if (json['id'] != null) {
      betId = json['id'].toString();
    }

    return Bettor(
      userId: isStarter
          ? json['starter_id']?.toString() ?? ''
          : json['finisher_id']?.toString() ?? '',
      userName: isStarter
          ? json['starter_name']?.toString() ?? 'Anonymous'
          : json['finisher_name']?.toString() ?? 'Anonymous',
      selection: isStarter
          ? _mapSelection(json['starter_selection']?.toString() ?? '')
          : _mapSelection(json['finisher_selection']?.toString() ?? ''),
      amount: isStarter ? starterAmount : finisherAmount,
      opponentId: isStarter
          ? json['finisher_id']?.toString()
          : json['starter_id']?.toString(),
      opponentName: isStarter
          ? json['finisher_name']?.toString()
          : json['starter_name']?.toString(),
      opponentSelection: isStarter
          ? _mapSelection(json['finisher_selection']?.toString() ?? '')
          : _mapSelection(json['starter_selection']?.toString() ?? ''),
      opponentAmount: isStarter ? finisherAmount : starterAmount,
      totalPot: totalPot,
      betId: betId, // ✅ Now correctly populated
      status: json['status']?.toString() ?? 'open',
      winner: json['winner_id']?.toString() == json['starter_id']?.toString(),
      payout: null,
      matchedAt: _parseDate(json['matched_at']),
      resolvedAt:
          json['settled_at'] != null ? _parseDate(json['settled_at']) : null,
      createdAt: _parseDate(json['created_at']),
    );
  }

  // ✅ FACTORY FOR API RESPONSE (auto-detects open vs matched)
  factory Bettor.fromJson(Map<String, dynamic> json) {
    final isOpenBet =
        json['finisher_id'] == null || json['finisher_id']?.toString() == '';

    if (isOpenBet) {
      return Bettor.fromOpenBet(json);
    } else {
      final userId =
          json['userId']?.toString() ?? json['starter_id']?.toString() ?? '';
      return Bettor.fromMatchedBet(json, userId);
    }
  }

  // ✅ FACTORY FOR CREATING A NEW PLEDGE
  factory Bettor.createPledge({
    required String userId,
    required String userName,
    required String selection,
    required double amount,
  }) {
    return Bettor(
      userId: userId,
      userName: userName,
      selection: selection,
      amount: amount,
      opponentId: null,
      opponentName: null,
      opponentSelection: null,
      opponentAmount: null,
      totalPot: null,
      betId: '',
      status: 'open',
      winner: null,
      payout: null,
      matchedAt: DateTime.now(),
      resolvedAt: null,
      createdAt: DateTime.now(),
    );
  }

  bool get isOpen => status == 'open' || status == null;
  bool get isMatched => status == 'matched';
  bool get isSettled => status == 'settled';
  bool get isActive => status == 'open' || status == 'matched';
  bool get isWon => winner == true;
  bool get isLost => winner == false;
  bool get isResolved => resolvedAt != null;
  bool get isPledge => opponentId == null && status == 'open';

  String get statusDisplay {
    if (isOpen) return '💰 Open';
    if (isWon) return '🏆 Won';
    if (isLost) return '💔 Lost';
    return '⚡ Active';
  }

  Color get statusColor {
    if (isOpen) return Colors.amber;
    if (isWon) return Colors.green;
    if (isLost) return Colors.red;
    return Colors.orange;
  }

  String get selectionDisplay {
    if (selection == 'home_team') return '🏠 Home';
    if (selection == 'away_team') return '✈️ Away';
    if (selection == 'draw') return '🤝 Draw';
    return selection;
  }

  String get opponentSelectionDisplay {
    if (opponentSelection == 'home_team') return '🏠 Home';
    if (opponentSelection == 'away_team') return '✈️ Away';
    if (opponentSelection == 'draw') return '🤝 Draw';
    return opponentSelection ?? 'Unknown';
  }

  double get potentialWinnings => totalPot ?? amount;

  Map<String, dynamic> toJson() {
    return {
      'userId': userId,
      'userName': userName,
      'selection': selection,
      'amount': amount,
      'opponentId': opponentId,
      'opponentName': opponentName,
      'opponentSelection': opponentSelection,
      'opponentAmount': opponentAmount,
      'totalPot': totalPot,
      'betId': betId,
      'status': status,
      'winner': winner,
      'payout': payout,
      'matchedAt': matchedAt.toIso8601String(),
      'resolvedAt': resolvedAt?.toIso8601String(),
      'createdAt': createdAt?.toIso8601String(),
    };
  }
}

// ========== SUB-FIXTURE MODEL ==========
class SubFixture {
  final String id;
  final String parentFixtureId;
  final SubFixtureType type;
  final SubFixtureFormat format;
  final String question;
  final String optionA;
  final String optionB;
  final String? optionC;
  final double oddsA;
  final double oddsB;
  final double? oddsC;
  final bool isActive;
  final int displayOrder;
  final IconData icon;

  SubFixture({
    required this.id,
    required this.parentFixtureId,
    required this.type,
    required this.format,
    required this.question,
    required this.optionA,
    required this.optionB,
    this.optionC,
    required this.oddsA,
    required this.oddsB,
    this.oddsC,
    required this.isActive,
    required this.displayOrder,
    required this.icon,
  });

  factory SubFixture.fromJson(Map<String, dynamic> json) {
    final typeValue = json['type'] ?? json['fixture_type'] ?? 'first_yellow';
    final type = _parseSubFixtureType(typeValue);

    return SubFixture(
      id: json['sub_fixture_id'] ?? json['id'] ?? '',
      parentFixtureId:
          json['parent_fixture_id'] ?? json['parentFixtureId'] ?? '',
      type: type,
      format: _parseSubFixtureFormat(json['format']),
      question: json['question'] ?? '',
      optionA: json['option_a'] ?? json['optionA'] ?? '',
      optionB: json['option_b'] ?? json['optionB'] ?? '',
      optionC: json['option_c'] ?? json['optionC'],
      oddsA: _parseDouble(json['odds_a'] ?? json['oddsA'] ?? 0.0),
      oddsB: _parseDouble(json['odds_b'] ?? json['oddsB'] ?? 0.0),
      oddsC: _parseNullableDouble(json['odds_c'] ?? json['oddsC']),
      isActive: json['is_active'] ?? json['isActive'] ?? true,
      displayOrder: json['display_order'] ?? json['displayOrder'] ?? 0,
      icon: _getIconForType(type),
    );
  }

  static SubFixtureType _parseSubFixtureType(String? type) {
    switch (type) {
      case 'first_yellow':
      case 'first_yellow_card':
        return SubFixtureType.firstYellowCard;
      case 'first_goal':
        return SubFixtureType.firstGoal;
      case 'first_corner':
        return SubFixtureType.firstCorner;
      case 'first_offside':
        return SubFixtureType.firstOffside;
      default:
        return SubFixtureType.firstYellowCard;
    }
  }

  String getBackendType() {
    switch (type) {
      case SubFixtureType.firstYellowCard:
        return 'first_yellow_card';
      case SubFixtureType.firstGoal:
        return 'first_goal';
      case SubFixtureType.firstCorner:
        return 'first_corner';
      case SubFixtureType.firstOffside:
        return 'first_offside';
    }
  }

  static SubFixtureFormat _parseSubFixtureFormat(String? format) {
    switch (format) {
      case 'team_vs_team':
        return SubFixtureFormat.teamVsTeam;
      case 'three_way':
        return SubFixtureFormat.threeWay;
      default:
        return SubFixtureFormat.teamVsTeam;
    }
  }

  static IconData _getIconForType(SubFixtureType type) {
    switch (type) {
      case SubFixtureType.firstYellowCard:
        return Icons.warning_amber_rounded;
      case SubFixtureType.firstGoal:
        return Icons.sports_soccer;
      case SubFixtureType.firstCorner:
        return Icons.flag;
      case SubFixtureType.firstOffside:
        return Icons.outlined_flag;
    }
  }

  static double _parseDouble(dynamic value) {
    if (value == null) return 0.0;
    if (value is double) return value;
    if (value is int) return value.toDouble();
    if (value is String) return double.tryParse(value) ?? 0.0;
    return 0.0;
  }

  static double? _parseNullableDouble(dynamic value) {
    if (value == null) return null;
    if (value is double) return value;
    if (value is int) return value.toDouble();
    if (value is String) return double.tryParse(value);
    return null;
  }

  Map<String, dynamic> toJson() {
    return {
      'sub_fixture_id': id,
      'parent_fixture_id': parentFixtureId,
      'fixture_type': getBackendType(),
      'question': question,
      'option_a': optionA,
      'option_b': optionB,
      'option_c': optionC,
      'odds_a': oddsA,
      'odds_b': oddsB,
      'odds_c': oddsC,
      'is_active': isActive,
      'display_order': displayOrder,
      'icon': _getIconString(icon),
    };
  }

  String _getIconString(IconData icon) {
    final iconMap = {
      Icons.warning_amber_rounded: '⚠️',
      Icons.sports_soccer: '⚽',
      Icons.flag: '🏁',
      Icons.outlined_flag: '🚩',
    };
    return iconMap[icon] ?? '🎲';
  }
}

// ========== VOTER MODEL ==========
// In fixture_models.dart - update the Voter class:

class Voter {
  final String userId;
  final String userName;
  final String selection;
  final bool? isCorrect;
  final int? pointsAwarded;
  final bool isComrade; // ✅ Add this field
  final DateTime votedAt;

  Voter({
    required this.userId,
    required this.userName,
    required this.selection,
    this.isCorrect,
    this.pointsAwarded,
    this.isComrade = false, // ✅ Default to false
    required this.votedAt,
  });

  factory Voter.fromJson(Map<String, dynamic> json) {
    return Voter(
      userId: json['userId']?.toString() ?? json['user_id']?.toString() ?? '',
      userName: json['userName']?.toString() ??
          json['user_name']?.toString() ??
          'Anonymous',
      selection: json['selection']?.toString() ?? '',
      isCorrect: json['isCorrect'] as bool?,
      pointsAwarded: json['pointsAwarded'] as int?,
      isComrade: json['isComrade'] as bool? ??
          json['is_comrade'] as bool? ??
          false, // ✅ Parse from JSON
      votedAt: DateTime.tryParse(json['votedAt']?.toString() ??
              json['voted_at']?.toString() ??
              '') ??
          DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'userId': userId,
      'userName': userName,
      'selection': selection,
      'isCorrect': isCorrect,
      'pointsAwarded': pointsAwarded,
      'isComrade': isComrade, // ✅ Add to JSON
      'votedAt': votedAt.toIso8601String(),
    };
  }

  String get selectionDisplay {
    if (selection == 'home_team') return '🏠 Home';
    if (selection == 'away_team') return '✈️ Away';
    if (selection == 'draw') return '🤝 Draw';
    return selection;
  }
}

// ============================================================================
// MAIN FIXTURE MODEL
// ============================================================================
class Fixture {
  final String id;
  final String matchId;
  final String homeTeam;
  final String awayTeam;
  final String league;
  final double homeWin;
  final double awayWin;
  final double draw;
  final String date;
  final String time;
  final int? homeScore;
  final int? awayScore;
  final String status;
  final bool isLive;
  final bool availableForVoting;
  final String source;
  final DateTime scrapedAt;
  final String dateIso;
  final String? result;

  final int votes;
  final List<Voter> voters;
  final int pledges;
  final List<Bettor> pledgers;
  final int bets;
  final List<Bettor> bettors;
  List<SubFixture> subFixtures;
  final int? minutesPlayed;
  final String? minuteDisplay; // ✅ ADDED

  Fixture({
    required this.id,
    required this.matchId,
    required this.homeTeam,
    required this.awayTeam,
    required this.league,
    required this.homeWin,
    required this.awayWin,
    required this.draw,
    required this.date,
    required this.time,
    this.homeScore,
    this.awayScore,
    required this.status,
    required this.isLive,
    required this.availableForVoting,
    required this.source,
    required this.scrapedAt,
    required this.dateIso,
    this.result,
    this.votes = 0,
    this.voters = const [],
    this.pledges = 0,
    this.pledgers = const [],
    this.bets = 0,
    this.bettors = const [],
    this.subFixtures = const [],
    this.minutesPlayed,
    this.minuteDisplay, // ✅ ADDED
  });

  // Helper to parse dates safely
  static DateTime _parseDate(dynamic dateValue) {
    if (dateValue == null) return DateTime.now();

    try {
      // Handle BSON date format: {"$date": {"$numberLong": "timestamp"}}
      if (dateValue is Map && dateValue['\$date'] != null) {
        final dateObj = dateValue['\$date'];
        if (dateObj is Map && dateObj['\$numberLong'] != null) {
          final timestamp = int.tryParse(dateObj['\$numberLong'].toString());
          if (timestamp != null) {
            return DateTime.fromMillisecondsSinceEpoch(timestamp);
          }
        }
        if (dateObj is String) {
          return DateTime.parse(dateObj);
        }
      }

      // Handle ISO string
      if (dateValue is String) {
        return DateTime.parse(dateValue);
      }

      return DateTime.now();
    } catch (e) {
      debugPrint('⚠️ Date parse error: $e for value: $dateValue');
      return DateTime.now();
    }
  }

  factory Fixture.fromJson(Map<String, dynamic> json) {
    String id;
    if (json['_id'] is String) {
      id = json['_id'];
    } else if (json['_id'] is Map) {
      id = json['_id']['\$oid']?.toString() ??
          json['_id']['oid']?.toString() ??
          '';
    } else {
      id = json['_id']?.toString() ?? '';
    }

    DateTime scrapedAt = _parseDate(json['scrapedAt'] ?? json['scraped_at']);

    List<Voter> voters = [];
    if (json['voters'] is List) {
      try {
        voters = (json['voters'] as List)
            .map((e) => Voter.fromJson(e as Map<String, dynamic>))
            .toList();
      } catch (_) {}
    }

    List<Bettor> pledgers = [];
    if (json['pledgers'] is List) {
      try {
        pledgers = (json['pledgers'] as List)
            .map((e) => Bettor.fromOpenBet(e as Map<String, dynamic>))
            .toList();
      } catch (_) {}
    }

    List<Bettor> bettors = [];
    if (json['bettors'] is List) {
      try {
        bettors = (json['bettors'] as List)
            .map((e) => Bettor.fromJson(e as Map<String, dynamic>))
            .toList();
      } catch (_) {}
    }

    List<SubFixture> subFixtures = [];
    if (json['subFixtures'] is List) {
      try {
        subFixtures = (json['subFixtures'] as List)
            .map((e) => SubFixture.fromJson(e as Map<String, dynamic>))
            .toList();
      } catch (_) {}
    }

    return Fixture(
      id: id,
      matchId:
          json['matchId']?.toString() ?? json['match_id']?.toString() ?? '',
      homeTeam:
          json['homeTeam']?.toString() ?? json['home_team']?.toString() ?? '',
      awayTeam:
          json['awayTeam']?.toString() ?? json['away_team']?.toString() ?? '',
      league: json['league']?.toString() ?? '',
      homeWin: _parseDouble(json['homeWin'] ?? json['home_win']),
      awayWin: _parseDouble(json['awayWin'] ?? json['away_win']),
      draw: _parseDouble(json['draw']),
      date: json['date']?.toString() ?? '',
      time: json['time']?.toString() ?? '',
      homeScore: _parseNullableInt(json['homeScore'] ?? json['home_score']),
      awayScore: _parseNullableInt(json['awayScore'] ?? json['away_score']),
      status: json['status']?.toString() ?? 'upcoming',
      isLive: json['isLive'] as bool? ?? json['is_live'] as bool? ?? false,
      availableForVoting: json['availableForVoting'] as bool? ??
          json['available_for_voting'] as bool? ??
          true,
      source: json['source']?.toString() ?? '',
      scrapedAt: scrapedAt,
      dateIso:
          json['dateIso']?.toString() ?? json['date_iso']?.toString() ?? '',
      result: json['result']?.toString(),
      votes: json['votes'] as int? ?? 0,
      voters: voters,
      pledges: json['pledges'] as int? ?? 0,
      pledgers: pledgers,
      bets: json['bets'] as int? ?? 0,
      bettors: bettors,
      subFixtures: subFixtures,
      minutesPlayed: json['minutesPlayed'] as int?, // ✅ ADDED
      minuteDisplay: json['minuteDisplay']?.toString(), // ✅ ADDED
    );
  }

  static double _parseDouble(dynamic value) {
    if (value == null) return 0.0;
    if (value is double) return value;
    if (value is int) return value.toDouble();
    if (value is String) return double.tryParse(value) ?? 0.0;
    return 0.0;
  }

  static int? _parseNullableInt(dynamic value) {
    if (value == null) return null;
    if (value is int) return value;
    if (value is double) return value.toInt();
    if (value is String) return int.tryParse(value);
    return null;
  }

  Map<String, dynamic> toJson() {
    return {
      '_id': id,
      'match_id': matchId,
      'home_team': homeTeam,
      'away_team': awayTeam,
      'league': league,
      'home_win': homeWin,
      'away_win': awayWin,
      'draw': draw,
      'date': date,
      'time': time,
      'home_score': homeScore,
      'away_score': awayScore,
      'status': status,
      'is_live': isLive,
      'available_for_voting': availableForVoting,
      'source': source,
      'scraped_at': scrapedAt.toIso8601String(),
      'date_iso': dateIso,
      'result': result,
      'votes': votes,
      'voters': voters.map((v) => v.toJson()).toList(),
      'pledges': pledges,
      'pledgers': pledgers.map((p) => p.toJson()).toList(),
      'bets': bets,
      'bettors': bettors.map((b) => b.toJson()).toList(),
      'subFixtures': subFixtures.map((sf) => sf.toJson()).toList(),
      'minutesPlayed': minutesPlayed, // ✅ ADDED
      'minuteDisplay': minuteDisplay, // ✅ ADDED
    };
  }

  bool get isUpcoming => status == 'upcoming';
  bool get isSoon => status == 'soon';
  bool get isCompleted => status == 'completed';
  bool get hasScores => homeScore != null && awayScore != null;

  String get scoreDisplay => hasScores ? '$homeScore - $awayScore' : '';
  String get formattedDateTime => '$date $time'.trim();
  String get displayDate => dateIso.isNotEmpty ? dateIso : '$date $time';

  double get totalPledgedAmount =>
      pledgers.fold(0.0, (sum, p) => sum + p.amount);
  double get totalBetAmount => bettors.fold(0.0, (sum, b) => sum + b.amount);
  double get totalBetPot =>
      bettors.fold(0.0, (sum, b) => sum + (b.totalPot ?? 0.0));

  List<Bettor> getPledgersBySelection(String selection) =>
      pledgers.where((p) => p.selection == selection).toList();

  List<Bettor> getBettorsBySelection(String selection) =>
      bettors.where((b) => b.selection == selection).toList();

  bool isUserPledger(String userId) => pledgers.any((p) => p.userId == userId);
  bool isUserBettor(String userId) => bettors.any((b) => b.userId == userId);

  Bettor? getUserBet(String userId) {
    try {
      return bettors.firstWhere((b) => b.userId == userId);
    } catch (_) {
      return null;
    }
  }

  Bettor? getUserPledge(String userId) {
    try {
      return pledgers.firstWhere((p) => p.userId == userId);
    } catch (_) {
      return null;
    }
  }

  // ✅ NEW: Helper to get formatted minute display
  String getFormattedMinuteDisplay() {
    if (minuteDisplay != null && minuteDisplay!.isNotEmpty) {
      return minuteDisplay!;
    }

    final minutes = minutesPlayed ?? 0;

    // Check if it's half time
    if (status == 'half_time' || minutes == 45) {
      return 'Half Time';
    }

    // Check if it's full time
    if (minutes >= 90 && minutes < 120) {
      final etMinutes = minutes - 90;
      if (etMinutes == 0) {
        return 'Full Time';
      }
      return 'ET ${etMinutes}\'';
    }

    // Check if it's penalties
    if (minutes >= 120) {
      return 'Penalties';
    }

    // Regular minutes
    return "$minutes'";
  }

  // ✅ NEW: Get color for minute display
  Color getMinuteDisplayColor() {
    final display = getFormattedMinuteDisplay();

    if (display == 'Half Time') {
      return Colors.orange;
    }
    if (display == 'Full Time') {
      return Colors.red;
    }
    if (display.startsWith('ET')) {
      return Colors.purple.shade300;
    }
    if (display == 'Penalties') {
      return Colors.red;
    }
    return Colors.white70;
  }

  // ✅ NEW: Check if match is at half time
  bool get isHalfTime {
    return status == 'half_time' ||
        minutesPlayed == 45 ||
        (minuteDisplay?.toLowerCase() == 'half time');
  }

  // ✅ NEW: Check if match is in extra time
  bool get isExtraTime {
    final minutes = minutesPlayed ?? 0;
    return minutes >= 90 && minutes < 120;
  }

  // ✅ NEW: Check if match is in penalties
  bool get isPenalties {
    final minutes = minutesPlayed ?? 0;
    return minutes >= 120;
  }

  // ✅ NEW: Check if match is at full time
  bool get isFullTime {
    final minutes = minutesPlayed ?? 0;
    return minutes >= 90 || status == 'completed';
  }
}

// ========== EXTENSION METHODS ==========
extension GameExtension on Fixture {
  String get winner {
    if (hasScores) {
      if (homeScore! > awayScore!) return homeTeam;
      if (awayScore! > homeScore!) return awayTeam;
      return 'Draw';
    }
    return 'Unknown';
  }

  Color get winnerColor {
    if (hasScores) {
      if (homeScore! > awayScore!) return const Color(0xFF10B981);
      if (awayScore! > homeScore!) return const Color(0xFF3B82F6);
      return const Color(0xFF8B5CF6);
    }
    return Colors.grey;
  }

  int get totalPledgeParticipants => pledgers.length + bettors.length;
  double get totalMoneyInvolved => totalPledgedAmount + totalBetPot;
}

// ========== ACTIVE FIXTURE (for UI) ==========
class ActiveFixture {
  final String fixtureId;
  final String homeTeam;
  final String awayTeam;
  final String league;
  final String date;
  final int commentCount;
  final int voteCount;
  final String? latestComment;
  final String? latestCommenter;
  bool hasUserJoined;

  ActiveFixture({
    required this.fixtureId,
    required this.homeTeam,
    required this.awayTeam,
    required this.league,
    required this.date,
    this.commentCount = 0,
    this.voteCount = 0,
    this.latestComment,
    this.latestCommenter,
    this.hasUserJoined = false,
  });
}

// ========== HISTORY MODELS ==========
class HistoryGame {
  final Fixture game;
  final DateTime completedAt;
  final bool movedToHistory;

  HistoryGame({
    required this.game,
    required this.completedAt,
    required this.movedToHistory,
  });

  factory HistoryGame.fromJson(Map<String, dynamic> json) {
    return HistoryGame(
      game: Fixture.fromJson(json),
      completedAt: DateTime.parse(
        json['completedAt']?.toString() ??
            json['completed_at']?.toString() ??
            DateTime.now().toIso8601String(),
      ),
      movedToHistory:
          json['movedToHistory'] ?? json['moved_to_history'] ?? true,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      ...game.toJson(),
      'completed_at': completedAt.toIso8601String(),
      'moved_to_history': movedToHistory,
    };
  }
}

class HistoryQueryParams {
  final int? limit;
  final int? skip;
  final String? league;
  final String? homeTeam;
  final String? awayTeam;
  final DateTime? fromDate;
  final DateTime? toDate;

  HistoryQueryParams({
    this.limit,
    this.skip,
    this.league,
    this.homeTeam,
    this.awayTeam,
    this.fromDate,
    this.toDate,
  });

  Map<String, String> toQueryParameters() {
    final params = <String, String>{};
    if (limit != null) params['limit'] = limit.toString();
    if (skip != null) params['skip'] = skip.toString();
    if (league != null) params['league'] = league!;
    if (homeTeam != null) params['home_team'] = homeTeam!;
    if (awayTeam != null) params['away_team'] = awayTeam!;
    if (fromDate != null) {
      params['from_date'] = fromDate!.toIso8601String().split('T')[0];
    }
    if (toDate != null) {
      params['to_date'] = toDate!.toIso8601String().split('T')[0];
    }
    return params;
  }
}

// ========== HISTORY SERVICE ==========
class HistoryService {
  static const String API_BASE_URL = 'https://clash-api-m5mr.onrender.com/api';
  static const Duration REQUEST_TIMEOUT = Duration(seconds: 15);

  static Future<List<HistoryGame>> fetchHistoryGames({
    HistoryQueryParams? params,
    String? authToken,
  }) async {
    try {
      final uri = Uri.parse('$API_BASE_URL/games/history')
          .replace(queryParameters: params?.toQueryParameters() ?? {});

      final headers = <String, String>{
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      };
      if (authToken != null && authToken.isNotEmpty) {
        headers['Authorization'] = 'Bearer $authToken';
      }

      final response =
          await http.get(uri, headers: headers).timeout(REQUEST_TIMEOUT);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final List<dynamic> gamesData = data['data'] ?? [];
        return gamesData.map((j) => HistoryGame.fromJson(j)).toList();
      }
      return [];
    } catch (e) {
      debugPrint('❌ Error fetching history games: $e');
      return [];
    }
  }

  static Future<HistoryGame?> fetchHistoryGameById(
    String matchId, {
    String? authToken,
  }) async {
    try {
      final headers = <String, String>{
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      };
      if (authToken != null && authToken.isNotEmpty) {
        headers['Authorization'] = 'Bearer $authToken';
      }

      final response = await http
          .get(
            Uri.parse('$API_BASE_URL/games/history/$matchId'),
            headers: headers,
          )
          .timeout(REQUEST_TIMEOUT);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return HistoryGame.fromJson(data['data']);
      }
      return null;
    } catch (e) {
      debugPrint('❌ Error fetching history game: $e');
      return null;
    }
  }

  static Future<int> getTotalHistoryCount({String? authToken}) async {
    try {
      final headers = <String, String>{
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      };
      if (authToken != null && authToken.isNotEmpty) {
        headers['Authorization'] = 'Bearer $authToken';
      }

      final response = await http
          .get(
            Uri.parse('$API_BASE_URL/games/history/count'),
            headers: headers,
          )
          .timeout(REQUEST_TIMEOUT);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data['total'] ?? 0;
      }
      return 0;
    } catch (e) {
      debugPrint('❌ Error fetching history count: $e');
      return 0;
    }
  }
}
