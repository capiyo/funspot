// models/user_channel.dart

class UserChannel {
  final String channelId;
  final String name;
  final int memberCount;
  final String season;
  final bool isAdmin;
  final List<String>? admins;
  final List<String> memberIds;
  final String inviteCode;
  final List<ChannelMember> members;

  UserChannel({
    required this.channelId,
    required this.name,
    required this.memberCount,
    required this.season,
    this.isAdmin = false,
    this.admins,
    this.memberIds = const [],
    this.inviteCode = '',
    this.members = const [],
  });

  factory UserChannel.fromJson(Map<String, dynamic> json) {
    final List<dynamic> membersData = json['members'] ?? [];
    final List<ChannelMember> members = membersData
        .map((m) => ChannelMember.fromJson(m as Map<String, dynamic>))
        .toList();

    // You'll need to handle AuthService differently here
    // Or pass currentUserId as parameter
    final bool isAdmin = false; // Set based on your logic

    return UserChannel(
      channelId: json['channel_id'] ?? '',
      name: json['name'] ?? '',
      memberCount: json['member_count'] ?? 0,
      season: json['season'] ?? '',
      isAdmin: isAdmin,
      admins: json['admins'] != null ? List<String>.from(json['admins']) : null,
      memberIds:
          members.map((m) => m.userId).where((id) => id.isNotEmpty).toList(),
      inviteCode: json['invite_code'] ?? '',
      members: members,
    );
  }

  Map<String, dynamic> toJson() => {
        'channel_id': channelId,
        'name': name,
        'member_count': memberCount,
        'season': season,
        'is_admin': isAdmin,
        'member_ids': memberIds,
        'members': members.map((m) => m.toJson()).toList(),
      };
}

class ChannelMember {
  final String userId;
  final String username;
  final String role;
  final DateTime joinedAt;
  final int seasonPoints;
  final int correctVotes;
  final int totalVotes;
  final int msgCount;

  ChannelMember({
    required this.userId,
    required this.username,
    required this.role,
    required this.joinedAt,
    required this.seasonPoints,
    required this.correctVotes,
    required this.totalVotes,
    required this.msgCount,
  });

  factory ChannelMember.fromJson(Map<String, dynamic> json) {
    return ChannelMember(
      userId: json['user_id']?.toString() ?? '',
      username: json['username']?.toString() ?? 'Anonymous',
      role: json['role']?.toString()?.toLowerCase() ?? 'member',
      joinedAt: DateTime.tryParse(json['joined_at']?.toString() ?? '') ??
          DateTime.now(),
      seasonPoints: json['season_points'] ?? 0,
      correctVotes: json['correct_votes'] ?? 0,
      totalVotes: json['total_votes'] ?? 0,
      msgCount: json['msg_count'] ?? 0,
    );
  }

  Map<String, dynamic> toJson() => {
        'user_id': userId,
        'username': username,
        'role': role,
        'joined_at': joinedAt.toIso8601String(),
        'season_points': seasonPoints,
        'correct_votes': correctVotes,
        'total_votes': totalVotes,
        'msg_count': msgCount,
      };

  bool get isAdmin => role == 'admin';
}
