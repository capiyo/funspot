// In models/post_models.dart
// models/post_models.dart

class Post {
  final String? id;
  final String? userId;
  final String? userName;
  final String? caption;
  final String? imageUrl;
  final String? cloudinaryPublicId;
  final String? imageFormat;
  final String? postType; // NEW: "text", "image", or "text_and_image"
  final int? likesCount;
  final int? commentsCount;
  final int? sharesCount;
  final List<String>? likedBy;
  final bool? isSaved;
  final String? createdAt;
  final String? updatedAt;
  final String? lastModified;
  final int? timestamp; // For cache

  Post({
    this.id,
    this.userId,
    this.userName,
    this.caption,
    this.imageUrl,
    this.cloudinaryPublicId,
    this.imageFormat,
    this.postType, // NEW
    this.likesCount,
    this.commentsCount,
    this.sharesCount,
    this.likedBy,
    this.isSaved,
    this.createdAt,
    this.updatedAt,
    this.lastModified,
    this.timestamp,
  });

  factory Post.fromJson(Map<String, dynamic> json) {
    return Post(
      id: json['id'] as String?,
      userId: json['user_id'] as String?,
      userName: json['user_name'] as String?,
      caption: json['caption'] as String?,
      imageUrl: json['image_url'] as String?,
      cloudinaryPublicId: json['cloudinary_public_id'] as String?,
      imageFormat: json['image_format'] as String?,
      postType: json['post_type'] as String?, // NEW
      likesCount: json['likes_count'] as int?,
      commentsCount: json['comments_count'] as int?,
      sharesCount: json['shares_count'] as int?,
      likedBy: (json['liked_by'] as List<dynamic>?)?.cast<String>(),
      isSaved: json['is_saved'] as bool?,
      createdAt: json['created_at'] as String?,
      updatedAt: json['updated_at'] as String?,
      lastModified: json['last_modified'] as String?,
      timestamp: json['timestamp'] as int?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'user_id': userId,
      'user_name': userName,
      'caption': caption,
      'image_url': imageUrl,
      'cloudinary_public_id': cloudinaryPublicId,
      'image_format': imageFormat,
      'post_type': postType, // NEW
      'likes_count': likesCount,
      'comments_count': commentsCount,
      'shares_count': sharesCount,
      'liked_by': likedBy,
      'is_saved': isSaved,
      'created_at': createdAt,
      'updated_at': updatedAt,
      'last_modified': lastModified,
      'timestamp': timestamp,
    };
  }

  // Helper method to check if post has an image
  bool hasImage() {
    return imageUrl != null &&
        imageUrl!.isNotEmpty &&
        imageUrl != 'null' &&
        imageUrl!.startsWith('http');
  }

  // Helper method to check if post has a caption
  bool hasCaption() {
    return caption != null && caption!.isNotEmpty;
  }

  // Helper method to get display type
  String getDisplayType() {
    if (postType != null) {
      return postType!;
    }

    // Fallback logic if postType is not available
    if (hasImage() && hasCaption()) {
      return 'text_and_image';
    } else if (hasImage()) {
      return 'image';
    } else if (hasCaption()) {
      return 'text';
    } else {
      return 'unknown';
    }
  }

  // Helper getter for formatted date
  String get formattedDate {
    if (createdAt == null) return '';

    try {
      final date = DateTime.parse(createdAt!);
      final now = DateTime.now();
      final difference = now.difference(date);

      if (difference.inSeconds < 60) {
        return '${difference.inSeconds}s ago';
      } else if (difference.inMinutes < 60) {
        return '${difference.inMinutes}m ago';
      } else if (difference.inHours < 24) {
        return '${difference.inHours}h ago';
      } else if (difference.inDays < 30) {
        return '${difference.inDays}d ago';
      } else {
        final months = (difference.inDays / 30).floor();
        return '${months}mo ago';
      }
    } catch (e) {
      return '';
    }
  }

  // Helper getter for like count
  String get formattedLikes {
    if (likesCount == null || likesCount == 0) return '';
    return _formatCount(likesCount!);
  }

  // Helper getter for comment count
  String get formattedComments {
    if (commentsCount == null || commentsCount == 0) return '';
    return _formatCount(commentsCount!);
  }

  // Helper getter for share count
  String get formattedShares {
    if (sharesCount == null || sharesCount == 0) return '';
    return _formatCount(sharesCount!);
  }

  // Internal helper for formatting numbers
  String _formatCount(int count) {
    if (count >= 1000000) {
      return '${(count / 1000000).toStringAsFixed(1)}M';
    } else if (count >= 1000) {
      return '${(count / 1000).toStringAsFixed(1)}K';
    }
    return count.toString();
  }

  // Check if post was liked by a specific user
  bool isLikedBy(String userId) {
    return likedBy?.contains(userId) ?? false;
  }

  // Create a copy with updated fields
  Post copyWith({
    String? id,
    String? userId,
    String? userName,
    String? caption,
    String? imageUrl,
    String? cloudinaryPublicId,
    String? imageFormat,
    String? postType,
    int? likesCount,
    int? commentsCount,
    int? sharesCount,
    List<String>? likedBy,
    bool? isSaved,
    String? createdAt,
    String? updatedAt,
    String? lastModified,
    int? timestamp,
  }) {
    return Post(
      id: id ?? this.id,
      userId: userId ?? this.userId,
      userName: userName ?? this.userName,
      caption: caption ?? this.caption,
      imageUrl: imageUrl ?? this.imageUrl,
      cloudinaryPublicId: cloudinaryPublicId ?? this.cloudinaryPublicId,
      imageFormat: imageFormat ?? this.imageFormat,
      postType: postType ?? this.postType,
      likesCount: likesCount ?? this.likesCount,
      commentsCount: commentsCount ?? this.commentsCount,
      sharesCount: sharesCount ?? this.sharesCount,
      likedBy: likedBy ?? this.likedBy,
      isSaved: isSaved ?? this.isSaved,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      lastModified: lastModified ?? this.lastModified,
      timestamp: timestamp ?? this.timestamp,
    );
  }
}
