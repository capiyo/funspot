import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:developer' as developer;

class AuthService extends ChangeNotifier {
  static final AuthService _instance = AuthService._internal();
  factory AuthService() => _instance;
  AuthService._internal();

  bool _isLoggedIn = false;
  String? _userId;
  String? _username;
  String? _phone;
  String? _authToken;

  bool get isLoggedIn => _isLoggedIn;
  String? get userId => _userId;
  String? get username => _username;
  String? get phone => _phone;
  String? get authToken => _authToken;

  Future<void> initialize() async {
    final prefs = await SharedPreferences.getInstance();
    _authToken = prefs.getString('usertoken');
    final userString = prefs.getString('user');

    if (_authToken != null && userString != null) {
      try {
        final userData = jsonDecode(userString);
        _userId = userData['id'] ?? userData['userId'] ?? userData['_id'];
        _username = userData['username'];
        _phone = userData['phone']?.toString() ?? '';
        _isLoggedIn = true;
      } catch (e) {
        _isLoggedIn = false;
      }
    } else {
      _isLoggedIn = false;
    }
    notifyListeners();
  }

  Future<void> login(
    String userId,
    String username,
    String authToken, {
    String? phone,
  }) async {
    debugPrint('🔐🔐🔐 AUTH SERVICE LOGIN START 🔐🔐🔐');
    debugPrint('🔐 userId: $userId');
    debugPrint('🔐 username: $username');
    debugPrint('🔐 phone received: "$phone"');
    debugPrint('🔐 phone is null: ${phone == null}');
    debugPrint('🔐 phone isEmpty: ${phone?.isEmpty}');

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('usertoken', authToken);
    await prefs.setString(
      'user',
      jsonEncode({'id': userId, 'username': username, 'phone': phone ?? ''}),
    );
    await prefs.setBool('isLoggedIn', true);

    if (phone != null && phone.isNotEmpty) {
      await prefs.setString('phone', phone);
      debugPrint('📞 Phone saved to SharedPreferences: $phone');
    } else {
      debugPrint('⚠️ WARNING: Phone is null or empty! Not saving.');
    }

    _userId = userId;
    _username = username;
    _phone = phone;
    _authToken = authToken;
    _isLoggedIn = true;

    debugPrint('🔐 _phone set to: $_phone');
    debugPrint('🔐🔐🔐 AUTH SERVICE LOGIN END 🔐🔐🔐');

    notifyListeners();
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();

    // Clear ALL auth-related data
    await prefs.remove('usertoken');
    await prefs.remove('user');
    await prefs.remove('isLoggedIn');
    await prefs.remove('userId');
    await prefs.remove('username');
    await prefs.remove('phone'); // Clear phone as well

    // Clear user data cache
    await prefs.remove('userBets');
    await prefs.remove('userProfile');
    await prefs.remove('availableGames');

    // Clear notifications
    await prefs.remove('notifications');
    await prefs.remove('notificationCount');

    // Clear any cached posts or fixtures
    await prefs.remove('cachedPosts');
    await prefs.remove('cachedFixtures');

    // Clear any other app-specific data
    await prefs.remove('lastCarouselFetch');
    await prefs.remove('forceNewUser');

    // Reset all state variables
    _userId = null;
    _username = null;
    _phone = null;
    _authToken = null;
    _isLoggedIn = false;

    // Notify listeners to rebuild UI
    notifyListeners();

    developer.log(
      '✅ All user data cleared from SharedPreferences',
      name: 'AuthService',
    );
  }

  Future<void> updateUserData(String userId, String username) async {
    final prefs = await SharedPreferences.getInstance();
    final userString = prefs.getString('user');
    if (userString != null) {
      try {
        final userData = jsonDecode(userString);
        userData['username'] = username;
        await prefs.setString('user', jsonEncode(userData));
      } catch (e) {}
    }

    _userId = userId;
    _username = username;
    notifyListeners();
  }

  // Helper method to clear all app data (for debugging)
  Future<void> clearAllAppData() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    _userId = null;
    _username = null;
    _phone = null;

    _authToken = null;
    _isLoggedIn = false;
    notifyListeners();
    developer.log('🗑️ ALL app data cleared', name: 'AuthService');
  }
}
