import 'dart:async';
import 'dart:convert';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/io.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

// ============================================================================
// REPLY DATA MODEL
// ============================================================================

class ReplyData {
  final String messageId;
  final String text;
  final String username;
  final String? selection;
  final bool isMe;

  ReplyData({
    required this.messageId,
    required this.text,
    required this.username,
    this.selection,
    required this.isMe,
  });

  Map<String, dynamic> toJson() => {
        'messageId': messageId,
        'text': text,
        'username': username,
        'selection': selection,
        'isMe': isMe,
      };
}

// ============================================================================
// WEB SOCKET SERVICE
// ============================================================================

class WebSocketService {
  static final WebSocketService _instance = WebSocketService._internal();
  factory WebSocketService() => _instance;
  WebSocketService._internal();

  WebSocketChannel? _channel;
  bool _isConnected = false;
  bool _isConnecting = false;
  String? _currentUserId;
  String? _currentAuthToken;
  String? _currentChannelId;
  String? _currentFixtureId;
  String? _currentUsername;

  Timer? _reconnectTimer;
  int _reconnectAttempts = 0;
  static const int _maxReconnectAttempts = 10;
  static const Duration _initialReconnectDelay = Duration(seconds: 2);
  static const Duration _connectionTimeout = Duration(seconds: 10);

  final List<Map<String, dynamic>> _messageQueue = [];
  final Map<String, List<void Function(Map<String, dynamic>)>> _listeners = {};

  Timer? _heartbeatTimer;
  static const Duration _heartbeatInterval = Duration(seconds: 30);
  static const Duration _heartbeatTimeout = Duration(seconds: 35);

  Timer? _connectionTimeoutTimer;
  Timer? _heartbeatTimeoutTimer;

  final StreamController<bool> _connectionStatusController =
      StreamController<bool>.broadcast();
  Stream<bool> get connectionStatus => _connectionStatusController.stream;

  // ==========================================================================
  // CONNECTION
  // ==========================================================================

  String? get currentRoomId {
    if (_currentChannelId == null) return null;
    return (_currentFixtureId != null && _currentFixtureId!.isNotEmpty)
        ? '${_currentChannelId}_${_currentFixtureId}'
        : '${_currentChannelId}_overall';
  }

  String? _currentRoomId;

  /// Switches the persistent connection to a different room without
  /// reconnecting the underlying socket. Falls back to a full connect()
  /// if there's no live socket yet.
  Future<void> joinRoom(String channelId, {String? fixtureId}) async {
    final targetRoomId = (fixtureId != null && fixtureId.isNotEmpty)
        ? '${channelId}_$fixtureId'
        : '${channelId}_overall';

    if (_currentRoomId == targetRoomId) return;

    if (!_isConnected) {
      await connect(
        _currentUserId ?? '',
        _currentAuthToken ?? '',
        channelId,
        _currentUsername ?? '',
        fixtureId: fixtureId,
      );
      return;
    }

    _currentChannelId = channelId;
    _currentFixtureId = fixtureId;
    _currentRoomId = targetRoomId;

    send('room.join', {
      'channel_id': channelId,
      'fixture_id': fixtureId,
    });

    debugPrint('🔀 Requested room switch to $targetRoomId');
  }

  Future<void> connect(
    String userId,
    String authToken,
    String channelId,
    String username, {
    String? fixtureId,
  }) async {
    final targetRoomId = (fixtureId != null && fixtureId.isNotEmpty)
        ? '${channelId}_$fixtureId'
        : '${channelId}_overall';

    if (_isConnected) {
      await joinRoom(channelId, fixtureId: fixtureId);
      return;
    }

    if (_isConnecting) return;

    _currentUserId = userId;
    _currentAuthToken = authToken;
    _currentChannelId = channelId;
    _currentFixtureId = fixtureId;
    _currentUsername = username;
    _currentRoomId = targetRoomId;
    _isConnecting = true;

    final wsUrl = 'wss://clash-api-m5mr.onrender.com/ws/channel'
        '?user_id=$userId'
        '&username=$username'
        '&channel_id=$channelId'
        '&fixture_id=${fixtureId ?? ''}';

    _connectionTimeoutTimer?.cancel();
    _connectionTimeoutTimer = Timer(_connectionTimeout, () {
      if (_isConnecting && !_isConnected) {
        debugPrint(
            '⏱️ WS connection timed out after ${_connectionTimeout.inSeconds}s — retrying');
        _handleConnectionFailure('Connection timed out');
      }
    });

    try {
      _channel = IOWebSocketChannel.connect(Uri.parse(wsUrl));

      _channel!.stream.listen(
        _handleMessage,
        onError: _handleError,
        onDone: _handleDisconnect,
      );
    } catch (e) {
      _handleConnectionFailure('Connection error: $e');
    }
  }

  void _handleConnectionFailure(String reason) {
    debugPrint('❌ WS connection failure: $reason');

    _connectionTimeoutTimer?.cancel();
    _connectionTimeoutTimer = null;
    _heartbeatTimer?.cancel();
    _heartbeatTimeoutTimer?.cancel();

    _isConnecting = false;
    _isConnected = false;
    _currentRoomId = null;

    _channel?.sink.close();
    _channel = null;

    _connectionStatusController.add(false);
    _scheduleReconnect();
  }

  void _handleConnectionSuccess() {
    _connectionTimeoutTimer?.cancel();
    _connectionTimeoutTimer = null;

    if (_isConnecting || !_isConnected) {
      _isConnected = true;
      _isConnecting = false;
      _reconnectAttempts = 0;
      _connectionStatusController.add(true);

      _flushMessageQueue();
      _startHeartbeat();
    }
  }

  void disconnect() {
    _connectionTimeoutTimer?.cancel();
    _heartbeatTimer?.cancel();
    _heartbeatTimeoutTimer?.cancel();
    _reconnectTimer?.cancel();

    _channel?.sink.close();
    _channel = null;
    _isConnected = false;
    _isConnecting = false;
    _currentRoomId = null;
    _connectionStatusController.add(false);
  }

  void _handleDisconnect() {
    _heartbeatTimer?.cancel();
    _heartbeatTimeoutTimer?.cancel();
    _connectionTimeoutTimer?.cancel();

    if (_isConnecting) {
      // Socket closed before the server's "connected" ack ever arrived —
      // this used to be silently swallowed because _isConnected was still
      // false, leaving the client permanently stuck "connecting" forever.
      _handleConnectionFailure('Socket closed during handshake');
      return;
    }

    if (_isConnected) {
      _isConnected = false;
      _currentRoomId = null;
      _connectionStatusController.add(false);
      _scheduleReconnect();
    }
  }

  void _handleError(Object error) {
    debugPrint('⚠️ WS stream error: $error');
    if (_isConnecting) {
      _handleConnectionFailure('Stream error during handshake: $error');
    } else if (_isConnected) {
      _handleDisconnect();
    }
  }

  void _scheduleReconnect() {
    // Keep retrying indefinitely with a capped backoff instead of giving up
    // after N attempts — during a live match, giving up permanently just
    // because the network blipped 10 times is worse than a slow retry loop.
    final delay = _reconnectAttempts < _maxReconnectAttempts
        ? _initialReconnectDelay * (_reconnectAttempts + 1)
        : const Duration(seconds: 30);

    _reconnectAttempts++;

    _reconnectTimer?.cancel();
    _reconnectTimer = Timer(delay, () {
      if (_currentUserId != null &&
          _currentAuthToken != null &&
          _currentChannelId != null &&
          _currentUsername != null) {
        connect(
          _currentUserId!,
          _currentAuthToken!,
          _currentChannelId!,
          _currentUsername!,
          fixtureId: _currentFixtureId,
        );
      }
    });
  }
  // ==========================================================================
  // HEARTBEAT
  // ==========================================================================

  void _startHeartbeat() {
    _heartbeatTimer?.cancel();
    _heartbeatTimer = Timer.periodic(_heartbeatInterval, (_) {
      if (_isConnected) {
        send('ping', {});

        _heartbeatTimeoutTimer?.cancel();
        _heartbeatTimeoutTimer = Timer(_heartbeatTimeout, () {
          if (_isConnected) {
            _handleDisconnect();
          }
        });
      }
    });
  }

  void _cancelHeartbeatTimeout() {
    _heartbeatTimeoutTimer?.cancel();
    _heartbeatTimeoutTimer = null;
  }

  // ==========================================================================
  // MESSAGE HANDLING
  // ==========================================================================

  void _handleMessage(dynamic message) {
    try {
      final data = json.decode(message as String);
      final eventType = data['type'] as String? ?? 'unknown';
      final payload = data['payload'] as Map<String, dynamic>? ?? {};

      if (eventType == 'connected') {
        _cancelHeartbeatTimeout();
        _handleConnectionSuccess();
        return;
      }

      if (eventType == 'pong') {
        _cancelHeartbeatTimeout();
        return;
      }

      if (_listeners.containsKey(eventType)) {
        for (var listener in _listeners[eventType]!) {
          listener(payload);
        }
      }

      if (_listeners.containsKey('*')) {
        for (var listener in _listeners['*']!) {
          listener({'type': eventType, ...payload});
        }
      }
    } catch (e) {}
  }

  // ==========================================================================
  // SEND MESSAGE
  // ==========================================================================

  void send(String type, Map<String, dynamic> payload) {
    final message = json.encode({
      'type': type,
      'payload': payload,
      'timestamp': DateTime.now().toIso8601String(),
    });

    if (_isConnected && _channel != null) {
      try {
        _channel!.sink.add(message);
      } catch (e) {
        _handleDisconnect();
      }
    } else {
      _messageQueue.add({'type': type, 'payload': payload});
    }
  }

  void _flushMessageQueue() {
    if (!_isConnected) return;

    final queued = List<Map<String, dynamic>>.from(_messageQueue);
    _messageQueue.clear();

    for (var message in queued) {
      send(message['type'], message['payload']);
    }
  }

  // ==========================================================================
  // EVENT SUBSCRIPTION
  // ==========================================================================

  void on(String eventType, void Function(Map<String, dynamic>) callback) {
    _listeners.putIfAbsent(eventType, () => []).add(callback);
  }

  void off(String eventType, void Function(Map<String, dynamic>) callback) {
    _listeners[eventType]?.remove(callback);
  }

  void offAll(String eventType) {
    _listeners.remove(eventType);
  }

  void clearAllListeners() {
    _listeners.clear();
  }

  // ==========================================================================
  // CHAT METHODS - FULLY UPDATED
  // ==========================================================================

  void sendChatMessage({
    required String message,
    required String selection,
    required String username,
    String? messageId,
    Map<String, dynamic>? replyTo,
    String? imageUrl,
    String? videoUrl,
    bool isImage = false,
    bool isVideo = false,
    String? channelId,
    String? fixtureId,
  }) {
    // Validate user is logged in
    if (_currentUserId == null || _currentUserId!.isEmpty) {
      print('❌ Cannot send message: userId is null or empty');
      return;
    }

    // Generate message ID if not provided
    final id = messageId ??
        '${DateTime.now().millisecondsSinceEpoch}_${_currentUserId}_${DateTime.now().microsecondsSinceEpoch}';

    // Use provided channelId or fallback to current
    final finalChannelId = channelId ?? _currentChannelId;

    // Use provided fixtureId or fallback to current
    final finalFixtureId = fixtureId ?? _currentFixtureId;

    // Validate channelId
    if (finalChannelId == null || finalChannelId.isEmpty) {
      print('❌ Cannot send message: channelId is null or empty');
      return;
    }

    // Build payload WITHOUT fixtureId for general chat
    final payload = <String, dynamic>{
      'message': message,
      'messageId': id,
      'selection': selection,
      'username': username,
      'channelId': finalChannelId,
      'userId': _currentUserId!,
    };

    // ✅ Only add optional fields if they exist
    if (replyTo != null && replyTo.isNotEmpty) {
      payload['replyTo'] = replyTo;
    }

    if (imageUrl != null && imageUrl.isNotEmpty) {
      payload['imageUrl'] = imageUrl;
    }

    if (videoUrl != null && videoUrl.isNotEmpty) {
      payload['videoUrl'] = videoUrl;
    }

    if (isImage) {
      payload['isImage'] = true;
    }

    if (isVideo) {
      payload['isVideo'] = true;
    }

    // ✅ CRITICAL FIX: Only add fixtureId if it's not null and not empty
    // For general chat, fixtureId is omitted entirely
    if (finalFixtureId != null && finalFixtureId.isNotEmpty) {
      payload['fixtureId'] = finalFixtureId;
    }
    // ✅ For general chat, fixtureId field is NOT included in the payload

    print(
        '📤 Sending message - Channel: $finalChannelId, Fixture: $finalFixtureId, User: $_currentUserId');
    print('📤 Payload: $payload');

    send('chat.message', payload);
  }

  void sendTyping({
    required String channelId,
    String? fixtureId,
    required bool isTyping,
    required String username,
  }) {
    if (_currentUserId == null || _currentUserId!.isEmpty) {
      return;
    }

    final payload = <String, dynamic>{
      'isTyping': isTyping,
      'username': username,
      'channelId': channelId,
      'userId': _currentUserId!,
    };

    // ✅ Only add fixtureId if it's not null and not empty
    if (fixtureId != null && fixtureId.isNotEmpty) {
      payload['fixtureId'] = fixtureId;
    }
    // ✅ For general chat, fixtureId is omitted

    send('typing', payload);
  }

  void sendPing() {
    send('ping', {});
  }

  // ==========================================================================
  // GETTERS
  // ==========================================================================

  bool get isConnected => _isConnected;
  String? get currentUserId => _currentUserId;
  String? get currentChannelId => _currentChannelId;
  String? get currentFixtureId => _currentFixtureId;

  // ==========================================================================
  // DISPOSE
  // ==========================================================================

  void dispose() {
    _connectionTimeoutTimer?.cancel();
    _heartbeatTimer?.cancel();
    _heartbeatTimeoutTimer?.cancel();
    _reconnectTimer?.cancel();
    disconnect();
    _connectionStatusController.close();
    _listeners.clear();
  }
}
