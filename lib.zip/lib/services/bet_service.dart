import 'dart:convert';
import 'package:http/http.dart' as http;

class BetService {
  static const String API_BASE_URL = 'https://clash-api-m5mr.onrender.com/api';
  static const Duration REQUEST_TIMEOUT = Duration(seconds: 15);

  // ============================================================
  // ✅ NEW: Create Bet with Vote ID (Pledge + Vote)
  // ============================================================
  static Future<Map<String, dynamic>> createBetWithVoteId({
    required String fixtureId,
    required String starterId,
    required String starterName,
    required String starterSelection,
    required double amount,
    required String channelId,
    required String voteId, // ← NEW: Required
    String? authToken,
  }) async {
    try {
      final headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      };
      if (authToken != null && authToken.isNotEmpty) {
        headers['Authorization'] = 'Bearer $authToken';
      }

      final response = await http
          .post(
            Uri.parse('$API_BASE_URL/actions/bet/create'),
            headers: headers,
            body: json.encode({
              'fixture_id': fixtureId,
              'starter_id': starterId,
              'starter_name': starterName,
              'starter_selection': starterSelection,
              'amount': amount,
              'channel_id': channelId,
              'vote_id': voteId, // ← NEW: Pass vote_id
            }),
          )
          .timeout(REQUEST_TIMEOUT);

      if (response.statusCode == 200 || response.statusCode == 201) {
        return json.decode(response.body);
      }
      return {
        'success': false,
        'message': 'Server error: ${response.statusCode}'
      };
    } catch (e) {
      return {'success': false, 'message': 'Network error: ${e.toString()}'};
    }
  }

  // ============================================================
  // ✅ KEEP: Original createBet (for backward compatibility)
  // ============================================================
  @Deprecated('Use createBetWithVoteId instead')
  static Future<Map<String, dynamic>> createBet({
    required String fixtureId,
    required String starterId,
    required String starterName,
    required String starterSelection,
    required double amount,
    required String channelId,
    String? authToken,
  }) async {
    // This is now deprecated - use createBetWithVoteId
    // But keep for backward compatibility
    try {
      final headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      };
      if (authToken != null && authToken.isNotEmpty) {
        headers['Authorization'] = 'Bearer $authToken';
      }

      final response = await http
          .post(
            Uri.parse('$API_BASE_URL/actions/bet/create'),
            headers: headers,
            body: json.encode({
              'fixture_id': fixtureId,
              'starter_id': starterId,
              'starter_name': starterName,
              'starter_selection': starterSelection,
              'amount': amount,
              'channel_id': channelId,
            }),
          )
          .timeout(REQUEST_TIMEOUT);

      if (response.statusCode == 200 || response.statusCode == 201) {
        return json.decode(response.body);
      }
      return {
        'success': false,
        'message': 'Server error: ${response.statusCode}'
      };
    } catch (e) {
      return {'success': false, 'message': 'Network error: ${e.toString()}'};
    }
  }

  // ============================================================
  // GET OPEN BETS (Channel-Specific)
  // ============================================================
  static Future<List<Bet>> getOpenBets({
    required String channelId,
    required String fixtureId,
    String? authToken,
  }) async {
    try {
      final headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      };
      if (authToken != null && authToken.isNotEmpty) {
        headers['Authorization'] = 'Bearer $authToken';
      }

      final response = await http
          .get(
            Uri.parse('$API_BASE_URL/actions/bet/open/$channelId/$fixtureId'),
            headers: headers,
          )
          .timeout(REQUEST_TIMEOUT);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final List<dynamic> betsData = data['open_bets'] ?? [];
        return betsData.map((json) => Bet.fromJson(json)).toList();
      }
      return [];
    } catch (e) {
      //debugPrint('❌ Error getting open bets: $e');
      return [];
    }
  }

  // ============================================================
  // GET CHANNEL BETTORS (Matched + Settled)
  // ============================================================
  static Future<List<Bet>> getChannelBettors({
    required String channelId,
    required String fixtureId,
    String? authToken,
  }) async {
    try {
      final headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      };
      if (authToken != null && authToken.isNotEmpty) {
        headers['Authorization'] = 'Bearer $authToken';
      }

      final response = await http
          .get(
            Uri.parse(
                '$API_BASE_URL/actions/bet/channel/$channelId/$fixtureId'),
            headers: headers,
          )
          .timeout(REQUEST_TIMEOUT);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final List<dynamic> betsData = data['bettors'] ?? [];
        return betsData.map((json) => Bet.fromJson(json)).toList();
      }
      return [];
    } catch (e) {
      // debugPrint('❌ Error getting bettors: $e');
      return [];
    }
  }

  // ============================================================
  // FILL BET (Finisher accepts)
  // ============================================================
  static Future<Map<String, dynamic>> fillBet({
    required String betId,
    required String finisherId,
    required String finisherName,
    required String finisherSelection,
    required double amount,
    required String channelId,
    String? authToken,
  }) async {
    try {
      final headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      };
      if (authToken != null && authToken.isNotEmpty) {
        headers['Authorization'] = 'Bearer $authToken';
      }

      final response = await http
          .post(
            Uri.parse('$API_BASE_URL/actions/bet/fill'),
            headers: headers,
            body: json.encode({
              'bet_id': betId,
              'finisher_id': finisherId,
              'finisher_name': finisherName,
              'finisher_selection': finisherSelection,
              'amount': amount,
              'channel_id': channelId,
            }),
          )
          .timeout(REQUEST_TIMEOUT);

      if (response.statusCode == 200 || response.statusCode == 201) {
        return json.decode(response.body);
      }
      return {
        'success': false,
        'message': 'Server error: ${response.statusCode}'
      };
    } catch (e) {
      return {'success': false, 'message': 'Network error: ${e.toString()}'};
    }
  }
}

// ============================================================
// BET MODEL
// ============================================================
class Bet {
  final String? id;
  final String fixtureId;
  final String starterId;
  final String starterName;
  final String starterSelection;
  final double starterAmount;
  final String? finisherId;
  final String? finisherName;
  final String? finisherSelection;
  final double? finisherAmount;
  final String? voteId; // ← NEW
  final String channelId;
  final String status; // "open", "matched", "settled"
  final String? winnerId;
  final String? starterResult;
  final String? finisherResult;
  final DateTime createdAt;
  final DateTime? matchedAt;
  final DateTime? settledAt;

  Bet({
    this.id,
    required this.fixtureId,
    required this.starterId,
    required this.starterName,
    required this.starterSelection,
    required this.starterAmount,
    this.finisherId,
    this.finisherName,
    this.finisherSelection,
    this.finisherAmount,
    this.voteId, // ← NEW
    required this.channelId,
    required this.status,
    this.winnerId,
    this.starterResult,
    this.finisherResult,
    required this.createdAt,
    this.matchedAt,
    this.settledAt,
  });

  factory Bet.fromJson(Map<String, dynamic> json) {
    return Bet(
      id: json['_id']?.toString() ?? json['id']?.toString(),
      fixtureId: json['fixture_id'] ?? '',
      starterId: json['starter_id'] ?? '',
      starterName: json['starter_name'] ?? '',
      starterSelection: json['starter_selection'] ?? '',
      starterAmount: (json['starter_amount'] ?? 0.0).toDouble(),
      finisherId: json['finisher_id']?.toString(),
      finisherName: json['finisher_name']?.toString(),
      finisherSelection: json['finisher_selection']?.toString(),
      finisherAmount: json['finisher_amount']?.toDouble(),
      voteId: json['vote_id']?.toString(), // ← NEW
      channelId: json['channel_id'] ?? '',
      status: json['status'] ?? 'open',
      winnerId: json['winner_id']?.toString(),
      starterResult: json['starter_result']?.toString(),
      finisherResult: json['finisher_result']?.toString(),
      createdAt: DateTime.parse(
          json['created_at'] ?? DateTime.now().toIso8601String()),
      matchedAt: json['matched_at'] != null
          ? DateTime.parse(json['matched_at'])
          : null,
      settledAt: json['settled_at'] != null
          ? DateTime.parse(json['settled_at'])
          : null,
    );
  }

  bool get isOpen => status == 'open';
  bool get isMatched => status == 'matched';
  bool get isSettled => status == 'settled';

  double get totalPot => starterAmount + (finisherAmount ?? 0.0);
}
