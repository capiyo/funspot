import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../../models/fixture_models.dart';
import '../../services/notification_service.dart';
import "../../pages/fan_clash_design.dart";
import '../../utils/add_helper.dart';
import 'package:intl/intl.dart';
import '../../main.dart';

// ============================================================================
// LOCAL STORAGE KEYS
// ============================================================================
class StorageKeys {
  static const String votersPrefix = 'cached_voters_';
  static const String timestampPrefix = 'voters_timestamp_';
  static const String comradesCacheKey = 'comrades_cache_';
  static const String comradesTimestampKey = 'comrades_timestamp_';
  static const Duration cacheDuration = Duration(minutes: 5);
}

// ============================================================================
// CAROUSEL ITEM TYPE
// ============================================================================
enum CarouselItemType { comrade, ad }

class CarouselItem {
  final CarouselItemType type;
  final ComradeWithStats? comrade;
  final String? adUnitId;

  CarouselItem.comrade({required this.comrade})
      : type = CarouselItemType.comrade,
        adUnitId = null;

  CarouselItem.ad({required this.adUnitId})
      : type = CarouselItemType.ad,
        comrade = null;
}

// ============================================================================
// VOTER MODEL
// ============================================================================
class Voter {
  final String userId;
  final String username;
  final String selection;
  final bool isComrade;
  final DateTime votedAt;

  Voter({
    required this.userId,
    required this.username,
    required this.selection,
    this.isComrade = false,
    required this.votedAt,
  });

  factory Voter.fromJson(Map<String, dynamic> json) {
    return Voter(
      userId: json['userId']?.toString() ?? '',
      username: json['userName']?.toString() ?? 'Anonymous',
      selection: json['selection']?.toString() ?? '',
      isComrade: json['isComrade'] ?? false,
      votedAt: json['votedAt'] != null
          ? DateTime.tryParse(json['votedAt'].toString()) ?? DateTime.now()
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'userId': userId,
      'userName': username,
      'selection': selection,
      'isComrade': isComrade,
      'votedAt': votedAt.toIso8601String(),
    };
  }
}

// ============================================================================
// VOTE STATS
// ============================================================================
class VoteStats {
  final int homeCount;
  final int awayCount;
  final int drawCount;
  final int total;

  VoteStats({
    required this.homeCount,
    required this.awayCount,
    required this.drawCount,
  }) : total = homeCount + awayCount + drawCount;

  double get homePercentage => total > 0 ? (homeCount / total) * 100 : 0;
  double get awayPercentage => total > 0 ? (awayCount / total) * 100 : 0;
  double get drawPercentage => total > 0 ? (drawCount / total) * 100 : 0;
}

// ============================================================================
// COMRADE MODEL WITH STATS
// ============================================================================
class ComradeWithStats {
  final String id;
  final String username;
  final String nickname;
  final String clubFan;
  final String countryFan;
  final bool isComrade;
  final DateTime? joinedDate;
  final int totalPoints;
  final double accuracyPercentage;
  final int correctVotes;
  final int totalVotes;
  final int currentStreak;
  final int bestStreak;
  final bool isOnline;
  final int rank;
  final String? avatarUrl;
  final int messageCount; // NEW: from channel leaderboard

  ComradeWithStats({
    required this.id,
    required this.username,
    required this.nickname,
    required this.clubFan,
    required this.countryFan,
    this.isComrade = true,
    this.joinedDate,
    required this.totalPoints,
    required this.accuracyPercentage,
    required this.correctVotes,
    required this.totalVotes,
    required this.currentStreak,
    required this.bestStreak,
    this.isOnline = false,
    required this.rank,
    this.avatarUrl,
    this.messageCount = 0,
  });

  // ✅ NEW: Factory for channel leaderboard data
  factory ComradeWithStats.fromChannelMember(
      Map<String, dynamic> json, Set<String> comradesList) {
    final userId = json['user_id']?.toString() ?? '';
    final totalVotes = (json['total_votes'] as int?) ?? 0;
    final correctVotes = (json['correct_votes'] as int?) ?? 0;
    final accuracy = (json['accuracy'] as num?)?.toDouble() ?? 0.0;
    final totalPoints = (json['season_points'] as int?) ?? 0;
    final rank = (json['rank'] as int?) ?? 0;

    return ComradeWithStats(
      id: userId,
      username: json['username']?.toString() ?? 'Anonymous',
      nickname: json['username']?.toString() ??
          'Anonymous', // Channel members use username
      clubFan: '', // Not available in channel leaderboard
      countryFan: '', // Not available in channel leaderboard
      isComrade: comradesList.contains(userId),
      joinedDate: null,
      totalPoints: totalPoints,
      accuracyPercentage: accuracy,
      correctVotes: correctVotes,
      totalVotes: totalVotes,
      currentStreak: 0, // Not available
      bestStreak: 0, // Not available
      isOnline: false,
      rank: rank,
      messageCount: (json['message_count'] as int?) ?? 0,
    );
  }
}

// ============================================================================
// AD MANAGER (simplified for carousel)
// ============================================================================
class CarouselAdManager {
  static final CarouselAdManager _instance = CarouselAdManager._internal();
  factory CarouselAdManager() => _instance;
  CarouselAdManager._internal();

  final Map<String, bool> _preloadedAds = {};

  void preloadAd(String adUnitId) {
    if (_preloadedAds.containsKey(adUnitId)) return;
    _preloadedAds[adUnitId] = true;
    // In production, you'd actually load the native ad here
  }

  bool isAdReady(String adUnitId) => _preloadedAds.containsKey(adUnitId);

  String getAdUnitId(int index) {
    final ids = AdHelper.carouselAdUnitIds;
    return ids.isEmpty ? '' : ids[index % ids.length];
  }
}

// ============================================================================
// MAIN COMBINED MODAL - LEADERBOARD + VOTERS (2 TABS) WITH CAROUSEL
// ============================================================================
class ComradeModal extends StatefulWidget {
  final bool isOpen;
  final VoidCallback onClose;
  final String? currentUserId;
  final String? currentUserName;
  final String? authToken;
  final String? channelId;
  final String? channelName;
  final Fixture? fixture;
  final Set<String> comradesList;
  final Map<String, Map<String, String>> comradesVoteMap;
  final bool hasUserVoted;
  final String? userVoteSelection;

  const ComradeModal({
    super.key,
    required this.isOpen,
    required this.onClose,
    this.currentUserId,
    this.currentUserName,
    this.authToken,
    this.channelId,
    this.channelName,
    this.fixture,
    this.comradesList = const {},
    this.comradesVoteMap = const {},
    this.hasUserVoted = false,
    this.userVoteSelection,
  });

  @override
  State<ComradeModal> createState() => _ComradeModalState();
}

class _ComradeModalState extends State<ComradeModal>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  // Voters data
  List<Voter> _voters = [];
  List<Voter> _filteredVoters = [];
  bool _isLoadingVoters = true;
  String _selectedFilter = 'all';
  final ScrollController _voterScroll = ScrollController();

  // Leaderboard data
  List<ComradeWithStats> _comrades = [];
  List<ComradeWithStats> _displayComrades = [];
  bool _isLoadingLeaderboard = true;
  bool _hasLoadedCache = false;

  // Carousel
  List<CarouselItem> _carouselItems = [];
  PageController? _carouselController;
  int _currentCarouselIndex = 0;
  Timer? _carouselTimer;
  bool _isCarouselRunning = false;
  final CarouselAdManager _adManager = CarouselAdManager();

  // Shared
  late SharedPreferences _prefs;
  StreamSubscription<Map<String, dynamic>>? _badgeSubscription;

  static const String _api = 'https://clash-api-m5mr.onrender.com/api';
  static const Duration _timeout = Duration(seconds: 15);

  // ==========================================================================
  // INIT
  // ==========================================================================
  @override
  void initState() {
    super.initState();
    _initPrefs();
    _tabController = TabController(length: _getTabCount(), vsync: this);
    _carouselController = PageController();
    _listenToFCMUpdates();
    if (widget.isOpen) {
      _loadVotersData();
      _loadLeaderboardData();
    }
  }

  int _getTabCount() {
    return widget.fixture != null ? 2 : 1;
  }

  @override
  void didUpdateWidget(covariant ComradeModal old) {
    super.didUpdateWidget(old);
    if (widget.isOpen && !old.isOpen) {
      _loadVotersData();
      _loadLeaderboardData();
    }
    if (widget.fixture != old.fixture && widget.isOpen) {
      _loadVotersData();
    }
    if (widget.comradesList != old.comradesList && widget.isOpen) {
      _loadLeaderboardData();
      _loadVotersData();
    }
    if (_getTabCount() != _tabController.length) {
      _tabController.dispose();
      _tabController = TabController(length: _getTabCount(), vsync: this);
    }
  }

  @override
  void dispose() {
    _stopCarouselAutoScroll();
    _badgeSubscription?.cancel();
    _carouselTimer?.cancel();
    _carouselController?.dispose();
    _voterScroll.dispose();
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _initPrefs() async {
    _prefs = await SharedPreferences.getInstance();
  }

  void _listenToFCMUpdates() {
    _badgeSubscription = NotificationService.badgeStream.listen((event) {
      if (!widget.isOpen || !mounted) return;
      final eventFixtureId = event['fixture_id'] as String?;
      final isForThisFixture =
          widget.fixture != null && eventFixtureId == widget.fixture!.matchId;
      final notificationType = event['notification_type'] as String?;
      final isVoteOrComment = notificationType == 'vote_supporter' ||
          notificationType == 'vote_rival' ||
          notificationType == 'fixture_comment';
      if (isForThisFixture && isVoteOrComment && mounted) {
        _refreshVotersData();
      }
    });
  }

  // ==========================================================================
  // CAROUSEL METHODS
  // ==========================================================================
  void _buildCarousel() {
    if (_comrades.isEmpty) return;

    final items = <CarouselItem>[];
    int adSlotIndex = 0;

    for (int i = 0; i < _comrades.length; i++) {
      items.add(CarouselItem.comrade(comrade: _comrades[i]));

      // Insert ad every 3 items
      if ((i + 1) % 3 == 0 && i < _comrades.length - 1) {
        final adUnitId = _adManager.getAdUnitId(adSlotIndex++);
        if (adUnitId.isNotEmpty) {
          _adManager.preloadAd(adUnitId);
          items.add(CarouselItem.ad(adUnitId: adUnitId));
        }
      }
    }

    setState(() {
      _carouselItems = items;
    });

    if (items.length > 1 && !_isCarouselRunning) {
      _startCarouselAutoScroll();
    }
  }

  void _startCarouselAutoScroll() {
    if (_isCarouselRunning || _carouselItems.length <= 1) return;
    _isCarouselRunning = true;
    _carouselTimer?.cancel();

    _carouselTimer = Timer.periodic(const Duration(seconds: 6), (timer) {
      if (!mounted || !_isCarouselRunning) {
        timer.cancel();
        _isCarouselRunning = false;
        return;
      }

      final controller = _carouselController;
      if (controller == null || !controller.hasClients) {
        timer.cancel();
        _isCarouselRunning = false;
        return;
      }

      final nextIndex = (_currentCarouselIndex + 1) % _carouselItems.length;
      controller.animateToPage(
        nextIndex,
        duration: const Duration(milliseconds: 400),
        curve: Curves.easeInOutCubic,
      );
    });
  }

  void _stopCarouselAutoScroll() {
    _isCarouselRunning = false;
    _carouselTimer?.cancel();
    _carouselTimer = null;
  }

  Widget _buildCarouselWidget() {
    if (_carouselItems.isEmpty) return const SizedBox.shrink();

    return Container(
      height: 80,
      margin: const EdgeInsets.only(top: 8, bottom: 8),
      child: PageView.builder(
        controller: _carouselController,
        onPageChanged: (index) {
          setState(() => _currentCarouselIndex = index);
        },
        itemCount: _carouselItems.length,
        itemBuilder: (context, index) => Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: _buildCarouselItem(_carouselItems[index]),
        ),
      ),
    );
  }

  Widget _buildCarouselItem(CarouselItem item) {
    if (item.type == CarouselItemType.comrade && item.comrade != null) {
      return _buildComradeCarouselCard(item.comrade!);
    } else if (item.type == CarouselItemType.ad) {
      return _buildAdCarouselCard(item.adUnitId ?? '');
    }
    return const SizedBox.shrink();
  }

  Widget _buildComradeCarouselCard(ComradeWithStats comrade) {
    final isCurrentUser = comrade.id == widget.currentUserId;
    final isComrade = widget.comradesList.contains(comrade.id);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: FanColors.surfaceElevated,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: FanColors.border.withValues(alpha: 0.3)),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  FanColors.primary.withValues(alpha: 0.2),
                  Colors.transparent,
                ],
              ),
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                comrade.nickname[0].toUpperCase(),
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: FanColors.primary,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      comrade.nickname,
                      style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: FanColors.textPrimary,
                      ),
                    ),
                    if (isCurrentUser) ...[
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: FanColors.primary.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Text(
                          'YOU',
                          style: TextStyle(
                              fontSize: 8,
                              fontWeight: FontWeight.bold,
                              color: FanColors.primary),
                        ),
                      ),
                    ] else if (isComrade) ...[
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: FanColors.secondary.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Text(
                          'COMRADE',
                          style: TextStyle(
                              fontSize: 8,
                              fontWeight: FontWeight.bold,
                              color: FanColors.secondary),
                        ),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 2),
                Row(
                  children: [
                    Icon(Icons.sports_soccer,
                        size: 10, color: FanColors.textSecondary),
                    const SizedBox(width: 4),
                    Text(
                      comrade.clubFan,
                      style: const TextStyle(
                          fontSize: 9, color: FanColors.textSecondary),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '${comrade.totalPoints} pts',
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: FanColors.primary,
                ),
              ),
              if (comrade.currentStreak > 0)
                Row(
                  children: [
                    const Icon(Icons.local_fire_department,
                        size: 10, color: Colors.orange),
                    const SizedBox(width: 2),
                    Text(
                      '${comrade.currentStreak}',
                      style: const TextStyle(fontSize: 9, color: Colors.orange),
                    ),
                  ],
                ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildAdCarouselCard(String adUnitId) {
    // Simplified ad card - in production you'd use actual native ad
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: FanColors.surfaceElevated,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: FanColors.border.withValues(alpha: 0.3)),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: FanColors.primary.withValues(alpha: 0.1),
              shape: BoxShape.circle,
            ),
            child: const Center(
              child: Text('⚡', style: TextStyle(fontSize: 20)),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Clash+',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: FanColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  'Remove ads • Unlock rewards',
                  style: TextStyle(fontSize: 9, color: FanColors.textSecondary),
                ),
              ],
            ),
          ),
          Container(
            width: 32,
            height: 32,
            decoration: const BoxDecoration(
              color: FanColors.primary,
              shape: BoxShape.circle,
            ),
            child: const Center(
              child: Icon(Icons.arrow_forward_rounded,
                  size: 14, color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  // ==========================================================================
  // VOTERS SECTION
  // ==========================================================================
  Future<void> _loadVotersData() async {
    if (widget.fixture == null) return;

    final cachedVoters = await _loadVotersFromCache();
    if (cachedVoters != null && cachedVoters.isNotEmpty) {
      setState(() {
        _voters = cachedVoters;
        _applyVoterFilter();
        _isLoadingVoters = false;
      });
    } else {
      setState(() => _isLoadingVoters = true);
    }
    await _fetchVotersFromServer();
  }

  Future<List<Voter>?> _loadVotersFromCache() async {
    if (widget.fixture == null) return null;
    try {
      final fixtureId = widget.fixture!.matchId;
      final cachedVotersJson =
          _prefs.getString('${StorageKeys.votersPrefix}$fixtureId');
      final cachedTimestamp =
          _prefs.getInt('${StorageKeys.timestampPrefix}$fixtureId');

      if (cachedVotersJson == null) return null;
      if (cachedTimestamp != null) {
        final cacheAge =
            DateTime.now().millisecondsSinceEpoch - cachedTimestamp;
        if (cacheAge > StorageKeys.cacheDuration.inMilliseconds) return null;
      }

      final List<dynamic> decoded = json.decode(cachedVotersJson);
      final voters = decoded
          .map((item) => Voter.fromJson(item as Map<String, dynamic>))
          .toList();
      final filteredVoters = voters
          .where((v) =>
              widget.comradesList.contains(v.userId) ||
              v.userId == widget.currentUserId)
          .toList();

      return filteredVoters;
    } catch (e) {
      return null;
    }
  }

  Future<void> _saveVotersToCache(List<Voter> voters) async {
    if (widget.fixture == null) return;
    try {
      final fixtureId = widget.fixture!.matchId;
      final votersJson = voters.map((v) => v.toJson()).toList();
      await _prefs.setString(
          '${StorageKeys.votersPrefix}$fixtureId', json.encode(votersJson));
      await _prefs.setInt('${StorageKeys.timestampPrefix}$fixtureId',
          DateTime.now().millisecondsSinceEpoch);
    } catch (e) {}
  }

  Future<void> _fetchVotersFromServer() async {
    if (widget.fixture == null) return;

    final fixtureId = widget.fixture!.matchId;

    // ✅ Check AppCache first
    final cachedVoters = AppCache.getCachedComradeVotersData(fixtureId);
    if (cachedVoters != null && cachedVoters.isNotEmpty && mounted) {
      debugPrint(
          '⚡ INSTANT: ${cachedVoters.length} voters from AppCache (RAM)');
      final voters = cachedVoters.map((v) => Voter.fromJson(v)).toList();
      final filteredVoters = voters
          .where((v) =>
              widget.comradesList.contains(v.userId) ||
              v.userId == widget.currentUserId)
          .toList();
      setState(() {
        _voters = filteredVoters;
        _applyVoterFilter();
        _isLoadingVoters = false;
      });
    }

    try {
      final response = await http
          .get(
            Uri.parse('$_api/games/fixture/${widget.fixture!.matchId}/voters'),
            headers: _headers(),
          )
          .timeout(_timeout);

      if (response.statusCode == 200 && mounted) {
        final data = json.decode(response.body);
        if (data['success'] == true && data['voters'] is List) {
          final votersList = data['voters'] as List;
          final List<Voter> voters = [];

          for (var voter in votersList) {
            final uid = voter['userId']?.toString() ?? '';
            final uname = voter['userName']?.toString() ?? 'Anonymous';
            final sel = voter['selection']?.toString() ?? '';

            if (uid.isNotEmpty && sel.isNotEmpty) {
              if (widget.comradesList.contains(uid) ||
                  uid == widget.currentUserId) {
                voters.add(Voter(
                  userId: uid,
                  username: uname,
                  selection: sel,
                  isComrade: widget.comradesList.contains(uid),
                  votedAt: DateTime.now(),
                ));
              }
            }
          }

          voters.sort((a, b) {
            if (a.userId == widget.currentUserId) return -1;
            if (b.userId == widget.currentUserId) return 1;
            return a.username.compareTo(b.username);
          });

          setState(() {
            _voters = voters;
            _applyVoterFilter();
            _isLoadingVoters = false;
          });

          // ✅ Save to AppCache
          final votersForCache = voters.map((v) => v.toJson()).toList();
          AppCache.cacheComradeVotersData(fixtureId, votersForCache);
        }
      }
    } catch (e) {
      if (mounted && _voters.isEmpty) setState(() => _isLoadingVoters = false);
    }
  }

  Future<void> _refreshVotersData() async {
    await _fetchVotersFromServer();
  }

  void _applyVoterFilter() {
    final List<Voter> filtered;
    switch (_selectedFilter) {
      case 'home':
        filtered = _voters.where((v) => v.selection == 'home_team').toList();
        break;
      case 'away':
        filtered = _voters.where((v) => v.selection == 'away_team').toList();
        break;
      case 'draw':
        filtered = _voters.where((v) => v.selection == 'draw').toList();
        break;
      default:
        filtered = List.from(_voters);
    }
    _filteredVoters = filtered;
  }

  VoteStats get _voteStats {
    int home = 0, away = 0, draw = 0;
    for (var v in _voters) {
      switch (v.selection) {
        case 'home_team':
          home++;
          break;
        case 'away_team':
          away++;
          break;
        case 'draw':
          draw++;
          break;
      }
    }
    return VoteStats(homeCount: home, awayCount: away, drawCount: draw);
  }

  // ==========================================================================
  // LEADERBOARD SECTION
  // ==========================================================================
  Future<void> _loadLeaderboardData() async {
    final userId = widget.currentUserId ?? '';

    // ✅ Check AppCache first (RAM - 0ms)
    final cachedLeaderboard = AppCache.getCachedComradeLeaderboard(userId);
    if (cachedLeaderboard != null && cachedLeaderboard.isNotEmpty) {
      debugPrint(
          '⚡ INSTANT: ${cachedLeaderboard.length} comrades from AppCache (RAM)');
      final comrades = <ComradeWithStats>[];
      for (int i = 0; i < cachedLeaderboard.length; i++) {
        // ✅ CHANGE THIS LINE - use fromChannelMember instead of fromComradeJson
        comrades.add(ComradeWithStats.fromChannelMember(
            cachedLeaderboard[i], widget.comradesList));
      }
      setState(() {
        _comrades = comrades;
        _displayComrades = comrades;
        _isLoadingLeaderboard = false;
        _hasLoadedCache = true;
      });
      _buildCarousel();
    } else {
      setState(() => _isLoadingLeaderboard = true);
    }

    await _fetchLeaderboardFromServer();
  }

  Future<void> _fetchLeaderboardFromServer() async {
    if (widget.authToken == null ||
        widget.currentUserId == null ||
        widget.channelId == null) {
      return;
    }

    try {
      // ✅ CORRECT ENDPOINT: Get channel members leaderboard
      final url = Uri.parse('$_api/channels/${widget.channelId}/leaderboard');
      final response = await http
          .get(
            url,
            headers: _headers(),
          )
          .timeout(_timeout);

      if (response.statusCode == 200 && mounted && response.body.isNotEmpty) {
        final dynamic data = json.decode(response.body);

        if (data['success'] == true && data['leaderboard'] is List) {
          final leaderboardData = data['leaderboard'] as List;
          List<ComradeWithStats> comrades = [];

          for (var item in leaderboardData) {
            // ✅ Use the new factory method
            comrades.add(
                ComradeWithStats.fromChannelMember(item, widget.comradesList));
          }

          // Sort by rank (already sorted from backend)
          comrades.sort((a, b) => a.rank.compareTo(b.rank));

          setState(() {
            _comrades = comrades;
            _displayComrades = comrades;
            _isLoadingLeaderboard = false;
          });
          _buildCarousel();

          // Save to AppCache
          AppCache.cacheComradeLeaderboard(widget.currentUserId!,
              leaderboardData.cast<Map<String, dynamic>>());
        } else {
          setState(() => _isLoadingLeaderboard = false);
        }
      } else {
        setState(() => _isLoadingLeaderboard = false);
      }
    } catch (e) {
      debugPrint('❌ Error fetching leaderboard: $e');
      if (!_hasLoadedCache) setState(() => _isLoadingLeaderboard = false);
    }
  }

  void _showUserActivity(ComradeWithStats comrade) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _ActivityHistorySheet(
        userId: comrade.id,
        userName: comrade.username,
        displayName: comrade.nickname,
        clubFan: comrade.clubFan,
        authToken: widget.authToken,
      ),
    );
  }

  // ==========================================================================
  // HELPERS
  // ==========================================================================
  Map<String, String> _headers() {
    final h = {'Content-Type': 'application/json'};
    if (widget.authToken != null && widget.authToken!.isNotEmpty) {
      h['Authorization'] = 'Bearer ${widget.authToken}';
    }
    return h;
  }

  String _initials(String name) =>
      name.isNotEmpty ? name[0].toUpperCase() : 'U';
  String _displayVote(String sel) {
    if (widget.fixture == null) return sel;
    if (sel == 'home_team') return widget.fixture!.homeTeam;
    if (sel == 'away_team') return widget.fixture!.awayTeam;
    if (sel == 'draw') return 'Draw';
    return sel;
  }

  Color _getVoteColor(String sel) {
    switch (sel) {
      case 'home_team':
        return FanColors.primary;
      case 'away_team':
        return const Color(0xFF2563EB);
      case 'draw':
        return const Color(0xFF7F77DD);
      default:
        return FanColors.textSecondary;
    }
  }

  Color _getVoteBg(String sel) => _getVoteColor(sel).withValues(alpha: 0.1);
  Color _getAccuracyColor(double accuracy) {
    if (accuracy >= 90) return FanColors.primary;
    if (accuracy >= 70) return FanColors.draw;
    return FanColors.textTertiary;
  }

  // ==========================================================================
  // BUILD
  // ==========================================================================
  @override
  Widget build(BuildContext context) {
    if (!widget.isOpen) return const SizedBox.shrink();
    final mq = MediaQuery.of(context);

    return Stack(
      children: [
        Positioned.fill(
          child: GestureDetector(
            onTap: widget.onClose,
            child: Container(color: Colors.black.withValues(alpha: 0.5)),
          ),
        ),
        Align(
          alignment: Alignment.bottomCenter,
          child: Container(
            height: mq.size.height * 0.85,
            decoration: BoxDecoration(
              color: FanColors.background,
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(28)),
            ),
            child: Column(
              children: [
                _buildHandle(),
                _buildHeader(),
                _buildCarouselWidget(),
                if (_getTabCount() > 1) _buildTabBar(),
                Expanded(
                  child: TabBarView(
                    controller: _tabController,
                    children: [
                      _buildLeaderboardContent(),
                      if (widget.fixture != null) _buildVotersContent(),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildHandle() => Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Center(
          child: Container(
            width: 36,
            height: 4,
            decoration: BoxDecoration(
              color: FanColors.border,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
        ),
      );

  Widget _buildHeader() => Padding(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 8),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: FanColors.primary.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child:
                  Icon(Icons.emoji_events, color: FanColors.primary, size: 20),
            ),
            const SizedBox(width: 14),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.channelName != null && widget.channelName!.isNotEmpty
                      ? widget.channelName!.toUpperCase()
                      : 'LEADERBOARD',
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: FanColors.textPrimary,
                  ),
                ),
                Text(
                  '${_comrades.length} comrades',
                  style: const TextStyle(
                    fontSize: 11,
                    color: FanColors.textSecondary,
                  ),
                ),
              ],
            ),
            const Spacer(),
            GestureDetector(
              onTap: widget.onClose,
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: FanColors.surfaceElevated,
                  shape: BoxShape.circle,
                ),
                child:
                    Icon(Icons.close, size: 18, color: FanColors.textSecondary),
              ),
            ),
          ],
        ),
      );

  Widget _buildTabBar() => Container(
        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
        decoration: BoxDecoration(
          color: FanColors.surfaceElevated,
          borderRadius: BorderRadius.circular(30),
        ),
        child: TabBar(
          controller: _tabController,
          indicator: BoxDecoration(
            color: FanColors.primary,
            borderRadius: BorderRadius.circular(30),
          ),
          labelColor: Colors.white,
          unselectedLabelColor: FanColors.textSecondary,
          labelStyle:
              const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
          unselectedLabelStyle: const TextStyle(fontSize: 12),
          tabs: const [
            Tab(text: 'LEADERBOARD'),
            Tab(text: 'VOTES'),
          ],
        ),
      );

  // ==========================================================================
  // LEADERBOARD CONTENT (from admin dashboard design)
  // ==========================================================================
  Widget _buildLeaderboardContent() {
    final champion =
        _displayComrades.isNotEmpty ? _displayComrades.first : null;
    final members = _displayComrades.length > 1
        ? _displayComrades.sublist(1)
        : <ComradeWithStats>[];

    return _isLoadingLeaderboard && !_hasLoadedCache
        ? _buildLoadingState()
        : RefreshIndicator(
            onRefresh: _fetchLeaderboardFromServer,
            color: FanColors.primary,
            child: ListView(
              padding: const EdgeInsets.only(bottom: 20),
              children: [
                if (champion != null) _buildChampionCard(champion),
                const SizedBox(height: 8),
                ...members.map((c) => _buildMemberCard(c)),
                if (members.isEmpty && champion == null)
                  _buildEmptyState('No comrades found'),
              ],
            ),
          );
  }

  // Champion card - gold/silver/bronze styling from admin dashboard
  Widget _buildChampionCard(ComradeWithStats comrade) {
    final isGold = comrade.rank == 1;
    final isSilver = comrade.rank == 2;
    final isBronze = comrade.rank == 3;

    Color rankColor;
    if (isGold) {
      rankColor = const Color(0xFFFFD700);
    } else if (isSilver)
      rankColor = Colors.grey.shade400;
    else if (isBronze)
      rankColor = const Color(0xFFCD7F32);
    else
      rankColor = FanColors.primary;

    return Container(
      margin: const EdgeInsets.fromLTRB(16, 8, 16, 16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            rankColor.withValues(alpha: 0.15),
            rankColor.withValues(alpha: 0.05),
          ],
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: rankColor.withValues(alpha: 0.2), width: 1),
        boxShadow: [
          BoxShadow(
            color: rankColor.withValues(alpha: 0.15),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Stack(
        children: [
          Positioned(
            top: -20,
            right: -20,
            child: Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: rankColor.withValues(alpha: 0.03),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: rankColor.withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.emoji_events, size: 14, color: rankColor),
                          const SizedBox(width: 4),
                          Text(
                            isGold
                                ? 'CHAMPION'
                                : (isSilver ? 'RUNNER UP' : '3RD PLACE'),
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              color: rankColor,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: rankColor.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        '#${comrade.rank}',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: rankColor,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Container(
                      width: 56,
                      height: 56,
                      decoration: BoxDecoration(
                        color: rankColor.withValues(alpha: 0.1),
                        shape: BoxShape.circle,
                        border: Border.all(
                            color: rankColor.withValues(alpha: 0.3), width: 2),
                      ),
                      child: Center(
                        child: Text(
                          comrade.nickname[0].toUpperCase(),
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: rankColor,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            comrade.nickname,
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: FanColors.textPrimary,
                            ),
                          ),
                          Row(
                            children: [
                              Text(
                                '@${comrade.username}',
                                style: const TextStyle(
                                  fontSize: 11,
                                  color: FanColors.textSecondary,
                                ),
                              ),
                              if (comrade.isOnline) ...[
                                const SizedBox(width: 6),
                                Container(
                                  width: 8,
                                  height: 8,
                                  decoration: const BoxDecoration(
                                    color: FanColors.secondary,
                                    shape: BoxShape.circle,
                                  ),
                                ),
                              ],
                            ],
                          ),
                          const SizedBox(height: 4),
                          Text(
                            comrade.clubFan,
                            style: const TextStyle(
                              fontSize: 10,
                              color: FanColors.textSecondary,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _buildChampionStat(
                        '${comrade.accuracyPercentage.toStringAsFixed(1)}%',
                        'ACCURACY',
                        '📊'),
                    _buildChampionStat(
                        '${comrade.totalPoints}', 'POINTS', '🎯'),
                    _buildChampionStat(
                        '${comrade.currentStreak}', 'STREAK', '🔥'),
                  ],
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () => _showUserActivity(comrade),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: rankColor,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                    ),
                    child: const Text(
                      'VIEW ACTIVITY',
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 11),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            top: 8,
            right: 16,
            child: Icon(Icons.workspace_premium, color: rankColor, size: 28),
          ),
        ],
      ),
    );
  }

  Widget _buildChampionStat(String value, String label, String emoji) {
    return Column(
      children: [
        Text(emoji, style: const TextStyle(fontSize: 16)),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: FanColors.textPrimary,
          ),
        ),
        Text(
          label,
          style: const TextStyle(fontSize: 9, color: FanColors.textSecondary),
        ),
      ],
    );
  }

  // Member card - same as admin dashboard
  Widget _buildMemberCard(ComradeWithStats comrade) {
    final isGold = comrade.rank == 1;
    final isSilver = comrade.rank == 2;
    final isBronze = comrade.rank == 3;

    Color rankColor;
    if (isGold) {
      rankColor = const Color(0xFFFFD700);
    } else if (isSilver)
      rankColor = Colors.grey.shade400;
    else if (isBronze)
      rankColor = const Color(0xFFCD7F32);
    else
      rankColor = FanColors.textSecondary;

    return GestureDetector(
      onTap: () => _showUserActivity(comrade),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: FanColors.surfaceElevated,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: FanColors.border.withValues(alpha: 0.5)),
        ),
        child: Row(
          children: [
            // Rank
            Container(
              width: 36,
              alignment: Alignment.center,
              child: Text(
                '#${comrade.rank}',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: rankColor,
                ),
              ),
            ),
            const SizedBox(width: 12),
            // Avatar
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    FanColors.primary.withValues(alpha: 0.2),
                    Colors.transparent,
                  ],
                ),
                shape: BoxShape.circle,
              ),
              child: Center(
                child: Text(
                  comrade.nickname[0].toUpperCase(),
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: FanColors.primary,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            // Info
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        comrade.nickname,
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: FanColors.textPrimary,
                        ),
                      ),
                      const SizedBox(width: 4),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: FanColors.primary.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: const Text(
                          'COM',
                          style: TextStyle(
                            fontSize: 7,
                            fontWeight: FontWeight.bold,
                            color: FanColors.primary,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 2),
                  Row(
                    children: [
                      Icon(Icons.sports_soccer,
                          size: 10, color: FanColors.textSecondary),
                      const SizedBox(width: 3),
                      Text(
                        comrade.clubFan,
                        style: const TextStyle(
                            fontSize: 9, color: FanColors.textSecondary),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            // Stats
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.trending_up,
                      size: 10,
                      color: _getAccuracyColor(comrade.accuracyPercentage),
                    ),
                    const SizedBox(width: 2),
                    Text(
                      '${comrade.accuracyPercentage.toStringAsFixed(0)}%',
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        color: _getAccuracyColor(comrade.accuracyPercentage),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 2),
                Text(
                  '${comrade.totalPoints} pts',
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: FanColors.primary,
                  ),
                ),
                if (comrade.currentStreak > 0) ...[
                  const SizedBox(height: 2),
                  Row(
                    children: [
                      const Icon(Icons.local_fire_department,
                          size: 10, color: Colors.orange),
                      const SizedBox(width: 2),
                      Text(
                        '${comrade.currentStreak}',
                        style:
                            const TextStyle(fontSize: 9, color: Colors.orange),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ==========================================================================
  // VOTERS CONTENT
  // ==========================================================================
  Widget _buildVotersContent() {
    if (widget.fixture == null) return const SizedBox.shrink();

    return Column(
      children: [
        _buildVoteSummary(),
        _buildFilterChips(),
        Expanded(
          child: _isLoadingVoters && _voters.isEmpty
              ? _buildLoadingState()
              : RefreshIndicator(
                  onRefresh: _refreshVotersData,
                  color: FanColors.primary,
                  child: _buildVotersList(),
                ),
        ),
      ],
    );
  }

  Widget _buildVoteSummary() => Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: FanColors.surface,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          children: [
            Row(
              children: [
                _buildVoteStat(widget.fixture!.homeTeam, _voteStats.homeCount,
                    _voteStats.homePercentage, FanColors.primary),
                const SizedBox(width: 12),
                _buildVoteStat('Draw', _voteStats.drawCount,
                    _voteStats.drawPercentage, const Color(0xFF7F77DD)),
                const SizedBox(width: 12),
                _buildVoteStat(widget.fixture!.awayTeam, _voteStats.awayCount,
                    _voteStats.awayPercentage, const Color(0xFF2563EB)),
              ],
            ),
            const SizedBox(height: 10),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: SizedBox(
                height: 4,
                child: Row(
                  children: _voteStats.total == 0
                      ? [Expanded(child: Container(color: FanColors.border))]
                      : [
                          if (_voteStats.homeCount > 0)
                            Flexible(
                                flex: _voteStats.homePercentage
                                    .round()
                                    .clamp(1, 100),
                                child: Container(color: FanColors.primary)),
                          if (_voteStats.drawCount > 0)
                            Flexible(
                                flex: _voteStats.drawPercentage
                                    .round()
                                    .clamp(1, 100),
                                child:
                                    Container(color: const Color(0xFF7F77DD))),
                          if (_voteStats.awayCount > 0)
                            Flexible(
                                flex: _voteStats.awayPercentage
                                    .round()
                                    .clamp(1, 100),
                                child:
                                    Container(color: const Color(0xFF2563EB))),
                        ],
                ),
              ),
            ),
          ],
        ),
      );

  Widget _buildVoteStat(
          String label, int count, double percentage, Color color) =>
      Expanded(
        child: Column(
          children: [
            Text(
              count.toString(),
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: color,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              style: TextStyle(
                  fontSize: 10, fontWeight: FontWeight.w500, color: color),
              overflow: TextOverflow.ellipsis,
            ),
            Text(
              '${percentage.toStringAsFixed(0)}%',
              style:
                  TextStyle(fontSize: 9, color: color.withValues(alpha: 0.7)),
            ),
          ],
        ),
      );

  Widget _buildFilterChips() => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Row(
          children: [
            _buildFilterChip('All', 'all', _voteStats.total),
            const SizedBox(width: 6),
            _buildFilterChip(
                widget.fixture!.homeTeam, 'home', _voteStats.homeCount,
                color: FanColors.primary),
            const SizedBox(width: 6),
            _buildFilterChip('Draw', 'draw', _voteStats.drawCount,
                color: const Color(0xFF7F77DD)),
            const SizedBox(width: 6),
            _buildFilterChip(
                widget.fixture!.awayTeam, 'away', _voteStats.awayCount,
                color: const Color(0xFF2563EB)),
          ],
        ),
      );

  Widget _buildFilterChip(String label, String filter, int count,
      {Color? color}) {
    final isSelected = _selectedFilter == filter;
    final chipColor = color ?? FanColors.primary;
    return GestureDetector(
      onTap: () => setState(() {
        _selectedFilter = filter;
        _applyVoterFilter();
      }),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: isSelected ? chipColor : chipColor.withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              label,
              style: TextStyle(
                fontSize: 11,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                color: isSelected ? Colors.white : chipColor,
              ),
            ),
            if (count > 0) ...[
              const SizedBox(width: 4),
              Text(
                '$count',
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                  color: isSelected
                      ? Colors.white.withValues(alpha: 0.8)
                      : chipColor,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildVotersList() {
    if (_filteredVoters.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.how_to_vote_outlined, size: 40, color: FanColors.border),
            const SizedBox(height: 12),
            Text(
              _selectedFilter == 'all'
                  ? 'No votes yet'
                  : 'No votes for this selection',
              style:
                  const TextStyle(fontSize: 13, color: FanColors.textSecondary),
            ),
          ],
        ),
      );
    }
    return ListView.builder(
      controller: _voterScroll,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      itemCount: _filteredVoters.length,
      itemBuilder: (context, index) => _buildVoterCard(_filteredVoters[index]),
    );
  }

  Widget _buildVoterCard(Voter voter) {
    final isMe = voter.userId == widget.currentUserId;
    final voteColor = _getVoteColor(voter.selection);
    final voteBg = _getVoteBg(voter.selection);
    final voteDisplay = _displayVote(voter.selection);

    return Container(
      margin: const EdgeInsets.only(bottom: 2),
      child: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 12),
            child: Row(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration:
                      BoxDecoration(color: voteBg, shape: BoxShape.circle),
                  child: Center(
                    child: Text(
                      _initials(voter.username),
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: voteColor,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            isMe ? 'You' : voter.username,
                            style: TextStyle(
                              fontWeight: FontWeight.w500,
                              fontSize: 13,
                              color: isMe
                                  ? FanColors.primary
                                  : FanColors.textPrimary,
                            ),
                          ),
                          if (voter.isComrade && !isMe) ...[
                            const SizedBox(width: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: FanColors.primary.withValues(alpha: 0.1),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: const Text(
                                'comrade',
                                style: TextStyle(
                                    fontSize: 8,
                                    color: FanColors.primary,
                                    fontWeight: FontWeight.w500),
                              ),
                            ),
                          ],
                        ],
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'Voted for $voteDisplay',
                        style: const TextStyle(
                            fontSize: 10, color: FanColors.textSecondary),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: voteBg,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Text(
                    voteDisplay,
                    style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                        color: voteColor),
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Divider(
              color: FanColors.border.withValues(alpha: 0.2),
              height: 0.5,
              thickness: 0.5,
            ),
          ),
        ],
      ),
    );
  }

  // ==========================================================================
  // COMMON WIDGETS
  // ==========================================================================
  Widget _buildLoadingState() => const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              width: 24,
              height: 24,
              child: CircularProgressIndicator(
                  strokeWidth: 2, color: FanColors.primary),
            ),
            SizedBox(height: 12),
            Text('Loading...',
                style: TextStyle(fontSize: 11, color: FanColors.textSecondary)),
          ],
        ),
      );

  Widget _buildEmptyState(String message) => Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.people_outline, size: 48, color: FanColors.textTertiary),
            const SizedBox(height: 12),
            Text(message,
                style: const TextStyle(
                    fontSize: 12, color: FanColors.textSecondary)),
          ],
        ),
      );
}

// ============================================================================
// ACTIVITY HISTORY SHEET (same as before, kept for completeness)
// ============================================================================
class _ActivityHistorySheet extends StatefulWidget {
  final String userId;
  final String userName;
  final String displayName;
  final String clubFan;
  final String? authToken;

  const _ActivityHistorySheet({
    required this.userId,
    required this.userName,
    required this.displayName,
    required this.clubFan,
    this.authToken,
  });

  @override
  State<_ActivityHistorySheet> createState() => _ActivityHistorySheetState();
}

class _ActivityHistorySheetState extends State<_ActivityHistorySheet> {
  List<ArchiveActivity> _activities = [];
  bool _isLoading = true;
  String _selectedFilter = 'All';
  static const String _baseUrl = 'https://clash-api-m5mr.onrender.com/api';

  @override
  void initState() {
    super.initState();
    _fetchActivities();
  }

  Future<void> _fetchActivities() async {
    setState(() => _isLoading = true);
    try {
      final headers = <String, String>{'Content-Type': 'application/json'};
      if (widget.authToken != null && widget.authToken!.isNotEmpty) {
        headers['Authorization'] = 'Bearer ${widget.authToken}';
      }
      final response = await http
          .get(Uri.parse('$_baseUrl/archive/user/${widget.userId}'),
              headers: headers)
          .timeout(const Duration(seconds: 10));
      if (response.statusCode == 200 && mounted && response.body.isNotEmpty) {
        final List<dynamic> data = json.decode(response.body);
        final activities = data.map((item) => _activityFromJson(item)).toList();
        activities.sort((a, b) => b.timestamp.compareTo(a.timestamp));
        setState(() {
          _activities = activities;
          _isLoading = false;
        });
      } else {
        setState(() {
          _activities = _generateMockActivities();
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _activities = _generateMockActivities();
        _isLoading = false;
      });
    }
  }

  ArchiveActivity _activityFromJson(Map<String, dynamic> json) {
    DateTime timestamp;
    try {
      timestamp = DateTime.parse(json['timestamp']).toLocal();
    } catch (e) {
      timestamp = DateTime.now();
    }
    final activityType = ActivityType.values.firstWhere(
        (e) => e.toString().split('.').last == json['activity_type'],
        orElse: () => ActivityType.vote);
    return ArchiveActivity(
      id: json['_id']?.toString() ??
          DateTime.now().millisecondsSinceEpoch.toString(),
      fixtureId: json['fixture_id']?.toString() ?? '',
      homeTeam: json['home_team']?.toString() ?? 'Liverpool',
      awayTeam: json['away_team']?.toString() ?? 'Manchester City',
      activityType: activityType,
      selection: json['selection']?.toString(),
      selectedTeam: json['selection'] == 'home_team'
          ? (json['home_team'] ?? 'Home')
          : (json['selection'] == 'away_team'
              ? (json['away_team'] ?? 'Away')
              : 'Draw'),
      comment: json['comment']?.toString(),
      isLiked: json['is_liked'],
      timestamp: timestamp,
    );
  }

  List<ArchiveActivity> _generateMockActivities() {
    final matches = [
      ('Liverpool', 'Arsenal'),
      ('Barcelona', 'Real Madrid'),
      ('Man United', 'Chelsea'),
    ];
    final List<ArchiveActivity> acts = [];
    for (int i = 0; i < 5; i++) {
      final match = matches[i % matches.length];
      acts.add(ArchiveActivity(
        id: i.toString(),
        fixtureId: 'fixture_$i',
        homeTeam: match.$1,
        awayTeam: match.$2,
        activityType: ActivityType.vote,
        selectedTeam: match.$1,
        timestamp: DateTime.now().subtract(Duration(days: i)),
      ));
    }
    return acts;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.6,
      decoration: const BoxDecoration(
        color: FanColors.surfaceElevated,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(28),
          topRight: Radius.circular(28),
        ),
      ),
      child: Column(
        children: [
          Container(
            margin: const EdgeInsets.only(top: 12),
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: FanColors.border,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          _buildHeader(),
          _buildFilterTabs(),
          Expanded(child: _buildContent()),
        ],
      ),
    );
  }

  Widget _buildHeader() => Padding(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 12),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: FanColors.primary.withValues(alpha: 0.08),
                shape: BoxShape.circle,
              ),
              child: Center(
                child: Text(
                  widget.displayName[0].toUpperCase(),
                  style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: FanColors.primary),
                ),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(widget.displayName,
                      style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.bold)),
                  Text('@${widget.userName}',
                      style: const TextStyle(
                          fontSize: 11, color: FanColors.textSecondary)),
                  Text(widget.clubFan,
                      style: const TextStyle(
                          fontSize: 11, color: FanColors.textSecondary)),
                ],
              ),
            ),
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: const BoxDecoration(
                    color: FanColors.surface, shape: BoxShape.circle),
                child:
                    Icon(Icons.close, size: 16, color: FanColors.textSecondary),
              ),
            ),
          ],
        ),
      );

  Widget _buildFilterTabs() {
    final filters = ['All', 'Votes', 'Comments', 'Likes'];
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      height: 44,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: filters.length,
        separatorBuilder: (_, __) => const SizedBox(width: 16),
        itemBuilder: (_, index) {
          final filter = filters[index];
          final isSelected = _selectedFilter == filter;
          return GestureDetector(
            onTap: () => setState(() => _selectedFilter = filter),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Text(
                filter,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                  color:
                      isSelected ? FanColors.primary : FanColors.textSecondary,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildContent() {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator(strokeWidth: 2));
    }

    List<ArchiveActivity> filtered = List.from(_activities);
    if (_selectedFilter != 'All') {
      final type = ActivityType.values.firstWhere(
          (e) => e.toString().split('.').last == _selectedFilter.toLowerCase());
      filtered = filtered.where((a) => a.activityType == type).toList();
    }

    if (filtered.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.inbox_outlined, size: 48, color: FanColors.textTertiary),
            const SizedBox(height: 12),
            const Text('No activities yet', style: TextStyle(fontSize: 14)),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: filtered.length,
      itemBuilder: (_, i) => _buildActivityCard(filtered[i]),
    );
  }

  Widget _buildActivityCard(ArchiveActivity activity) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(activity.getActivityIcon(),
                        size: 14, color: activity.getActivityColor()),
                    const SizedBox(width: 8),
                    Text(
                      activity.activityType
                          .toString()
                          .split('.')
                          .last
                          .toUpperCase(),
                      style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                          color: activity.getActivityColor()),
                    ),
                    const SizedBox(width: 8),
                    Text('•',
                        style: TextStyle(
                            fontSize: 10, color: FanColors.textSecondary)),
                    const SizedBox(width: 8),
                    Text(activity.getTimeAgo(),
                        style: const TextStyle(
                            fontSize: 10, color: FanColors.textSecondary)),
                  ],
                ),
                const SizedBox(height: 8),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(activity.homeTeam,
                            style: const TextStyle(fontWeight: FontWeight.w500),
                            textAlign: TextAlign.right),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8),
                        child: Text('vs',
                            style: const TextStyle(
                                fontSize: 11, color: FanColors.textSecondary)),
                      ),
                      Expanded(
                        child: Text(activity.awayTeam,
                            style: const TextStyle(fontWeight: FontWeight.w500),
                            textAlign: TextAlign.left),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                _buildActivityContent(activity),
              ],
            ),
          ),
          Divider(color: FanColors.border.withValues(alpha: 0.3), height: 1),
        ],
      ),
    );
  }

  Widget _buildActivityContent(ArchiveActivity activity) {
    switch (activity.activityType) {
      case ActivityType.vote:
        return Row(
          children: [
            Container(
                width: 3,
                height: 14,
                decoration: BoxDecoration(
                    color: FanColors.primary,
                    borderRadius: BorderRadius.circular(2))),
            const SizedBox(width: 10),
            Icon(Icons.how_to_vote, size: 12, color: FanColors.primary),
            const SizedBox(width: 8),
            Text(activity.selectedTeam,
                style: const TextStyle(fontSize: 12, color: FanColors.primary)),
          ],
        );
      case ActivityType.comment:
        return Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
                width: 3,
                height: 14,
                decoration: BoxDecoration(
                    color: FanColors.draw,
                    borderRadius: BorderRadius.circular(2))),
            const SizedBox(width: 10),
            Icon(Icons.format_quote, size: 12, color: FanColors.draw),
            const SizedBox(width: 8),
            Expanded(
                child: Text(activity.comment ?? 'No comment',
                    style: const TextStyle(fontSize: 12))),
          ],
        );
      case ActivityType.like:
        return Row(
          children: [
            Container(
                width: 3,
                height: 14,
                decoration: BoxDecoration(
                    color: FanColors.textSecondary,
                    borderRadius: BorderRadius.circular(2))),
            const SizedBox(width: 10),
            Icon(Icons.favorite_border,
                size: 12, color: FanColors.textSecondary),
            const SizedBox(width: 8),
            const Text('Showed support',
                style: TextStyle(fontSize: 12, color: FanColors.textSecondary)),
          ],
        );
    }
  }
}

// ============================================================================
// ENUMS (if not already defined elsewhere)
// ============================================================================
enum ActivityType { vote, comment, like }

class ArchiveActivity {
  final String id;
  final String fixtureId;
  final String homeTeam;
  final String awayTeam;
  final ActivityType activityType;
  final String? selection;
  final String selectedTeam;
  final String? comment;
  final bool? isLiked;
  final DateTime timestamp;

  ArchiveActivity({
    required this.id,
    required this.fixtureId,
    required this.homeTeam,
    required this.awayTeam,
    required this.activityType,
    this.selection,
    required this.selectedTeam,
    this.comment,
    this.isLiked,
    required this.timestamp,
  });

  String getTimeAgo() {
    final now = DateTime.now();
    final diff = now.difference(timestamp);
    if (diff.inMinutes < 1) return 'Just now';
    if (diff.inHours < 1) return '${diff.inMinutes}m ago';
    if (diff.inDays < 1) return '${diff.inHours}h ago';
    if (diff.inDays == 1) return 'Yesterday';
    return DateFormat('MMM d').format(timestamp);
  }

  IconData getActivityIcon() {
    switch (activityType) {
      case ActivityType.vote:
        return Icons.how_to_vote;
      case ActivityType.comment:
        return Icons.comment;
      case ActivityType.like:
        return Icons.favorite_border;
    }
  }

  Color getActivityColor() {
    switch (activityType) {
      case ActivityType.vote:
        return FanColors.primary;
      case ActivityType.comment:
        return FanColors.draw;
      case ActivityType.like:
        return FanColors.textSecondary;
    }
  }
}
