// ============================================================================
// CHAT SCREEN - WITH FULL MATCH UPDATES + APPCACHE + COMMENTARY
// ============================================================================

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:clash/modals/FAB/profile_modal.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import '../../services/bet_service.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as path;
import 'package:image_picker/image_picker.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:video_player/video_player.dart';
import 'package:video_thumbnail/video_thumbnail.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../models/fixture_models.dart';
import '../../services/web_soecket.dart';
import '../../services/api_services.dart';
import '../../modals/clash/match_details.dart';
import '../../modals/FAB/archive_modal.dart';
import "../../pages/fan_clash_design.dart";
import '../../utils/add_helper.dart';
import 'leaderboard.dart';
import '../../services/comrade_service.dart';
import '../../main.dart';
import '../clash/swipabledialogue.dart';

// ============================================================================
// COMRADE CACHE SERVICE
// ============================================================================

class ComradeCacheService {
  static final ComradeCacheService _instance = ComradeCacheService._internal();
  factory ComradeCacheService() => _instance;
  ComradeCacheService._internal();

  static const String _cacheKey = 'chat_cached_comrades';
  static const String _timestampKey = 'chat_comrades_cache_timestamp';
  static const Duration _cacheDuration = Duration(minutes: 30);

  Future<void> cacheComrades(List<Map<String, dynamic>> comrades) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final jsonString = jsonEncode(comrades);
      await prefs.setString(_cacheKey, jsonString);
      await prefs.setString(_timestampKey, DateTime.now().toIso8601String());
      debugPrint('✅ ChatComrades cached: ${comrades.length} users');
    } catch (e) {
      debugPrint('❌ Failed to cache comrades: $e');
    }
  }

  Future<List<Map<String, dynamic>>> getCachedComrades() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final timestampStr = prefs.getString(_timestampKey);
      if (timestampStr != null) {
        final cacheTime = DateTime.parse(timestampStr);
        if (DateTime.now().difference(cacheTime) > _cacheDuration) {
          debugPrint('⚠️ Comrades cache expired');
          return [];
        }
      } else {
        return [];
      }
      final jsonString = prefs.getString(_cacheKey);
      if (jsonString != null) {
        final List<dynamic> decoded = jsonDecode(jsonString);
        final comrades = decoded.cast<Map<String, dynamic>>();
        debugPrint('📦 Loaded ${comrades.length} comrades from cache');
        return comrades;
      }
    } catch (e) {
      debugPrint('❌ Failed to load cached comrades: $e');
    }
    return [];
  }

  Future<void> clearCache() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_cacheKey);
      await prefs.remove(_timestampKey);
      debugPrint('🗑️ Comrades cache cleared');
    } catch (e) {
      debugPrint('❌ Failed to clear comrades cache: $e');
    }
  }

  Future<bool> isCacheValid() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final timestampStr = prefs.getString(_timestampKey);
      if (timestampStr == null) return false;
      final cacheTime = DateTime.parse(timestampStr);
      return DateTime.now().difference(cacheTime) <= _cacheDuration;
    } catch (e) {
      return false;
    }
  }
}

// ============================================================================
// SPEECH BUBBLE CLIPPER
// ============================================================================

class SpeechBubbleClipper extends CustomClipper<Path> {
  final bool isLeftAligned;
  SpeechBubbleClipper({this.isLeftAligned = true});

  @override
  Path getClip(Size size) {
    final path = Path();
    final bubbleRadius = 16.0;
    final tailSize = 12.0;

    if (isLeftAligned) {
      path.moveTo(bubbleRadius, 0);
      path.lineTo(size.width - bubbleRadius, 0);
      path.quadraticBezierTo(size.width, 0, size.width, bubbleRadius);
      path.lineTo(size.width, size.height - bubbleRadius);
      path.quadraticBezierTo(
          size.width, size.height, size.width - bubbleRadius, size.height);
      path.lineTo(bubbleRadius + tailSize, size.height);
      path.lineTo(bubbleRadius, size.height + tailSize);
      path.lineTo(bubbleRadius, size.height);
      path.quadraticBezierTo(0, size.height, 0, size.height - bubbleRadius);
      path.lineTo(0, bubbleRadius);
      path.quadraticBezierTo(0, 0, bubbleRadius, 0);
    } else {
      path.moveTo(bubbleRadius, 0);
      path.lineTo(size.width - bubbleRadius, 0);
      path.quadraticBezierTo(size.width, 0, size.width, bubbleRadius);
      path.lineTo(size.width, size.height - bubbleRadius);
      path.quadraticBezierTo(
          size.width, size.height, size.width - bubbleRadius, size.height);
      path.lineTo(bubbleRadius, size.height);
      path.lineTo(size.width - bubbleRadius, size.height + tailSize);
      path.lineTo(size.width - bubbleRadius, size.height);
      path.quadraticBezierTo(0, size.height, 0, size.height - bubbleRadius);
      path.lineTo(0, bubbleRadius);
      path.quadraticBezierTo(0, 0, bubbleRadius, 0);
    }
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}

// ============================================================================
// SPEECH BUBBLE WIDGET
// ============================================================================

class SpeechBubble extends StatelessWidget {
  final Widget child;
  final Color color;
  final bool isLeftAligned;
  final EdgeInsets padding;

  const SpeechBubble({
    super.key,
    required this.child,
    this.color = FanColors.surface,
    this.isLeftAligned = true,
    this.padding = const EdgeInsets.all(12),
  });

  @override
  Widget build(BuildContext context) {
    return ClipPath(
      clipper: SpeechBubbleClipper(isLeftAligned: isLeftAligned),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          color: color,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.05),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: child,
      ),
    );
  }
}

// ============================================================================
// CAROUSEL ITEM TYPE
// ============================================================================

enum CarouselItemType { gameInfo, voteStats, ad, comrade, matchUpdate }

class CarouselItem {
  final CarouselItemType type;
  final String? adUnitId;
  final Fixture? fixture;
  final int? homeVotes;
  final int? awayVotes;
  final int? drawVotes;
  final String? userVoteSelection;
  final Map<String, dynamic>? comradeData;
  final bool added;
  final Map<String, dynamic>? matchUpdateData;

  const CarouselItem.gameInfo({
    required this.fixture,
    this.userVoteSelection,
  })  : type = CarouselItemType.gameInfo,
        adUnitId = null,
        homeVotes = null,
        awayVotes = null,
        drawVotes = null,
        comradeData = null,
        added = false,
        matchUpdateData = null;

  const CarouselItem.voteStats({
    required this.fixture,
    required this.homeVotes,
    required this.awayVotes,
    required this.drawVotes,
    this.userVoteSelection,
  })  : type = CarouselItemType.voteStats,
        adUnitId = null,
        comradeData = null,
        added = false,
        matchUpdateData = null;

  const CarouselItem.ad({required this.adUnitId})
      : type = CarouselItemType.ad,
        fixture = null,
        homeVotes = null,
        awayVotes = null,
        drawVotes = null,
        userVoteSelection = null,
        comradeData = null,
        added = false,
        matchUpdateData = null;

  const CarouselItem.comrade({
    required this.comradeData,
    this.added = false,
  })  : type = CarouselItemType.comrade,
        fixture = null,
        adUnitId = null,
        homeVotes = null,
        awayVotes = null,
        drawVotes = null,
        userVoteSelection = null,
        matchUpdateData = null;

  const CarouselItem.matchUpdate({
    required this.matchUpdateData,
    required this.fixture,
  })  : type = CarouselItemType.matchUpdate,
        adUnitId = null,
        homeVotes = null,
        awayVotes = null,
        drawVotes = null,
        userVoteSelection = null,
        comradeData = null,
        added = false;
}

// ============================================================================
// AD MANAGER - Singleton
// ============================================================================

class ChatAdManager {
  static final ChatAdManager _instance = ChatAdManager._internal();
  factory ChatAdManager() => _instance;
  ChatAdManager._internal();

  final Map<String, NativeAd> _loadedAds = {};
  final Map<String, bool> _loadingAds = {};

  bool isAdLoaded(String adUnitId) => _loadedAds.containsKey(adUnitId);
  bool isLoading(String adUnitId) => _loadingAds[adUnitId] == true;

  NativeAd? getAd(String adUnitId) {
    final ad = _loadedAds[adUnitId];
    if (ad != null) {
      _loadedAds.remove(adUnitId);
      _reload(adUnitId);
    }
    return ad;
  }

  void preloadAd(String adUnitId) {
    if (_loadedAds.containsKey(adUnitId)) return;
    if (_loadingAds[adUnitId] == true) return;
    _load(adUnitId);
  }

  void _reload(String adUnitId) {
    Future.delayed(const Duration(seconds: 2), () => _load(adUnitId));
  }

  void _load(String adUnitId) {
    if (_loadingAds[adUnitId] == true) return;
    _loadingAds[adUnitId] = true;

    final ad = NativeAd(
      adUnitId: adUnitId,
      factoryId: 'nativeAdFactory',
      request: const AdRequest(
        nonPersonalizedAds: true,
        keywords: ['sports', 'football', 'soccer', 'gaming'],
      ),
      listener: NativeAdListener(
        onAdLoaded: (ad) {
          _loadedAds[adUnitId] = ad as NativeAd;
          _loadingAds[adUnitId] = false;
        },
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
          _loadingAds[adUnitId] = false;
          Future.delayed(const Duration(seconds: 30), () => _load(adUnitId));
        },
      ),
    );
    ad.load();
  }

  void disposeAll() {
    for (final ad in _loadedAds.values) {
      ad.dispose();
    }
    _loadedAds.clear();
    _loadingAds.clear();
  }
}

// ============================================================================
// AD SLOT WIDGET
// ============================================================================

class AdSlotWidget extends StatefulWidget {
  final String adUnitId;
  final int position;

  const AdSlotWidget(
      {super.key, required this.adUnitId, required this.position});

  @override
  State<AdSlotWidget> createState() => _AdSlotWidgetState();
}

class _AdSlotWidgetState extends State<AdSlotWidget> {
  NativeAd? _ad;
  bool _isReady = false;
  Timer? _pollTimer;

  @override
  void initState() {
    super.initState();
    _tryGetAd();
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    super.dispose();
  }

  void _tryGetAd() {
    final adManager = ChatAdManager();
    final preloadedAd = adManager.getAd(widget.adUnitId);
    if (preloadedAd != null) {
      if (mounted) {
        setState(() {
          _ad = preloadedAd;
          _isReady = true;
        });
      }
      return;
    }
    adManager.preloadAd(widget.adUnitId);
    _pollForAd();
  }

  void _pollForAd() {
    int attempts = 0;
    _pollTimer = Timer.periodic(const Duration(milliseconds: 200), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      attempts++;
      final ad = ChatAdManager().getAd(widget.adUnitId);
      if (ad != null) {
        timer.cancel();
        setState(() {
          _ad = ad;
          _isReady = true;
        });
      } else if (attempts >= 75) {
        timer.cancel();
        Future.delayed(const Duration(seconds: 3), () {
          if (mounted) _tryGetAd();
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!_isReady || _ad == null) {
      return Container(
        decoration: BoxDecoration(
          color: FanColors.surface,
          borderRadius: BorderRadius.circular(12),
        ),
        child: const SizedBox.expand(),
      );
    }
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: AdWidget(ad: _ad!),
    );
  }
}

// ============================================================================
// FALLBACK AD WIDGET
// ============================================================================

class FallbackAdWidget extends StatelessWidget {
  final Widget? dotsWidget;
  const FallbackAdWidget({super.key, this.dotsWidget});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: FanColors.primary.withValues(alpha: 0.1),
              shape: BoxShape.circle,
            ),
            child: const Center(
              child: Text('⚡', style: TextStyle(fontSize: 16)),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Text(
                      'Clash+',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: FanColors.textPrimary,
                      ),
                    ),
                    const SizedBox(width: 4),
                    const Text(
                      '@upgrade',
                      style: TextStyle(
                          fontSize: 9, color: FanColors.textSecondary),
                    ),
                  ],
                ),
                const SizedBox(height: 2),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: FanColors.primary.withValues(alpha: 0.08),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.bolt,
                          size: 10,
                          color: FanColors.primary.withValues(alpha: 0.7)),
                      const SizedBox(width: 4),
                      const Text(
                        'remove ads • unlock rewards',
                        style: TextStyle(
                            fontSize: 9, color: FanColors.textPrimary),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Container(
            width: 32,
            height: 32,
            decoration: const BoxDecoration(
              color: FanColors.primary,
              shape: BoxShape.circle,
            ),
            child: const Center(
              child: Icon(Icons.arrow_forward_rounded,
                  size: 16, color: Colors.white),
            ),
          ),
          if (dotsWidget != null) ...[
            const SizedBox(width: 6),
            dotsWidget!,
          ],
        ],
      ),
    );
  }
}

// ============================================================================
// CHAT MESSAGE MODEL
// ============================================================================

enum MessageStatus { sending, sent, delivered, read, failed }

class ChatMessage {
  final String id;
  final String userId;
  final String username;
  final String text;
  final String? selection;
  final DateTime timestamp;
  final MessageStatus status;
  final bool isSeen;
  final ReplyData? replyTo;
  final String? imageUrl;
  final String? videoUrl;
  final bool isImage;
  final bool isVideo;
  final bool isCommentary;
  final String? commentaryType;

  ChatMessage({
    required this.id,
    required this.userId,
    required this.username,
    required this.text,
    this.selection,
    required this.timestamp,
    this.status = MessageStatus.sent,
    this.isSeen = false,
    this.replyTo,
    this.imageUrl,
    this.videoUrl,
    this.isImage = false,
    this.isVideo = false,
    this.isCommentary = false,
    this.commentaryType,
  });

  factory ChatMessage.commentary({
    required int minute,
    required String text,
    required String type,
    required DateTime createdAt,
  }) {
    return ChatMessage(
      id: 'commentary_${createdAt.millisecondsSinceEpoch}_$minute',
      userId: '__commentary__',
      username: "Live Commentary • $minute'",
      text: text,
      timestamp: createdAt,
      status: MessageStatus.delivered,
      isCommentary: true,
      commentaryType: type,
    );
  }
}

// ============================================================================
// REPLY DATA
// ============================================================================

class ReplyData {
  final String messageId;
  final String text;
  final String username;
  final String? selection;
  final bool isMe;

  ReplyData({
    required this.messageId,
    required this.text,
    required this.username,
    this.selection,
    this.isMe = false,
  });

  Map<String, dynamic> toJson() => {
        'messageId': messageId,
        'text': text,
        'username': username,
        'selection': selection,
        'isMe': isMe,
      };
}

// ============================================================================
// LOCAL DATABASE SERVICE (Fallback only)
// ============================================================================

class ChatDatabaseService {
  static final ChatDatabaseService _instance = ChatDatabaseService._internal();
  factory ChatDatabaseService() => _instance;
  ChatDatabaseService._internal();

  static Database? _database;
  static const String _tableName = 'channel_messages';

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    String dbPath =
        path.join(await getDatabasesPath(), 'fanclash_channel_chat.db');
    return await openDatabase(dbPath,
        version: 2, onCreate: _onCreate, onUpgrade: _onUpgrade);
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE $_tableName (
        id TEXT PRIMARY KEY,
        channel_id TEXT NOT NULL,
        fixture_id TEXT,
        user_id TEXT NOT NULL,
        username TEXT NOT NULL,
        text TEXT NOT NULL,
        selection TEXT,
        timestamp TEXT NOT NULL,
        status INTEGER DEFAULT 1,
        is_seen INTEGER DEFAULT 0,
        reply_to_id TEXT,
        reply_to_text TEXT,
        reply_to_username TEXT,
        reply_to_selection TEXT,
        image_url TEXT,
        video_url TEXT,
        is_image INTEGER DEFAULT 0,
        is_video INTEGER DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
      )
    ''');
    await db.execute(
        'CREATE INDEX idx_channel_fixture ON $_tableName(channel_id, fixture_id)');
    await db.execute('CREATE INDEX idx_timestamp ON $_tableName(timestamp)');
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) {
      await db.execute(
          'ALTER TABLE $_tableName ADD COLUMN reply_to_selection TEXT');
    }
  }

  Future<void> insertMessage(
      ChatMessage message, String channelId, String? fixtureId) async {
    final db = await database;
    await db.insert(
        _tableName,
        {
          'id': message.id,
          'channel_id': channelId,
          'fixture_id': fixtureId,
          'user_id': message.userId,
          'username': message.username,
          'text': message.text,
          'selection': message.selection,
          'timestamp': message.timestamp.toIso8601String(),
          'status': message.status.index,
          'is_seen': message.isSeen ? 1 : 0,
          'reply_to_id': message.replyTo?.messageId,
          'reply_to_text': message.replyTo?.text,
          'reply_to_username': message.replyTo?.username,
          'reply_to_selection': message.replyTo?.selection,
          'image_url': message.imageUrl,
          'video_url': message.videoUrl,
          'is_image': message.isImage ? 1 : 0,
          'is_video': message.isVideo ? 1 : 0,
        },
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<ChatMessage>> getMessages(String channelId, String? fixtureId,
      {int limit = 100}) async {
    final db = await database;
    final List<Map<String, dynamic>> maps;
    if (fixtureId == null) {
      maps = await db.query(_tableName,
          where: 'channel_id = ? AND fixture_id IS NULL',
          whereArgs: [channelId],
          orderBy: 'timestamp ASC',
          limit: limit);
    } else {
      maps = await db.query(_tableName,
          where: 'channel_id = ? AND fixture_id = ?',
          whereArgs: [channelId, fixtureId],
          orderBy: 'timestamp ASC',
          limit: limit);
    }
    return maps.map((map) => _fromMap(map)).toList();
  }

  ChatMessage _fromMap(Map<String, dynamic> map) {
    ReplyData? replyTo;
    if (map['reply_to_id'] != null) {
      replyTo = ReplyData(
        messageId: map['reply_to_id'] as String,
        text: map['reply_to_text'] as String? ?? '',
        username: map['reply_to_username'] as String? ?? '',
        selection: map['reply_to_selection'] as String?,
        isMe: false,
      );
    }
    return ChatMessage(
      id: map['id'] as String,
      userId: map['user_id'] as String,
      username: map['username'] as String,
      text: map['text'] as String,
      selection: map['selection'] as String?,
      timestamp: DateTime.parse(map['timestamp'] as String),
      status: MessageStatus.values[map['status'] as int? ?? 1],
      isSeen: (map['is_seen'] as int? ?? 0) == 1,
      replyTo: replyTo,
      imageUrl: map['image_url'] as String?,
      videoUrl: map['video_url'] as String?,
      isImage: (map['is_image'] as int? ?? 0) == 1,
      isVideo: (map['is_video'] as int? ?? 0) == 1,
    );
  }

  Future<void> updateMessageStatus(
      String messageId, MessageStatus status) async {
    final db = await database;
    await db.update(_tableName, {'status': status.index},
        where: 'id = ?', whereArgs: [messageId]);
  }

  Future<void> deleteMessage(String messageId) async {
    final db = await database;
    await db.delete(_tableName, where: 'id = ?', whereArgs: [messageId]);
  }
}

// ============================================================================
// VOTER MODEL
// ============================================================================

class Voter {
  final String userId;
  final String username;
  final String selection;
  final bool isComrade;
  final DateTime votedAt;

  Voter({
    required this.userId,
    required this.username,
    required this.selection,
    this.isComrade = false,
    required this.votedAt,
  });

  factory Voter.fromJson(Map<String, dynamic> json) {
    return Voter(
      userId: json['userId']?.toString() ?? json['user_id']?.toString() ?? '',
      username: json['userName']?.toString() ??
          json['user_name']?.toString() ??
          'Anonymous',
      selection: json['selection']?.toString() ?? '',
      isComrade: json['isComrade'] ?? json['is_comrade'] ?? false,
      votedAt: json['votedAt'] != null
          ? DateTime.tryParse(json['votedAt'].toString()) ?? DateTime.now()
          : json['voted_at'] != null
              ? DateTime.tryParse(json['voted_at'].toString()) ?? DateTime.now()
              : DateTime.now(),
    );
  }
}

// ============================================================================
// KEEP ALIVE WRAPPER
// ============================================================================

class KeepAliveWrapper extends StatefulWidget {
  final Widget child;
  const KeepAliveWrapper({super.key, required this.child});

  @override
  State<KeepAliveWrapper> createState() => _KeepAliveWrapperState();
}

class _KeepAliveWrapperState extends State<KeepAliveWrapper>
    with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return widget.child;
  }
}

// ============================================================================
// VIDEO PLAYER PAGE
// ============================================================================

class VideoPlayerPage extends StatefulWidget {
  final String videoUrl;
  const VideoPlayerPage({super.key, required this.videoUrl});

  @override
  State<VideoPlayerPage> createState() => _VideoPlayerPageState();
}

class _VideoPlayerPageState extends State<VideoPlayerPage> {
  late VideoPlayerController _controller;
  bool _isInitialized = false;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.networkUrl(Uri.parse(widget.videoUrl));
    _controller.initialize().then((_) {
      setState(() => _isInitialized = true);
      _controller.play();
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          iconTheme: const IconThemeData(color: Colors.white)),
      body: Center(
        child: _isInitialized
            ? GestureDetector(
                onTap: () => setState(() {
                  _controller.value.isPlaying
                      ? _controller.pause()
                      : _controller.play();
                }),
                child: AspectRatio(
                  aspectRatio: _controller.value.aspectRatio,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      VideoPlayer(_controller),
                      if (!_controller.value.isPlaying)
                        Container(
                          decoration: BoxDecoration(
                              color: Colors.black.withValues(alpha: 0.5),
                              shape: BoxShape.circle),
                          child: const Icon(Icons.play_arrow,
                              size: 64, color: Colors.white),
                        ),
                    ],
                  ),
                ),
              )
            : const Center(
                child: CircularProgressIndicator(color: Colors.white)),
      ),
    );
  }
}

// ============================================================================
// VIDEO THUMBNAIL
// ============================================================================

class _VideoThumbnail extends StatefulWidget {
  final String videoUrl;
  const _VideoThumbnail({required this.videoUrl});

  @override
  State<_VideoThumbnail> createState() => _VideoThumbnailState();
}

class _VideoThumbnailState extends State<_VideoThumbnail> {
  static final Map<String, Uint8List?> _cache = {};
  Uint8List? _thumbnail;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadThumbnail();
  }

  Future<void> _loadThumbnail() async {
    if (_cache.containsKey(widget.videoUrl)) {
      setState(() {
        _thumbnail = _cache[widget.videoUrl];
        _loading = false;
      });
      return;
    }
    try {
      final bytes = await VideoThumbnail.thumbnailData(
        video: widget.videoUrl,
        imageFormat: ImageFormat.JPEG,
        maxWidth: 400,
        quality: 70,
        timeMs: 500,
      );
      _cache[widget.videoUrl] = bytes;
      if (mounted) {
        setState(() {
          _thumbnail = bytes;
          _loading = false;
        });
      }
    } catch (e) {
      _cache[widget.videoUrl] = null;
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading || _thumbnail == null) {
      return Container(
          color: const Color(0xFF1A1A2E),
          child: const Center(
              child: Icon(Icons.videocam, size: 48, color: Colors.grey)));
    }
    return Image.memory(_thumbnail!,
        fit: BoxFit.cover, width: double.infinity, height: 200);
  }
}

// ============================================================================
// TYPING ANIMATION WIDGET
// ============================================================================

class TypingAnimationWidget extends StatefulWidget {
  const TypingAnimationWidget({super.key});

  @override
  State<TypingAnimationWidget> createState() => _TypingAnimationWidgetState();
}

class _TypingAnimationWidgetState extends State<TypingAnimationWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
        duration: const Duration(milliseconds: 900), vsync: this)
      ..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Row(mainAxisSize: MainAxisSize.min, children: [
      _buildDot(0),
      const SizedBox(width: 4),
      _buildDot(1),
      const SizedBox(width: 4),
      _buildDot(2),
    ]);
  }

  Widget _buildDot(int index) {
    final animation = CurvedAnimation(
        parent: _controller,
        curve: Interval(index * 0.15, index * 0.15 + 0.4,
            curve: Curves.easeInOut));
    return FadeTransition(
      opacity: animation,
      child: Container(
          width: 8,
          height: 8,
          decoration: const BoxDecoration(
              color: Color(0xFF34B7F1), shape: BoxShape.circle)),
    );
  }
}

// ============================================================================
// MAIN CHAT SCREEN
// ============================================================================

class ChatScreen extends StatefulWidget {
  final String channelId;
  final String? fixtureId;
  final Fixture? fixture;
  final String userId;
  final String username;
  final String? authToken;
  final bool isLoggedIn;
  final Set<String> comradesList;
  final String? userVoteSelection;

  const ChatScreen({
    super.key,
    required this.channelId,
    this.fixtureId,
    this.fixture,
    required this.userId,
    required this.username,
    this.authToken,
    required this.isLoggedIn,
    required this.comradesList,
    this.userVoteSelection,
  });

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> with WidgetsBindingObserver {
  // ==========================================================================
  // DATA
  // ==========================================================================
  final List<ChatMessage> _messages = [];
  final List<String> _typingUsers = [];
  final ChatDatabaseService _db = ChatDatabaseService();
  bool _messageSent = false;
  String? _latestLiveMessageId;
  Timer? _latestLiveHighlightTimer;

  // Vote data
  int _homeVotes = 0;
  int _awayVotes = 0;
  int _drawVotes = 0;
  String? _userVoteSelection;
  List<Voter> _voters = [];

  // Match update data
  int _homeScore = 0;
  int _awayScore = 0;
  int _minutesPlayed = 0;
  String _minuteDisplay = "0'";
  String _matchStatus = 'upcoming';
  bool _isLive = false;

  // Comrade data for carousel
  List<Map<String, dynamic>> _realComrades = [];
  bool _loadingComrades = true;
  final Set<String> _addedComradeIds = {};
  bool _isCastingVote = false;

  // ==========================================================================
  // CAROUSEL SYSTEM
  // ==========================================================================
  late PageController _carouselController;
  int _currentCarouselIndex = 0;
  bool _isCarouselRunning = false;
  Timer? _carouselTimer;
  List<CarouselItem> _carouselItems = [];
  final Set<String> _preloadedAdUnitIds = {};

  // ==========================================================================
  // UI STATE
  // ==========================================================================
  bool _loading = true;
  bool _isConnected = false;
  bool _isSendingMessage = false;
  bool _isUploadingMedia = false;
  bool _showVotesSection = false;

  // ==========================================================================
  // CONTROLLERS
  // ==========================================================================
  final TextEditingController _messageCtrl = TextEditingController();
  final ScrollController _chatScroll = ScrollController();
  final ScrollController _voterScroll = ScrollController();
  final FocusNode _focusNode = FocusNode();
  Timer? _typingTimer;
  Timer? _reconnectTimer;
  Timer? _scrollToBottomTimer;

  // ==========================================================================
  // REPLY STATE
  // ==========================================================================
  ReplyData? _replyingTo;

  // ==========================================================================
  // MEDIA PICKER
  // ==========================================================================
  final ImagePicker _picker = ImagePicker();

  // ==========================================================================
  // WEBSOCKET
  // ==========================================================================
  final WebSocketService _ws = WebSocketService();
  bool _webSocketSetupDone = false;

  // ==========================================================================
  // CONSTANTS
  // ==========================================================================
  static const String _api = 'https://clash-api-m5mr.onrender.com/api';

  // ==========================================================================
  // GETTERS
  // ==========================================================================
  String get _roomId => widget.fixtureId != null
      ? '${widget.channelId}_${widget.fixtureId}'
      : '${widget.channelId}_overall';

  String _adUnitIdForIndex(int index) {
    final ids = AdHelper.carouselAdUnitIds;
    if (ids.isEmpty) return '';
    return ids[index % ids.length];
  }

  int get _totalVotes => _homeVotes + _awayVotes + _drawVotes;
  bool get _hasVotes => _totalVotes > 0;

  // ==========================================================================
  // FETCH COMRADES FOR CAROUSEL - WITH APPCACHE
  // ==========================================================================
  Future<void> _fetchRealComrades({bool forceRefresh = false}) async {
    if (!forceRefresh && AppCache.comrades.isNotEmpty) {
      debugPrint(
          '⚡ INSTANT: ${AppCache.comrades.length} comrades from AppCache');
      setState(() {
        _realComrades = List<Map<String, dynamic>>.from(AppCache.comrades);
        _loadingComrades = false;
      });
      _buildCarouselItems();
      return;
    }

    if (!forceRefresh) {
      final cachedComrades = await ComradeCacheService().getCachedComrades();
      if (cachedComrades.isNotEmpty) {
        debugPrint(
            '📦 Using disk cached comrades (${cachedComrades.length} users)');
        setState(() {
          _realComrades = cachedComrades;
          _loadingComrades = false;
        });
        _buildCarouselItems();
        _fetchRealComradesFromApi(forceRefresh: true);
        return;
      }
    }

    await _fetchRealComradesFromApi(forceRefresh: forceRefresh);
  }

  Future<void> _fetchRealComradesFromApi({bool forceRefresh = false}) async {
    setState(() => _loadingComrades = true);
    try {
      final url = '$_api/profile/profiles';
      final headers = {'Content-Type': 'application/json'};
      if (widget.authToken != null && widget.authToken!.isNotEmpty) {
        headers['Authorization'] = 'Bearer ${widget.authToken}';
      }

      final response = await http
          .get(Uri.parse(url), headers: headers)
          .timeout(const Duration(seconds: 30));

      if (response.statusCode == 200 && mounted) {
        final List<dynamic> data = json.decode(response.body);
        final List<Map<String, dynamic>> profiles =
            data.cast<Map<String, dynamic>>();

        List<Map<String, dynamic>> availableUsers;
        if (widget.isLoggedIn && widget.userId.isNotEmpty) {
          availableUsers = profiles.where((profile) {
            final profileUserId = profile['user_id']?.toString() ?? '';
            return profileUserId != widget.userId;
          }).toList();
        } else {
          availableUsers = List.from(profiles);
        }

        final formattedComrades = availableUsers
            .map((item) => {
                  'id': item['user_id']?.toString() ?? '',
                  'nickname': item['nickname']?.toString() ??
                      item['username']?.toString() ??
                      'Fan',
                  'club': item['club_fan']?.toString() ?? 'Football Fan',
                  'country': item['country_fan']?.toString() ?? 'World',
                  'username': item['username']?.toString() ?? 'user',
                })
            .toList();

        AppCache.comrades = formattedComrades;
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('cached_comrades', jsonEncode(formattedComrades));

        if (mounted) {
          setState(() {
            _realComrades = formattedComrades;
            _loadingComrades = false;
          });
          _buildCarouselItems();
        }
      } else {
        if (mounted) {
          setState(() => _loadingComrades = false);
          _buildCarouselItems();
        }
      }
    } catch (e) {
      debugPrint('❌ Error fetching users: $e');
      if (mounted) {
        setState(() => _loadingComrades = false);
        _buildCarouselItems();
      }
    }
  }

  // ==========================================================================
  // BUILD CAROUSEL ITEMS - WITH MATCH UPDATES
  // ==========================================================================
  void _buildCarouselItems() {
    if (!mounted) return;

    final List<CarouselItem> newItems = [];

    // Always add game info if fixture exists
    if (widget.fixture != null) {
      final updatedFixture = Fixture(
        id: widget.fixture!.id,
        matchId: widget.fixture!.matchId,
        homeTeam: widget.fixture!.homeTeam,
        awayTeam: widget.fixture!.awayTeam,
        league: widget.fixture!.league,
        homeWin: widget.fixture!.homeWin,
        awayWin: widget.fixture!.awayWin,
        draw: widget.fixture!.draw,
        date: widget.fixture!.date,
        time: widget.fixture!.time,
        homeScore: _homeScore,
        awayScore: _awayScore,
        status: _matchStatus,
        isLive: _isLive,
        availableForVoting: widget.fixture!.availableForVoting,
        source: widget.fixture!.source,
        scrapedAt: widget.fixture!.scrapedAt,
        dateIso: widget.fixture!.dateIso,
        subFixtures: widget.fixture!.subFixtures,
        minutesPlayed: _minutesPlayed,
        minuteDisplay: _minuteDisplay,
      );

      newItems.add(CarouselItem.matchUpdate(
        matchUpdateData: {
          'homeScore': _homeScore,
          'awayScore': _awayScore,
          'minutesPlayed': _minutesPlayed,
          'minuteDisplay': _minuteDisplay,
          'status': _matchStatus,
          'isLive': _isLive,
        },
        fixture: updatedFixture,
      ));

      newItems.add(CarouselItem.gameInfo(
        fixture: updatedFixture,
        userVoteSelection: _userVoteSelection,
      ));
    }

    if (widget.fixtureId != null) {
      newItems.add(CarouselItem.voteStats(
        fixture: widget.fixture,
        homeVotes: _homeVotes,
        awayVotes: _awayVotes,
        drawVotes: _drawVotes,
        userVoteSelection: _userVoteSelection,
      ));

      if (_realComrades.isNotEmpty) {
        final comradesToShow = _realComrades.take(2).toList();
        for (var comrade in comradesToShow) {
          final isAlreadyComrade =
              widget.comradesList.contains(comrade['id']) ||
                  _addedComradeIds.contains(comrade['id']);
          newItems.add(CarouselItem.comrade(
            comradeData: {
              'id': comrade['id'] ?? '',
              'nickname': comrade['nickname'] ?? 'Fan',
              'username': comrade['username'] ?? 'user',
              'club': comrade['club'] ?? 'Football',
              'country': comrade['country'] ?? 'World',
              'votedFor': 'No vote yet',
              'fixture': widget.fixture?.homeTeam ?? 'Match',
            },
            added: isAlreadyComrade,
          ));
        }
      }
    }

    // Insert ads
    if (newItems.isNotEmpty) {
      final adIds = AdHelper.carouselAdUnitIds;
      if (adIds.isNotEmpty && adIds[0].isNotEmpty) {
        if (newItems.length >= 2 && adIds.length > 1) {
          newItems.insert(1, CarouselItem.ad(adUnitId: adIds[1]));
        }
        newItems.add(CarouselItem.ad(adUnitId: adIds[0]));
      }
    }

    // Fallback fixture
    if (newItems.isEmpty) {
      final now = DateTime.now();
      final fallbackFixture = Fixture(
        id: 'default',
        matchId: 'default_match',
        homeTeam: 'Clash',
        awayTeam: 'Chat',
        league: 'Clash Chat',
        homeWin: 0.0,
        awayWin: 0.0,
        draw: 0.0,
        date:
            '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}',
        time:
            '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}',
        status: 'upcoming',
        isLive: false,
        availableForVoting: true,
        source: 'fallback',
        scrapedAt: now,
        dateIso: now.toIso8601String(),
        subFixtures: [],
      );

      newItems.add(CarouselItem.gameInfo(
        fixture: fallbackFixture,
        userVoteSelection: null,
      ));
    }

    if (mounted) {
      setState(() => _carouselItems = newItems);
      if (_carouselItems.length > 1 && !_isCarouselRunning) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted && _carouselController.hasClients) {
            _startCarouselAutoScroll();
          }
        });
      }
    }
  }

  void _startCarouselAutoScroll() {
    if (_isCarouselRunning) return;
    if (_carouselItems.length <= 1) return;
    if (!_carouselController.hasClients) return;

    _isCarouselRunning = true;
    _carouselTimer?.cancel();

    bool goingForward = true;
    _carouselTimer = Timer.periodic(const Duration(seconds: 5), (timer) {
      if (!mounted || !_isCarouselRunning) {
        timer.cancel();
        _isCarouselRunning = false;
        return;
      }
      if (!_carouselController.hasClients) {
        timer.cancel();
        _isCarouselRunning = false;
        return;
      }

      final itemCount = _carouselItems.length;
      if (itemCount <= 1) {
        timer.cancel();
        _isCarouselRunning = false;
        return;
      }

      int currentPage =
          _carouselController.page?.round() ?? _currentCarouselIndex;
      int nextIndex;
      if (goingForward) {
        nextIndex = currentPage + 1;
        if (nextIndex >= itemCount) {
          goingForward = false;
          nextIndex = currentPage - 1;
        }
      } else {
        nextIndex = currentPage - 1;
        if (nextIndex < 0) {
          goingForward = true;
          nextIndex = currentPage + 1;
        }
      }
      nextIndex = nextIndex.clamp(0, itemCount - 1);
      _carouselController.animateToPage(nextIndex,
          duration: const Duration(milliseconds: 400),
          curve: Curves.easeInOutCubic);
    });
  }

  void _stopCarouselAutoScroll() {
    _isCarouselRunning = false;
    _carouselTimer?.cancel();
    _carouselTimer = null;
  }

  // ==========================================================================
  // CAROUSEL ITEM WIDGETS
  // ==========================================================================

  Widget _buildMatchUpdateCard(Fixture f, Map<String, dynamic> updateData) {
    final isLeftAligned = _currentCarouselIndex % 2 == 0;
    final homeScore = updateData['homeScore'] ?? 0;
    final awayScore = updateData['awayScore'] ?? 0;
    final minutes = updateData['minutesPlayed'] ?? 0;
    final minuteDisplay = updateData['minuteDisplay'] ?? "${minutes}'";
    final status = updateData['status'] ?? 'upcoming';
    final isLive = updateData['isLive'] ?? false;

    String statusText;
    Color statusColor;
    if (status == 'live' || isLive) {
      if (minutes == 45 || minuteDisplay == 'Half Time') {
        statusText = '⚡ HT';
        statusColor = Colors.orange;
      } else if (minutes >= 90) {
        statusText = '🏁 FT';
        statusColor = Colors.red;
      } else {
        statusText = '🔴 LIVE';
        statusColor = Colors.red;
      }
    } else if (status == 'completed') {
      statusText = '✅ FT';
      statusColor = Colors.green;
    } else if (status == 'upcoming') {
      statusText = '⏳ UPCOMING';
      statusColor = Colors.grey;
    } else if (status == 'soon') {
      statusText = '🔜 SOON';
      statusColor = Colors.orange;
    } else {
      statusText = status.toUpperCase();
      statusColor = Colors.grey;
    }

    return Container(
      height: 56,
      margin: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
      child: SpeechBubble(
        isLeftAligned: isLeftAligned,
        color:
            isLive ? FanColors.live.withValues(alpha: 0.08) : FanColors.surface,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: statusColor.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(4),
              ),
              child: Text(
                statusText,
                style: TextStyle(
                  fontSize: 8,
                  fontWeight: FontWeight.w700,
                  color: statusColor,
                ),
              ),
            ),
            const SizedBox(width: 6),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: isLive
                    ? Colors.red.withValues(alpha: 0.1)
                    : FanColors.primary.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(4),
              ),
              child: Text(
                '$homeScore - $awayScore',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: isLive ? Colors.red : FanColors.primary,
                ),
              ),
            ),
            const SizedBox(width: 6),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
              decoration: BoxDecoration(
                color: FanColors.surface,
                borderRadius: BorderRadius.circular(4),
                border:
                    Border.all(color: FanColors.border.withValues(alpha: 0.2)),
              ),
              child: Text(
                minuteDisplay,
                style: TextStyle(
                  fontSize: 9,
                  color: FanColors.textSecondary,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            const Spacer(),
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    f.homeTeam,
                    style: TextStyle(
                      fontSize: 9,
                      fontWeight: FontWeight.w600,
                      color: FanColors.textPrimary,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    'vs',
                    style: TextStyle(
                      fontSize: 8,
                      color: FanColors.textSecondary,
                    ),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    f.awayTeam,
                    style: TextStyle(
                      fontSize: 9,
                      fontWeight: FontWeight.w600,
                      color: FanColors.textPrimary,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            if (_carouselItems.length > 1) _buildCarouselDots(),
          ],
        ),
      ),
    );
  }

  Widget _buildGameInfoCard(Fixture f, String? userVoteSelection) {
    final isLeftAligned = _currentCarouselIndex % 2 == 0;

    return Container(
      height: 56,
      margin: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
      child: SpeechBubble(
        isLeftAligned: isLeftAligned,
        color: FanColors.surface,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        child: Row(
          children: [
            Expanded(
              child: Text(
                f.homeTeam,
                style: const TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    color: FanColors.textPrimary),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 6),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                    color: FanColors.primary.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(6)),
                child: Text(
                  f.homeScore != null && f.awayScore != null
                      ? '${f.homeScore} - ${f.awayScore}'
                      : (f.league.isNotEmpty == true ? f.league : 'VS'),
                  style: const TextStyle(
                      fontSize: 9,
                      fontWeight: FontWeight.w800,
                      color: FanColors.primary),
                ),
              ),
            ),
            Expanded(
              child: Text(
                f.awayTeam,
                style: const TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    color: FanColors.textPrimary),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
              ),
            ),
            if (_carouselItems.length > 1) _buildCarouselDots(),
          ],
        ),
      ),
    );
  }

  // ==========================================================================
  // COMMENTARY - FETCH FROM APPCACHE FIRST
  // ==========================================================================
  Future<void> _loadCommentaryFromAppCache() async {
    if (widget.fixtureId == null) return;

    // Check AppCache for cached messages (including commentary)
    final cachedMessages =
        AppCache.getCachedMessages(widget.channelId, widget.fixtureId);

    if (cachedMessages != null && cachedMessages.isNotEmpty) {
      // Extract commentary messages from cache
      final commentaryMessages = cachedMessages
          .where((msg) => msg['isCommentary'] == true)
          .map((msg) => ChatMessage(
                id: msg['id'] ?? '',
                userId: msg['userId'] ?? '__commentary__',
                username: msg['username'] ?? 'Live Commentary',
                text: msg['text'] ?? '',
                selection: msg['selection'],
                timestamp: DateTime.parse(
                    msg['timestamp'] ?? DateTime.now().toIso8601String()),
                status: MessageStatus.delivered,
                isCommentary: true,
                commentaryType: msg['commentaryType'],
              ))
          .toList();

      if (commentaryMessages.isNotEmpty) {
        debugPrint(
            '📦 Loaded ${commentaryMessages.length} commentary from AppCache');
        setState(() {
          _messages.addAll(commentaryMessages);
          _sortMessages();
        });
        _scrollToBottom();
        return;
      }
    }

    // Not in cache - fetch from API based on game type
    if (_isHistoryGame) {
      debugPrint('📜 History game - fetching commentary from API');
      await _fetchHistoryCommentaryFromApi();
    } else {
      debugPrint('🔴 Live/upcoming game - fetching commentary from API');
      await _fetchCommentaryFromApi();
    }
  }

  Future<void> _fetchHistoryCommentaryFromApi() async {
    if (widget.fixtureId == null) return;

    try {
      final response = await http
          .get(
            Uri.parse('$_api/games/history/${widget.fixtureId}'),
            headers: _headers(),
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200 && mounted) {
        final data = json.decode(response.body);
        final historyGame = data['data'];

        if (historyGame != null) {
          final commentaryList = historyGame['commentary'] ?? [];
          final entries = commentaryList
              .whereType<Map>()
              .map((e) => ChatMessage.commentary(
                    minute: e['minute'] ?? 0,
                    text: e['text'] ?? '',
                    type: e['type'] ?? 'update',
                    createdAt: _parseCommentaryTimestamp(e['createdAt']),
                  ))
              .toList();

          final existingIds = _messages.map((m) => m.id).toSet();
          final newEntries =
              entries.where((c) => !existingIds.contains(c.id)).toList();

          if (newEntries.isNotEmpty) {
            debugPrint(
                '📜 Loaded ${newEntries.length} commentary from history');
            setState(() {
              _messages.addAll(newEntries);
              _sortMessages();
            });

            // ✅ SAVE TO APPCACHE FOR FUTURE USE
            _saveMessagesToAppCache();
            _scrollToBottom();
          }
        }
      } else {
        debugPrint('⚠️ History endpoint failed, trying regular commentary');
        await _fetchCommentaryFromApi();
      }
    } catch (e) {
      debugPrint('❌ Error fetching history commentary: $e');
      await _fetchCommentaryFromApi();
    }
  }

  Future<void> _fetchCommentaryFromApi() async {
    if (widget.fixtureId == null) return;
    try {
      final response = await http
          .get(
            Uri.parse(
                '$_api/games/${widget.fixtureId}/commentary/latest?limit=50'),
            headers: _headers(),
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200 && mounted) {
        final data = json.decode(response.body);
        final List<dynamic> raw = data['commentary'] ?? [];

        final entries = raw
            .whereType<Map>()
            .map((e) => ChatMessage.commentary(
                  minute: e['minute'] ?? 0,
                  text: e['text'] ?? '',
                  type: e['type'] ?? 'update',
                  createdAt: _parseCommentaryTimestamp(e['createdAt']),
                ))
            .toList();

        final existingIds = _messages.map((m) => m.id).toSet();
        final newEntries =
            entries.where((c) => !existingIds.contains(c.id)).toList();

        if (newEntries.isNotEmpty) {
          setState(() {
            _messages.addAll(newEntries);
            _sortMessages();
          });
          _saveMessagesToAppCache();
          _scrollToBottom();
        }
      }
    } catch (e) {
      debugPrint('❌ Error fetching commentary: $e');
    }
  }

  // ==========================================================================
  // HANDLE NEW COMMENTARY FROM WEBSOCKET (REAL-TIME)
  // ==========================================================================
  void _handleNewCommentary(Map<String, dynamic> payload) {
    // ✅ Skip if it's a history game (no real-time updates needed)
    if (_isHistoryGame) return;

    final entryData = payload['payload'] ?? payload;
    final createdAt = _parseCommentaryTimestamp(entryData['createdAt']);

    final entry = ChatMessage.commentary(
      minute: entryData['minute'] ?? 0,
      text: entryData['text'] ?? '',
      type: entryData['type'] ?? 'update',
      createdAt: createdAt,
    );

    if (_messages.any((m) => m.id == entry.id)) return;

    debugPrint('📢 New commentary: ${entry.text}');

    if (mounted) {
      setState(() {
        _messages.add(entry);
        _sortMessages();
      });

      _saveMessagesToAppCache(); // ✅ SAVE TO APPCACHE
      _markAsLatestLiveArrival(entry.id);

      WidgetsBinding.instance.addPostFrameCallback((_) {
        _scrollToBottom();
      });
    }
  }

  void _handleServerConnectedAck(Map<String, dynamic> payload) {
    debugPrint('✅ Server confirmed WebSocket connection');
    if (widget.fixtureId != null && !_isHistoryGame) {
      _ws.send('get.commentary', {'fixtureId': widget.fixtureId});
    }
  }

  void _markAsLatestLiveArrival(String messageId) {
    setState(() => _latestLiveMessageId = messageId);

    _latestLiveHighlightTimer?.cancel();
    _latestLiveHighlightTimer = Timer(const Duration(seconds: 6), () {
      if (mounted && _latestLiveMessageId == messageId) {
        setState(() => _latestLiveMessageId = null);
      }
    });
  }

  Widget _buildComradeCard(
      Map<String, dynamic> comrade, bool added, int index) {
    final isLeftAligned = index % 2 == 0;

    final nickname = comrade['nickname'] ?? 'Fan';
    final username = comrade['username'] ?? 'user';
    final team = comrade['votedFor'] ?? 'No vote';
    final fixtureText = comrade['fixture'] ?? 'Match';
    final isLoading = nickname == 'Loading...';
    final isPrompt = comrade['id'] == 'prompt';

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
      child: SpeechBubble(
        isLeftAligned: isLeftAligned,
        color: FanColors.surface,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        child: Row(
          children: [
            GestureDetector(
              onTap: isLoading || isPrompt
                  ? null
                  : () => _showComradeProfile(comrade),
              child: Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: isLoading || isPrompt
                      ? FanColors.textTertiary.withValues(alpha: 0.2)
                      : FanColors.primary.withValues(alpha: 0.1),
                  shape: BoxShape.circle,
                ),
                child: isLoading
                    ? const Center(
                        child: SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 1.5),
                        ),
                      )
                    : Center(
                        child: Text(
                          isPrompt ? '➕' : nickname[0].toUpperCase(),
                          style: TextStyle(
                            fontSize: isPrompt ? 16 : 14,
                            fontWeight: FontWeight.w600,
                            color: isPrompt
                                ? FanColors.primary
                                : FanColors.primary,
                          ),
                        ),
                      ),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        nickname,
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight:
                              isPrompt ? FontWeight.w600 : FontWeight.w600,
                          color: isPrompt
                              ? FanColors.primary
                              : FanColors.textPrimary,
                        ),
                      ),
                      const SizedBox(width: 4),
                      Text(
                        isPrompt ? '' : '@$username',
                        style: const TextStyle(
                            fontSize: 9, color: FanColors.textSecondary),
                      ),
                    ],
                  ),
                  const SizedBox(height: 2),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: isPrompt
                          ? FanColors.primary.withValues(alpha: 0.15)
                          : FanColors.primary.withValues(alpha: 0.08),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          isPrompt ? Icons.group_add : Icons.how_to_vote,
                          size: 10,
                          color: isPrompt
                              ? FanColors.primary
                              : FanColors.primary.withValues(alpha: 0.7),
                        ),
                        const SizedBox(width: 4),
                        Text(
                          isPrompt
                              ? 'Add comrades to see votes!'
                              : 'voted $team in $fixtureText',
                          style: TextStyle(
                            fontSize: 9,
                            color: isPrompt
                                ? FanColors.primary
                                : FanColors.textPrimary,
                            fontWeight:
                                isPrompt ? FontWeight.w500 : FontWeight.normal,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            if (!isPrompt)
              GestureDetector(
                onTap: () {
                  if (added) return;
                  if (!widget.isLoggedIn) return;
                  if (isLoading) return;
                  _addComradeDirectly(comrade);
                },
                child: Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    color: added
                        ? FanColors.primary.withValues(alpha: 0.1)
                        : (isLoading
                            ? FanColors.textTertiary.withValues(alpha: 0.3)
                            : FanColors.primary),
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: added
                        ? Icon(
                            Icons.check,
                            size: 16,
                            color: FanColors.primary.withValues(alpha: 0.7),
                          )
                        : Icon(
                            isLoading
                                ? Icons.access_time
                                : Icons.person_add_alt_rounded,
                            size: 16,
                            color: isLoading
                                ? FanColors.textSecondary
                                : Colors.white,
                          ),
                  ),
                ),
              ),
            if (_carouselItems.length > 1) _buildCarouselDots(),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickVoteChip(String label, String selection, Color color) {
    return GestureDetector(
      onTap: () => _castQuickVote(selection),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withValues(alpha: 0.3)),
        ),
        child: Text(
          label,
          style: TextStyle(
              fontSize: 10, fontWeight: FontWeight.w600, color: color),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
      ),
    );
  }

  Widget _buildVoteStatsCard(Fixture f, int homeVotes, int awayVotes,
      int drawVotes, String? userVoteSelection) {
    final total = homeVotes + awayVotes + drawVotes;
    final isLeftAligned = _currentCarouselIndex % 2 == 0;

    if (total == 0) {
      return Container(
        height: 56,
        margin: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
        child: SpeechBubble(
          isLeftAligned: isLeftAligned,
          color: FanColors.surface,
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          child: Row(
            children: [
              Expanded(
                child: _isCastingVote
                    ? const Center(
                        child: SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        ),
                      )
                    : Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          _buildQuickVoteChip(
                              f.homeTeam, 'home_team', FanColors.primary),
                          _buildQuickVoteChip(
                              'Draw', 'draw', const Color(0xFF8B5CF6)),
                          _buildQuickVoteChip(
                              f.awayTeam, 'away_team', const Color(0xFF2563EB)),
                        ],
                      ),
              ),
              if (_carouselItems.length > 1) _buildCarouselDots(),
            ],
          ),
        ),
      );
    }

    final homeP = ((homeVotes / total) * 100).round();
    final awayP = ((awayVotes / total) * 100).round();
    final drawP = 100 - homeP - awayP;

    return GestureDetector(
      onTap: _openVotesModal,
      child: Container(
        height: 56,
        margin: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
        child: SpeechBubble(
          isLeftAligned: isLeftAligned,
          color: FanColors.surface,
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          child: Row(
            children: [
              Expanded(
                flex: homeP,
                child: Container(
                  height: 6,
                  decoration: BoxDecoration(
                    color: FanColors.primary,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(4),
                      bottomLeft: Radius.circular(4),
                    ),
                  ),
                ),
              ),
              Expanded(
                flex: drawP,
                child: Container(
                  height: 6,
                  color: const Color(0xFF8B5CF6),
                ),
              ),
              Expanded(
                flex: awayP,
                child: Container(
                  height: 6,
                  decoration: BoxDecoration(
                    color: const Color(0xFF2563EB),
                    borderRadius: BorderRadius.only(
                      topRight: Radius.circular(4),
                      bottomRight: Radius.circular(4),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Text(
                '$total',
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                  color: FanColors.textPrimary,
                ),
              ),
              if (_carouselItems.length > 1) _buildCarouselDots(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCarouselDots() {
    return Padding(
      padding: const EdgeInsets.only(left: 6),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: List.generate(_carouselItems.length, (i) {
          final active = i == _currentCarouselIndex;
          return Container(
            margin: const EdgeInsets.symmetric(horizontal: 1),
            width: active ? 5 : 3,
            height: active ? 5 : 3,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: active
                  ? FanColors.primary
                  : FanColors.textTertiary.withValues(alpha: 0.4),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildCarouselItemWidget(CarouselItem item, int index) {
    switch (item.type) {
      case CarouselItemType.matchUpdate:
        return _buildMatchUpdateCard(item.fixture!, item.matchUpdateData!);
      case CarouselItemType.gameInfo:
        return _buildGameInfoCard(item.fixture!, item.userVoteSelection);
      case CarouselItemType.voteStats:
        return _buildVoteStatsCard(item.fixture!, item.homeVotes!,
            item.awayVotes!, item.drawVotes!, item.userVoteSelection);
      case CarouselItemType.comrade:
        return _buildComradeCard(item.comradeData!, item.added, index);
      case CarouselItemType.ad:
        return ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Container(
            height: 56,
            margin: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
            decoration: BoxDecoration(
              color: FanColors.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: FanColors.primary.withValues(alpha: 0.12),
                width: 0.5,
              ),
            ),
            child: item.adUnitId == null || item.adUnitId!.isEmpty
                ? const FallbackAdWidget()
                : AdSlotWidget(
                    key: ValueKey('ad_slot_${item.adUnitId}_$index'),
                    adUnitId: item.adUnitId!,
                    position: index,
                  ),
          ),
        );
    }
  }

  Widget _buildCarousel() {
    if (_carouselItems.isEmpty) {
      return const SizedBox(height: 60);
    }

    return SizedBox(
      height: 60,
      child: PageView.builder(
        controller: _carouselController,
        onPageChanged: (index) => setState(() => _currentCarouselIndex = index),
        itemCount: _carouselItems.length,
        itemBuilder: (context, index) {
          final item = _carouselItems[index];
          return KeepAliveWrapper(
            key: ValueKey('carousel_item_$index'),
            child: _buildCarouselItemWidget(item, index),
          );
        },
      ),
    );
  }

  // ==========================================================================
  // VOTE METHODS
  // ==========================================================================

  void _openVotesModal() async {
    if (widget.fixture == null) return;

    final bool showFullModal = await _checkVotesButtonVisibility();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => SwipeableVotePledgeModal(
        fixture: widget.fixture!,
        userId: widget.userId,
        username: widget.username,
        authToken: widget.authToken,
        isLoggedIn: widget.isLoggedIn,
        hasUserVoted: _userVoteSelection != null,
        userVoteSelection: _userVoteSelection,
        comradesList: widget.comradesList,
        showPledgesTab: showFullModal,
        showBetsTab: showFullModal,
        channelId: widget.channelId,
        onVote: _castQuickVote,
        onPledge: _handlePledge,
      ),
    );
  }

  Future<bool> _handlePledge(String selection, double amount) async {
    if (!widget.isLoggedIn) {
      Fluttertoast.showToast(msg: '🔒 Log in to pledge');
      return false;
    }

    if (widget.fixtureId == null) {
      Fluttertoast.showToast(msg: '❌ No fixture selected');
      return false;
    }

    try {
      final result = await BetService.createBet(
        fixtureId: widget.fixtureId!,
        starterId: widget.userId,
        starterName: widget.username,
        starterSelection: selection,
        amount: amount,
        channelId: widget.channelId,
        authToken: widget.authToken,
      );

      if (result['success'] == true) {
        Fluttertoast.showToast(
          msg: '✅ Bet of KES ${amount.toStringAsFixed(2)} placed!',
          backgroundColor: Colors.green,
        );
        return true;
      } else {
        Fluttertoast.showToast(
          msg: result['message'] ?? '❌ Bet failed',
          backgroundColor: Colors.red,
        );
        return false;
      }
    } catch (e) {
      debugPrint('❌ Bet error: $e');
      Fluttertoast.showToast(
        msg: '❌ Network error creating bet',
        backgroundColor: Colors.red,
      );
      return false;
    }
  }

  Future<bool> _castQuickVote(String localSelection) async {
    if (widget.fixtureId == null) return false;
    if (!widget.isLoggedIn) {
      Fluttertoast.showToast(msg: '🔒 Log in to vote');
      return false;
    }
    if (_userVoteSelection != null || _isCastingVote) return false;

    final backendSelection = localSelection == 'home_team'
        ? 'home'
        : localSelection == 'away_team'
            ? 'away'
            : 'draw';

    setState(() => _isCastingVote = true);

    try {
      final response = await http
          .post(
            Uri.parse('$_api/actions/vote/cast'),
            headers: _headers(),
            body: json.encode({
              'fixture_id': widget.fixtureId,
              'user_id': widget.userId,
              'username': widget.username,
              'selection': backendSelection,
            }),
          )
          .timeout(const Duration(seconds: 15));

      if (response.statusCode == 200 || response.statusCode == 201) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          setState(() {
            _userVoteSelection = localSelection;
            if (localSelection == 'home_team') _homeVotes++;
            if (localSelection == 'away_team') _awayVotes++;
            if (localSelection == 'draw') _drawVotes++;
          });
          _buildCarouselItems();
          _fetchVoteCounts();
          return true;
        } else {
          Fluttertoast.showToast(msg: data['message'] ?? 'Vote failed');
          return false;
        }
      } else if (response.statusCode == 409) {
        Fluttertoast.showToast(msg: 'You already voted for this fixture');
        _fetchVoteCounts();
        return false;
      } else {
        Fluttertoast.showToast(msg: 'Failed to submit vote');
        return false;
      }
    } catch (e) {
      Fluttertoast.showToast(msg: 'Network error casting vote');
      return false;
    } finally {
      if (mounted) setState(() => _isCastingVote = false);
    }
  }

  // ==========================================================================
  // MATCH UPDATE HANDLERS
  // ==========================================================================

  void _handleMatchStatusUpdate(Map<String, dynamic> payload) {
    final fixtureId = payload['fixture_id']?.toString();
    if (fixtureId != widget.fixtureId) return;

    final status = payload['status']?.toString() ?? 'live';
    final homeScore = payload['home_score'] as int? ?? _homeScore;
    final awayScore = payload['away_score'] as int? ?? _awayScore;
    final minutesPlayed = payload['minutes_played'] as int? ?? _minutesPlayed;
    final minuteDisplay =
        payload['minute_display']?.toString() ?? "${minutesPlayed}'";
    final isLive = status == 'live' || status == 'half_time';

    setState(() {
      _matchStatus = status;
      _homeScore = homeScore;
      _awayScore = awayScore;
      _minutesPlayed = minutesPlayed;
      _minuteDisplay = minuteDisplay;
      _isLive = isLive;
    });

    _buildCarouselItems();
  }

  void _handleGoalEvent(Map<String, dynamic> payload) {
    final fixtureId = payload['fixture_id']?.toString();
    if (fixtureId != widget.fixtureId) return;

    final homeScore = payload['home_score'] as int? ?? _homeScore;
    final awayScore = payload['away_score'] as int? ?? _awayScore;
    final minutesPlayed = payload['minutes_played'] as int? ?? _minutesPlayed;
    final minuteDisplay =
        payload['minute_display']?.toString() ?? "${minutesPlayed}'";
    final scorer = payload['scorer']?.toString() ?? 'Unknown';

    setState(() {
      _homeScore = homeScore;
      _awayScore = awayScore;
      _minutesPlayed = minutesPlayed;
      _minuteDisplay = minuteDisplay;
    });

    _buildCarouselItems();

    Fluttertoast.showToast(
      msg: "⚽ GOAL! $scorer scores at $minuteDisplay",
      backgroundColor: Colors.green,
    );
  }

  // ==========================================================================
  // VOTE COUNTS
  // ==========================================================================

  Future<void> _fetchVoteCounts() async {
    if (widget.fixtureId == null) return;
    try {
      final response = await http.get(
          Uri.parse(
              '$_api/channels/channel/${widget.channelId}/fixtures/${widget.fixtureId}/votes'),
          headers: _headers());
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          _homeVotes = data['home_votes'] ?? 0;
          _awayVotes = data['away_votes'] ?? 0;
          _drawVotes = data['draw_votes'] ?? 0;
          _userVoteSelection = data['user_vote'];
        });
        _buildCarouselItems();
      } else {
        _buildCarouselItems();
      }
    } catch (e) {
      debugPrint('Error fetching vote counts: $e');
      _buildCarouselItems();
    }
  }

  void _handleVoteUpdate(Map<String, dynamic> payload) {
    final fixtureId = payload['fixture_id'] as String?;
    if (fixtureId != widget.fixtureId) return;
    setState(() {
      _homeVotes = payload['home_votes'] ?? _homeVotes;
      _awayVotes = payload['away_votes'] ?? _awayVotes;
      _drawVotes = payload['draw_votes'] ?? _drawVotes;
    });
    _buildCarouselItems();
    _fetchVoters();
  }

  // ==========================================================================
  // VOTERS
  // ==========================================================================

  Future<void> _fetchVoters() async {
    if (widget.fixtureId == null) return;
    try {
      final response = await http
          .get(
            Uri.parse('$_api/actions/vote/fixture/${widget.fixtureId}/voters'),
            headers: _headers(),
          )
          .timeout(const Duration(seconds: 10));
      if (response.statusCode == 200 && mounted) {
        final data = json.decode(response.body);
        if (data['success'] == true && data['voters'] is List) {
          final votersList = data['voters'] as List;
          final List<Voter> voters = [];
          for (var voter in votersList) {
            final uid = voter['userId']?.toString() ?? '';
            final uname = voter['userName']?.toString() ?? 'Anonymous';
            final sel = voter['selection']?.toString() ?? '';
            if (uid.isNotEmpty && sel.isNotEmpty) {
              if (widget.comradesList.contains(uid) || uid == widget.userId) {
                voters.add(Voter(
                    userId: uid,
                    username: uname,
                    selection: sel,
                    isComrade: widget.comradesList.contains(uid),
                    votedAt: DateTime.now()));
              }
            }
          }
          voters.sort((a, b) {
            if (a.userId == widget.userId) return -1;
            if (b.userId == widget.userId) return 1;
            return a.username.compareTo(b.username);
          });
          setState(() => _voters = voters);
        }
      }
    } catch (e) {
      debugPrint('Error fetching voters: $e');
    }
  }

  // ==========================================================================
  // MESSAGES - WITH APPCACHE
  // ==========================================================================

  Future<void> _loadMessages() async {
    setState(() => _loading = true);

    // 1. Load from AppCache FIRST
    final cachedMessages =
        AppCache.getCachedMessages(widget.channelId, widget.fixtureId);
    if (cachedMessages != null && cachedMessages.isNotEmpty) {
      final messages = cachedMessages
          .map((msgMap) => ChatMessage(
                id: msgMap['id'] ?? '',
                userId: msgMap['userId'] ?? '',
                username: msgMap['username'] ?? '',
                text: msgMap['text'] ?? '',
                selection: msgMap['selection'],
                timestamp: DateTime.parse(
                    msgMap['timestamp'] ?? DateTime.now().toIso8601String()),
                status: MessageStatus.values[msgMap['status'] ?? 1],
                isSeen: msgMap['isSeen'] ?? false,
                isCommentary: msgMap['isCommentary'] ?? false,
                commentaryType: msgMap['commentaryType'],
              ))
          .toList();

      setState(() {
        _messages.clear();
        _messages.addAll(messages);
        _sortMessages();
      });
      _scrollToBottom();
      debugPrint('📦 Loaded ${_messages.length} messages from AppCache');
    }

    // 2. Load commentary from AppCache
    await _loadCommentaryFromAppCache();

    // 3. Fallback to SQLite only if nothing came from AppCache at all
    if (_messages.isEmpty) {
      try {
        final sqliteMessages =
            await _db.getMessages(widget.channelId, widget.fixtureId);
        if (sqliteMessages.isNotEmpty) {
          setState(() {
            _messages.clear();
            _messages.addAll(sqliteMessages);
            _sortMessages();
          });
          _saveMessagesToAppCache();
          _scrollToBottom();
        }
      } catch (e) {
        debugPrint('Error loading messages: $e');
      }
    }

    // ✅ SINGLE, UNCONDITIONAL EXIT POINT — this is the actual fix
    if (mounted) setState(() => _loading = false);

    // 4. Sync from server in background
    _syncFromServer();

    // 5. Request latest commentary via WebSocket
    if (widget.fixtureId != null && _ws.isConnected) {
      _ws.send('get.commentary', {'fixtureId': widget.fixtureId});
    }
  }

  void _saveMessagesToAppCache() {
    final messagesMap = _messages
        .map((msg) => {
              'id': msg.id,
              'userId': msg.userId,
              'username': msg.username,
              'text': msg.text,
              'selection': msg.selection,
              'timestamp': msg.timestamp.toIso8601String(),
              'status': msg.status.index,
              'isSeen': msg.isSeen,
              'isCommentary': msg.isCommentary,
              'commentaryType': msg.commentaryType,
            })
        .toList();

    AppCache.cacheMessages(widget.channelId, widget.fixtureId, messagesMap);
  }

  Future<void> _syncFromServer() async {
    try {
      String url;
      if (widget.fixtureId != null) {
        url = '$_api/channels/messages'
            '?channel_id=${widget.channelId}'
            '&fixture_id=${widget.fixtureId}'
            '&limit=100';
      } else {
        url = '$_api/channels/messages'
            '?channel_id=${widget.channelId}'
            '&limit=100';
      }

      final response = await http
          .get(Uri.parse(url), headers: _headers())
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200 && mounted) {
        final data = json.decode(response.body);
        final List<dynamic> messagesData = data['messages'] ?? [];

        final existingIds = _messages.map((m) => m.id).toSet();
        bool hasNew = false;

        for (var item in messagesData) {
          String id = item['message_id'] ?? '';
          if (id.isEmpty) {
            final idObj = item['_id'];
            if (idObj is Map && idObj['\$oid'] != null) {
              id = idObj['\$oid'];
            } else if (idObj is String) {
              id = idObj;
            }
          }

          if (id.isEmpty || existingIds.contains(id)) continue;

          hasNew = true;

          ReplyData? replyTo;
          final replyToData = item['reply_to'];
          if (replyToData != null && replyToData is Map) {
            replyTo = ReplyData(
              messageId: replyToData['messageId'] ?? '',
              text: replyToData['text'] ?? '',
              username: replyToData['username'] ?? '',
              selection: replyToData['selection'],
              isMe: replyToData['isMe'] ?? false,
            );
          }

          DateTime timestamp;
          final sentAt = item['sent_at'];
          if (sentAt is Map) {
            final dateObj = sentAt['\$date'];
            if (dateObj is Map && dateObj['\$numberLong'] != null) {
              final milliseconds =
                  int.parse(dateObj['\$numberLong'].toString());
              timestamp = DateTime.fromMillisecondsSinceEpoch(milliseconds);
            } else if (dateObj is String) {
              timestamp = DateTime.parse(dateObj);
            } else {
              timestamp = DateTime.now();
            }
          } else if (sentAt is String) {
            timestamp = DateTime.parse(sentAt);
          } else {
            timestamp = DateTime.now();
          }

          final message = ChatMessage(
            id: id,
            userId: item['sender_id'] ?? '',
            username: item['sender_name'] ?? 'Anonymous',
            text: item['text'] ?? '',
            selection: item['selection'],
            timestamp: timestamp,
            status: MessageStatus.delivered,
            replyTo: replyTo,
            imageUrl: item['image_url'],
            videoUrl: item['video_url'],
            isImage: item['is_image'] ?? false,
            isVideo: item['is_video'] ?? false,
          );

          if (mounted) {
            setState(() => _messages.add(message));
          }
        }

        if (hasNew && mounted) {
          setState(() => _sortMessages());
          _saveMessagesToAppCache();
          WidgetsBinding.instance.addPostFrameCallback((_) {
            _scrollToBottom();
          });
        }
      }
    } catch (e) {
      debugPrint('❌ Sync error: $e');
    }
  }

  // ==========================================================================
  // HANDLE INCOMING MESSAGE (REAL-TIME)
  // ==========================================================================
  void _handleIncomingMessage(Map<String, dynamic> payload) {
    final fromUserId = payload['userId'] as String?;
    if (fromUserId == null || fromUserId == widget.userId) return;

    final messageId = payload['messageId'] as String? ?? _generateMessageId();

    if (_messages.any((m) => m.id == messageId)) return;

    DateTime timestamp;
    if (payload['timestamp'] != null) {
      timestamp = DateTime.parse(payload['timestamp'] as String);
    } else {
      timestamp = DateTime.now();
    }

    ReplyData? replyTo;
    if (payload['replyTo'] != null && payload['replyTo'] is Map) {
      final replyData = payload['replyTo'] as Map<String, dynamic>;
      replyTo = ReplyData(
        messageId: replyData['messageId'] ?? '',
        text: replyData['text'] ?? '',
        username: replyData['username'] ?? '',
        selection: replyData['selection'],
        isMe: replyData['isMe'] ?? false,
      );
    }

    final message = ChatMessage(
      id: messageId,
      userId: fromUserId,
      username: payload['username'] as String? ?? 'Anonymous',
      text: payload['message'] as String? ?? '',
      selection: payload['selection'] as String?,
      timestamp: timestamp,
      status: MessageStatus.delivered,
      replyTo: replyTo,
      imageUrl: payload['imageUrl'] as String?,
      videoUrl: payload['videoUrl'] as String?,
      isImage: payload['isImage'] as bool? ?? false,
      isVideo: payload['isVideo'] as bool? ?? false,
    );

    debugPrint('💬 New message from ${message.username}: ${message.text}');

    if (mounted) {
      setState(() {
        _messages.add(message);
        _sortMessages();
      });

      _saveMessagesToAppCache();
      _markAsLatestLiveArrival(messageId);

      WidgetsBinding.instance.addPostFrameCallback((_) {
        _scrollToBottom();
      });
    }
  }
  // ==========================================================================
  // SEND MESSAGE
  // ==========================================================================

  Future<void> _sendMessage() async {
    final text = _messageCtrl.text.trim();

    if (text.isEmpty) {
      Fluttertoast.showToast(
          msg: '📝 Type a message first', backgroundColor: Colors.orange);
      return;
    }

    if (_isSendingMessage) {
      Fluttertoast.showToast(
          msg: '⏳ Already sending...', backgroundColor: Colors.orange);
      return;
    }

    if (!_ws.isConnected) {
      // Don't block the send — WebSocketService queues messages internally
      // and flushes them the instant the reconnect succeeds. Just make sure
      // a reconnect attempt is actually in flight.
      _connectWebSocket();
    }

    _isSendingMessage = true;
    setState(() {});

    final messageId = _generateMessageId();
    final timestamp = DateTime.now();

    Map<String, dynamic>? replyToMap;
    if (_replyingTo != null) {
      replyToMap = {
        'messageId': _replyingTo!.messageId,
        'text': _replyingTo!.text,
        'username': _replyingTo!.username,
        'selection': _replyingTo!.selection,
        'isMe': _replyingTo!.isMe,
      };
    }

    final optimisticMessage = ChatMessage(
      id: messageId,
      userId: widget.userId,
      username: widget.username,
      text: text,
      selection: _userVoteSelection,
      timestamp: timestamp,
      status: MessageStatus.sending,
      replyTo: _replyingTo,
    );

    setState(() {
      _messages.add(optimisticMessage);
      _sortMessages();
    });

    _saveMessagesToAppCache();

    _messageCtrl.clear();
    _cancelReply();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToBottom();
    });

    _ws.sendChatMessage(
      message: text,
      selection: _userVoteSelection ?? '',
      username: widget.username,
      messageId: messageId,
      replyTo: replyToMap,
      imageUrl: null,
      videoUrl: null,
      isImage: false,
      isVideo: false,
      channelId: widget.channelId,
      fixtureId: widget.fixtureId,
    );

    _messageSent = true;

    _isSendingMessage = false;
    setState(() {});
  }

  // ==========================================================================
  // TYPING INDICATOR
  // ==========================================================================

  void _sendTypingIndicator() {
    if (!_ws.isConnected) return;

    _ws.send('typing', {
      'isTyping': true,
      'username': widget.username,
    });

    _typingTimer?.cancel();
    _typingTimer = Timer(const Duration(seconds: 2), () {
      if (_ws.isConnected && mounted) {
        _ws.send('typing', {
          'isTyping': false,
          'username': widget.username,
        });
      }
    });
  }

  void _handleTypingIndicator(Map<String, dynamic> payload) {
    final fromUserId = payload['fromUserId'] as String?;
    if (fromUserId == null || fromUserId == widget.userId) return;
    if (!widget.comradesList.contains(fromUserId)) return;
    final isTyping = payload['isTyping'] as bool? ?? false;
    final username = payload['username'] as String? ?? 'Someone';
    setState(() {
      if (isTyping && !_typingUsers.contains(username)) {
        _typingUsers.add(username);
      } else if (!isTyping && _typingUsers.contains(username)) {
        _typingUsers.remove(username);
      }
    });
  }

  // ==========================================================================
  // REPLY
  // ==========================================================================

  void _setReplyTo(ChatMessage message) {
    setState(() {
      _replyingTo = ReplyData(
        messageId: message.id,
        text: message.text.isEmpty
            ? (message.isImage
                ? '📷 Image'
                : (message.isVideo ? '🎥 Video' : 'Media'))
            : message.text,
        username: message.username,
        selection: message.selection,
        isMe: message.userId == widget.userId,
      );
    });
    _focusNode.requestFocus();
    _scrollToBottom();
  }

  void _cancelReply() => setState(() => _replyingTo = null);

  // ==========================================================================
  // MESSAGE OPTIONS
  // ==========================================================================

  void _showMessageOptions(ChatMessage message) {
    final isMe = message.userId == widget.userId;
    showModalBottomSheet(
      context: context,
      backgroundColor: FanColors.surface,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
                width: 40,
                height: 4,
                margin: const EdgeInsets.symmetric(vertical: 12),
                decoration: BoxDecoration(
                    color: FanColors.textTertiary,
                    borderRadius: BorderRadius.circular(2))),
            ListTile(
                leading: Icon(Icons.reply, color: FanColors.primary),
                title: Text('Reply',
                    style: TextStyle(color: FanColors.textPrimary)),
                onTap: () {
                  Navigator.pop(context);
                  _setReplyTo(message);
                }),
            if (message.text.isNotEmpty)
              ListTile(
                  leading: Icon(Icons.copy, color: FanColors.textSecondary),
                  title: Text('Copy text',
                      style: TextStyle(color: FanColors.textPrimary)),
                  onTap: () {
                    Navigator.pop(context);
                    Clipboard.setData(ClipboardData(text: message.text));
                    _flashError('Copied to clipboard');
                  }),
            if (isMe)
              ListTile(
                  leading: const Icon(Icons.delete_outline, color: Colors.red),
                  title:
                      const Text('Delete', style: TextStyle(color: Colors.red)),
                  onTap: () {
                    Navigator.pop(context);
                    _confirmDeleteMessage(message);
                  }),
          ],
        ),
      ),
    );
  }

  void _confirmDeleteMessage(ChatMessage message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: FanColors.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Delete Message',
            style: TextStyle(color: FanColors.textPrimary)),
        content: Text('Are you sure you want to delete this message?',
            style: TextStyle(color: FanColors.textSecondary)),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel',
                  style: TextStyle(color: FanColors.textSecondary))),
          TextButton(
              onPressed: () async {
                Navigator.pop(context);
                await _db.deleteMessage(message.id);
                setState(
                    () => _messages.removeWhere((m) => m.id == message.id));
                _flashError('Message deleted');
              },
              child: const Text('Delete', style: TextStyle(color: Colors.red))),
        ],
      ),
    );
  }

  // ==========================================================================
  // MESSAGE BUBBLE
  // ==========================================================================

  Widget _buildMediaPreview(ChatMessage message) {
    if (message.isImage &&
        message.imageUrl != null &&
        message.imageUrl!.isNotEmpty) {
      return GestureDetector(
        onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
                builder: (_) => Scaffold(
                      backgroundColor: Colors.black,
                      appBar: AppBar(
                          backgroundColor: Colors.transparent,
                          elevation: 0,
                          iconTheme: const IconThemeData(color: Colors.white)),
                      body: Center(
                          child: InteractiveViewer(
                              child: CachedNetworkImage(
                                  imageUrl: message.imageUrl!))),
                    ))),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: CachedNetworkImage(
            imageUrl: message.imageUrl!,
            height: 200,
            width: double.infinity,
            fit: BoxFit.cover,
            placeholder: (context, _) => Container(
                height: 200,
                color: FanColors.surface,
                child: const Center(
                    child: CircularProgressIndicator(strokeWidth: 2))),
            errorWidget: (context, error, _) => Container(
                height: 200,
                color: FanColors.surface,
                child: const Icon(Icons.broken_image, size: 40)),
          ),
        ),
      );
    }
    if (message.isVideo &&
        message.videoUrl != null &&
        message.videoUrl!.isNotEmpty) {
      return GestureDetector(
        onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
                builder: (_) => VideoPlayerPage(videoUrl: message.videoUrl!))),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: SizedBox(
            height: 200,
            width: double.infinity,
            child: Stack(
              fit: StackFit.expand,
              children: [
                _VideoThumbnail(videoUrl: message.videoUrl!),
                Positioned(
                  bottom: 8,
                  right: 8,
                  child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.7),
                          borderRadius: BorderRadius.circular(4)),
                      child:
                          const Row(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.videocam, size: 12, color: Colors.white),
                        SizedBox(width: 4),
                        Text('Video',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 10,
                                fontWeight: FontWeight.w500))
                      ])),
                ),
              ],
            ),
          ),
        ),
      );
    }
    return const SizedBox.shrink();
  }

  Widget _buildMessageBubble(ChatMessage message, bool isMe, int index) {
    final bool isCommentary = message.isCommentary;
    final bool effectiveIsMe = isCommentary ? false : isMe;
    final bool isLatestLiveArrival = message.id == _latestLiveMessageId;

    final commentaryPurple = const Color(0xFF8B5CF6);
    final liveHighlight =
        const Color(0xFF10B981); // distinct "just arrived" green

    final bubbleColor = isLatestLiveArrival
        ? liveHighlight.withValues(alpha: 0.15)
        : isCommentary
            ? commentaryPurple.withValues(alpha: 0.12)
            : (effectiveIsMe
                ? FanColors.primary.withValues(alpha: 0.08)
                : FanColors.surface);

    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Column(
        crossAxisAlignment:
            effectiveIsMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          if (!effectiveIsMe)
            Padding(
              padding: const EdgeInsets.only(left: 36, bottom: 2),
              child: isCommentary
                  ? Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.sports_soccer,
                            size: 11, color: commentaryPurple),
                        const SizedBox(width: 4),
                        Text(
                          message.username,
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                            color: commentaryPurple,
                          ),
                        ),
                      ],
                    )
                  : GestureDetector(
                      onTap: () =>
                          _showArchiveModal(message.userId, message.username),
                      child: Text(
                        message.username,
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                          color: FanColors.primary,
                          decoration: TextDecoration.underline,
                        ),
                      ),
                    ),
            ),
          GestureDetector(
            onLongPress:
                isCommentary ? null : () => _showMessageOptions(message),
            child: Row(
              mainAxisAlignment: effectiveIsMe
                  ? MainAxisAlignment.end
                  : MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                if (!effectiveIsMe) ...[
                  Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      color: isCommentary
                          ? commentaryPurple.withValues(alpha: 0.15)
                          : FanColors.primary.withValues(alpha: 0.1),
                      shape: BoxShape.circle,
                    ),
                    child: Center(
                      child: isCommentary
                          ? Icon(Icons.sports_soccer,
                              size: 14, color: commentaryPurple)
                          : Text(
                              message.username[0].toUpperCase(),
                              style: const TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: FanColors.primary,
                              ),
                            ),
                    ),
                  ),
                  const SizedBox(width: 6),
                ],
                Flexible(
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 400),
                    constraints: BoxConstraints(
                      maxWidth: MediaQuery.of(context).size.width * 0.75,
                    ),
                    decoration: BoxDecoration(
                      color: bubbleColor,
                      borderRadius: BorderRadius.only(
                        topLeft: const Radius.circular(16),
                        topRight: const Radius.circular(16),
                        bottomLeft: Radius.circular(effectiveIsMe ? 16 : 4),
                        bottomRight: Radius.circular(effectiveIsMe ? 4 : 16),
                      ),
                      border: isLatestLiveArrival
                          ? Border.all(
                              color: liveHighlight.withValues(alpha: 0.5),
                              width: 1)
                          : isCommentary
                              ? Border.all(
                                  color:
                                      commentaryPurple.withValues(alpha: 0.25),
                                  width: 1)
                              : null,
                    ),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          message.text,
                          style: TextStyle(
                            fontSize: 13,
                            color: FanColors.textPrimary,
                            fontStyle: isCommentary
                                ? FontStyle.italic
                                : FontStyle.normal,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          _timeAgo(message.timestamp),
                          style: TextStyle(
                              fontSize: 10, color: FanColors.textSecondary),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // In ChatScreen
  bool get _isHistoryGame {
    if (widget.fixture != null) {
      return widget.fixture!.status == 'completed' ||
          widget.fixture!.status == 'finished';
    }
    // Check if the game is in history via matchId
    return false;
  }

  DateTime _parseCommentaryTimestamp(dynamic raw) {
    if (raw is Map && raw['\$date'] != null) {
      final d = raw['\$date'];
      if (d is Map && d['\$numberLong'] != null) {
        return DateTime.fromMillisecondsSinceEpoch(
            int.parse(d['\$numberLong'].toString()));
      }
    } else if (raw is String) {
      return DateTime.tryParse(raw) ?? DateTime.now();
    }
    return DateTime.now();
  }

  // ==========================================================================
  // REPLY INDICATOR
  // ==========================================================================

  Widget _buildReplyIndicator() {
    if (_replyingTo == null) return const SizedBox.shrink();
    return Container(
      margin: const EdgeInsets.only(bottom: 4),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
          color: FanColors.primary.withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(12)),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                    'Replying to ${_replyingTo!.isMe ? 'yourself' : '@${_replyingTo!.username}'}',
                    style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: FanColors.primary)),
                const SizedBox(height: 2),
                Text(
                    _replyingTo!.text.length > 50
                        ? '${_replyingTo!.text.substring(0, 50)}...'
                        : _replyingTo!.text,
                    style: const TextStyle(
                        fontSize: 11,
                        color: FanColors.textSecondary,
                        fontStyle: FontStyle.italic)),
              ],
            ),
          ),
          GestureDetector(
              onTap: _cancelReply,
              child: Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                      color: FanColors.textTertiary.withValues(alpha: 0.2),
                      shape: BoxShape.circle),
                  child: Icon(Icons.close,
                      size: 14, color: FanColors.textSecondary))),
        ],
      ),
    );
  }

  // ==========================================================================
  // TYPING INDICATOR WIDGET
  // ==========================================================================

  Widget _buildTypingIndicator() {
    if (_typingUsers.isEmpty) return const SizedBox.shrink();
    final text = _typingUsers.length == 1
        ? '${_typingUsers[0]} is typing...'
        : '${_typingUsers.length} people are typing...';
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          const SizedBox(width: 20, height: 20, child: TypingAnimationWidget()),
          const SizedBox(width: 8),
          Text(text,
              style: TextStyle(
                  fontSize: 12,
                  fontStyle: FontStyle.italic,
                  color: FanColors.textSecondary)),
        ],
      ),
    );
  }

  // ==========================================================================
  // VOTES SECTION
  // ==========================================================================

  String _displayVote(String sel) {
    if (widget.fixture == null) return sel;
    if (sel == 'home_team') return widget.fixture!.homeTeam;
    if (sel == 'away_team') return widget.fixture!.awayTeam;
    if (sel == 'draw') return 'Draw';
    return sel;
  }

  Color _getVoteColor(String sel) {
    switch (sel) {
      case 'home_team':
        return FanColors.primary;
      case 'away_team':
        return const Color(0xFF2563EB);
      case 'draw':
        return const Color(0xFF8B5CF6);
      default:
        return FanColors.textSecondary;
    }
  }

  String _initials(String name) =>
      name.isNotEmpty ? name[0].toUpperCase() : 'U';

  Widget _buildVotesSection() {
    if (_voters.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(16),
        child: Center(
            child: Column(children: [
          Icon(Icons.how_to_vote_outlined, size: 32, color: FanColors.border),
          const SizedBox(height: 8),
          Text('No votes yet',
              style: TextStyle(fontSize: 12, color: FanColors.textSecondary)),
        ])),
      );
    }

    return Container(
      constraints:
          BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.4),
      decoration: BoxDecoration(
          color: FanColors.surface.withValues(alpha: 0.95),
          borderRadius: const BorderRadius.vertical(top: Radius.circular(16))),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Row(
              children: [
                Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                        color: FanColors.primary.withValues(alpha: 0.1),
                        shape: BoxShape.circle),
                    child: const Icon(Icons.how_to_vote,
                        size: 16, color: FanColors.primary)),
                const SizedBox(width: 12),
                Expanded(
                    child: Text('Votes (${_voters.length})',
                        style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: FanColors.textPrimary))),
                GestureDetector(
                  onTap: () => setState(() => _showVotesSection = false),
                  child: Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                          color: FanColors.border.withValues(alpha: 0.3),
                          shape: BoxShape.circle),
                      child: Icon(Icons.close,
                          size: 16, color: FanColors.textSecondary)),
                ),
              ],
            ),
          ),
          const Divider(height: 1, color: FanColors.border),
          Expanded(
            child: ListView.builder(
              controller: _voterScroll,
              padding: const EdgeInsets.symmetric(vertical: 8),
              itemCount: _voters.length,
              itemBuilder: (context, index) {
                final voter = _voters[index];
                final isMe = voter.userId == widget.userId;
                final voteColor = _getVoteColor(voter.selection);
                final voteDisplay = _displayVote(voter.selection);
                return Container(
                  margin:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                  child: Row(
                    children: [
                      Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                              color: voteColor.withValues(alpha: 0.1),
                              shape: BoxShape.circle),
                          child: Center(
                              child: Text(_initials(voter.username),
                                  style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w600,
                                      color: voteColor)))),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Text(isMe ? 'You' : voter.username,
                                    style: TextStyle(
                                        fontSize: 13,
                                        fontWeight: isMe
                                            ? FontWeight.w600
                                            : FontWeight.normal,
                                        color: isMe
                                            ? FanColors.primary
                                            : FanColors.textPrimary)),
                                if (voter.isComrade && !isMe) ...[
                                  const SizedBox(width: 6),
                                  Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 6, vertical: 2),
                                      decoration: BoxDecoration(
                                          color: FanColors.primary
                                              .withValues(alpha: 0.1),
                                          borderRadius:
                                              BorderRadius.circular(10)),
                                      child: const Text('comrade',
                                          style: TextStyle(
                                              fontSize: 8,
                                              color: FanColors.primary))),
                                ],
                              ],
                            ),
                            const SizedBox(height: 2),
                            Text('Voted for $voteDisplay',
                                style: TextStyle(
                                    fontSize: 10,
                                    color: FanColors.textSecondary)),
                          ],
                        ),
                      ),
                      Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                              color: voteColor.withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(16)),
                          child: Text(voteDisplay,
                              style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.w500,
                                  color: voteColor))),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // ==========================================================================
  // INPUT BAR
  // ==========================================================================

  Widget _buildInputBar() {
    final canComment = widget.isLoggedIn;

    final bool hasVoted =
        widget.fixtureId == null || _userVoteSelection != null;

    final bool needsVote =
        widget.fixtureId != null && _userVoteSelection == null;

    return SafeArea(
      top: false,
      child: Column(
        children: [
          if (_replyingTo != null) _buildReplyIndicator(),
          if (_isUploadingMedia)
            Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: const Row(children: [
                  SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2)),
                  SizedBox(width: 8),
                  Text('Uploading media...', style: TextStyle(fontSize: 12))
                ])),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                GestureDetector(
                  onTap: _openVotesModal,
                  child: Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: needsVote
                          ? Colors.orange.withValues(alpha: 0.2)
                          : FanColors.surface,
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: needsVote
                            ? Colors.orange.withValues(alpha: 0.5)
                            : FanColors.primary.withValues(alpha: 0.3),
                      ),
                    ),
                    child: ClipOval(
                      child: CachedNetworkImage(
                        imageUrl:
                            'https://www.theeastafrican.co.ke/tea/opinion/columnists/let-s-all-first-register-then-vote-for-less-annoying-leadership-4982426',
                        fit: BoxFit.cover,
                        placeholder: (context, url) => Center(
                          child: needsVote
                              ? Icon(Icons.warning_amber_rounded,
                                  size: 18, color: Colors.orange)
                              : const SizedBox(
                                  width: 14,
                                  height: 14,
                                  child: CircularProgressIndicator(
                                      strokeWidth: 1.5),
                                ),
                        ),
                        errorWidget: (context, url, error) => Icon(
                          needsVote ? Icons.how_to_vote : Icons.how_to_vote,
                          size: 18,
                          color: needsVote ? Colors.orange : FanColors.primary,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Row(
                      children: [
                        if (canComment &&
                            !_isSendingMessage &&
                            !_isUploadingMedia &&
                            !needsVote)
                          GestureDetector(
                              onTap: _showAttachmentMenu,
                              child: Container(
                                  padding: const EdgeInsets.all(8),
                                  child: Icon(Icons.attach_file,
                                      size: 20,
                                      color: FanColors.textSecondary))),
                        Expanded(
                          child: needsVote
                              ? GestureDetector(
                                  onTap: () {
                                    Fluttertoast.showToast(
                                      msg:
                                          '🗳️ Vote on this match to join the chat',
                                      backgroundColor: Colors.orange,
                                      toastLength: Toast.LENGTH_LONG,
                                    );
                                    _openVotesModal();
                                  },
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 12),
                                    decoration: BoxDecoration(
                                      color: FanColors.surface
                                          .withValues(alpha: 0.5),
                                      borderRadius: BorderRadius.circular(8),
                                      border: Border.all(
                                        color: Colors.orange
                                            .withValues(alpha: 0.3),
                                      ),
                                    ),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Icon(Icons.lock_outline,
                                            size: 14, color: Colors.orange),
                                        const SizedBox(width: 6),
                                        Text(
                                          'Vote to chat 💬',
                                          style: TextStyle(
                                            fontSize: 13,
                                            color: Colors.orange,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                )
                              : TextField(
                                  controller: _messageCtrl,
                                  focusNode: _focusNode,
                                  maxLines: null,
                                  maxLength: 500,
                                  enabled: canComment && !_isSendingMessage,
                                  style: TextStyle(
                                      fontSize: 14,
                                      color: FanColors.textPrimary),
                                  decoration: InputDecoration(
                                    hintText: !widget.isLoggedIn
                                        ? 'Log in to chat'
                                        : 'Type a message...',
                                    hintStyle: TextStyle(
                                        fontSize: 14,
                                        color: FanColors.textSecondary
                                            .withValues(alpha: 0.6)),
                                    border: InputBorder.none,
                                    enabledBorder: InputBorder.none,
                                    focusedBorder: InputBorder.none,
                                    disabledBorder: InputBorder.none,
                                    errorBorder: InputBorder.none,
                                    focusedErrorBorder: InputBorder.none,
                                    contentPadding: EdgeInsets.zero,
                                    isDense: true,
                                    counterText: '',
                                    fillColor: Colors.transparent,
                                    filled: false,
                                  ),
                                  onChanged: (text) {
                                    setState(() {});
                                    if (text.isNotEmpty &&
                                        canComment &&
                                        !_isSendingMessage) {
                                      _sendTypingIndicator();
                                    }
                                  },
                                  onSubmitted: (_) => _sendMessage(),
                                ),
                        ),
                        if (canComment &&
                            _messageCtrl.text.trim().isNotEmpty &&
                            !_isSendingMessage &&
                            !needsVote)
                          Padding(
                              padding: const EdgeInsets.only(left: 8),
                              child: GestureDetector(
                                  onTap: _sendMessage,
                                  child: const Icon(Icons.send_rounded,
                                      size: 20, color: FanColors.primary))),
                        if (_isSendingMessage)
                          const Padding(
                              padding: EdgeInsets.only(left: 8),
                              child: SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: CircularProgressIndicator(
                                      strokeWidth: 2))),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<bool> _checkVotesButtonVisibility() async {
    try {
      final response = await http.get(
        Uri.parse('$_api/visibility/votes_button_show'),
        headers: _headers(),
      );
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data['value'] ?? true;
      }
      return true;
    } catch (e) {
      debugPrint('❌ Error checking visibility: $e');
      return true;
    }
  }

  // ==========================================================================
  // EMPTY STATE
  // ==========================================================================

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.chat_bubble_outline_rounded,
              size: 48, color: FanColors.textSecondary),
          const SizedBox(height: 16),
          Text('No messages yet\nBe the first to send a message!',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 14, color: FanColors.textSecondary)),
        ],
      ),
    );
  }

  // ==========================================================================
  // COMRADE METHODS
  // ==========================================================================

  void _showComradeProfile(Map<String, dynamic> comrade) {
    if (!widget.isLoggedIn) return;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => SwipeableProfileModal(
        // ← Changed from ProfileModal
        apiBaseUrl: 'https://clash-api-m5mr.onrender.com',
        userId: comrade['id'].toString(),
        username: comrade['username'].toString(),
        phone: comrade['phone']?.toString() ?? '',
        onUserUpdated: (updatedUserData) {},
        onLogout: () {},
      ),
    );
  }

  void _addComradeDirectly(Map<String, dynamic> comrade) {
    if (!widget.isLoggedIn) return;
    if (widget.comradesList.contains(comrade['id'])) {
      _flashError('${comrade['nickname']} is already your comrade');
      return;
    }
    setState(() => _addedComradeIds.add(comrade['id']));
    _flashError('Added ${comrade['nickname']} as comrade! 🎉');
    _addComradeToBackend(comrade);
  }

  Future<void> _addComradeToBackend(Map<String, dynamic> comrade) async {
    if (widget.authToken == null) return;
    await ComradeService.addComrade(
      userId: widget.userId,
      comradeId: comrade['id'].toString(),
      username: widget.username,
      comradeUsername: comrade['username'].toString(),
      comradeNickname: comrade['nickname'].toString(),
      comradeClub: comrade['club']?.toString() ?? '',
      comradeCountry: comrade['country']?.toString() ?? '',
      authToken: widget.authToken!,
    );
  }

  void _showLeaderboard() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => ComradeModal(
        isOpen: true,
        onClose: () => Navigator.pop(context),
        currentUserId: widget.userId,
        currentUserName: widget.username,
        authToken: widget.authToken,
        channelId: widget.channelId,
        channelName: null,
        fixture: widget.fixture,
        comradesList: widget.comradesList,
        comradesVoteMap: {},
        hasUserVoted: _userVoteSelection != null,
        userVoteSelection: _userVoteSelection,
      ),
    );
  }

  void _showArchiveModal(String userId, String username) {
    showArchiveModal(
      context: context,
      userId: userId,
      userName: username,
      authToken: widget.authToken,
      displayName: username,
      isCurrentUser: userId == widget.userId,
    );
  }

  void _openMatchDetails() {
    if (widget.fixture != null) {
      showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (context) => MatchDetailsModal(
          fixture: widget.fixture!,
          userId: widget.userId,
          username: widget.username,
          authToken: widget.authToken,
        ),
      );
    }
  }

  // ==========================================================================
  // WEBSOCKET - COMPLETE WITH COMMENTARY
  // ==========================================================================

  void _setupWebSocketListeners() {
    if (_webSocketSetupDone) return;
    _webSocketSetupDone = true;

    _ws.connectionStatus.listen((connected) {
      if (mounted) {
        setState(() => _isConnected = connected);
        if (connected) {
          debugPrint('✅ WebSocket connected');
          _fetchVoteCounts();
          _syncFromServer();

          // ✅ Only request commentary for live games
          if (widget.fixtureId != null && !_isHistoryGame) {
            _ws.send('get.commentary', {'fixtureId': widget.fixtureId});
          } else if (widget.fixtureId != null && _isHistoryGame) {
            debugPrint(
                '📜 History game - skipping WebSocket commentary request');
          }
        }
      }
    });

    // ── Chat Message ──────────────────────────────────────────────────────────
    _ws.on('chat.message', _handleIncomingMessage);

    // ── Typing Indicator ──────────────────────────────────────────────────────
    _ws.on('typing', _handleTypingIndicator);

    // ── Vote Update ───────────────────────────────────────────────────────────
    _ws.on('vote.update', _handleVoteUpdate);

    // ── Comment Count Update ──────────────────────────────────────────────────
    _ws.on('comment.count', _handleCommentCountUpdate);

    // ── Match Status Update ────────────────────────────────────────────────────
    _ws.on('match.status', _handleMatchStatusUpdate);

    // ── Match Goal Event ──────────────────────────────────────────────────────
    _ws.on('match.goal', _handleGoalEvent);

    // ── Commentary New (Real-time) ────────────────────────────────────────────
    _ws.on('commentary.new', _handleNewCommentary);

    // ── Server Connected Acknowledgment ──────────────────────────────────────
    _ws.on('connected', _handleServerConnectedAck);

    // ── Error Handler ─────────────────────────────────────────────────────────
    _ws.on('error', _handleWsError);

    // ── Like Update ───────────────────────────────────────────────────────────
    _ws.on('like', (payload) {
      final fixtureId = payload['fixture_id'] as String?;
      final totalLikes = payload['total_likes'] as int?;
      if (fixtureId != null &&
          fixtureId == widget.fixtureId &&
          totalLikes != null) {
        debugPrint('❤️ Like update: $fixtureId → $totalLikes');
        // Update UI if needed
      }
    });

    // ── Pledge Update ─────────────────────────────────────────────────────────
    _ws.on('pledge.update', (payload) {
      final fixtureId = payload['fixture_id'] as String?;
      final totalPledges = payload['total_pledges'] as int?;
      if (fixtureId != null &&
          fixtureId == widget.fixtureId &&
          totalPledges != null) {
        debugPrint('💰 Pledge update: $fixtureId → $totalPledges');
        // Update UI if needed
      }
    });

    // ── Bet Update ────────────────────────────────────────────────────────────
    _ws.on('bet.update', (payload) {
      final fixtureId = payload['fixture_id'] as String?;
      final totalBets = payload['total_bets'] as int?;
      if (fixtureId != null &&
          fixtureId == widget.fixtureId &&
          totalBets != null) {
        debugPrint('🎯 Bet update: $fixtureId → $totalBets');
        // Update UI if needed
      }
    });

    // ── Join Responses ────────────────────────────────────────────────────────
    _ws.on('join_approved', (data) {
      final channelId = data['channel_id']?.toString();
      final channelName = data['channel_name']?.toString() ?? 'Unknown';
      if (channelId != null && mounted) {
        // ToastHelper.showSuccess('✅ You joined "$channelName" 🎉');
        // Refresh channels if needed
      }
    });

    _ws.on('join_rejected', (data) {
      final channelName = data['channel_name']?.toString() ?? 'Unknown';
      final reason = data['reason']?.toString() ?? 'No reason provided';
      if (mounted) {
        // ToastHelper.showWarning('❌ Join request to "$channelName" was declined: $reason');
      }
    });

    _ws.on('join_request_status', (data) {
      final status = data['status']?.toString();
      final channelName = data['channel_name']?.toString() ?? 'Unknown';
      if (status == 'approved' && mounted) {
        //  ToastHelper.showSuccess('✅ You joined "$channelName" 🎉');
      } else if (status == 'rejected' && mounted) {
        final reason = data['reason']?.toString() ?? 'No reason provided';
        // ToastHelper.showWarning('❌ Join request to "$channelName" was declined: $reason');
      }
    });

    // ── Match Ended ───────────────────────────────────────────────────────────
    _ws.on('match.ended', (payload) {
      final fixtureId = payload['fixture_id'] as String?;
      if (fixtureId != null && fixtureId == widget.fixtureId) {
        setState(() {
          _matchStatus = 'completed';
          _isLive = false;
        });
        //ToastHelper.showInfo('🏁 Match has ended');
        _buildCarouselItems();
      }
    });

    // ── Sub-Fixture Vote Update ──────────────────────────────────────────────
    _ws.on('sub_fixture.vote', (payload) {
      final fixtureId = payload['fixture_id'] as String?;
      final subFixtureId = payload['sub_fixture_id'] as String?;
      final selection = payload['selection'] as String?;
      if (fixtureId != null && fixtureId == widget.fixtureId) {
        debugPrint('📊 Sub-fixture vote update: $subFixtureId → $selection');
      }
    });
  }

  void _handleWsError(Map<String, dynamic> payload) {
    final error = payload['message']?.toString() ?? 'Unknown error';
    debugPrint('❌ WebSocket error: $error');
  }

  void _teardownWebSocketListeners() {
    _ws.off('chat.message', _handleIncomingMessage);
    _ws.off('typing', _handleTypingIndicator);
    _ws.off('vote.update', _handleVoteUpdate);
    _ws.off('comment.count', _handleCommentCountUpdate);
    _ws.off('match.status', _handleMatchStatusUpdate);
    _ws.off('match.goal', _handleGoalEvent);
    _ws.off('commentary.new', _handleNewCommentary);
    _ws.off('connected', _handleServerConnectedAck);
    _ws.off('error', _handleWsError);
  }

  void _handleCommentCountUpdate(Map<String, dynamic> payload) {
    final fixtureId = payload['fixture_id'] as String?;
    final count = payload['count'] as int?;
    if (fixtureId != null && fixtureId == widget.fixtureId && count != null) {
      debugPrint('📊 Comment count update for fixture $fixtureId: $count');
    }
  }

  Future<void> _connectWebSocket() async {
    if (!widget.isLoggedIn) {
      Fluttertoast.showToast(
          msg: '❌ Not logged in', backgroundColor: Colors.red);
      return;
    }

    try {
      await _ws.connect(
        widget.userId,
        widget.authToken ?? '',
        widget.channelId,
        widget.username,
        fixtureId: widget.fixtureId,
      );
    } catch (e) {
      _scheduleReconnect();
    }
  }

  void _scheduleReconnect() {
    _reconnectTimer?.cancel();
    _reconnectTimer = Timer(const Duration(seconds: 5), () {
      if (mounted) _connectWebSocket();
    });
  }

  void _reconnectIfNeeded() {
    if (!_ws.isConnected && mounted) _connectWebSocket();
  }

  // ==========================================================================
  // UTILITIES
  // ==========================================================================

  String _generateMessageId() =>
      '${DateTime.now().millisecondsSinceEpoch}_${widget.userId}_${DateTime.now().microsecondsSinceEpoch}';

  Map<String, String> _headers() {
    final headers = {'Content-Type': 'application/json'};
    if (widget.authToken != null && widget.authToken!.isNotEmpty) {
      headers['Authorization'] = 'Bearer ${widget.authToken}';
    }
    return headers;
  }

  void _sortMessages() {
    _messages.sort((a, b) => a.timestamp.compareTo(b.timestamp));
  }

  String _timeAgo(DateTime time) {
    final diff = DateTime.now().difference(time);
    if (diff.inMinutes < 1) return 'now';
    if (diff.inHours < 1) return '${diff.inMinutes}m';
    if (diff.inDays < 1) return '${diff.inHours}h';
    if (diff.inDays == 1) return 'yesterday';
    if (diff.inDays < 7) return '${diff.inDays}d';
    return DateFormat('MMM d').format(time);
  }

  void _flashError(String msg) => Fluttertoast.showToast(
      msg: msg, backgroundColor: Colors.red, textColor: Colors.white);

  void _scrollToBottom() {
    _scrollToBottomTimer?.cancel();
    _scrollToBottomTimer = Timer(const Duration(milliseconds: 150), () {
      if (!mounted || !_chatScroll.hasClients) return;
      final maxExtent = _chatScroll.position.maxScrollExtent;
      if (maxExtent > 0) {
        _chatScroll.animateTo(
          maxExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _markChatAsRead() async {
    if (!widget.isLoggedIn) return;
    try {
      final response = await http.put(
        Uri.parse(
            '$_api/channels/${widget.channelId}/fixtures/${widget.fixtureId ?? 'overall'}/read/${widget.userId}'),
        headers: _headers(),
      );
      if (response.statusCode == 200) {
        debugPrint('✅ Chat marked as read on backend');
      }
    } catch (e) {
      debugPrint('❌ Error marking chat as read: $e');
    }
  }

  // ==========================================================================
  // MEDIA PICKER METHODS
  // ==========================================================================

  void _showAttachmentMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: FanColors.surface,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
                width: 40,
                height: 4,
                margin: const EdgeInsets.symmetric(vertical: 12),
                decoration: BoxDecoration(
                    color: FanColors.textTertiary,
                    borderRadius: BorderRadius.circular(2))),
            ListTile(
              leading: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                      color: FanColors.primary.withValues(alpha: 0.1),
                      shape: BoxShape.circle),
                  child: Icon(Icons.image_rounded,
                      color: FanColors.primary, size: 22)),
              title: Text('Gallery',
                  style: TextStyle(color: FanColors.textPrimary)),
              onTap: () {
                Navigator.pop(context);
                _pickAndSendImage();
              },
            ),
            ListTile(
              leading: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                      color: FanColors.primary.withValues(alpha: 0.1),
                      shape: BoxShape.circle),
                  child: Icon(Icons.videocam_rounded,
                      color: FanColors.primary, size: 22)),
              title:
                  Text('Video', style: TextStyle(color: FanColors.textPrimary)),
              onTap: () {
                Navigator.pop(context);
                _pickAndSendVideo();
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  Future<void> _pickAndSendImage() async {
    if (_isUploadingMedia) return;

    final XFile? image = await _picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 80,
    );

    if (image == null) return;

    setState(() => _isUploadingMedia = true);

    try {
      final imageUrl = await ApiService.uploadChatImage(
        File(image.path),
        authToken: widget.authToken,
      );

      if (imageUrl != null) {
        await _sendMediaMessage(imageUrl, isImage: true);
      } else {
        _flashError('Failed to upload image');
      }
    } catch (e) {
      _flashError('Failed to upload image');
    } finally {
      setState(() => _isUploadingMedia = false);
    }
  }

  Future<void> _pickAndSendVideo() async {
    if (_isUploadingMedia) return;
    final XFile? video = await _picker.pickVideo(source: ImageSource.gallery);
    if (video == null) return;
    setState(() => _isUploadingMedia = true);
    try {
      final videoUrl = await ApiService.uploadChatVideo(File(video.path),
          authToken: widget.authToken);
      if (videoUrl != null) {
        await _sendMediaMessage(videoUrl, isVideo: true);
      } else {
        _flashError('Failed to upload video');
      }
    } catch (e) {
      _flashError('Failed to upload video');
    } finally {
      setState(() => _isUploadingMedia = false);
    }
  }

  Future<void> _sendMediaMessage(String url,
      {bool isImage = false, bool isVideo = false}) async {
    if (_isSendingMessage) return;

    _isSendingMessage = true;
    final messageId = _generateMessageId();
    final timestamp = DateTime.now();

    final optimisticMessage = ChatMessage(
      id: messageId,
      userId: widget.userId,
      username: widget.username,
      text: '',
      selection: _userVoteSelection,
      timestamp: timestamp,
      status: MessageStatus.sending,
      replyTo: _replyingTo,
      imageUrl: isImage ? url : null,
      videoUrl: isVideo ? url : null,
      isImage: isImage,
      isVideo: isVideo,
    );

    setState(() {
      _messages.add(optimisticMessage);
      _sortMessages();
    });

    _cancelReply();
    _scrollToBottom();

    if (_ws.isConnected) {
      _ws.sendChatMessage(
        message: '',
        selection: _userVoteSelection ?? '',
        username: widget.username,
        messageId: messageId,
        replyTo: _replyingTo?.toJson(),
        imageUrl: isImage ? url : null,
        videoUrl: isVideo ? url : null,
        isImage: isImage,
        isVideo: isVideo,
        channelId: widget.channelId,
        fixtureId: widget.fixtureId,
      );

      _messageSent = true;
    } else {
      _flashError('Failed to send media');
    }

    _isSendingMessage = false;
    setState(() {});
  }

  // ==========================================================================
  // LIFECYCLE
  // ==========================================================================

  @override
  void initState() {
    super.initState();
    _carouselController = PageController();
    WidgetsBinding.instance.addObserver(this);

    // Set initial match data from fixture
    if (widget.fixture != null) {
      _homeScore = widget.fixture!.homeScore ?? 0;
      _awayScore = widget.fixture!.awayScore ?? 0;
      _minutesPlayed = widget.fixture!.minutesPlayed ?? 0;
      _minuteDisplay = widget.fixture!.minuteDisplay ?? "${_minutesPlayed}'";
      _matchStatus = widget.fixture!.status;
      _isLive = widget.fixture!.isLive;
    }

    if (widget.userVoteSelection != null) {
      _userVoteSelection = widget.userVoteSelection;
    }

    _loadMessages();
    _fetchRealComrades();
    _buildCarouselItems();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _setupWebSocketListeners();
      _connectWebSocket();
      if (widget.fixtureId != null) {
        _fetchVoteCounts();
        _fetchVoters();
      }
      _preloadInitialAds();
    });
  }

  void _preloadInitialAds() {
    final adIds = AdHelper.carouselAdUnitIds;
    if (adIds.isNotEmpty) {
      for (int i = 0; i < adIds.length && i < 4; i++) {
        final adUnitId = adIds[i];
        if (adUnitId.isNotEmpty && !_preloadedAdUnitIds.contains(adUnitId)) {
          _preloadedAdUnitIds.add(adUnitId);
          ChatAdManager().preloadAd(adUnitId);
        }
      }
    }
  }

  @override
  void dispose() {
    _markChatAsRead();
    _teardownWebSocketListeners();
    _stopCarouselAutoScroll();
    _carouselTimer?.cancel();
    _carouselController.dispose();
    _typingTimer?.cancel();
    _reconnectTimer?.cancel();
    _scrollToBottomTimer?.cancel();
    _focusNode.dispose();
    _messageCtrl.dispose();
    _chatScroll.dispose();
    _latestLiveHighlightTimer?.cancel();
    _voterScroll.dispose();
    if (_ws.isConnected) {
      _ws.joinRoom(widget.channelId, fixtureId: null);
    }
    WidgetsBinding.instance.removeObserver(this);
    ChatAdManager().disposeAll();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _reconnectIfNeeded();
      if (_carouselItems.length > 1 && !_isCarouselRunning) {
        _startCarouselAutoScroll();
      }
    } else if (state == AppLifecycleState.paused) {
      _stopCarouselAutoScroll();
    }
  }

  // ==========================================================================
  // BUILD
  // ==========================================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: FanColors.background,
      appBar: AppBar(
        backgroundColor: FanColors.background,
        elevation: 0,
        leadingWidth: widget.fixture != null ? 80 : 48,
        leading: Row(
          children: [
            IconButton(
              icon: const Icon(Icons.arrow_back_rounded,
                  color: Colors.white, size: 20),
              padding: const EdgeInsets.only(left: 8),
              onPressed: () => Navigator.pop(context, _messageSent),
            ),
            if (widget.fixture != null)
              IconButton(
                icon: const Icon(Icons.info_outline_rounded,
                    color: Colors.white, size: 18),
                padding: EdgeInsets.zero,
                onPressed: _openMatchDetails,
                tooltip: 'Match Details',
              ),
          ],
        ),
        title: _buildCarousel(),
        actions: [
          IconButton(
            icon: const Icon(Icons.people_alt, color: Colors.white, size: 20),
            padding: const EdgeInsets.only(right: 12),
            onPressed: _showLeaderboard,
          ),
        ],
      ),
      body: Column(
        children: [
          AnimatedCrossFade(
            duration: const Duration(milliseconds: 300),
            crossFadeState: _showVotesSection && _voters.isNotEmpty
                ? CrossFadeState.showFirst
                : CrossFadeState.showSecond,
            firstChild: _buildVotesSection(),
            secondChild: const SizedBox.shrink(),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
                : _messages.isEmpty
                    ? _buildEmptyState()
                    : ListView.builder(
                        controller: _chatScroll,
                        padding: const EdgeInsets.only(
                            left: 12, right: 12, top: 8, bottom: 80),
                        itemCount: _messages.length,
                        itemBuilder: (context, index) {
                          final message = _messages[index];
                          return _buildMessageBubble(
                              message, message.userId == widget.userId, index);
                        },
                      ),
          ),
          _buildTypingIndicator(),
          _buildInputBar(),
        ],
      ),
    );
  }
}
