// modals/clash/swipeable_vote_pledge_modal.dart
//
// Redesign notes
// ----------------------------------------------------------------------
// The old file repeated the same "pick a team" cards in both the Vote
// tab and the Pledge tab (_buildVoteOption / _buildPledgeOption), the
// same avatar+name+badge row in both the voters list and the pledges
// list, and near-identical Top Up / Withdraw dialogs. This version
// pulls all of that into small shared widgets:
//
//   _Tokens        -> spacing/radius constants used everywhere
//   _Avatar        -> initials circle used by voters + pledges
//   _Badge         -> tiny pill (comrade / you / live / status)
//   _OutcomeCard   -> the team/draw/team odds picker (vote + pledge + match dialog)
//   _PersonTile    -> shell row for a voter or a pledge (avatar, name, badges, trailing)
//   _BalanceBar    -> wallet balance + Top up / Withdraw pill buttons
//   _PillButton    -> gradient/solid rounded button with loading state
//   _showFundsDialog -> single dialog used for BOTH top up and withdraw
//   _fetchSavedPhone / _savePhone -> generic replacements for the four
//                      near-identical topup/withdraw phone helpers
//
// All networking / business logic (STK push polling, bet create/fill,
// balance checks, FCM refresh) is unchanged - only the UI layer and the
// duplicated glue code around it were consolidated and restyled.
// ----------------------------------------------------------------------

import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:share_plus/share_plus.dart';
import '../../models/fixture_models.dart';
import '../../pages/social_theme.dart';
import '../../pages/fan_clash_design.dart';
import '../../services/toast_helper.dart';
import '../../services/notification_service.dart';
import '../../services/bet_service.dart' as bet_service;

// ============================================================================
// DESIGN TOKENS (local to this file)
// ============================================================================
class _Tokens {
  static const double radiusSm = 10;
  static const double radiusMd = 14;
  static const double radiusLg = 18;
  static const double radiusXl = 24;
  static const double gap4 = 4;
  static const double gap8 = 8;
  static const double gap12 = 12;
  static const double gap16 = 16;

  static const Color away = Color(0xFF2563EB);
  static const Color draw = Color(0xFF7F77DD);

  static BoxDecoration card(
      {Color? color, Color? borderColor, double radius = radiusMd}) {
    return BoxDecoration(
      color: color ?? FanColors.surface,
      borderRadius: BorderRadius.circular(radius),
      border: borderColor != null ? Border.all(color: borderColor) : null,
    );
  }
}

// ============================================================================
// VOTE STATS
// ============================================================================
class VoteStats {
  final int homeCount;
  final int awayCount;
  final int drawCount;

  VoteStats({
    required this.homeCount,
    required this.awayCount,
    required this.drawCount,
  });

  int get total => homeCount + awayCount + drawCount;

  double get homePercentage => total > 0 ? (homeCount / total) * 100 : 0;
  double get awayPercentage => total > 0 ? (awayCount / total) * 100 : 0;
  double get drawPercentage => total > 0 ? (drawCount / total) * 100 : 0;
}

// ============================================================================
// SHARED UI PIECES
// ============================================================================

/// Initials circle used by both the voters list and the pledges list.
class _Avatar extends StatelessWidget {
  final String name;
  final Color color;
  final double size;

  const _Avatar({required this.name, required this.color, this.size = 32});

  @override
  Widget build(BuildContext context) {
    final initial = name.isNotEmpty ? name[0].toUpperCase() : 'U';
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [color.withOpacity(0.28), color.withOpacity(0.12)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        shape: BoxShape.circle,
        border: Border.all(color: color.withOpacity(0.35), width: 1),
      ),
      child: Center(
        child: Text(
          initial,
          style: TextStyle(
            fontSize: size * 0.4,
            fontWeight: FontWeight.w700,
            color: color,
          ),
        ),
      ),
    );
  }
}

/// Small pill badge - "you", "comrade", "LIVE", status tags, etc.
class _Badge extends StatelessWidget {
  final String label;
  final Color color;
  final IconData? icon;

  const _Badge({required this.label, required this.color, this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 9, color: color),
            const SizedBox(width: 3),
          ],
          Text(
            label,
            style: TextStyle(
              fontSize: 8,
              fontWeight: FontWeight.w600,
              color: color,
              letterSpacing: 0.2,
            ),
          ),
        ],
      ),
    );
  }
}

/// One outcome (Home / Draw / Away) selector card. Used by the Vote tab,
/// the Pledge tab, and the "pick a side" step of the match-pledge dialog -
/// previously three separate, near-identical builder methods.
class _OutcomeCard extends StatelessWidget {
  final String title;
  final double? odds;
  final bool isSelected;
  final Color color;
  final VoidCallback? onTap;
  final bool isLocked;
  final bool compact;

  const _OutcomeCard({
    required this.title,
    this.odds,
    required this.isSelected,
    required this.color,
    required this.onTap,
    this.isLocked = false,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        curve: Curves.easeOut,
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(_Tokens.radiusSm),
            onTap: isLocked ? null : onTap,
            child: Container(
              padding: EdgeInsets.symmetric(vertical: compact ? 9 : 12),
              decoration: BoxDecoration(
                color: isSelected ? color.withOpacity(0.14) : FanColors.surface,
                borderRadius: BorderRadius.circular(_Tokens.radiusSm),
                border: Border.all(
                  color:
                      isSelected ? color : FanColors.border.withOpacity(0.25),
                  width: isSelected ? 1.6 : 1,
                ),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: compact ? 11 : 12,
                      fontWeight:
                          isSelected ? FontWeight.w700 : FontWeight.w500,
                      color: isSelected ? color : Colors.white,
                    ),
                  ),
                  if (odds != null) ...[
                    const SizedBox(height: 2),
                    Text(
                      odds!.toStringAsFixed(2),
                      style: TextStyle(
                        fontSize: compact ? 11 : 12,
                        fontWeight: FontWeight.bold,
                        color: isSelected ? color : FanColors.textSecondary,
                      ),
                    ),
                  ],
                  if (isLocked && isSelected)
                    const Padding(
                      padding: EdgeInsets.only(top: 3),
                      child: Icon(Icons.check_circle,
                          size: 12, color: FanColors.primary),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Row of three _OutcomeCard widgets (Home / Draw / Away) - the shape
/// used identically by the Vote tab and the Pledge tab.
class _OutcomeRow extends StatelessWidget {
  final String homeLabel;
  final String awayLabel;
  final double? homeOdds;
  final double? drawOdds;
  final double? awayOdds;
  final String? selected;
  final bool locked;
  final ValueChanged<String>? onSelect;
  final bool compact;

  const _OutcomeRow({
    required this.homeLabel,
    required this.awayLabel,
    this.homeOdds,
    this.drawOdds,
    this.awayOdds,
    required this.selected,
    this.locked = false,
    required this.onSelect,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _OutcomeCard(
          title: homeLabel,
          odds: homeOdds,
          isSelected: selected == 'home',
          color: FanColors.primary,
          isLocked: locked,
          compact: compact,
          onTap: onSelect == null ? null : () => onSelect!('home'),
        ),
        const SizedBox(width: 8),
        _OutcomeCard(
          title: 'Draw',
          odds: drawOdds,
          isSelected: selected == 'draw',
          color: _Tokens.draw,
          isLocked: locked,
          compact: compact,
          onTap: onSelect == null ? null : () => onSelect!('draw'),
        ),
        const SizedBox(width: 8),
        _OutcomeCard(
          title: awayLabel,
          odds: awayOdds,
          isSelected: selected == 'away',
          color: _Tokens.away,
          isLocked: locked,
          compact: compact,
          onTap: onSelect == null ? null : () => onSelect!('away'),
        ),
      ],
    );
  }
}

/// Shared shell for a voter row or a pledge row: avatar, name, optional
/// badges, a subtitle line, and a trailing widget (a colored pill for
/// votes, an amount + MATCH button for pledges).
class _PersonTile extends StatelessWidget {
  final String name;
  final bool isMe;
  final Color accent;
  final String subtitle;
  final List<Widget> badges;
  final Widget trailing;
  final bool highlight;

  const _PersonTile({
    required this.name,
    required this.isMe,
    required this.accent,
    required this.subtitle,
    this.badges = const [],
    required this.trailing,
    this.highlight = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      decoration: BoxDecoration(
        color:
            highlight ? FanColors.primary.withOpacity(0.06) : FanColors.surface,
        borderRadius: BorderRadius.circular(_Tokens.radiusSm),
        border: highlight
            ? Border.all(color: FanColors.primary.withOpacity(0.3))
            : Border.all(color: Colors.transparent),
      ),
      child: Row(
        children: [
          _Avatar(name: name, color: accent),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        isMe ? 'You' : name,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontWeight: isMe ? FontWeight.w700 : FontWeight.w500,
                          fontSize: 12,
                          color:
                              isMe ? FanColors.primary : FanColors.textPrimary,
                        ),
                      ),
                    ),
                    for (final b in badges) ...[const SizedBox(width: 4), b],
                  ],
                ),
                const SizedBox(height: 1),
                Text(
                  subtitle,
                  style:
                      TextStyle(fontSize: 9.5, color: FanColors.textSecondary),
                ),
              ],
            ),
          ),
          trailing,
        ],
      ),
    );
  }
}

/// Rounded solid/gradient button with a built-in loading spinner.
class _PillButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final Color color;
  final bool loading;
  final VoidCallback? onTap;
  final bool small;

  const _PillButton({
    required this.label,
    this.icon,
    required this.color,
    this.loading = false,
    required this.onTap,
    this.small = false,
  });

  @override
  Widget build(BuildContext context) {
    final disabled = onTap == null || loading;
    return Opacity(
      opacity: disabled && !loading ? 0.5 : 1,
      child: GestureDetector(
        onTap: disabled ? null : onTap,
        child: Container(
          padding: EdgeInsets.symmetric(
              horizontal: small ? 10 : 14, vertical: small ? 6 : 10),
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                  color: color.withOpacity(0.35),
                  blurRadius: 10,
                  offset: const Offset(0, 4)),
            ],
          ),
          child: loading
              ? SizedBox(
                  width: small ? 14 : 18,
                  height: small ? 14 : 18,
                  child: const CircularProgressIndicator(
                      strokeWidth: 2, color: Colors.white),
                )
              : Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (icon != null) ...[
                      Icon(icon, size: small ? 13 : 16, color: Colors.white),
                      const SizedBox(width: 4),
                    ],
                    Text(
                      label,
                      style: TextStyle(
                        fontSize: small ? 10 : 13,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                        letterSpacing: 0.2,
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}

/// Wallet balance strip + Top up / Withdraw actions.
class _BalanceBar extends StatelessWidget {
  final bool loading;
  final double balance;
  final bool processing;
  final VoidCallback onTopUp;
  final VoidCallback onWithdraw;

  const _BalanceBar({
    required this.loading,
    required this.balance,
    required this.processing,
    required this.onTopUp,
    required this.onWithdraw,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            FanColors.primary.withOpacity(0.14),
            FanColors.primary.withOpacity(0.04)
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(_Tokens.radiusMd),
        border: Border.all(color: FanColors.primary.withOpacity(0.18)),
      ),
      child: Row(
        children: [
          const Icon(Icons.account_balance_wallet_rounded,
              size: 18, color: FanColors.primary),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              loading
                  ? 'Loading balance…'
                  : 'KES ${balance.toStringAsFixed(2)}',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w700,
                color: loading ? FanColors.textSecondary : Colors.white,
              ),
            ),
          ),
          _PillButton(
              label: 'Top up',
              icon: Icons.add,
              color: FanColors.primary,
              small: true,
              loading: processing,
              onTap: onTopUp),
          const SizedBox(width: 8),
          _PillButton(
              label: 'Withdraw',
              icon: Icons.arrow_downward,
              color: Colors.orange,
              small: true,
              loading: processing,
              onTap: onWithdraw),
        ],
      ),
    );
  }
}

// ============================================================================
// MAIN MODAL
// ============================================================================
class SwipeableVotePledgeModal extends StatefulWidget {
  final Fixture fixture;
  final String userId;
  final String username;
  final String? authToken;
  final bool isLoggedIn;
  final bool hasUserVoted;
  final String? userVoteSelection;
  final Set<String> comradesList;
  final bool showPledgesTab;
  final bool showBetsTab;
  final String channelId;
  final Future<bool> Function(String) onVote;
  final Future<bool> Function(String, double) onPledge;

  const SwipeableVotePledgeModal({
    super.key,
    required this.fixture,
    required this.userId,
    required this.username,
    this.authToken,
    required this.isLoggedIn,
    required this.hasUserVoted,
    this.userVoteSelection,
    required this.comradesList,
    this.showPledgesTab = true,
    this.showBetsTab = false,
    required this.channelId,
    required this.onVote,
    required this.onPledge,
  });

  @override
  State<SwipeableVotePledgeModal> createState() =>
      _SwipeableVotePledgeModalState();
}

class _SwipeableVotePledgeModalState extends State<SwipeableVotePledgeModal>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  int _selectedTab = 0;

  // Vote state
  String? _selectedVoteOption;
  bool _isVoting = false;

  // Voters state
  List<Voter> _voters = [];
  List<Voter> _filteredVoters = [];
  bool _isLoadingVoters = true;
  String _selectedFilter = 'all';
  final ScrollController _voterScroll = ScrollController();

  // Pledge state
  String? _selectedPledgeOption;
  final TextEditingController _pledgeAmountController = TextEditingController();
  double _userBalance = 0.0;
  bool _isLoadingBalance = true;
  bool _isPledging = false;
  List<Bettor> _pledges = [];
  bool _isLoadingPledges = true;

  // Bets state
  List<Bet> _bets = [];
  bool _isLoadingBets = true;
  int _currentBetIndex = 0;
  final PageController _betPageController = PageController();

  // STK Push state
  bool _isProcessingPayment = false;
  String? _currentCheckoutRequestId;

  // Match-pledge state
  String? _selectedMatchOption;
  bool _isMatching = false;

  StreamSubscription<Map<String, dynamic>>? _badgeSubscription;
  Timer? _pollingTimer;

  static const String _api = 'https://clash-api-m5mr.onrender.com/api';
  static const Duration _timeout = Duration(seconds: 15);

  // ==========================================================================
  // GETTERS
  // ==========================================================================

  bool get _showPledges => widget.showPledgesTab;
  bool get _showBets => widget.showBetsTab;

  int get _tabCount {
    int count = 1;
    if (_showPledges) count++;
    if (_showBets) count++;
    return count;
  }

  List<String> get _tabLabels {
    final labels = <String>['Votes'];
    if (_showPledges) labels.add('Pledges');
    if (_showBets) labels.add('Bets');
    return labels;
  }

  VoteStats get _voteStats {
    int home = 0, away = 0, draw = 0;
    for (var v in _voters) {
      switch (v.selection) {
        case 'home':
        case 'home_team':
          home++;
          break;
        case 'away':
        case 'away_team':
          away++;
          break;
        case 'draw':
          draw++;
          break;
      }
    }
    return VoteStats(homeCount: home, awayCount: away, drawCount: draw);
  }

  bool get _hasUserPledged => _pledges.any((p) => p.userId == widget.userId);

  // ==========================================================================
  // INIT
  // ==========================================================================

  @override
  void initState() {
    super.initState();

    _tabController =
        TabController(length: _tabCount, vsync: this, initialIndex: 0);
    _selectedTab = 0;

    _fetchUserBalance();
    _loadVoters();
    _loadPledges();
    if (_showBets) _loadBets();

    _tabController.addListener(() {
      if (_tabController.indexIsChanging) {
        setState(() => _selectedTab = _tabController.index);
      }
    });

    _listenToFCMUpdates();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _pledgeAmountController.dispose();
    _betPageController.dispose();
    _voterScroll.dispose();
    _badgeSubscription?.cancel();
    _pollingTimer?.cancel();
    super.dispose();
  }

  void _listenToFCMUpdates() {
    _badgeSubscription = NotificationService.badgeStream.listen((event) {
      if (!mounted) return;
      final eventFixtureId = event['fixture_id'] as String?;
      if (eventFixtureId == widget.fixture.matchId) {
        _loadVoters();
        _loadPledges();
        if (_showBets) _loadBets();
      }
    });
  }

  // ==========================================================================
  // DATA LOADING
  // ==========================================================================

  Map<String, String> _headers() {
    final h = {'Content-Type': 'application/json'};
    if (widget.authToken != null && widget.authToken!.isNotEmpty) {
      h['Authorization'] = 'Bearer ${widget.authToken}';
    }
    return h;
  }

  Future<void> _loadVoters() async {
    setState(() => _isLoadingVoters = true);
    try {
      final response = await http
          .get(
            Uri.parse(
                '$_api/actions/channel/${widget.channelId}/${widget.fixture.matchId}/votes'),
            headers: _headers(),
          )
          .timeout(_timeout);

      debugPrint('📥 VOTERS ${response.statusCode}: ${response.body}');

      if (response.statusCode == 200 && mounted) {
        final data = json.decode(response.body);
        setState(() {
          _voters = (data['votes'] as List? ?? [])
              .map((v) => Voter.fromJson(v))
              .toList();
          _filteredVoters = List.from(_voters);
          _isLoadingVoters = false;
        });
      } else {
        setState(() => _isLoadingVoters = false);
      }
    } catch (e) {
      debugPrint('❌ Error loading voters: $e');
      if (mounted) setState(() => _isLoadingVoters = false);
    }
  }

  Future<void> _loadPledges() async {
    setState(() => _isLoadingPledges = true);
    try {
      final response = await http
          .get(
            Uri.parse(
                '$_api/actions/channel/${widget.channelId}/${widget.fixture.matchId}/pledges'),
            headers: _headers(),
          )
          .timeout(_timeout);

      debugPrint('📥 PLEDGES ${response.statusCode}: ${response.body}');

      if (response.statusCode == 200 && mounted) {
        final data = json.decode(response.body);
        setState(() {
          _pledges = (data['pledges'] as List? ?? [])
              .map((p) => Bettor.fromOpenBet(p))
              .toList();
          _isLoadingPledges = false;
        });

        final userPledge = _pledges.firstWhere(
          (p) => p.userId == widget.userId,
          orElse: () => null as Bettor,
        );
        if (userPledge != null) {
          setState(() {
            _selectedPledgeOption = userPledge.selection;
            _pledgeAmountController.text = userPledge.amount.toString();
          });
        }
      } else {
        setState(() => _isLoadingPledges = false);
      }
    } catch (e) {
      debugPrint('❌ Error loading pledges: $e');
      if (mounted) setState(() => _isLoadingPledges = false);
    }
  }

  Future<void> _loadBets() async {
    setState(() => _isLoadingBets = true);
    try {
      final response = await http
          .get(
            Uri.parse(
                '$_api/actions/channel/${widget.channelId}/${widget.fixture.matchId}/bettors'),
            headers: _headers(),
          )
          .timeout(_timeout);

      debugPrint('📥 BETS ${response.statusCode}: ${response.body}');

      if (response.statusCode == 200 && mounted) {
        final data = json.decode(response.body);
        setState(() {
          _bets = (data['bettors'] as List? ?? [])
              .map((b) => Bet.fromJson(b))
              .toList();
          _isLoadingBets = false;
        });
      } else {
        setState(() => _isLoadingBets = false);
      }
    } catch (e) {
      debugPrint('❌ Error loading bets: $e');
      if (mounted) setState(() => _isLoadingBets = false);
    }
  }

  Future<void> _fetchUserBalance() async {
    if (!widget.isLoggedIn) {
      setState(() => _isLoadingBalance = false);
      return;
    }

    setState(() => _isLoadingBalance = true);
    try {
      final response = await http
          .get(Uri.parse('$_api/auth/user/id/${widget.userId}'),
              headers: _headers())
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200 && mounted) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          _userBalance = (data['user']['balance'] ?? 0.0).toDouble();
        }
      }
    } catch (e) {
      debugPrint('❌ Error fetching balance: $e');
    } finally {
      if (mounted) setState(() => _isLoadingBalance = false);
    }
  }

  Future<String> _getUserPhoneNumber() async {
    try {
      final response = await http
          .get(Uri.parse('$_api/auth/user/id/${widget.userId}'),
              headers: _headers())
          .timeout(const Duration(seconds: 5));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          return data['user']['phone']?.toString() ?? '';
        }
      }
      return '';
    } catch (e) {
      debugPrint('❌ Error fetching phone: $e');
      return '';
    }
  }

  // ==========================================================================
  // GENERIC SAVED-PHONE HELPERS
  // (replaces _fetchTopUpPhone/_saveTopUpPhone/_fetchWithdrawPhone/_saveWithdrawPhone)
  // ==========================================================================

  Future<String?> _fetchSavedPhone(String kind) async {
    try {
      final response = await http
          .get(Uri.parse('$_api/auth/user/${widget.userId}/$kind-phone'),
              headers: _headers())
          .timeout(const Duration(seconds: 5));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) return data['phone']?.toString();
      }
      return null;
    } catch (e) {
      debugPrint('❌ Error fetching $kind phone: $e');
      return null;
    }
  }

  Future<bool> _savePhone(String kind, String phone) async {
    try {
      final response = await http
          .post(
            Uri.parse('$_api/auth/user/${widget.userId}/$kind-phone'),
            headers: _headers(),
            body: json.encode({'phone': phone}),
          )
          .timeout(const Duration(seconds: 5));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data['success'] == true;
      }
      return false;
    } catch (e) {
      debugPrint('❌ Error saving $kind phone: $e');
      return false;
    }
  }

  bool _isValidPhoneNumber(String phone) {
    final cleaned = phone.replaceAll(RegExp(r'[^0-9]'), '');
    final regex = RegExp(r'^(0|254)?[7-9][0-9]{8}$');
    return regex.hasMatch(cleaned);
  }

  // ==========================================================================
  // VOTE HANDLING
  // ==========================================================================

  void _handleVote() async {
    if (_selectedVoteOption == null || widget.hasUserVoted) return;

    setState(() => _isVoting = true);
    try {
      final success = await widget.onVote(_selectedVoteOption!);
      if (success) {
        ToastHelper.showSuccess('Vote submitted!');
        if (mounted) Navigator.pop(context);
      } else {
        ToastHelper.showError('Vote failed. Please try again.');
      }
    } catch (e) {
      ToastHelper.showError('Vote failed: ${e.toString()}');
    } finally {
      if (mounted) setState(() => _isVoting = false);
    }
  }

  // ==========================================================================
  // PLEDGE HANDLING
  // ==========================================================================

  void _handlePledge() async {
    if (_selectedPledgeOption == null) {
      ToastHelper.showWarning('Please select a pick first');
      return;
    }

    final amount = double.tryParse(_pledgeAmountController.text);
    if (amount == null || amount <= 0) {
      ToastHelper.showWarning('Please enter a valid amount');
      return;
    }

    if (_userBalance < amount) {
      final shortfall = amount - _userBalance;
      ToastHelper.showInfo(
          'Insufficient balance. You need KES ${shortfall.toStringAsFixed(2)} more.');
      _showTopUpDialog(
        onComplete: () async {
          await _fetchUserBalance();
          if (_userBalance >= amount) {
            await _executePledge(_selectedPledgeOption!, amount);
          } else {
            ToastHelper.showError('Balance still insufficient after top up');
          }
        },
      );
      return;
    }

    await _executePledge(_selectedPledgeOption!, amount);
  }

  Future<void> _executePledge(String selection, double amount) async {
    setState(() => _isPledging = true);
    try {
      final response = await http
          .post(
            Uri.parse('$_api/actions/bet/create'),
            headers: _headers(),
            body: json.encode({
              'fixture_id': widget.fixture.matchId,
              'starter_id': widget.userId,
              'starter_name': widget.username,
              'starter_selection': selection,
              'amount': amount,
              'vote_id': widget.userId,
            }),
          )
          .timeout(_timeout);

      debugPrint('📥 PLEDGE ${response.statusCode}: ${response.body}');
      final data = json.decode(response.body);

      if (data['success'] == true) {
        ToastHelper.showSuccess('Pledge created! 🎉');
        await _fetchUserBalance();
        await _loadPledges();
        if (mounted) Navigator.pop(context);
      } else {
        ToastHelper.showError(data['message'] ?? 'Failed to create pledge');
      }
    } catch (e) {
      debugPrint('❌ Pledge error: $e');
      ToastHelper.showError('Network error: ${e.toString()}');
    } finally {
      if (mounted) setState(() => _isPledging = false);
    }
  }

  // ==========================================================================
  // STK PUSH PAYMENT
  // ==========================================================================

  Future<bool> _waitForSTKCompletion(String checkoutRequestId) async {
    final completer = Completer<bool>();

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: FanColors.surfaceElevated,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(_Tokens.radiusLg)),
        title: const Text('Processing Payment'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const CircularProgressIndicator(color: FanColors.primary),
            const SizedBox(height: 16),
            Text(
              'Enter PIN on your phone to complete payment',
              style: TextStyle(color: Colors.white.withOpacity(0.7)),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              'This will automatically update your balance',
              style: TextStyle(
                  fontSize: 12, color: FanColors.primary.withOpacity(0.7)),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                _pollingTimer?.cancel();
                completer.complete(false);
              },
              child: const Text('Cancel Payment'),
            ),
          ],
        ),
      ),
    );

    bool isCompleted = false;
    int attempts = 0;
    const maxAttempts = 60;

    while (!isCompleted && attempts < maxAttempts) {
      await Future.delayed(const Duration(seconds: 1));
      attempts++;

      try {
        final status = await _checkSTKStatus(checkoutRequestId);
        if (status == 'completed') {
          isCompleted = true;
          ToastHelper.showSuccess('Payment successful!');
          if (mounted) Navigator.pop(context);
          completer.complete(true);
          break;
        } else if (status == 'failed' || status == 'cancelled') {
          isCompleted = true;
          ToastHelper.showError(
              'Payment ${status == 'cancelled' ? 'cancelled' : 'failed'}');
          if (mounted) Navigator.pop(context);
          completer.complete(false);
          break;
        }
      } catch (e) {
        debugPrint('❌ Status check error: $e');
      }
    }

    if (!isCompleted) {
      ToastHelper.showWarning('Payment timeout - check your phone');
      if (mounted) Navigator.pop(context);
      completer.complete(false);
    }

    return completer.future;
  }

  Future<String> _checkSTKStatus(String checkoutRequestId) async {
    try {
      final response = await http
          .post(
            Uri.parse('$_api/lipaclash/check-payment-status'),
            headers: _headers(),
            body: json.encode({'checkout_request_id': checkoutRequestId}),
          )
          .timeout(const Duration(seconds: 5));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) return 'completed';
        if (data['failed'] == true) return 'failed';
        if (data['cancelled'] == true) return 'cancelled';
        return 'pending';
      }
      return 'pending';
    } catch (e) {
      debugPrint('❌ Status check error: $e');
      return 'pending';
    }
  }

  Future<bool> _initiateSTKPush(double amount,
      {String? phoneNumber, String? purpose}) async {
    if (_isProcessingPayment) return false;
    setState(() => _isProcessingPayment = true);

    try {
      String phone = phoneNumber ?? '';
      if (phone.isEmpty) phone = await _getUserPhoneNumber();

      if (phone.isEmpty) {
        ToastHelper.showError(
            'Phone number required. Please update your profile.');
        setState(() => _isProcessingPayment = false);
        return false;
      }

      final response = await http
          .post(
            Uri.parse('$_api/lipaclash/stk-push'),
            headers: _headers(),
            body: json.encode({
              'phone_number': phone,
              'amount': amount.toString(),
              'account_reference': widget.username,
              'transaction_desc': purpose ?? 'Top up balance',
            }),
          )
          .timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          _currentCheckoutRequestId = data['checkout_request_id'];
          final success =
              await _waitForSTKCompletion(_currentCheckoutRequestId!);
          setState(() => _isProcessingPayment = false);
          return success;
        } else {
          ToastHelper.showError(data['message'] ?? 'Payment initiation failed');
          setState(() => _isProcessingPayment = false);
          return false;
        }
      } else {
        ToastHelper.showError('Payment service unavailable');
        setState(() => _isProcessingPayment = false);
        return false;
      }
    } catch (e) {
      debugPrint('❌ STK Push error: $e');
      ToastHelper.showError('Failed to initiate payment');
      setState(() => _isProcessingPayment = false);
      return false;
    }
  }

  Future<bool> _processWithdrawal(
      {required double amount, required String phone}) async {
    setState(() => _isProcessingPayment = true);
    try {
      final response = await http
          .post(
            Uri.parse('$_api/transactions/withdraw'),
            headers: _headers(),
            body: json.encode({
              'user_id': widget.userId,
              'username': widget.username,
              'amount': amount,
              'phone_number': phone,
              'timestamp': DateTime.now().toIso8601String(),
            }),
          )
          .timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          setState(() => _isProcessingPayment = false);
          return true;
        }
        ToastHelper.showError(data['message'] ?? 'Withdrawal failed');
        setState(() => _isProcessingPayment = false);
        return false;
      }
      ToastHelper.showError('Withdrawal service unavailable');
      setState(() => _isProcessingPayment = false);
      return false;
    } catch (e) {
      debugPrint('❌ Withdrawal error: $e');
      ToastHelper.showError('Failed to process withdrawal');
      setState(() => _isProcessingPayment = false);
      return false;
    }
  }

  // ==========================================================================
  // ONE DIALOG FOR TOP UP + WITHDRAW
  // (replaces _showTopUpDialog + _showWithdrawDialog, which were ~95% identical)
  // ==========================================================================

  void _showTopUpDialog({VoidCallback? onComplete}) =>
      _showFundsDialog(isWithdraw: false, onComplete: onComplete);
  void _showWithdrawDialog() => _showFundsDialog(isWithdraw: true);

  void _showFundsDialog({required bool isWithdraw, VoidCallback? onComplete}) {
    final amountController = TextEditingController();
    final phoneController = TextEditingController();
    final kind = isWithdraw ? 'withdraw' : 'topup';
    bool useSavedPhone = true;
    String? savedPhone;
    bool isLoading = true;

    _fetchSavedPhone(kind).then((phone) {
      savedPhone = phone;
      if (phone != null && phone.isNotEmpty) phoneController.text = phone;
      isLoading = false;
    });

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => StatefulBuilder(
        builder: (context, setStateDialog) {
          if (isLoading) {
            Future.delayed(const Duration(milliseconds: 60), () {
              if (context.mounted) setStateDialog(() {});
            });
          }

          final accent = isWithdraw ? Colors.orange : FanColors.primary;

          return AlertDialog(
            backgroundColor: FanColors.surfaceElevated,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(_Tokens.radiusLg),
              side: const BorderSide(color: FanColors.border),
            ),
            title: Row(
              children: [
                Icon(isWithdraw ? Icons.account_balance : Icons.add_circle,
                    color: accent, size: 22),
                const SizedBox(width: 8),
                Text(isWithdraw ? 'Withdraw Funds' : 'Top Up Balance'),
              ],
            ),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 10),
                    decoration: _Tokens.card(
                        borderColor: FanColors.border.withOpacity(0.3)),
                    child: Row(
                      children: [
                        const Icon(Icons.account_balance_wallet,
                            size: 16, color: FanColors.primary),
                        const SizedBox(width: 8),
                        Text(
                          'Balance: KES ${_userBalance.toStringAsFixed(2)}',
                          style: const TextStyle(
                              fontSize: 13, color: FanColors.textPrimary),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: amountController,
                    autofocus: !isWithdraw,
                    decoration: const InputDecoration(
                      labelText: 'Amount (KES)',
                      hintText: 'Enter amount',
                      prefixIcon: Icon(Icons.monetization_on),
                    ),
                    keyboardType: TextInputType.number,
                  ),
                  const SizedBox(height: 12),
                  isLoading && isWithdraw
                      ? const Padding(
                          padding: EdgeInsets.all(12),
                          child: SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                                strokeWidth: 2, color: FanColors.primary),
                          ),
                        )
                      : TextField(
                          controller: phoneController,
                          decoration: InputDecoration(
                            labelText: 'M-Pesa Phone Number',
                            hintText: 'e.g., 0712345678',
                            prefixIcon: const Icon(Icons.phone_android),
                            suffixIcon: IconButton(
                              icon: const Icon(Icons.clear, size: 18),
                              onPressed: () => phoneController.clear(),
                            ),
                          ),
                          keyboardType: TextInputType.phone,
                        ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Checkbox(
                        value: useSavedPhone,
                        activeColor: FanColors.primary,
                        onChanged: (val) {
                          setStateDialog(() {
                            useSavedPhone = val ?? true;
                            if (useSavedPhone && savedPhone != null) {
                              phoneController.text = savedPhone!;
                            } else {
                              phoneController.clear();
                            }
                          });
                        },
                      ),
                      Expanded(
                        child: Text(
                          'Save this number for future ${isWithdraw ? 'withdrawals' : 'top-ups'}',
                          style: const TextStyle(
                              fontSize: 12, color: FanColors.textSecondary),
                        ),
                      ),
                    ],
                  ),
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: accent.withOpacity(0.06),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      children: [
                        Icon(
                            isWithdraw
                                ? Icons.warning_amber_rounded
                                : Icons.info_outline,
                            size: 14,
                            color: accent),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            isWithdraw
                                ? 'Withdrawals are processed within 24 hours'
                                : 'Enter any M-Pesa number. You will receive a prompt to enter your PIN.',
                            style: TextStyle(fontSize: 10, color: accent),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text('Cancel',
                    style: TextStyle(color: FanColors.textSecondary)),
              ),
              ElevatedButton(
                onPressed: () async {
                  final amountText = amountController.text.trim();
                  final phone = phoneController.text.trim();

                  if (amountText.isEmpty ||
                      double.tryParse(amountText) == null ||
                      double.parse(amountText) <= 0) {
                    ToastHelper.showWarning('Please enter a valid amount');
                    return;
                  }
                  if (phone.isEmpty || !_isValidPhoneNumber(phone)) {
                    ToastHelper.showWarning(
                        'Please enter a valid phone number');
                    return;
                  }

                  final amount = double.parse(amountText);

                  if (isWithdraw) {
                    if (amount > _userBalance) {
                      ToastHelper.showWarning('Insufficient balance');
                      return;
                    }
                    Navigator.pop(context);
                    final success =
                        await _processWithdrawal(amount: amount, phone: phone);
                    if (success && mounted) {
                      if (useSavedPhone) await _savePhone(kind, phone);
                      await _fetchUserBalance();
                      ToastHelper.showSuccess('Withdrawal request submitted!');
                    }
                  } else {
                    Navigator.pop(context);
                    final success = await _initiateSTKPush(amount,
                        phoneNumber: phone, purpose: 'Top up balance');
                    if (success && mounted) {
                      if (useSavedPhone) await _savePhone(kind, phone);
                      await _fetchUserBalance();
                      ToastHelper.showSuccess('Balance updated successfully!');
                      onComplete?.call();
                    }
                  }
                },
                style: ElevatedButton.styleFrom(backgroundColor: accent),
                child: _isProcessingPayment
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                            strokeWidth: 2, color: Colors.white),
                      )
                    : Text(isWithdraw ? 'Withdraw' : 'Pay via M-Pesa'),
              ),
            ],
          );
        },
      ),
    );
  }

  // ==========================================================================
  // SHARE
  // ==========================================================================

  void _shareChannel() {
    final matchName =
        '${widget.fixture.homeTeam} vs ${widget.fixture.awayTeam}';
    final message = '⚔️ Join the voting on Clash!\n\n'
        '📊 Vote on: $matchName\n'
        '🏆 ${widget.fixture.league}\n\n'
        'Download the app and vote now!';

    Share.share(message, subject: 'Clash - $matchName');
  }

  // ==========================================================================
  // HELPERS
  // ==========================================================================

  void _applyFilter() {
    final List<Voter> filtered;
    switch (_selectedFilter) {
      case 'home':
        filtered = _voters
            .where((v) => v.selection == 'home_team' || v.selection == 'home')
            .toList();
        break;
      case 'away':
        filtered = _voters
            .where((v) => v.selection == 'away_team' || v.selection == 'away')
            .toList();
        break;
      case 'draw':
        filtered = _voters.where((v) => v.selection == 'draw').toList();
        break;
      default:
        filtered = List.from(_voters);
    }
    _filteredVoters = filtered;
  }

  String _displayVote(String sel) {
    if (sel == 'home_team' || sel == 'home') return widget.fixture.homeTeam;
    if (sel == 'away_team' || sel == 'away') return widget.fixture.awayTeam;
    if (sel == 'draw') return 'Draw';
    return sel;
  }

  Color _getVoteColor(String sel) {
    switch (sel) {
      case 'home_team':
      case 'home':
        return FanColors.primary;
      case 'away_team':
      case 'away':
        return _Tokens.away;
      case 'draw':
        return _Tokens.draw;
      default:
        return FanColors.textSecondary;
    }
  }

  String _timeAgo(DateTime date) {
    final diff = DateTime.now().difference(date);
    if (diff.inMinutes < 1) return 'Just now';
    if (diff.inHours < 1) return '${diff.inMinutes}m ago';
    if (diff.inDays < 1) return '${diff.inHours}h ago';
    return '${diff.inDays}d ago';
  }

  // ==========================================================================
  // HEADER / TAB BAR
  // ==========================================================================

  Widget _buildHandleBar() => Container(
        margin: const EdgeInsets.only(top: 10, bottom: 6),
        width: 40,
        height: 4,
        decoration: BoxDecoration(
          color: FanColors.border.withOpacity(0.3),
          borderRadius: BorderRadius.circular(2),
        ),
      );

  Widget _buildHeader() {
    final tabLabels = _tabLabels;
    final currentLabel =
        _selectedTab < tabLabels.length ? tabLabels[_selectedTab] : 'Votes';
    final icon = _selectedTab == 0
        ? Icons.how_to_vote_rounded
        : (_selectedTab == 1 && _showPledges
            ? Icons.attach_money_rounded
            : Icons.sports_score_rounded);

    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 12),
      child: Row(
        children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  FanColors.primary.withOpacity(0.35),
                  FanColors.primary.withOpacity(0.1)
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, size: 22, color: FanColors.primary),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  currentLabel,
                  style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                      color: Colors.white),
                ),
                Text(
                  '${widget.fixture.homeTeam} vs ${widget.fixture.awayTeam}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontSize: 12, color: Colors.white.withOpacity(0.55)),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(7),
              decoration: const BoxDecoration(
                  color: FanColors.surface, shape: BoxShape.circle),
              child: const Icon(Icons.close, size: 18, color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabBar() {
    if (_tabCount <= 1) return const SizedBox.shrink();

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
          color: FanColors.surface, borderRadius: BorderRadius.circular(14)),
      child: TabBar(
        controller: _tabController,
        indicator: BoxDecoration(
          color: FanColors.primary.withOpacity(0.18),
          borderRadius: BorderRadius.circular(10),
        ),
        indicatorSize: TabBarIndicatorSize.tab,
        labelColor: FanColors.primary,
        unselectedLabelColor: FanColors.textSecondary,
        labelStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
        unselectedLabelStyle:
            const TextStyle(fontSize: 13, fontWeight: FontWeight.w400),
        tabs: _tabLabels.map((label) => Tab(text: label)).toList(),
      ),
    );
  }

  // ==========================================================================
  // VOTE SELECTION (top strip, shared _OutcomeRow)
  // ==========================================================================

  Widget _buildVoteSelectionFragment() {
    final fixture = widget.fixture;
    final isVoted = widget.hasUserVoted;
    final effectiveSelection =
        isVoted ? widget.userVoteSelection : _selectedVoteOption;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        children: [
          _OutcomeRow(
            homeLabel: fixture.homeTeam,
            awayLabel: fixture.awayTeam,
            homeOdds: fixture.homeWin,
            drawOdds: fixture.draw,
            awayOdds: fixture.awayWin,
            selected: effectiveSelection,
            locked: isVoted,
            onSelect:
                isVoted ? null : (v) => setState(() => _selectedVoteOption = v),
          ),
          if (_selectedVoteOption != null && !isVoted)
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: SizedBox(
                width: double.infinity,
                child: _PillButton(
                  label: 'Confirm Vote',
                  color: FanColors.primary,
                  loading: _isVoting,
                  onTap: _handleVote,
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ==========================================================================
  // VOTES LIST FRAGMENT
  // ==========================================================================

  Widget _buildVotesListFragment() {
    return Column(
      children: [
        _buildVoteSummary(),
        _buildFilterChips(),
        Expanded(child: _buildVotersList()),
      ],
    );
  }

  Widget _buildVoteSummary() => Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: _Tokens.card(),
        child: Column(
          children: [
            Row(
              children: [
                _buildVoteStat(widget.fixture.homeTeam, _voteStats.homeCount,
                    _voteStats.homePercentage, FanColors.primary),
                const SizedBox(width: 8),
                _buildVoteStat('Draw', _voteStats.drawCount,
                    _voteStats.drawPercentage, _Tokens.draw),
                const SizedBox(width: 8),
                _buildVoteStat(widget.fixture.awayTeam, _voteStats.awayCount,
                    _voteStats.awayPercentage, _Tokens.away),
              ],
            ),
            const SizedBox(height: 8),
            ClipRRect(
              borderRadius: BorderRadius.circular(3),
              child: SizedBox(
                height: 5,
                child: Row(
                  children: _voteStats.total == 0
                      ? [Expanded(child: Container(color: FanColors.border))]
                      : [
                          if (_voteStats.homeCount > 0)
                            Flexible(
                              flex: _voteStats.homePercentage
                                  .round()
                                  .clamp(1, 100),
                              child: Container(color: FanColors.primary),
                            ),
                          if (_voteStats.drawCount > 0)
                            Flexible(
                              flex: _voteStats.drawPercentage
                                  .round()
                                  .clamp(1, 100),
                              child: Container(color: _Tokens.draw),
                            ),
                          if (_voteStats.awayCount > 0)
                            Flexible(
                              flex: _voteStats.awayPercentage
                                  .round()
                                  .clamp(1, 100),
                              child: Container(color: _Tokens.away),
                            ),
                        ],
                ),
              ),
            ),
          ],
        ),
      );

  Widget _buildVoteStat(
      String label, int count, double percentage, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 6),
        decoration: BoxDecoration(
            color: color.withOpacity(0.06),
            borderRadius: BorderRadius.circular(10)),
        child: Column(
          children: [
            Text(count.toString(),
                style: TextStyle(
                    fontSize: 15, fontWeight: FontWeight.w800, color: color)),
            Text(label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    fontSize: 8, fontWeight: FontWeight.w600, color: color)),
            Text('${percentage.toStringAsFixed(0)}%',
                style: TextStyle(fontSize: 7, color: color.withOpacity(0.7))),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterChips() => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        child: Row(
          children: [
            _buildFilterChip('All', 'all', _voteStats.total, FanColors.primary),
            const SizedBox(width: 4),
            _buildFilterChip(widget.fixture.homeTeam, 'home',
                _voteStats.homeCount, FanColors.primary),
            const SizedBox(width: 4),
            _buildFilterChip(
                'Draw', 'draw', _voteStats.drawCount, _Tokens.draw),
            const SizedBox(width: 4),
            _buildFilterChip(widget.fixture.awayTeam, 'away',
                _voteStats.awayCount, _Tokens.away),
          ],
        ),
      );

  Widget _buildFilterChip(String label, String filter, int count, Color color) {
    final isSelected = _selectedFilter == filter;
    return GestureDetector(
      onTap: () => setState(() {
        _selectedFilter = filter;
        _applyFilter();
      }),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: isSelected ? color : color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              label,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                  fontSize: 9,
                  fontWeight: isSelected ? FontWeight.w700 : FontWeight.normal,
                  color: isSelected ? Colors.white : color),
            ),
            if (count > 0) ...[
              const SizedBox(width: 3),
              Text('$count',
                  style: TextStyle(
                      fontSize: 8,
                      fontWeight: FontWeight.w700,
                      color:
                          isSelected ? Colors.white.withOpacity(0.85) : color)),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildVotersList() {
    if (_isLoadingVoters && _voters.isEmpty) {
      return _emptyState(spinner: true, label: 'Loading votes…');
    }

    if (_filteredVoters.isEmpty) {
      return _emptyState(
        icon: Icons.how_to_vote_outlined,
        label: _selectedFilter == 'all'
            ? 'No votes yet'
            : 'No votes for this selection',
        actionLabel: _selectedFilter != 'all' ? 'Show all votes' : null,
        onAction: () => setState(() {
          _selectedFilter = 'all';
          _applyFilter();
        }),
      );
    }

    return ListView.builder(
      controller: _voterScroll,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      itemCount: _filteredVoters.length,
      itemBuilder: (context, index) {
        final voter = _filteredVoters[index];
        final isMe = voter.userId == widget.userId;
        final voteColor = _getVoteColor(voter.selection);
        final voteDisplay = _displayVote(voter.selection);

        return _PersonTile(
          name: voter.userName,
          isMe: isMe,
          accent: voteColor,
          subtitle: 'Voted for $voteDisplay',
          badges: [
            if (voter.isComrade && !isMe)
              const _Badge(label: 'comrade', color: FanColors.primary)
          ],
          trailing: Container(
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
            decoration: BoxDecoration(
                color: voteColor.withOpacity(0.12),
                borderRadius: BorderRadius.circular(14)),
            child: Text(voteDisplay,
                style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                    color: voteColor)),
          ),
        );
      },
    );
  }

  // ==========================================================================
  // SHARED EMPTY-STATE
  // ==========================================================================

  Widget _emptyState({
    bool spinner = false,
    IconData icon = Icons.info_outline,
    required String label,
    String? sublabel,
    String? actionLabel,
    VoidCallback? onAction,
  }) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (spinner)
            const SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(
                    color: FanColors.primary, strokeWidth: 2))
          else
            Icon(icon, size: 38, color: FanColors.border),
          const SizedBox(height: 12),
          Text(label,
              style: TextStyle(fontSize: 13, color: FanColors.textSecondary)),
          if (sublabel != null) ...[
            const SizedBox(height: 4),
            Text(sublabel,
                style: TextStyle(fontSize: 10, color: FanColors.textTertiary)),
          ],
          if (actionLabel != null)
            Padding(
              padding: const EdgeInsets.only(top: 12),
              child: GestureDetector(
                onTap: onAction,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                  decoration: BoxDecoration(
                      color: FanColors.primary.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(20)),
                  child: Text(actionLabel,
                      style: const TextStyle(
                          color: FanColors.primary,
                          fontWeight: FontWeight.w600,
                          fontSize: 11)),
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ==========================================================================
  // PLEDGE FRAGMENT
  // ==========================================================================

  Widget _buildPledgesFragment() {
    if (!_showPledges) return const SizedBox.shrink();

    final fixture = widget.fixture;
    final hasUserPledged = _hasUserPledged;

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _BalanceBar(
            loading: _isLoadingBalance,
            balance: _userBalance,
            processing: _isProcessingPayment,
            onTopUp: _showTopUpDialog,
            onWithdraw: _showWithdrawDialog,
          ),
          const SizedBox(height: 12),
          Text(
            hasUserPledged
                ? '💰 You can pledge multiple times on different picks'
                : 'Select your pick and enter amount to pledge',
            style:
                TextStyle(fontSize: 11, color: Colors.white.withOpacity(0.6)),
          ),
          const SizedBox(height: 12),
          _OutcomeRow(
            homeLabel: fixture.homeTeam,
            awayLabel: fixture.awayTeam,
            homeOdds: fixture.homeWin,
            drawOdds: fixture.draw,
            awayOdds: fixture.awayWin,
            selected: _selectedPledgeOption,
            onSelect: (v) => setState(() => _selectedPledgeOption = v),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _pledgeAmountController,
                  keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                  style: const TextStyle(color: Colors.white, fontSize: 13),
                  decoration: InputDecoration(
                    labelText: 'Amount (KES)',
                    labelStyle: TextStyle(
                        color: Colors.white.withOpacity(0.6), fontSize: 12),
                    filled: true,
                    fillColor: FanColors.surface,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(_Tokens.radiusSm),
                      borderSide:
                          BorderSide(color: FanColors.border.withOpacity(0.3)),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(_Tokens.radiusSm),
                      borderSide:
                          BorderSide(color: FanColors.border.withOpacity(0.3)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(_Tokens.radiusSm),
                      borderSide: const BorderSide(color: FanColors.primary),
                    ),
                    prefixIcon: const Icon(Icons.attach_money,
                        color: FanColors.primary, size: 18),
                    contentPadding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                  onChanged: (_) => setState(() {}),
                ),
              ),
              const SizedBox(width: 8),
              _PillButton(
                label: '',
                icon: Icons.send_rounded,
                color: FanColors.primary,
                loading: _isPledging,
                onTap: (_selectedPledgeOption != null &&
                        _pledgeAmountController.text.isNotEmpty)
                    ? _handlePledge
                    : null,
              ),
            ],
          ),
          const SizedBox(height: 12),
          const Divider(color: FanColors.border, height: 1),
          const SizedBox(height: 8),
          Row(
            children: [
              Text('Pledges (${_pledges.length})',
                  style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: Colors.white)),
              const Spacer(),
              if (_isLoadingPledges)
                const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: FanColors.primary)),
            ],
          ),
          const SizedBox(height: 8),
          Expanded(child: _buildPledgeList()),
        ],
      ),
    );
  }

  Widget _buildPledgeList() {
    if (_isLoadingPledges) {
      return const Center(
        child: SizedBox(
            width: 20,
            height: 20,
            child: CircularProgressIndicator(
                strokeWidth: 2, color: FanColors.primary)),
      );
    }

    if (_pledges.isEmpty) {
      return _emptyState(
          icon: Icons.attach_money,
          label: 'No pledges yet',
          sublabel: 'Be the first to pledge on this match');
    }

    final isLive = widget.fixture.isLive == true;

    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: _pledges.length,
      itemBuilder: (context, index) {
        final pledge = _pledges[index];
        final isMe = pledge.userId == widget.userId;
        final voteColor = _getVoteColor(pledge.selection);
        final voteDisplay = _displayVote(pledge.selection);
        final canMatch = !isMe && pledge.isOpen && !isLive;

        return _PersonTile(
          name: pledge.userName,
          isMe: isMe,
          accent: voteColor,
          highlight: isMe,
          subtitle: 'Pledged for $voteDisplay',
          badges: [
            if (isMe) const _Badge(label: 'you', color: FanColors.primary),
            if (isLive && !isMe)
              const _Badge(
                  label: 'LIVE', color: Colors.orange, icon: Icons.circle),
          ],
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (canMatch) ...[
                _PillButton(
                    label: 'MATCH',
                    color: FanColors.primary,
                    small: true,
                    onTap: () => _matchPledge(pledge)),
                const SizedBox(width: 6),
              ],
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                    color: FanColors.primary.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(12)),
                child: Text('KES ${pledge.amount.toStringAsFixed(2)}',
                    style: const TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: FanColors.primary)),
              ),
            ],
          ),
        );
      },
    );
  }

  // ==========================================================================
  // MATCH BET (CLOSE PLEDGE)
  // ==========================================================================

  Future<void> _matchPledge(Bettor pledge) async {
    if (_isMatching) return;

    await _fetchUserBalance();

    if (_userBalance < pledge.amount) {
      final shortfall = pledge.amount - _userBalance;

      final shouldTopUp = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
          backgroundColor: FanColors.surfaceElevated,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(_Tokens.radiusLg)),
          title: const Row(
            children: [
              Icon(Icons.warning_amber_rounded, color: Colors.orange, size: 24),
              SizedBox(width: 8),
              Text('Insufficient Balance'),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: _Tokens.card(
                    borderColor: FanColors.border.withOpacity(0.3)),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                        'You need KES ${pledge.amount.toStringAsFixed(2)} to match this pledge',
                        style: const TextStyle(color: FanColors.textPrimary)),
                    const SizedBox(height: 4),
                    Text('Your balance: KES ${_userBalance.toStringAsFixed(2)}',
                        style: const TextStyle(color: FanColors.textSecondary)),
                    const SizedBox(height: 4),
                    Text('Shortfall: KES ${shortfall.toStringAsFixed(2)}',
                        style: const TextStyle(
                            color: Colors.orange, fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                    color: FanColors.primary.withOpacity(0.06),
                    borderRadius: BorderRadius.circular(8)),
                child: Row(
                  children: [
                    const Icon(Icons.info_outline,
                        size: 16, color: FanColors.primary),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                          'Top up the shortfall amount (KES ${shortfall.toStringAsFixed(2)}) to continue',
                          style: const TextStyle(
                              fontSize: 11, color: FanColors.textSecondary)),
                    ),
                  ],
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: Text('Cancel',
                    style: TextStyle(color: FanColors.textSecondary))),
            ElevatedButton(
              onPressed: () => Navigator.pop(context, true),
              style:
                  ElevatedButton.styleFrom(backgroundColor: FanColors.primary),
              child: const Text('Top Up & Match'),
            ),
          ],
        ),
      );

      if (shouldTopUp != true) return;

      final topUpSuccess =
          await _initiateSTKPush(shortfall, purpose: 'Top up to match pledge');
      if (!topUpSuccess) {
        ToastHelper.showError('Top-up failed. Please try again.');
        return;
      }

      await _fetchUserBalance();
      if (_userBalance < pledge.amount) {
        ToastHelper.showError('Balance still insufficient after top-up');
        return;
      }
    }

    _showMatchConfirmation(pledge);
  }

  void _showMatchConfirmation(Bettor pledge) {
    final String oppositeSelection;
    final String oppositeTitle;
    final Color oppositeColor;

    if (pledge.selection == 'home' || pledge.selection == 'home_team') {
      oppositeSelection = 'away';
      oppositeTitle = widget.fixture.awayTeam;
      oppositeColor = _Tokens.away;
    } else if (pledge.selection == 'away' || pledge.selection == 'away_team') {
      oppositeSelection = 'home';
      oppositeTitle = widget.fixture.homeTeam;
      oppositeColor = FanColors.primary;
    } else {
      _showDrawMatchConfirmation(pledge);
      return;
    }

    _selectedMatchOption = oppositeSelection;

    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (context) => AlertDialog(
        backgroundColor: FanColors.surfaceElevated,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(_Tokens.radiusMd)),
        titlePadding: const EdgeInsets.fromLTRB(20, 16, 12, 0),
        contentPadding: const EdgeInsets.fromLTRB(20, 12, 20, 8),
        title: Row(
          children: [
            const Icon(Icons.sports_score,
                color: FanColors.secondary, size: 18),
            const SizedBox(width: 8),
            const Text('Match Pledge',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _matchPledgeSummaryCard(pledge),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                color: oppositeColor.withOpacity(0.15),
                borderRadius: BorderRadius.circular(_Tokens.radiusSm),
                border: Border.all(color: oppositeColor, width: 2),
              ),
              child: Center(
                child: Text(oppositeTitle,
                    style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: oppositeColor)),
              ),
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                  color: Colors.red.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(4)),
              child: Row(
                children: [
                  const Icon(Icons.block, size: 12, color: Colors.red),
                  const SizedBox(width: 4),
                  Text('Cannot pick ${pledge.selectionDisplay}',
                      style: const TextStyle(fontSize: 10, color: Colors.red)),
                ],
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _executeMatch(pledge, oppositeSelection);
            },
            style: ElevatedButton.styleFrom(backgroundColor: FanColors.primary),
            child: const Text('Match'),
          ),
        ],
      ),
    );
  }

  void _showDrawMatchConfirmation(Bettor pledge) {
    _selectedMatchOption = null;

    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (context) => StatefulBuilder(
        builder: (context, setStateDialog) => AlertDialog(
          backgroundColor: FanColors.surfaceElevated,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(_Tokens.radiusMd)),
          titlePadding: const EdgeInsets.fromLTRB(20, 16, 12, 0),
          contentPadding: const EdgeInsets.fromLTRB(20, 12, 20, 8),
          title: Row(
            children: [
              const Icon(Icons.sports_score,
                  color: FanColors.secondary, size: 18),
              const SizedBox(width: 8),
              const Text('Match Pledge',
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _matchPledgeSummaryCard(pledge),
              const SizedBox(height: 10),
              const Align(
                alignment: Alignment.centerLeft,
                child: Text('Pick a team:',
                    style: TextStyle(fontSize: 12, color: Colors.white70)),
              ),
              const SizedBox(height: 6),
              _OutcomeRow(
                homeLabel: widget.fixture.homeTeam,
                awayLabel: widget.fixture.awayTeam,
                selected: _selectedMatchOption,
                compact: true,
                onSelect: (v) {
                  if (v == 'draw') return;
                  setStateDialog(() => _selectedMatchOption = v);
                },
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                _selectedMatchOption = null;
                Navigator.pop(context);
              },
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: _selectedMatchOption == null
                  ? null
                  : () {
                      Navigator.pop(context);
                      _executeMatch(pledge, _selectedMatchOption!);
                    },
              style:
                  ElevatedButton.styleFrom(backgroundColor: FanColors.primary),
              child: const Text('Match'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _matchPledgeSummaryCard(Bettor pledge) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: _Tokens.card(
            borderColor: FanColors.border.withOpacity(0.2), radius: 6),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(pledge.userName,
                    style: const TextStyle(
                        fontSize: 12, color: FanColors.textPrimary)),
                Text('Picked ${pledge.selectionDisplay}',
                    style: const TextStyle(
                        fontSize: 10, color: FanColors.primary)),
              ],
            ),
            Text('KES ${pledge.amount.toStringAsFixed(2)}',
                style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    color: FanColors.secondary)),
          ],
        ),
      );

  Future<void> _executeMatch(Bettor pledge, String selection) async {
    setState(() => _isMatching = true);
    try {
      ToastHelper.showInfo('🔄 Matching pledge...');

      final response = await http
          .post(
            Uri.parse('$_api/actions/bet/fill'),
            headers: _headers(),
            body: json.encode({
              'bet_id': pledge.betId,
              'finisher_id': widget.userId,
              'finisher_name': widget.username,
              'finisher_selection': selection,
              'amount': pledge.amount,
              'channel_id': '',
            }),
          )
          .timeout(const Duration(seconds: 15));

      final data = json.decode(response.body);

      if (data['success'] == true) {
        ToastHelper.showSuccess('✅ Bet matched successfully! 🎉');
        await _loadPledges();
        await _loadBets();
        await _fetchUserBalance();

        Future.delayed(const Duration(milliseconds: 500), () {
          if (mounted) Navigator.pop(context);
        });
      } else {
        ToastHelper.showError(data['message'] ?? 'Failed to match bet');
      }
    } catch (e) {
      ToastHelper.showError('Error: ${e.toString()}');
    } finally {
      if (mounted) setState(() => _isMatching = false);
    }
  }

  // ==========================================================================
  // BETS FRAGMENT
  // ==========================================================================

  Widget _buildBetsFragment() {
    if (!_showBets) return const SizedBox.shrink();

    final isLive = widget.fixture.isLive == true;

    if (isLive) {
      return _emptyState(
        icon: Icons.sports_score,
        label: '⛔ Betting is disabled during live matches',
        sublabel: 'Come back after the match ends',
      );
    }

    if (_isLoadingBets)
      return _emptyState(spinner: true, label: 'Loading bets…');

    if (_bets.isEmpty) {
      return _emptyState(
          icon: Icons.sports_score,
          label: 'No active bets',
          sublabel: 'Accept a pledge to start betting');
    }

    return Column(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(
              _bets.length,
              (index) => AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                margin: const EdgeInsets.symmetric(horizontal: 4),
                width: _currentBetIndex == index ? 20 : 8,
                height: 6,
                decoration: BoxDecoration(
                  color: _currentBetIndex == index
                      ? FanColors.primary
                      : FanColors.border,
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
            ),
          ),
        ),
        Expanded(
          child: PageView.builder(
            controller: _betPageController,
            onPageChanged: (index) => setState(() => _currentBetIndex = index),
            itemCount: _bets.length,
            itemBuilder: (context, index) => _buildBetCard(_bets[index]),
          ),
        ),
      ],
    );
  }

  Widget _buildBetCard(Bet bet) {
    final isStarter = bet.starterId == widget.userId;
    final isFinisher = bet.finisherId == widget.userId;

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      padding: const EdgeInsets.all(14),
      decoration: _Tokens.card(
          borderColor: FanColors.border.withOpacity(0.3),
          radius: _Tokens.radiusMd),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(5),
                    decoration: BoxDecoration(
                        color: FanColors.primary.withOpacity(0.1),
                        shape: BoxShape.circle),
                    child: const Icon(Icons.sports_score,
                        size: 14, color: FanColors.primary),
                  ),
                  const SizedBox(width: 6),
                  Text('Bet #${bet.id.substring(0, 8)}',
                      style: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          color: FanColors.textPrimary)),
                ],
              ),
              _Badge(
                label: bet.status.toUpperCase(),
                color: bet.isActive
                    ? FanColors.primary
                    : (bet.isSettled ? FanColors.secondary : FanColors.away),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text('${widget.fixture.homeTeam} vs ${widget.fixture.awayTeam}',
              style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: FanColors.textPrimary)),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: _betSideBox(
                  label: isStarter ? 'YOU' : bet.starterName.toUpperCase(),
                  highlight: isStarter,
                  color: FanColors.primary,
                  pick: bet.starterSelection == 'home'
                      ? widget.fixture.homeTeam
                      : bet.starterSelection == 'away'
                          ? widget.fixture.awayTeam
                          : 'Draw',
                  amount: bet.starterAmount,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: Column(
                  children: [
                    Text('VS',
                        style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            color: FanColors.textTertiary)),
                    const SizedBox(height: 4),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 4, vertical: 2),
                      decoration: BoxDecoration(
                          color: FanColors.primary.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(6)),
                      child: Text('KES ${bet.totalPot.toStringAsFixed(2)}',
                          style: const TextStyle(
                              fontSize: 9,
                              fontWeight: FontWeight.w700,
                              color: FanColors.primary)),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: _betSideBox(
                  label: isFinisher
                      ? 'YOU'
                      : (bet.finisherName?.toUpperCase() ?? '?'),
                  highlight: isFinisher,
                  color: FanColors.secondary,
                  pick: bet.finisherSelection == 'home'
                      ? widget.fixture.homeTeam
                      : bet.finisherSelection == 'away'
                          ? widget.fixture.awayTeam
                          : bet.finisherSelection == 'draw'
                              ? 'Draw'
                              : '?',
                  amount: bet.finisherAmount,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Divider(color: FanColors.border.withOpacity(0.3)),
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.timer, size: 10, color: FanColors.textTertiary),
              const SizedBox(width: 4),
              Text(bet.isSettled ? 'Settled' : 'Waiting for match result',
                  style: TextStyle(fontSize: 9, color: FanColors.textTertiary)),
              const SizedBox(width: 6),
              Container(
                  width: 3,
                  height: 3,
                  decoration: BoxDecoration(
                      color: FanColors.textTertiary, shape: BoxShape.circle)),
              const SizedBox(width: 6),
              Text('Created ${_timeAgo(bet.createdAt)}',
                  style: TextStyle(fontSize: 8, color: FanColors.textTertiary)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _betSideBox(
      {required String label,
      required bool highlight,
      required Color color,
      required String pick,
      double? amount}) {
    return Container(
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
          color: FanColors.background, borderRadius: BorderRadius.circular(6)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(label,
              style: TextStyle(
                  fontSize: 8,
                  fontWeight: highlight ? FontWeight.w800 : FontWeight.w500,
                  color: highlight ? color : FanColors.textSecondary)),
          const SizedBox(height: 2),
          Text(pick,
              style: TextStyle(
                  fontSize: 10, fontWeight: FontWeight.w700, color: color)),
          Text('KES ${amount?.toStringAsFixed(2) ?? '0.00'}',
              style: TextStyle(fontSize: 9, color: FanColors.textSecondary)),
        ],
      ),
    );
  }

  // ==========================================================================
  // BOTTOM BUTTON
  // ==========================================================================

  Widget _buildBottomButton() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
      child: SafeArea(
        child: GestureDetector(
          onTap: _shareChannel,
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 11),
            decoration: BoxDecoration(
              color: FanColors.surface,
              borderRadius: BorderRadius.circular(_Tokens.radiusSm),
              border: Border.all(color: FanColors.border.withOpacity(0.3)),
            ),
            child: const Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.ios_share_rounded,
                      size: 16, color: FanColors.textSecondary),
                  SizedBox(width: 6),
                  Text('Share Match',
                      style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: FanColors.textSecondary)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ==========================================================================
  // MAIN BUILD
  // ==========================================================================

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;

    final List<Widget> tabChildren = [_buildVotesListFragment()];
    if (_showPledges) tabChildren.add(_buildPledgesFragment());
    if (_showBets) tabChildren.add(_buildBetsFragment());

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: EdgeInsets.zero,
      child: Container(
        width: screenWidth,
        height: screenHeight * 0.75,
        decoration: BoxDecoration(
          color: FanColors.background,
          borderRadius: const BorderRadius.vertical(
              top: Radius.circular(_Tokens.radiusXl)),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withOpacity(0.4),
                blurRadius: 24,
                offset: const Offset(0, -8))
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildHandleBar(),
            _buildHeader(),
            _buildVoteSelectionFragment(),
            _buildTabBar(),
            if (_tabCount > 1)
              Expanded(
                child: TabBarView(
                  controller: _tabController,
                  physics: const BouncingScrollPhysics(),
                  children: tabChildren,
                ),
              )
            else
              Expanded(child: _buildVotesListFragment()),
            _buildBottomButton(),
          ],
        ),
      ),
    );
  }
}
