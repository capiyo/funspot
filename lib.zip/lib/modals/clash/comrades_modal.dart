import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import '../../models/fixture_models.dart';
import '../../pages/social_theme.dart';
import '../../services/notification_service.dart';
import '../../services/web_soecket.dart';
import '../../modals/login_modal.dart';
import '../../main.dart';

// Add this class at the top of your file (after imports)
class WhatsAppBackground extends StatelessWidget {
  final Widget child;

  const WhatsAppBackground({required this.child, super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        // WhatsApp's iconic dark background
        color: const Color(0xFF0B342C), // Dark teal/green
        image: const DecorationImage(
          image: NetworkImage(
            'https://raw.githubusercontent.com/Shubham0812/WhatsApp-Clone-UI-Flutter/master/assets/whatsapp_bg.png',
          ),
          fit: BoxFit.cover,
          opacity: 0.05,
        ),
      ),
      child: child,
    );
  }
}

// Alternative: Custom painter for WhatsApp-like pattern
class WhatsAppPatternBackground extends StatelessWidget {
  final Widget child;

  const WhatsAppPatternBackground({required this.child, super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF0B342C), // Dark teal
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            const Color(0xFF0B342C),
            const Color(0xFF0A2F28),
            const Color(0xFF092A23),
          ],
        ),
      ),
      child: CustomPaint(painter: WhatsAppPatternPainter(), child: child),
    );
  }
}

// Custom painter for WhatsApp-like dotted pattern
class WhatsAppPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withValues(alpha: 0.03)
      ..style = PaintingStyle.fill;

    // Draw dots pattern
    const dotSpacing = 20.0;
    const dotRadius = 1.5;

    for (double x = 0; x < size.width; x += dotSpacing) {
      for (double y = 0; y < size.height; y += dotSpacing) {
        canvas.drawCircle(Offset(x, y), dotRadius, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// WhatsApp-style chat message model
class ChatMessage {
  final String id;
  final String userId;
  final String username;
  final String text;
  final String? selection;
  final DateTime timestamp;
  final MessageStatus status;
  final bool isSeen;

  ChatMessage({
    required this.id,
    required this.userId,
    required this.username,
    required this.text,
    this.selection,
    required this.timestamp,
    this.status = MessageStatus.sent,
    this.isSeen = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'userId': userId,
        'username': username,
        'text': text,
        'selection': selection,
        'timestamp': timestamp.toIso8601String(),
        'status': status.index,
        'isSeen': isSeen,
      };

  factory ChatMessage.fromJson(Map<String, dynamic> json) => ChatMessage(
        id: json['id'] as String,
        userId: json['userId'] as String,
        username: json['username'] as String,
        text: json['text'] as String,
        selection: json['selection'] as String?,
        timestamp: DateTime.parse(json['timestamp'] as String),
        status: MessageStatus.values[json['status'] as int? ?? 1],
        isSeen: json['isSeen'] as bool? ?? false,
      );
}

enum MessageStatus { sending, sent, delivered, read, failed }

// WhatsApp-style chat page
class ComradeVotingModal extends StatefulWidget {
  final bool isOpen;
  final VoidCallback onClose;
  final Fixture fixture;
  final String userId;
  final String username;
  final String? authToken;
  final bool isLoggedIn;
  final bool hasUserVoted;
  final String? userVoteSelection;
  final Set<String> comradesList;
  final Map<String, Map<String, String>> comradesVoteMap;

  const ComradeVotingModal({
    super.key,
    required this.isOpen,
    required this.onClose,
    required this.fixture,
    required this.userId,
    required this.username,
    this.authToken,
    required this.isLoggedIn,
    required this.hasUserVoted,
    this.userVoteSelection,
    required this.comradesList,
    this.comradesVoteMap = const {},
  });

  @override
  State<ComradeVotingModal> createState() => _ComradeVotingModalState();
}

class _ComradeVotingModalState extends State<ComradeVotingModal>
    with WidgetsBindingObserver {
  // ==========================================================================
  // DATA
  // ==========================================================================
  final List<ChatMessage> _messages = [];
  final Map<String, Map<String, String>> _voters = {};
  final List<String> _typingUsers = [];

  // ==========================================================================
  // UI STATE
  // ==========================================================================
  bool _loading = true;
  bool _isConnected = false;
  bool _showVotersSection = false;
  bool _hasVoted = false;
  String? _mySelection;

  // ==========================================================================
  // CONTROLLERS
  // ==========================================================================
  final TextEditingController _messageCtrl = TextEditingController();
  final ScrollController _chatScroll = ScrollController();
  final ScrollController _voterScroll = ScrollController();
  final FocusNode _focusNode = FocusNode();
  Timer? _typingTimer;
  Timer? _reconnectTimer;
  String get _roomId => '${widget.fixture.matchId}_chat';

  // ==========================================================================
  // WEBSOCKET SERVICE
  // ==========================================================================
  final WebSocketService _ws = WebSocketService();

  // ==========================================================================
  // CONSTANTS
  // ==========================================================================
  static const String _api = 'https://clash-api-m5mr.onrender.com/api';
  static const Duration _timeout = Duration(seconds: 15);
  static const int _maxRetries = 3;

  // ==========================================================================
  // LIFECYCLE
  // ==========================================================================
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _hasVoted = widget.hasUserVoted;
    _mySelection = widget.userVoteSelection;
    _voters.addAll(widget.comradesVoteMap);

    _setupWebSocket();
    _focusNode.addListener(_onFocusChange);

    if (widget.isOpen) {
      _loadMessages();
      _connectWebSocket();
    }
  }

  @override
  void didUpdateWidget(covariant ComradeVotingModal old) {
    super.didUpdateWidget(old);
    if (widget.isOpen && !old.isOpen) {
      _hasVoted = widget.hasUserVoted;
      _mySelection = widget.userVoteSelection;
      _voters
        ..clear()
        ..addAll(widget.comradesVoteMap);
      _loadMessages();
      _connectWebSocket();
    }
    if (!widget.isOpen && old.isOpen) {
      _disconnectWebSocket();
    }
  }

  @override
  void dispose() {
    _typingTimer?.cancel();
    _reconnectTimer?.cancel();
    _focusNode.removeListener(_onFocusChange);
    _focusNode.dispose();
    _messageCtrl.dispose();
    _chatScroll.dispose();
    _voterScroll.dispose();
    _disconnectWebSocket();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _reconnectIfNeeded();
    }
  }

  // ==========================================================================
  // WEBSOCKET SETUP (WhatsApp-style real-time)
  // ==========================================================================
  void _setupWebSocket() {
    // Listen to connection status
    _ws.connectionStatus.listen((connected) {
      if (mounted) {
        setState(() => _isConnected = connected);
        if (connected) {
          _sendPresence();
          _markMessagesAsDelivered();
        }
      }
    });

    // Listen to incoming messages
    _ws.on('chat.message', _handleIncomingMessage);
    _ws.on('typing', _handleTypingIndicator);
    _ws.on('message.delivered', _handleDeliveryReceipt);
    _ws.on('message.read', _handleReadReceipt);
    _ws.on('presence', _handlePresenceUpdate);
    _ws.on('vote.update', _handleVoteUpdate);
  }

  Future<void> _connectWebSocket() async {
    if (!widget.isLoggedIn) return;
    try {
      await _ws.connect(
        widget.userId,
        widget.authToken ?? '',
        _roomId,
        widget.username,
      );
    } catch (e) {
      _scheduleReconnect();
    }
  }

  void _disconnectWebSocket() {
    _ws.disconnect();
  }

  void _scheduleReconnect() {
    _reconnectTimer?.cancel();
    _reconnectTimer = Timer(const Duration(seconds: 5), () {
      if (widget.isOpen && mounted) {
        _connectWebSocket();
      }
    });
  }

  void _reconnectIfNeeded() {
    if (!_ws.isConnected && widget.isOpen && mounted) {
      _connectWebSocket();
    }
  }

  // ==========================================================================
  // MESSAGE HANDLING (WhatsApp-style)
  // ==========================================================================
  void _sendMessage() async {
    final text = _messageCtrl.text.trim();
    if (text.isEmpty) return;
    if (!_hasVoted || _mySelection == null) {
      _flashError('Vote on the match first');
      return;
    }
    if (!widget.isLoggedIn) {
      _flashError('Please log in');
      _showLoginModal();
      return;
    }

    final messageId = _generateMessageId();
    final timestamp = DateTime.now();

    // Create optimistic message (sending status)
    final optimisticMessage = ChatMessage(
      id: messageId,
      userId: widget.userId,
      username: widget.username,
      text: text,
      selection: _mySelection,
      timestamp: timestamp,
      status: MessageStatus.sending,
    );

    _addMessage(optimisticMessage);
    _messageCtrl.clear();
    _scrollToBottom();

    // Send via WebSocket
    try {
      // _ws.sendChatMessage('all', text, widget.fixture.matchId);

      // Update status to sent
      _updateMessageStatus(messageId, MessageStatus.sent);

      // Also send to API for persistence
      await _sendToApi(text, messageId);

      // Send delivery notifications to comrades
      _sendDeliveryNotifications(messageId);
    } catch (e) {
      _updateMessageStatus(messageId, MessageStatus.failed);
      _flashError('Failed to send');
    }
  }

  Future<void> _sendToApi(String text, String messageId) async {
    try {
      final requestBody = {
        'voterId': widget.userId,
        'username': widget.username,
        'fixtureId': widget.fixture.matchId,
        'comment': text,
        'selection': _mySelection,
        'messageId': messageId,
        'timestamp': DateTime.now().toUtc().toIso8601String(),
      };

      final response = await http
          .post(
            Uri.parse('$_api/votes/comment'),
            headers: _headers(),
            body: json.encode(requestBody),
          )
          .timeout(_timeout);

      if (response.statusCode == 200 || response.statusCode == 201) {
        final data = json.decode(response.body);
        final serverId = data['_id']?.toString() ?? data['id']?.toString();
        if (serverId != null && serverId.isNotEmpty) {
          _updateMessageId(messageId, serverId);
        }
        _updateMessageStatus(messageId, MessageStatus.sent);
      }
    } catch (e) {
      debugPrint('API send error: $e');
    }
  }

  void _sendDeliveryNotifications(String messageId) {
    for (final comradeId in widget.comradesList) {
      if (comradeId != widget.userId) {
        _ws.send('message.delivered', {
          'messageId': messageId,
          'toUserId': comradeId,
          'fixtureId': widget.fixture.matchId,
        });
      }
    }
  }

  void _handleIncomingMessage(Map<String, dynamic> payload) {
    final fromUserId = payload['fromUserId'] as String?;
    if (fromUserId == null || fromUserId == widget.userId) return;
    if (!widget.comradesList.contains(fromUserId)) return;

    final messageId = payload['messageId'] as String? ?? _generateMessageId();
    final username = payload['username'] as String? ?? 'Anonymous';
    final text = payload['message'] as String? ?? '';
    final selection = payload['selection'] as String?;

    if (text.isEmpty) return;

    final message = ChatMessage(
      id: messageId,
      userId: fromUserId,
      username: username,
      text: text,
      selection: selection,
      timestamp: DateTime.parse(
        payload['timestamp'] as String? ?? DateTime.now().toIso8601String(),
      ),
      status: MessageStatus.delivered,
    );

    _addMessage(message);
    _scrollToBottom();

    // Send read receipt automatically (WhatsApp-style)
    _sendReadReceipt(message.id, fromUserId);

    // Show notification (only if not in foreground)
    if (mounted) {
      _showMessageNotification(message);
    }

    // Update voters map if selection provided
    if (selection != null) {
      _voters[fromUserId] = {'username': username, 'selection': selection};
      setState(() {});
    }
  }

  void _handleTypingIndicator(Map<String, dynamic> payload) {
    final fromUserId = payload['fromUserId'] as String?;
    if (fromUserId == null || fromUserId == widget.userId) return;
    if (!widget.comradesList.contains(fromUserId)) return;

    final isTyping = payload['isTyping'] as bool? ?? false;
    final username = payload['username'] as String? ?? 'Someone';

    setState(() {
      if (isTyping && !_typingUsers.contains(username)) {
        _typingUsers.add(username);
      } else if (!isTyping && _typingUsers.contains(username)) {
        _typingUsers.remove(username);
      }
    });

    // Auto-remove after 3 seconds
    if (isTyping) {
      Timer(const Duration(seconds: 3), () {
        if (mounted) {
          setState(() {
            _typingUsers.remove(username);
          });
        }
      });
    }
  }

  void _handleDeliveryReceipt(Map<String, dynamic> payload) {
    final messageId = payload['messageId'] as String?;
    if (messageId != null) {
      _updateMessageStatus(messageId, MessageStatus.delivered);
    }
  }

  void _handleReadReceipt(Map<String, dynamic> payload) {
    final messageId = payload['messageId'] as String?;
    if (messageId != null) {
      _updateMessageStatus(messageId, MessageStatus.read);
    }
  }

  void _handlePresenceUpdate(Map<String, dynamic> payload) {
    // Handle online/offline status of comrades
    // Can be used to show typing indicators or online status
  }

  void _handleVoteUpdate(Map<String, dynamic> payload) {
    final userId = payload['userId'] as String?;
    final selection = payload['selection'] as String?;
    if (userId != null && selection != null) {
      _voters[userId] = {'username': '', 'selection': selection};
      setState(() {});
    }
  }

  void _sendTypingIndicator() {
    if (!_ws.isConnected) return;

    // _ws.sendTyping('all', true);

    _typingTimer?.cancel();
    _typingTimer = Timer(const Duration(seconds: 2), () {
      if (_ws.isConnected && mounted) {
        // _ws.sendTyping('all', false);
      }
    });
  }

  void _sendReadReceipt(String messageId, String fromUserId) {
    if (!_ws.isConnected) return;
    if (fromUserId.isEmpty) return;

    _ws.send('message.read', {
      'messageId': messageId,
      'toUserId': fromUserId,
      'fixtureId': widget.fixture.matchId,
    });
  }

  void _sendPresence() {
    _ws.send('presence', {
      'userId': widget.userId,
      'status': 'online',
      'fixtureId': widget.fixture.matchId,
    });
  }

  void _markMessagesAsDelivered() {
    // Mark all undelivered messages as delivered
    for (var message in _messages) {
      if (message.userId != widget.userId &&
          message.status == MessageStatus.sent) {
        _updateMessageStatus(message.id, MessageStatus.delivered);
      }
    }
  }

  void _showMessageNotification(ChatMessage message) {
    // Only show if message is from someone else
    if (message.userId == widget.userId) return;

    try {
      NotificationService.sendNotification(
        userId: message.userId,
        notificationType: 'chat_message',
        title: message.username,
        body: message.text,
        data: {
          'fixture_id': widget.fixture.matchId,
          'message_id': message.id,
          'type': 'chat_message',
          'sender_id': message.userId,
          'timestamp': message.timestamp.toIso8601String(),
        },
      );
    } catch (e) {
      debugPrint('Notification error: $e');
    }
  }

  // ==========================================================================
  // MESSAGE MANAGEMENT
  // ==========================================================================
  void _addMessage(ChatMessage message) {
    // Check for duplicates
    if (_messages.any((m) => m.id == message.id)) return;

    setState(() {
      _messages.add(message);
      _sortMessages();
    });
    _saveMessagesToCache();
    _scrollToBottom();
  }

  void _updateMessageStatus(String messageId, MessageStatus status) {
    setState(() {
      final index = _messages.indexWhere((m) => m.id == messageId);
      if (index != -1) {
        _messages[index] = ChatMessage(
          id: _messages[index].id,
          userId: _messages[index].userId,
          username: _messages[index].username,
          text: _messages[index].text,
          selection: _messages[index].selection,
          timestamp: _messages[index].timestamp,
          status: status,
          isSeen: status == MessageStatus.read,
        );
      }
    });
    _saveMessagesToCache();
  }

  void _updateMessageId(String tempId, String realId) {
    setState(() {
      final index = _messages.indexWhere((m) => m.id == tempId);
      if (index != -1) {
        _messages[index] = ChatMessage(
          id: realId,
          userId: _messages[index].userId,
          username: _messages[index].username,
          text: _messages[index].text,
          selection: _messages[index].selection,
          timestamp: _messages[index].timestamp,
          status: _messages[index].status,
        );
      }
    });
  }

  void _sortMessages() {
    _messages.sort((a, b) => a.timestamp.compareTo(b.timestamp));
  }

  // ==========================================================================
  // PERSISTENCE
  // ==========================================================================
  Future<void> _loadMessages() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final key = 'chat_messages_${widget.fixture.matchId}';
      final cached = prefs.getString(key);

      if (cached != null) {
        final List<dynamic> decoded = json.decode(cached);
        _messages.clear();
        for (var item in decoded) {
          final msg = ChatMessage.fromJson(item as Map<String, dynamic>);
          if (widget.comradesList.contains(msg.userId) ||
              msg.userId == widget.userId) {
            _messages.add(msg);
          }
        }
        _sortMessages();
        debugPrint('Loaded ${_messages.length} messages from cache');
      }

      await _loadHistoricalMessages();
    } catch (e) {
      debugPrint('Cache load error: $e');
    } finally {
      setState(() => _loading = false);
    }
  }

  Future<void> _loadHistoricalMessages() async {
    try {
      final response = await http
          .get(
            Uri.parse(
              '$_api/votes/comments?fixtureId=${widget.fixture.matchId}&limit=50',
            ),
            headers: _headers(),
          )
          .timeout(_timeout);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final comments = _parseComments(data);

        for (var comment in comments) {
          if (!_messages.any((m) => m.id == comment['id'])) {
            final msg = ChatMessage(
              id: comment['id'],
              userId: comment['userId'],
              username: comment['username'],
              text: comment['comment'],
              selection: comment['selection'],
              timestamp: DateTime.parse(comment['timestamp']),
              status: MessageStatus.delivered,
            );
            _messages.add(msg);
          }
        }
        _sortMessages();
        _saveMessagesToCache();
        setState(() {});
        _scrollToBottom();
      }
    } catch (e) {
      debugPrint('Historical load error: $e');
    }
  }

  Future<void> _saveMessagesToCache() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final key = 'chat_messages_${widget.fixture.matchId}';
      final toSave = _messages.map((m) => m.toJson()).toList();
      await prefs.setString(key, json.encode(toSave));
    } catch (e) {
      debugPrint('Cache save error: $e');
    }
  }

  List<Map<String, dynamic>> _parseComments(dynamic data) {
    final List<Map<String, dynamic>> comments = [];

    List<dynamic>? rawComments;
    if (data is Map) {
      if (data['data'] is Map && data['data']['recentComments'] is List) {
        rawComments = data['data']['recentComments'];
      } else if (data['data'] is List) {
        rawComments = data['data'];
      } else if (data['comments'] is List) {
        rawComments = data['comments'];
      }
    } else if (data is List) {
      rawComments = data;
    }

    if (rawComments != null) {
      for (var item in rawComments) {
        if (item is! Map) continue;

        final userId =
            item['voterId']?.toString() ?? item['userId']?.toString() ?? '';
        if (!widget.comradesList.contains(userId) && userId != widget.userId) {
          continue;
        }

        comments.add({
          'id': item['_id']?.toString() ?? item['id']?.toString() ?? '',
          'userId': userId,
          'username': item['username']?.toString() ?? 'Anonymous',
          'comment': item['comment']?.toString() ?? '',
          'selection': item['selection']?.toString() ?? '',
          'timestamp': _parseTimestamp(item['createdAt'] ?? item['timestamp']),
        });
      }
    }

    return comments;
  }

  String _parseTimestamp(dynamic timestamp) {
    if (timestamp == null) return DateTime.now().toIso8601String();
    try {
      if (timestamp is String) {
        return DateTime.parse(timestamp).toIso8601String();
      }
      if (timestamp is num) {
        if (timestamp > 10000000000) {
          return DateTime.fromMillisecondsSinceEpoch(
            timestamp.toInt(),
          ).toIso8601String();
        } else {
          return DateTime.fromMillisecondsSinceEpoch(
            timestamp.toInt() * 1000,
          ).toIso8601String();
        }
      }
    } catch (_) {}
    return DateTime.now().toIso8601String();
  }

  // ==========================================================================
  // UTILITIES
  // ==========================================================================
  String _generateMessageId() =>
      '${DateTime.now().millisecondsSinceEpoch}_${widget.userId}_${DateTime.now().microsecondsSinceEpoch}';

  bool _isLoggedIn() =>
      widget.isLoggedIn && widget.userId.isNotEmpty && widget.userId != 'guest';

  Map<String, String> _headers() {
    final h = {'Content-Type': 'application/json'};
    if (widget.authToken != null && widget.authToken!.isNotEmpty) {
      h['Authorization'] = 'Bearer ${widget.authToken}';
    }
    return h;
  }

  String _timeAgo(DateTime time) {
    final now = DateTime.now();
    final diff = now.difference(time);

    if (diff.inMinutes < 1) return 'now';
    if (diff.inHours < 1) return '${diff.inMinutes}m';
    if (diff.inDays < 1) return '${diff.inHours}h';
    if (diff.inDays == 1) return 'yesterday';
    if (diff.inDays < 7) return '${diff.inDays}d';
    return DateFormat('MMM d').format(time);
  }

  String _initials(String name) =>
      name.isNotEmpty ? name[0].toUpperCase() : 'U';

  String _displayVote(String? sel) {
    if (sel == 'home_team') return widget.fixture.homeTeam;
    if (sel == 'away_team') return widget.fixture.awayTeam;
    if (sel == 'draw') return 'Draw';
    return sel ?? '';
  }

  IconData _getStatusIcon(MessageStatus status) {
    switch (status) {
      case MessageStatus.sending:
        return Icons.access_time_rounded;
      case MessageStatus.sent:
        return Icons.check_rounded;
      case MessageStatus.delivered:
        return Icons.done_all_rounded;
      case MessageStatus.read:
        return Icons.done_all_rounded;
      case MessageStatus.failed:
        return Icons.error_outline_rounded;
    }
  }

  Color _getStatusColor(MessageStatus status) {
    switch (status) {
      case MessageStatus.read:
        return const Color(0xFF34B7F1); // WhatsApp blue
      case MessageStatus.failed:
        return Colors.red;
      default:
        return SocialTheme.mutedForeground;
    }
  }

  int get _homeCount =>
      _voters.values.where((v) => v['selection'] == 'home_team').length;
  int get _awayCount =>
      _voters.values.where((v) => v['selection'] == 'away_team').length;
  int get _drawCount =>
      _voters.values.where((v) => v['selection'] == 'draw').length;
  int get _totalVotes => _homeCount + _awayCount + _drawCount;

  void _flashError(String msg) {
    Fluttertoast.showToast(
      msg: msg,
      backgroundColor: Colors.red,
      textColor: Colors.white,
    );
  }

  void _showLoginModal() {
    widget.onClose();
    Future.delayed(const Duration(milliseconds: 200), () {
      showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (_) => LoginModal(
          messengerKey: messengerKey,
          onLoginSuccess: (uid, uname) => Navigator.pop(context),
        ),
      );
    });
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_chatScroll.hasClients && _chatScroll.position.hasContentDimensions) {
        _chatScroll.animateTo(
          _chatScroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _onFocusChange() {
    if (_focusNode.hasFocus) {
      _scrollToBottom();
    }
  }

  // ==========================================================================
  // BUILD (WhatsApp-style UI)
  // ==========================================================================
  @override
  Widget build(BuildContext context) {
    if (!widget.isOpen) return const SizedBox.shrink();

    final mq = MediaQuery.of(context);
    final keyboardH = mq.viewInsets.bottom;
    final bottomPad = mq.padding.bottom;

    return Stack(
      children: [
        // Backdrop
        Positioned.fill(
          child: GestureDetector(
            onTap: () {
              _focusNode.unfocus();
              widget.onClose();
            },
            child: Container(color: Colors.black.withValues(alpha: 0.5)),
          ),
        ),

        // WhatsApp-style sheet
        AnimatedPadding(
          padding: EdgeInsets.only(bottom: keyboardH),
          duration: const Duration(milliseconds: 150),
          child: Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              height: mq.size.height * 0.9,
              decoration: BoxDecoration(
                color: SocialTheme.card,
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(SocialTheme.radius),
                ),
              ),
              child: Column(
                children: [
                  _buildHeader(),
                  _buildVoteStatusBar(),
                  if (_hasVoted && _mySelection != null) _buildMyVotePill(),

                  // Chat messages
                  Expanded(
                    child: _loading
                        ? const Center(
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : _messages.isEmpty
                            ? _buildEmptyState()
                            : _buildChatList(),
                  ),

                  // Typing indicator
                  if (_typingUsers.isNotEmpty) _buildTypingIndicator(),

                  // Input bar (WhatsApp-style)
                  _buildInputBar(bottomPadding: bottomPad),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  // WhatsApp-style header
  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(color: SocialTheme.divider, width: 0.5),
        ),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: widget.onClose,
            child: Icon(
              Icons.arrow_downward_rounded,
              color: SocialTheme.mutedForeground,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${widget.fixture.homeTeam} vs ${widget.fixture.awayTeam}',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
                Row(
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _isConnected ? Colors.green : Colors.grey,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      _isConnected ? 'Connected' : 'Connecting...',
                      style: TextStyle(
                        fontSize: 11,
                        color: SocialTheme.mutedForeground,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: () =>
                setState(() => _showVotersSection = !_showVotersSection),
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: SocialTheme.primary.withValues(alpha: 0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(
                _showVotersSection
                    ? Icons.people_rounded
                    : Icons.people_outline_rounded,
                size: 20,
                color: SocialTheme.primary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVoteStatusBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Column(
        children: [
          Row(
            children: [
              _buildVoteStat(
                _homeCount,
                widget.fixture.homeTeam,
                SocialTheme.primary,
              ),
              const Spacer(),
              _buildVoteStat(_drawCount, 'Draw', const Color(0xFF7F77DD)),
              const Spacer(),
              _buildVoteStat(
                _awayCount,
                widget.fixture.awayTeam,
                const Color(0xFF2563EB),
                textAlignRight: true,
              ),
            ],
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: SizedBox(
              height: 4,
              child: Row(
                children: _totalVotes == 0
                    ? [Expanded(child: Container(color: SocialTheme.border))]
                    : [
                        if (_homeCount > 0)
                          Flexible(
                            flex: (_homeCount / _totalVotes * 100).round(),
                            child: Container(color: SocialTheme.primary),
                          ),
                        if (_drawCount > 0)
                          Flexible(
                            flex: (_drawCount / _totalVotes * 100).round(),
                            child: Container(color: const Color(0xFF7F77DD)),
                          ),
                        if (_awayCount > 0)
                          Flexible(
                            flex: (_awayCount / _totalVotes * 100).round(),
                            child: Container(color: const Color(0xFF2563EB)),
                          ),
                      ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVoteStat(
    int count,
    String label,
    Color color, {
    bool textAlignRight = false,
  }) {
    return Column(
      crossAxisAlignment:
          textAlignRight ? CrossAxisAlignment.end : CrossAxisAlignment.start,
      children: [
        Text(
          count.toString(),
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
        Text(
          label,
          style: TextStyle(fontSize: 11, color: SocialTheme.mutedForeground),
          overflow: TextOverflow.ellipsis,
        ),
      ],
    );
  }

  Widget _buildMyVotePill() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: _mySelection!.voteBg,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.check_circle_rounded,
            size: 14,
            color: _mySelection!.voteColor,
          ),
          const SizedBox(width: 6),
          Text(
            'You voted ${_displayVote(_mySelection)}',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              color: _mySelection!.voteColor,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChatList() {
    return WhatsAppBackground(
      child: Column(
        children: [
          // Voters section (collapsible)
          AnimatedCrossFade(
            duration: const Duration(milliseconds: 300),
            crossFadeState: _showVotersSection && _voters.isNotEmpty
                ? CrossFadeState.showFirst
                : CrossFadeState.showSecond,
            firstChild: Container(
              height: 200,
              decoration: BoxDecoration(
                color: SocialTheme.card.withValues(alpha: 0.95),
                border: Border(
                  bottom: BorderSide(color: SocialTheme.divider, width: 0.5),
                ),
              ),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Text(
                      'VOTED ($_totalVotes)',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: SocialTheme.mutedForeground,
                      ),
                    ),
                  ),
                  Expanded(
                    child: ListView.builder(
                      controller: _voterScroll,
                      padding: EdgeInsets.zero,
                      itemCount: _voters.length,
                      itemBuilder: (_, index) {
                        final entry = _voters.entries.elementAt(index);
                        return Container(
                          color: SocialTheme.card.withValues(alpha: 0.95),
                          child: _buildVoterRow(
                            entry.value['username'] ?? 'Anonymous',
                            entry.value['selection'] ?? '',
                            isMe: entry.key == widget.userId,
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
            secondChild: const SizedBox.shrink(),
          ),

          // Messages list with WhatsApp background
          Expanded(
            child: ListView.builder(
              controller: _chatScroll,
              reverse: true,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              itemCount: _messages.length,
              itemBuilder: (_, index) {
                final message = _messages[_messages.length - 1 - index];
                final isMe = message.userId == widget.userId;
                return _buildMessageBubble(message, isMe);
              },
            ),
          ),
        ],
      ),
    );
  }

  // WhatsApp-style message bubble
  // Update _buildMessageBubble method with WhatsApp-style colors
  Widget _buildMessageBubble(ChatMessage message, bool isMe) {
    final showName = !isMe &&
        (_messages.length < 2 ||
            _messages[_messages.length - 2].userId != message.userId);

    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Column(
        crossAxisAlignment:
            isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          if (showName)
            Padding(
              padding: const EdgeInsets.only(left: 12, bottom: 2),
              child: Text(
                message.username,
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  color: Colors.white70, // Lighter text on dark background
                ),
              ),
            ),
          Row(
            mainAxisAlignment:
                isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              if (!isMe) ...[
                _Avatar(
                  label: _initials(message.username),
                  color: message.selection?.voteColor ??
                      SocialTheme.mutedForeground,
                  size: 32,
                ),
                const SizedBox(width: 8),
              ],
              Flexible(
                child: Container(
                  constraints: BoxConstraints(
                    maxWidth: MediaQuery.of(context).size.width * 0.7,
                  ),
                  decoration: BoxDecoration(
                    // WhatsApp colors:
                    // Me: #DCF8C6 (light green)
                    // Other: #FFFFFF (white)
                    color: isMe
                        ? const Color(0xFFDCF8C6) // WhatsApp sent message color
                        : Colors.white, // WhatsApp received message color
                    borderRadius: BorderRadius.only(
                      topLeft: const Radius.circular(16),
                      topRight: const Radius.circular(16),
                      bottomLeft: Radius.circular(isMe ? 16 : 4),
                      bottomRight: Radius.circular(isMe ? 4 : 16),
                    ),
                  ),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 8,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      if (message.selection != null)
                        Container(
                          margin: const EdgeInsets.only(bottom: 4),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: message.selection!.voteBg,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            _displayVote(message.selection),
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.w600,
                              color: message.selection!.voteColor,
                            ),
                          ),
                        ),
                      Text(
                        message.text,
                        style: TextStyle(
                          fontSize: 14,
                          color: isMe
                              ? Colors.black87 // Dark text on light green
                              : Colors.black87, // Dark text on white
                        ),
                      ),
                      const SizedBox(height: 2),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            _timeAgo(message.timestamp),
                            style: TextStyle(
                              fontSize: 10,
                              color:
                                  isMe ? Colors.black54 : Colors.grey.shade600,
                            ),
                          ),
                          if (isMe) ...[
                            const SizedBox(width: 4),
                            Icon(
                              _getStatusIcon(message.status),
                              size: 12,
                              color: message.status == MessageStatus.read
                                  ? const Color(
                                      0xFF34B7F1,
                                    ) // WhatsApp blue for read
                                  : Colors.grey.shade600,
                            ),
                          ],
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildVoterRow(String name, String sel, {bool isMe = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          _Avatar(label: _initials(name), color: sel.voteColor, size: 36),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              isMe ? 'You' : name,
              style: TextStyle(
                fontSize: 14,
                fontWeight: isMe ? FontWeight.w600 : FontWeight.normal,
                color: isMe ? SocialTheme.primary : SocialTheme.foreground,
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: BoxDecoration(
              color: sel.voteBg,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Text(
              _displayVote(sel),
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w500,
                color: sel.voteText,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTypingIndicator() {
    String text = _typingUsers.length == 1
        ? '${_typingUsers[0]} is typing...'
        : '${_typingUsers.length} people are typing...';

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          const SizedBox(width: 20, height: 20, child: TypingAnimationWidget()),
          const SizedBox(width: 8),
          Text(
            text,
            style: TextStyle(
              fontSize: 12,
              fontStyle: FontStyle.italic,
              color: SocialTheme.mutedForeground,
            ),
          ),
        ],
      ),
    );
  }

  // WhatsApp-style input bar
  Widget _buildInputBar({required double bottomPadding}) {
    final canComment = _hasVoted && _mySelection != null && _isLoggedIn();

    return Container(
      padding: EdgeInsets.fromLTRB(12, 8, 12, bottomPadding + 8),
      decoration: BoxDecoration(
        color: SocialTheme.card,
        border: Border(top: BorderSide(color: SocialTheme.divider, width: 0.5)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: SocialTheme.background,
                borderRadius: BorderRadius.circular(24),
              ),
              child: TextField(
                controller: _messageCtrl,
                focusNode: _focusNode,
                maxLines: null,
                maxLength: 500,
                textInputAction: TextInputAction.send,
                enabled: canComment && !_loading,
                style: const TextStyle(fontSize: 15),
                decoration: InputDecoration(
                  hintText: canComment
                      ? 'Type a message...'
                      : _hasVoted
                          ? 'Vote to join the chat'
                          : 'Vote first to comment',
                  hintStyle: TextStyle(
                    fontSize: 15,
                    color: SocialTheme.mutedForeground.withValues(alpha: 0.7),
                    fontStyle: canComment ? FontStyle.normal : FontStyle.italic,
                  ),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 10,
                  ),
                  counterText: '',
                ),
                onChanged: (text) {
                  if (text.isNotEmpty && canComment) {
                    _sendTypingIndicator();
                  }
                },
                onSubmitted: (_) => _sendMessage(),
              ),
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: _sendMessage,
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: canComment && _messageCtrl.text.isNotEmpty
                    ? SocialTheme.primary
                    : SocialTheme.border,
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.send_rounded, size: 20, color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.chat_bubble_outline_rounded,
            size: 48,
            color: SocialTheme.border,
          ),
          const SizedBox(height: 16),
          Text(
            _hasVoted
                ? 'No messages yet\nBe the first to send a message!'
                : 'Vote on this match\nto join the conversation',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: SocialTheme.mutedForeground,
              fontSize: 14,
              height: 1.4,
            ),
          ),
          const SizedBox(height: 24),
          if (!_hasVoted)
            OutlinedButton.icon(
              onPressed: () {
                widget.onClose();
              },
              icon: Icon(Icons.how_to_vote_rounded, size: 18),
              label: const Text('Vote Now'),
              style: OutlinedButton.styleFrom(
                foregroundColor: SocialTheme.primary,
                side: BorderSide(color: SocialTheme.primary),
              ),
            ),
        ],
      ),
    );
  }
}

// Typing animation widget
class TypingAnimationWidget extends StatefulWidget {
  const TypingAnimationWidget({super.key});

  @override
  State<TypingAnimationWidget> createState() => _TypingAnimationWidgetState();
}

class _TypingAnimationWidgetState extends State<TypingAnimationWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 900),
      vsync: this,
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        _buildDot(0),
        const SizedBox(width: 4),
        _buildDot(1),
        const SizedBox(width: 4),
        _buildDot(2),
      ],
    );
  }

  Widget _buildDot(int index) {
    final delay = index * 0.15;
    final animation = CurvedAnimation(
      parent: _controller,
      curve: Interval(delay, delay + 0.4, curve: Curves.easeInOut),
    );

    return FadeTransition(
      opacity: animation,
      child: Container(
        width: 8,
        height: 8,
        decoration: const BoxDecoration(
          color: Color(0xFF34B7F1), // WhatsApp blue
          shape: BoxShape.circle,
        ),
      ),
    );
  }
}

// Avatar widget
class _Avatar extends StatelessWidget {
  final String label;
  final Color color;
  final double size;

  const _Avatar({required this.label, required this.color, required this.size});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        shape: BoxShape.circle,
        border: Border.all(color: color.withValues(alpha: 0.4), width: 1.5),
      ),
      child: Center(
        child: Text(
          label,
          style: TextStyle(
            fontSize: size * 0.4,
            fontWeight: FontWeight.w600,
            color: color,
          ),
        ),
      ),
    );
  }
}

// Extension for vote colors
extension SelectionColor on String {
  Color get voteColor {
    switch (this) {
      case 'home_team':
        return SocialTheme.primary;
      case 'away_team':
        return const Color(0xFF2563EB);
      case 'draw':
        return const Color(0xFF7F77DD);
      default:
        return SocialTheme.mutedForeground;
    }
  }

  Color get voteBg => voteColor.withValues(alpha: 0.1);
  Color get voteText => voteColor;
}
