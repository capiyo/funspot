import 'package:flutter/material.dart';
import '../../pages/social_theme.dart';
import '../../services/auth_service.dart';
import '../../modals/login_modal.dart';
import '../../main.dart';
import '../../models/fixture_models.dart';

class FirstCornerModal extends StatefulWidget {
  final bool isOpen;
  final VoidCallback onClose;
  final Fixture fixture;
  final SubFixture subFixture;
  final String userId;
  final String username;
  final String? authToken;
  final Function(String selection) onVote; // Add this

  const FirstCornerModal({
    super.key,
    required this.isOpen,
    required this.onClose,
    required this.fixture,
    required this.subFixture,
    required this.userId,
    required this.username,
    required this.onVote, // Add this
    this.authToken,
  });

  @override
  State<FirstCornerModal> createState() => _FirstCornerModalState();
}

class _FirstCornerModalState extends State<FirstCornerModal> {
  String? _selectedOption;
  bool _isSubmitting = false;
  late final AuthService _authService;

  final List<Map<String, dynamic>> _homeVoters = [
    {
      'username': 'KevinS',
      'avatar': 'KS',
      'timestamp': DateTime.now().subtract(const Duration(minutes: 3)),
    },
    {
      'username': 'RachelL',
      'avatar': 'RL',
      'timestamp': DateTime.now().subtract(const Duration(minutes: 12)),
    },
    {
      'username': 'SteveM',
      'avatar': 'SM',
      'timestamp': DateTime.now().subtract(const Duration(minutes: 24)),
    },
    {
      'username': 'AmyW',
      'avatar': 'AW',
      'timestamp': DateTime.now().subtract(const Duration(minutes: 38)),
    },
    {
      'username': 'BrianK',
      'avatar': 'BK',
      'timestamp': DateTime.now().subtract(const Duration(hours: 1)),
    },
  ];

  final List<Map<String, dynamic>> _awayVoters = [
    {
      'username': 'NicoleP',
      'avatar': 'NP',
      'timestamp': DateTime.now().subtract(const Duration(minutes: 7)),
    },
    {
      'username': 'JasonR',
      'avatar': 'JR',
      'timestamp': DateTime.now().subtract(const Duration(minutes: 19)),
    },
    {
      'username': 'MeganC',
      'avatar': 'MC',
      'timestamp': DateTime.now().subtract(const Duration(minutes: 31)),
    },
    {
      'username': 'RyanH',
      'avatar': 'RH',
      'timestamp': DateTime.now().subtract(const Duration(minutes: 45)),
    },
  ];

  @override
  void initState() {
    super.initState();
    _authService = AuthService();
  }

  bool _isUserLoggedIn() {
    return _authService.isLoggedIn &&
        widget.userId.isNotEmpty &&
        widget.userId != 'guest';
  }

  void _showLoginModal() {
    widget.onClose();
    Future.delayed(const Duration(milliseconds: 200), () {
      showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (context) => LoginModal(
          messengerKey: messengerKey,
          onLoginSuccess: (String userId, String username) {
            Navigator.pop(context);
          },
        ),
      );
    });
  }

  Future<void> _submitVote() async {
    if (!_isUserLoggedIn()) {
      _showLoginModal();
      return;
    }
    if (_selectedOption == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select an option'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }
    setState(() => _isSubmitting = true);
    await Future.delayed(const Duration(seconds: 1));
    setState(() => _isSubmitting = false);
    widget.onVote(_selectedOption!);
    widget.onClose();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Voted for ${_selectedOption == 'home' ? widget.fixture.homeTeam : widget.fixture.awayTeam}',
        ),
        backgroundColor: Colors.green,
      ),
    );
  }

  String _formatTime(DateTime time) {
    final diff = DateTime.now().difference(time);
    if (diff.inMinutes < 1) return 'Just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    return '${diff.inDays}d ago';
  }

  Widget _buildVoterList(List<Map<String, dynamic>> voters, Color color) {
    if (voters.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.people_outline, size: 32, color: Colors.grey),
            SizedBox(height: 8),
            Text('No votes yet', style: TextStyle(color: Colors.grey)),
          ],
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: voters.length,
      itemBuilder: (context, index) {
        final voter = voters[index];
        return Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: SocialTheme.surface,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.2),
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: Text(
                    voter['avatar'],
                    style: TextStyle(color: color, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      voter['username'],
                      style: const TextStyle(color: Colors.white),
                    ),
                    Text(
                      _formatTime(voter['timestamp']),
                      style: const TextStyle(color: Colors.grey, fontSize: 10),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.isOpen) return const SizedBox.shrink();

    final homeTeamColor = SocialTheme.primary;
    final awayTeamColor = const Color(0xFF2563EB);
    final homeVotes = _homeVoters.length;
    final awayVotes = _awayVoters.length;
    final totalVotes = homeVotes + awayVotes;
    final homePercentage = totalVotes > 0 ? (homeVotes / totalVotes * 100) : 50;
    final awayPercentage = totalVotes > 0 ? (awayVotes / totalVotes * 100) : 50;

    return Stack(
      children: [
        Positioned.fill(
          child: GestureDetector(
            onTap: widget.onClose,
            child: Container(color: Colors.black.withValues(alpha: 0.6)),
          ),
        ),
        Align(
          alignment: Alignment.bottomCenter,
          child: Container(
            height: MediaQuery.of(context).size.height * 0.85,
            decoration: BoxDecoration(
              color: SocialTheme.background,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Column(
              children: [
                Container(
                  margin: const EdgeInsets.only(top: 12, bottom: 8),
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey[800],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Who Gets First Corner?',
                            style: SocialTheme.headline.copyWith(fontSize: 18),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            '${widget.fixture.homeTeam} vs ${widget.fixture.awayTeam}',
                            style: SocialTheme.small,
                          ),
                        ],
                      ),
                      GestureDetector(
                        onTap: widget.onClose,
                        child: Container(
                          width: 36,
                          height: 36,
                          decoration: BoxDecoration(
                            color: SocialTheme.surface,
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            Icons.close,
                            color: SocialTheme.text,
                            size: 20,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      Expanded(
                        child: _buildStatBar(
                          '${homePercentage.toStringAsFixed(0)}%',
                          widget.fixture.homeTeam,
                          homeTeamColor,
                          homeVotes,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: _buildStatBar(
                          '${awayPercentage.toStringAsFixed(0)}%',
                          widget.fixture.awayTeam,
                          awayTeamColor,
                          awayVotes,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Column(
                    children: [
                      _buildRadioOption(
                        title: widget.fixture.homeTeam,
                        value: 'home',
                        groupValue: _selectedOption,
                        color: homeTeamColor,
                        voteCount: homeVotes,
                      ),
                      const SizedBox(height: 12),
                      _buildRadioOption(
                        title: widget.fixture.awayTeam,
                        value: 'away',
                        groupValue: _selectedOption,
                        color: awayTeamColor,
                        voteCount: awayVotes,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: ElevatedButton(
                      onPressed: _isSubmitting ? null : _submitVote,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: SocialTheme.primary,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: _isSubmitting
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : const Text(
                              'Submit Vote',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Expanded(
                  child: DefaultTabController(
                    length: 2,
                    child: Column(
                      children: [
                        Container(
                          color: SocialTheme.surface,
                          child: TabBar(
                            tabs: [
                              Tab(text: widget.fixture.homeTeam),
                              Tab(text: widget.fixture.awayTeam),
                            ],
                            labelColor: SocialTheme.text,
                            unselectedLabelColor: SocialTheme.textSecondary,
                            indicatorColor: SocialTheme.primary,
                          ),
                        ),
                        Expanded(
                          child: TabBarView(
                            children: [
                              _buildVoterList(_homeVoters, homeTeamColor),
                              _buildVoterList(_awayVoters, awayTeamColor),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 12),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildStatBar(
    String percentage,
    String label,
    Color color,
    int votes,
  ) {
    return Column(
      children: [
        Text(
          percentage,
          style: TextStyle(
            color: color,
            fontWeight: FontWeight.bold,
            fontSize: 14,
          ),
        ),
        const SizedBox(height: 4),
        LinearProgressIndicator(
          value: double.parse(percentage.replaceAll('%', '')) / 100,
          backgroundColor: Colors.grey[800],
          color: color,
          minHeight: 4,
          borderRadius: BorderRadius.circular(2),
        ),
        const SizedBox(height: 4),
        Text(
          label.length > 8 ? '${label.substring(0, 6)}...' : label,
          style: TextStyle(color: Colors.grey[400], fontSize: 10),
        ),
        Text(
          '$votes votes',
          style: TextStyle(color: Colors.grey[500], fontSize: 9),
        ),
      ],
    );
  }

  Widget _buildRadioOption({
    required String title,
    required String value,
    required String? groupValue,
    required Color color,
    required int voteCount,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: SocialTheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: groupValue == value ? color : Colors.grey[800]!,
          width: groupValue == value ? 2 : 1,
        ),
      ),
      child: Row(
        children: [
          Radio<String>(
            value: value,
            groupValue: groupValue,
            onChanged: (v) => setState(() => _selectedOption = v),
            activeColor: color,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              '$voteCount votes',
              style: TextStyle(
                color: color,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
