import 'dart:async';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../pages/social_theme.dart';
import '../../services/auth_service.dart';
import '../../modals/login_modal.dart';
import '../../main.dart';
import '../../models/fixture_models.dart';
import '../../services/api_services.dart';
import '../../services/notification_service.dart';

class SubFixtureModal extends StatefulWidget {
  final bool isOpen;
  final VoidCallback onClose;
  final Fixture fixture;
  final SubFixture subFixture;
  final String userId;
  final String username;
  final String? authToken;
  final Function(String selection) onVote;

  const SubFixtureModal({
    super.key,
    required this.isOpen,
    required this.onClose,
    required this.fixture,
    required this.subFixture,
    required this.userId,
    required this.username,
    required this.onVote,
    this.authToken,
  });

  @override
  State<SubFixtureModal> createState() => _SubFixtureModalState();
}

class _SubFixtureModalState extends State<SubFixtureModal> {
  String? _selectedOption;
  bool _isSubmitting = false;
  bool _isLoading = true;
  late final AuthService _authService;

  // Voters data - dynamic based on options
  final Map<String, List<Map<String, dynamic>>> _votersMap = {};

  // Stats data
  final Map<String, int> _voteCounts = {};
  int _totalVotes = 0;
  String? _userVote;

  // Options list
  final List<String> _options = [];

  @override
  void initState() {
    super.initState();
    _authService = AuthService();
    _buildOptionsList();
    _loadData();
  }

  void _buildOptionsList() {
    _options.clear();
    _options.add(widget.subFixture.optionA);
    _options.add(widget.subFixture.optionB);
    if (widget.subFixture.optionC != null &&
        widget.subFixture.optionC!.isNotEmpty) {
      _options.add(widget.subFixture.optionC!);
    }

    // Initialize maps
    for (var option in _options) {
      _voteCounts[option] = 0;
      _votersMap[option] = [];
    }
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);

    try {
      // Fetch sub-fixture stats
      final stats = await ApiService.getSubFixtureStats(widget.subFixture.id);
      if (stats != null) {
        _voteCounts[widget.subFixture.optionA] = stats['option_a_votes'] ?? 0;
        _voteCounts[widget.subFixture.optionB] = stats['option_b_votes'] ?? 0;
        if (widget.subFixture.optionC != null) {
          _voteCounts[widget.subFixture.optionC!] =
              stats['option_c_votes'] ?? 0;
        }
        _totalVotes = stats['total_votes'] ?? 0;
      }

      // Fetch voters for each option
      for (var option in _options) {
        final voters = await ApiService.getSubFixtureVoters(
          widget.subFixture.id,
          selection: option,
        );
        if (voters != null) {
          _votersMap[option] = voters;
        }
      }

      // Check if user has voted
      if (_authService.isLoggedIn &&
          widget.userId.isNotEmpty &&
          widget.userId != 'guest') {
        final userVote = await ApiService.checkUserSubFixtureVote(
          widget.subFixture.id,
          widget.userId,
        );
        if (userVote != null && userVote['has_voted'] == true) {
          setState(() {
            _userVote = userVote['vote']?['selection'];
            _selectedOption = _userVote;
          });
        }
      }

      setState(() {});
    } catch (e) {
      debugPrint('Error loading sub-fixture data: $e');
      _loadMockData();
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _loadMockData() {
    // Mock data for development
    for (var option in _options) {
      _voteCounts[option] = 5 + (option.hashCode % 20);
      _votersMap[option] = List.generate(
        3 + (option.hashCode % 5),
        (i) => {
          'voter_id': 'user_${(option.hashCode + i) % 100}',
          'username': 'User${(option.hashCode + i) % 100}',
          'selection': option,
          'voted_at': DateTime.now()
              .subtract(Duration(minutes: (i + 1) * 5))
              .toIso8601String(),
        },
      );
    }
    _totalVotes = _voteCounts.values.fold(0, (sum, count) => sum + count);
  }

  bool _isUserLoggedIn() {
    return _authService.isLoggedIn &&
        widget.userId.isNotEmpty &&
        widget.userId != 'guest';
  }

  void _showLoginModal() {
    widget.onClose();
    Future.delayed(const Duration(milliseconds: 200), () {
      showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (context) => LoginModal(
          messengerKey: messengerKey,
          onLoginSuccess: (String userId, String username) {
            Navigator.pop(context);
          },
        ),
      );
    });
  }

  // ========== NOTIFICATION HELPERS ==========
  Future<void> _sendNotificationSafe({
    required String userId,
    required String notificationType,
    required String title,
    required String body,
    required Map<String, dynamic> data,
  }) async {
    try {
      // Skip invalid user IDs
      if (userId.isEmpty || userId == 'guest' || userId.length < 5) {
        debugPrint('⚠️ Skipping notification - invalid user ID: $userId');
        return;
      }

      debugPrint('📤 Sending "$notificationType" notification to $userId');
      final success = await NotificationService.sendNotification(
        userId: userId,
        notificationType: notificationType,
        title: title,
        body: body,
        data: data,
      );
      if (success) {
        debugPrint('✅ Notification delivered to $userId');
      } else {
        debugPrint('❌ Notification FAILED for $userId (returned false)');
      }
    } catch (e) {
      debugPrint('❌ Notification exception for $userId: $e');
    }
  }

  Future<void> _notifyUsersAboutNewSubFixtureVote(String selection) async {
    try {
      // Get current vote data for this sub-fixture
      final voteData = _votersMap[selection] ?? [];

      if (voteData.isEmpty) return;

      final fixtureName =
          '${widget.fixture.homeTeam} vs ${widget.fixture.awayTeam}';
      final currentTime = DateTime.now().toIso8601String();

      // Find users who voted for the same option (supporters)
      final supporters = voteData
          .where((v) => v['selection'] == selection)
          .toList();

      // Find users who voted for different options (rivals)
      final rivals = _votersMap.entries
          .where((entry) => entry.key != selection)
          .expand((entry) => entry.value)
          .toList();

      // Notify supporters (people who voted the same)
      for (var user in supporters) {
        final userId =
            user['voter_id']?.toString() ?? user['userId']?.toString() ?? '';
        if (userId.isEmpty || userId == widget.userId) continue;

        await _sendNotificationSafe(
          userId: userId,
          notificationType: 'sub_fixture_supporter',
          title: '🎯 Someone agrees with your prop bet!',
          body:
              '@${widget.username} also voted for ${_getOptionDisplayName(selection)} in $fixtureName',
          data: {
            'fixture_id': widget.fixture.matchId,
            'sub_fixture_id': widget.subFixture.id,
            'sub_fixture_question': widget.subFixture.question,
            'voter_id': widget.userId,
            'voter_username': widget.username,
            'voter_selection': selection,
            'selection_display': _getOptionDisplayName(selection),
            'type': 'sub_fixture_supporter',
            'timestamp': currentTime,
          },
        );
        await Future.delayed(const Duration(milliseconds: 50));
      }

      // Notify rivals (people who voted differently)
      for (var user in rivals) {
        final userId =
            user['voter_id']?.toString() ?? user['userId']?.toString() ?? '';
        if (userId.isEmpty || userId == widget.userId) continue;

        await _sendNotificationSafe(
          userId: userId,
          notificationType: 'sub_fixture_rival',
          title: '⚔️ Someone voted against your prop bet!',
          body:
              '@${widget.username} voted for ${_getOptionDisplayName(selection)} in $fixtureName',
          data: {
            'fixture_id': widget.fixture.matchId,
            'sub_fixture_id': widget.subFixture.id,
            'sub_fixture_question': widget.subFixture.question,
            'voter_id': widget.userId,
            'voter_username': widget.username,
            'voter_selection': selection,
            'selection_display': _getOptionDisplayName(selection),
            'type': 'sub_fixture_rival',
            'timestamp': currentTime,
          },
        );
        await Future.delayed(const Duration(milliseconds: 50));
      }

      debugPrint(
        '✅ Sub-fixture vote notifications sent for ${widget.subFixture.question}',
      );
    } catch (e) {
      debugPrint('❌ Error in sub-fixture notification process: $e');
      // Don't throw - we don't want to fail the vote if notifications fail
    }
  }

  Future<void> _submitVote() async {
    if (!_isUserLoggedIn()) {
      _showLoginModal();
      return;
    }

    if (_selectedOption == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select an option'),
          backgroundColor: Colors.orange,
          duration: Duration(seconds: 2),
        ),
      );
      return;
    }

    if (_userVote != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('You have already voted on this prop'),
          backgroundColor: Colors.orange,
          duration: Duration(seconds: 2),
        ),
      );
      return;
    }

    setState(() => _isSubmitting = true);

    try {
      final iconString = _getIconString(widget.subFixture.icon);

      debugPrint('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
      debugPrint('🎯 SUBMITTING VOTE');
      debugPrint('🏷️ Type: ${widget.subFixture.getBackendType()}');
      debugPrint('📝 Question: ${widget.subFixture.question}');
      debugPrint('🎯 Selection: $_selectedOption');
      debugPrint('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

      final response = await ApiService.submitSubFixtureVote(
        voterId: widget.userId,
        username: widget.username,
        subFixtureId: widget.subFixture.id,
        parentFixtureId: widget.fixture.matchId,
        selection: _selectedOption!,
        question: widget.subFixture.question,
        optionA: widget.subFixture.optionA,
        optionB: widget.subFixture.optionB,
        optionC: widget.subFixture.optionC,
        icon: iconString,
        authToken: widget.authToken,
        fixtureType: widget.subFixture
            .getBackendType(), // ✅ This is the key fix
      );

      if (response != null && response['success'] == true) {
        widget.onVote(_selectedOption!);

        _notifyUsersAboutNewSubFixtureVote(_selectedOption!).catchError((e) {
          debugPrint('Background notification error: $e');
        });

        widget.onClose();

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                'Voted for ${_getOptionDisplayName(_selectedOption!)}',
              ),
              backgroundColor: Colors.green,
              duration: const Duration(seconds: 2),
            ),
          );
        }
      } else {
        throw Exception(response?['message'] ?? 'Failed to submit vote');
      }
    } catch (e) {
      debugPrint('❌ Error submitting vote: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: ${e.toString()}'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 3),
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isSubmitting = false);
      }
    }
  }

  // Helper method to convert IconData to string representation
  String _getIconString(IconData icon) {
    // Map common icon code points to emoji strings
    final iconMap = {
      Icons.sports_soccer.codePoint: '⚽',
      Icons.sports_basketball.codePoint: '🏀',
      Icons.sports_tennis.codePoint: '🎾',
      Icons.sports_baseball.codePoint: '⚾',
      Icons.sports_football.codePoint: '🏈',
      Icons.sports_hockey.codePoint: '🏒',
      Icons.sports_cricket.codePoint: '🏏',
      Icons.flag.codePoint: '🏁',
      Icons.people.codePoint: '👥',
      Icons.person.codePoint: '👤',
      Icons.star.codePoint: '⭐',
      Icons.trending_up.codePoint: '📈',
      Icons.trending_down.codePoint: '📉',
      Icons.bolt.codePoint: '⚡',
      Icons.fire_extinguisher.codePoint: '🔥',
      Icons.emoji_events.codePoint: '🏆',
      Icons.quiz.codePoint: '❓',
      Icons.question_mark.codePoint: '❓',
      Icons.check_circle.codePoint: '✅',
      Icons.cancel.codePoint: '❌',
    };

    return iconMap[icon.codePoint] ?? '🎲';
  }

  String _getOptionDisplayName(String selection) {
    if (selection == widget.subFixture.optionA) return widget.fixture.homeTeam;
    if (selection == widget.subFixture.optionB) return widget.fixture.awayTeam;
    if (widget.subFixture.optionC != null &&
        selection == widget.subFixture.optionC) {
      return widget.subFixture.optionC!;
    }
    return selection;
  }

  // Helper method to parse MongoDB date format
  String _parseTimestamp(dynamic timestampValue) {
    if (timestampValue == null) {
      return DateTime.now().toIso8601String();
    }

    // If it's already a string
    if (timestampValue is String) {
      return timestampValue;
    }

    // If it's a Map (MongoDB format)
    if (timestampValue is Map) {
      try {
        // Handle {"$date": {"$numberLong": "..."}}
        if (timestampValue.containsKey('\$date')) {
          final dateObj = timestampValue['\$date'];
          if (dateObj is Map && dateObj.containsKey('\$numberLong')) {
            final milliseconds = int.parse(dateObj['\$numberLong'].toString());
            return DateTime.fromMillisecondsSinceEpoch(
              milliseconds,
            ).toIso8601String();
          } else if (dateObj is String) {
            return dateObj;
          }
        }
      } catch (e) {
        debugPrint('Error parsing MongoDB date: $e');
      }
    }

    // Fallback
    return DateTime.now().toIso8601String();
  }

  String _formatTime(dynamic timestamp) {
    try {
      String timestampStr;
      if (timestamp is String) {
        timestampStr = timestamp;
      } else if (timestamp is Map) {
        timestampStr = _parseTimestamp(timestamp);
      } else {
        timestampStr = timestamp.toString();
      }

      final time = DateTime.parse(timestampStr);
      final now = DateTime.now();
      final diff = now.difference(time);
      if (diff.inMinutes < 1) return 'Just now';
      if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
      if (diff.inHours < 24) return '${diff.inHours}h ago';
      if (diff.inDays < 7) return '${diff.inDays}d ago';
      return DateFormat('MMM d').format(time);
    } catch (e) {
      return 'Recently';
    }
  }

  Color _getOptionColor(String option) {
    if (option == widget.subFixture.optionA) return SocialTheme.primary;
    if (option == widget.subFixture.optionB) return const Color(0xFF2563EB);
    return Colors.purple; // For option C
  }

  Widget _buildVoterList(
    String option,
    List<Map<String, dynamic>> voters,
    Color color,
  ) {
    if (voters.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            children: [
              Icon(Icons.people_outline, size: 32, color: Colors.grey),
              const SizedBox(height: 8),
              Text('No votes yet', style: TextStyle(color: Colors.grey)),
            ],
          ),
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: voters.length,
      itemBuilder: (context, index) {
        final voter = voters[index];

        // Extract username safely
        final username = voter['username']?.toString() ?? 'Anonymous';

        // Extract avatar (first letter of username or custom avatar)
        String avatar = '';
        if (voter['avatar'] != null) {
          avatar = voter['avatar'].toString();
        } else if (username.isNotEmpty && username != 'Anonymous') {
          avatar = username.substring(0, 1).toUpperCase();
        } else {
          avatar = '?';
        }

        // Get timestamp (could be String or MongoDB Map format)
        final timestampValue = voter['voted_at'] ?? voter['timestamp'];

        return Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: SocialTheme.surface,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.2),
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: Text(
                    avatar,
                    style: TextStyle(color: color, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      username,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Text(
                      _formatTime(timestampValue),
                      style: TextStyle(color: Colors.grey[400], fontSize: 11),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  _getOptionDisplayName(option).toLowerCase(),
                  style: TextStyle(
                    color: color,
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.isOpen) return const SizedBox.shrink();

    final optionCount = _options.length;

    return Stack(
      children: [
        // Backdrop
        Positioned.fill(
          child: GestureDetector(
            onTap: widget.onClose,
            child: Container(color: Colors.black.withValues(alpha: 0.6)),
          ),
        ),

        // Modal Content
        Align(
          alignment: Alignment.bottomCenter,
          child: Container(
            height: MediaQuery.of(context).size.height * 0.85,
            decoration: BoxDecoration(
              color: SocialTheme.background,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(24),
                topRight: Radius.circular(24),
              ),
            ),
            child: Column(
              children: [
                // Drag handle
                Container(
                  margin: const EdgeInsets.only(top: 12, bottom: 8),
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey[800],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),

                // Header
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                widget.subFixture.icon,
                                color: SocialTheme.primary,
                                size: 24,
                              ),
                              const SizedBox(width: 8),
                              Text(
                                widget.subFixture.question,
                                style: SocialTheme.headline.copyWith(
                                  fontSize: 18,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Text(
                            '${widget.fixture.homeTeam} vs ${widget.fixture.awayTeam}',
                            style: SocialTheme.small,
                          ),
                        ],
                      ),
                      GestureDetector(
                        onTap: widget.onClose,
                        child: Container(
                          width: 36,
                          height: 36,
                          decoration: BoxDecoration(
                            color: SocialTheme.surface,
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            Icons.close,
                            color: SocialTheme.text,
                            size: 20,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                // Stats bars
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      for (int i = 0; i < optionCount; i++) ...[
                        Expanded(
                          child: _buildStatBar(
                            '${_getPercentage(i).toStringAsFixed(0)}%',
                            _getOptionDisplayName(_options[i]),
                            _getOptionColor(_options[i]),
                            _voteCounts[_options[i]] ?? 0,
                          ),
                        ),
                        if (i < optionCount - 1) const SizedBox(width: 8),
                      ],
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                // Radio options
                if (_userVote == null) ...[
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Column(
                      children: [
                        for (int i = 0; i < optionCount; i++) ...[
                          _buildRadioOption(
                            title: _getOptionDisplayName(_options[i]),
                            value: _options[i],
                            groupValue: _selectedOption,
                            color: _getOptionColor(_options[i]),
                            voteCount: _voteCounts[_options[i]] ?? 0,
                            onChanged: (value) =>
                                setState(() => _selectedOption = value),
                          ),
                          if (i < optionCount - 1) const SizedBox(height: 12),
                        ],
                      ],
                    ),
                  ),

                  const SizedBox(height: 16),

                  // Vote button
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: SizedBox(
                      width: double.infinity,
                      height: 52,
                      child: ElevatedButton(
                        onPressed: _isSubmitting ? null : _submitVote,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: SocialTheme.primary,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                        child: _isSubmitting
                            ? const SizedBox(
                                width: 22,
                                height: 22,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : const Text(
                                'Submit Vote',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                      ),
                    ),
                  ),
                ] else ...[
                  // User already voted
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 16),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: SocialTheme.surface,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: Colors.green.withValues(alpha: 0.3),
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.check_circle, color: Colors.green, size: 24),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'You voted',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14,
                                ),
                              ),
                              Text(
                                _getOptionDisplayName(_userVote!),
                                style: TextStyle(
                                  color: Colors.green,
                                  fontSize: 13,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],

                const SizedBox(height: 16),

                // Voters list section
                Expanded(
                  child: _isLoading
                      ? Center(
                          child: CircularProgressIndicator(
                            color: SocialTheme.primary,
                          ),
                        )
                      : DefaultTabController(
                          length: optionCount,
                          child: Column(
                            children: [
                              Container(
                                color: SocialTheme.surface,
                                child: TabBar(
                                  tabs: _options.map((option) {
                                    return Tab(
                                      text: _getOptionDisplayName(option),
                                    );
                                  }).toList(),
                                  labelColor: SocialTheme.text,
                                  unselectedLabelColor:
                                      SocialTheme.textSecondary,
                                  indicatorColor: SocialTheme.primary,
                                  isScrollable: optionCount > 3,
                                ),
                              ),
                              Expanded(
                                child: TabBarView(
                                  children: _options.map((option) {
                                    return _buildVoterList(
                                      option,
                                      _votersMap[option] ?? [],
                                      _getOptionColor(option),
                                    );
                                  }).toList(),
                                ),
                              ),
                            ],
                          ),
                        ),
                ),

                const SizedBox(height: 12),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // Helper method to get percentage
  double _getPercentage(int index) {
    final option = _options[index];
    final votes = _voteCounts[option] ?? 0;
    return _totalVotes > 0
        ? (votes / _totalVotes * 100)
        : (100 / _options.length);
  }

  Widget _buildStatBar(
    String percentage,
    String label,
    Color color,
    int votes,
  ) {
    return Column(
      children: [
        Text(
          percentage,
          style: TextStyle(
            color: color,
            fontWeight: FontWeight.bold,
            fontSize: 14,
          ),
        ),
        const SizedBox(height: 4),
        LinearProgressIndicator(
          value: double.parse(percentage.replaceAll('%', '')) / 100,
          backgroundColor: Colors.grey[800],
          color: color,
          minHeight: 4,
          borderRadius: BorderRadius.circular(2),
        ),
        const SizedBox(height: 4),
        Text(
          label.length > 8 ? '${label.substring(0, 6)}...' : label,
          style: TextStyle(color: Colors.grey[400], fontSize: 10),
        ),
        Text(
          '$votes votes',
          style: TextStyle(color: Colors.grey[500], fontSize: 9),
        ),
      ],
    );
  }

  Widget _buildRadioOption({
    required String title,
    required String value,
    required String? groupValue,
    required Color color,
    required int voteCount,
    required void Function(String?) onChanged,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: SocialTheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: groupValue == value ? color : Colors.grey[800]!,
          width: groupValue == value ? 2 : 1,
        ),
      ),
      child: Row(
        children: [
          Radio<String>(
            value: value,
            groupValue: groupValue,
            onChanged: onChanged,
            activeColor: color,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              '$voteCount votes',
              style: TextStyle(
                color: color,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
