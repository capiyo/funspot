import 'package:flutter/material.dart';
import '../../pages/social_theme.dart';
import '../../services/auth_service.dart';
import '../../modals/login_modal.dart';
import '../../main.dart';
import '../../models/fixture_models.dart';

class FirstGoalModal extends StatefulWidget {
  final bool isOpen;
  final VoidCallback onClose;
  final Fixture fixture;
  final SubFixture subFixture;
  final String userId;
  final String username;
  final String? authToken;
  final Function(String selection) onVote; // Add this

  const FirstGoalModal({
    super.key,
    required this.isOpen,
    required this.onClose,
    required this.fixture,
    required this.subFixture,
    required this.userId,
    required this.username,
    required this.onVote, // Add this
    this.authToken,
  });

  @override
  State<FirstGoalModal> createState() => _FirstGoalModalState();
}

class _FirstGoalModalState extends State<FirstGoalModal> {
  String? _selectedOption;
  bool _isSubmitting = false;
  late final AuthService _authService;

  // Mock data for voters
  final List<Map<String, dynamic>> _homeVoters = [
    {
      'username': 'JohnDoe',
      'avatar': 'JD',
      'timestamp': DateTime.now().subtract(const Duration(minutes: 5)),
    },
    {
      'username': 'SarahK',
      'avatar': 'SK',
      'timestamp': DateTime.now().subtract(const Duration(minutes: 12)),
    },
    {
      'username': 'MikeT',
      'avatar': 'MT',
      'timestamp': DateTime.now().subtract(const Duration(minutes: 23)),
    },
    {
      'username': 'EmmaW',
      'avatar': 'EW',
      'timestamp': DateTime.now().subtract(const Duration(minutes: 34)),
    },
    {
      'username': 'ChrisP',
      'avatar': 'CP',
      'timestamp': DateTime.now().subtract(const Duration(hours: 1)),
    },
  ];

  final List<Map<String, dynamic>> _awayVoters = [
    {
      'username': 'AlexR',
      'avatar': 'AR',
      'timestamp': DateTime.now().subtract(const Duration(minutes: 8)),
    },
    {
      'username': 'LisaM',
      'avatar': 'LM',
      'timestamp': DateTime.now().subtract(const Duration(minutes: 15)),
    },
    {
      'username': 'TomH',
      'avatar': 'TH',
      'timestamp': DateTime.now().subtract(const Duration(minutes: 28)),
    },
    {
      'username': 'NinaC',
      'avatar': 'NC',
      'timestamp': DateTime.now().subtract(const Duration(minutes: 45)),
    },
    {
      'username': 'PaulD',
      'avatar': 'PD',
      'timestamp': DateTime.now().subtract(const Duration(hours: 2)),
    },
  ];

  final List<Map<String, dynamic>> _noGoalVoters = [
    {
      'username': 'MarkS',
      'avatar': 'MS',
      'timestamp': DateTime.now().subtract(const Duration(minutes: 20)),
    },
    {
      'username': 'JaneL',
      'avatar': 'JL',
      'timestamp': DateTime.now().subtract(const Duration(minutes: 35)),
    },
  ];

  @override
  void initState() {
    super.initState();
    _authService = AuthService();
  }

  bool _isUserLoggedIn() {
    return _authService.isLoggedIn &&
        widget.userId.isNotEmpty &&
        widget.userId != 'guest';
  }

  void _showLoginModal() {
    widget.onClose();
    Future.delayed(const Duration(milliseconds: 200), () {
      showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (context) => LoginModal(
          messengerKey: messengerKey,
          onLoginSuccess: (String userId, String username) {
            Navigator.pop(context);
          },
        ),
      );
    });
  }

  Future<void> _submitVote() async {
    if (!_isUserLoggedIn()) {
      _showLoginModal();
      return;
    }

    if (_selectedOption == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select an option'),
          backgroundColor: Colors.orange,
          duration: Duration(seconds: 2),
        ),
      );
      return;
    }

    setState(() => _isSubmitting = true);

    // Simulate API call
    await Future.delayed(const Duration(seconds: 1));

    setState(() => _isSubmitting = false);
    widget.onVote(_selectedOption!);
    widget.onClose();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Voted for ${_selectedOption == 'home'
              ? widget.fixture.homeTeam
              : _selectedOption == 'away'
              ? widget.fixture.awayTeam
              : 'No Goal'}',
        ),
        backgroundColor: Colors.green,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  String _formatTime(DateTime time) {
    final now = DateTime.now();
    final diff = now.difference(time);
    if (diff.inMinutes < 1) return 'Just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    return '${diff.inDays}d ago';
  }

  Widget _buildVoterList(List<Map<String, dynamic>> voters, Color color) {
    if (voters.isEmpty) {
      return Padding(
        padding: const EdgeInsets.all(32),
        child: Center(
          child: Column(
            children: [
              Icon(Icons.people_outline, size: 32, color: Colors.grey),
              const SizedBox(height: 8),
              Text(
                'No votes yet',
                style: TextStyle(color: Colors.grey[400], fontSize: 12),
              ),
            ],
          ),
        ),
      );
    }

    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: voters.length,
      itemBuilder: (context, index) {
        final voter = voters[index];
        return Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: SocialTheme.surface,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.2),
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: Text(
                    voter['avatar'],
                    style: TextStyle(color: color, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      voter['username'],
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Text(
                      _formatTime(voter['timestamp']),
                      style: TextStyle(color: Colors.grey[400], fontSize: 10),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.isOpen) return const SizedBox.shrink();

    final homeTeamColor = SocialTheme.primary;
    final awayTeamColor = const Color(0xFF2563EB);
    final noGoalColor = Colors.purple;

    final homeVotes = _homeVoters.length;
    final awayVotes = _awayVoters.length;
    final noGoalVotes = _noGoalVoters.length;
    final totalVotes = homeVotes + awayVotes + noGoalVotes;

    final homePercentage = totalVotes > 0
        ? (homeVotes / totalVotes * 100)
        : 33.3;
    final awayPercentage = totalVotes > 0
        ? (awayVotes / totalVotes * 100)
        : 33.3;
    final noGoalPercentage = totalVotes > 0
        ? (noGoalVotes / totalVotes * 100)
        : 33.4;

    return Stack(
      children: [
        Positioned.fill(
          child: GestureDetector(
            onTap: widget.onClose,
            child: Container(color: Colors.black.withValues(alpha: 0.6)),
          ),
        ),
        Align(
          alignment: Alignment.bottomCenter,
          child: Container(
            height: MediaQuery.of(context).size.height * 0.85,
            decoration: BoxDecoration(
              color: SocialTheme.background,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Column(
              children: [
                // Drag handle
                Container(
                  margin: const EdgeInsets.only(top: 12, bottom: 8),
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey[800],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                // Header
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Who Scores First?',
                            style: SocialTheme.headline.copyWith(fontSize: 18),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            '${widget.fixture.homeTeam} vs ${widget.fixture.awayTeam}',
                            style: SocialTheme.small,
                          ),
                        ],
                      ),
                      GestureDetector(
                        onTap: widget.onClose,
                        child: Container(
                          width: 36,
                          height: 36,
                          decoration: BoxDecoration(
                            color: SocialTheme.surface,
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            Icons.close,
                            color: SocialTheme.text,
                            size: 20,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                // Stats bars
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      Expanded(
                        child: _buildStatBar(
                          '${homePercentage.toStringAsFixed(0)}%',
                          widget.fixture.homeTeam,
                          homeTeamColor,
                          homeVotes,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: _buildStatBar(
                          '${awayPercentage.toStringAsFixed(0)}%',
                          widget.fixture.awayTeam,
                          awayTeamColor,
                          awayVotes,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: _buildStatBar(
                          '${noGoalPercentage.toStringAsFixed(0)}%',
                          'No Goal',
                          noGoalColor,
                          noGoalVotes,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                // Radio buttons
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Column(
                    children: [
                      _buildRadioOption(
                        title: widget.fixture.homeTeam,
                        value: 'home',
                        groupValue: _selectedOption,
                        color: homeTeamColor,
                        voteCount: homeVotes,
                        onChanged: (value) =>
                            setState(() => _selectedOption = value),
                      ),
                      const SizedBox(height: 12),
                      _buildRadioOption(
                        title: widget.fixture.awayTeam,
                        value: 'away',
                        groupValue: _selectedOption,
                        color: awayTeamColor,
                        voteCount: awayVotes,
                        onChanged: (value) =>
                            setState(() => _selectedOption = value),
                      ),
                      const SizedBox(height: 12),
                      _buildRadioOption(
                        title: 'No Goal',
                        value: 'no_goal',
                        groupValue: _selectedOption,
                        color: noGoalColor,
                        voteCount: noGoalVotes,
                        onChanged: (value) =>
                            setState(() => _selectedOption = value),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                // Vote button
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: ElevatedButton(
                      onPressed: _isSubmitting ? null : _submitVote,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: SocialTheme.primary,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: _isSubmitting
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : const Text(
                              'Submit Vote',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                // Voters list section
                Expanded(
                  child: DefaultTabController(
                    length: 3,
                    child: Column(
                      children: [
                        Container(
                          color: SocialTheme.surface,
                          child: TabBar(
                            tabs: [
                              Tab(text: widget.fixture.homeTeam),
                              Tab(text: widget.fixture.awayTeam),
                              const Tab(text: 'No Goal'),
                            ],
                            labelColor: SocialTheme.text,
                            unselectedLabelColor: SocialTheme.textSecondary,
                            indicatorColor: SocialTheme.primary,
                          ),
                        ),
                        Expanded(
                          child: TabBarView(
                            children: [
                              _buildVoterList(_homeVoters, homeTeamColor),
                              _buildVoterList(_awayVoters, awayTeamColor),
                              _buildVoterList(_noGoalVoters, noGoalColor),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 12),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildStatBar(
    String percentage,
    String label,
    Color color,
    int votes,
  ) {
    return Column(
      children: [
        Text(
          percentage,
          style: TextStyle(
            color: color,
            fontWeight: FontWeight.bold,
            fontSize: 14,
          ),
        ),
        const SizedBox(height: 4),
        LinearProgressIndicator(
          value: double.parse(percentage.replaceAll('%', '')) / 100,
          backgroundColor: Colors.grey[800],
          color: color,
          minHeight: 4,
          borderRadius: BorderRadius.circular(2),
        ),
        const SizedBox(height: 4),
        Text(
          label.length > 8 ? '${label.substring(0, 6)}...' : label,
          style: TextStyle(color: Colors.grey[400], fontSize: 10),
        ),
        Text(
          '$votes votes',
          style: TextStyle(color: Colors.grey[500], fontSize: 9),
        ),
      ],
    );
  }

  Widget _buildRadioOption({
    required String title,
    required String value,
    required String? groupValue,
    required Color color,
    required int voteCount,
    required void Function(String?) onChanged,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: SocialTheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: groupValue == value ? color : Colors.grey[800]!,
          width: groupValue == value ? 2 : 1,
        ),
      ),
      child: Row(
        children: [
          Radio<String>(
            value: value,
            groupValue: groupValue,
            onChanged: onChanged,
            activeColor: color,
            fillColor: WidgetStateProperty.resolveWith((states) => color),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              '$voteCount votes',
              style: TextStyle(
                color: color,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
