import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:country_code_picker/country_code_picker.dart';
import 'dart:async';
import 'dart:convert';
import 'dart:developer' as developer;

import '../pages/social_theme.dart';
import '../services/auth_service.dart';

// ============================================================================
//  CLASH LOGIN MODAL — Firebase Phone Auth + PIN fallback for uncertified devices
// ============================================================================
class LoginModal extends StatelessWidget {
  final Function(String userId, String username)? onLoginSuccess;
  final GlobalKey<ScaffoldMessengerState>? messengerKey;

  const LoginModal({super.key, this.onLoginSuccess, this.messengerKey});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.pop(context),
      child: Container(
        color: Colors.transparent,
        child: GestureDetector(
          onTap: () {},
          child: DraggableScrollableSheet(
            initialChildSize: 0.60,
            minChildSize: 0.45,
            maxChildSize: 0.85,
            expand: false,
            builder: (context, scrollController) => _LoginContent(
              onLoginSuccess: onLoginSuccess,
              messengerKey: messengerKey,
              scrollController: scrollController,
            ),
          ),
        ),
      ),
    );
  }
}

// ============================================================================
//  CONTENT STATE
// ============================================================================
class _LoginContent extends StatefulWidget {
  final Function(String userId, String username)? onLoginSuccess;
  final GlobalKey<ScaffoldMessengerState>? messengerKey;
  final ScrollController scrollController;

  const _LoginContent({
    required this.onLoginSuccess,
    required this.messengerKey,
    required this.scrollController,
  });

  @override
  State<_LoginContent> createState() => _LoginContentState();
}

class _LoginContentState extends State<_LoginContent> {
  // ── view state ─────────────────────────────
  bool _loading = false;
  bool _showOtp = false;
  bool _showPinFallback = false; // true when Firebase fails → PIN flow
  bool _isNewPinUser = false; // true = set PIN, false = enter existing PIN
  bool _acceptTerms = false;

  // ── country code — default Kenya ───────────
  String _dialCode = '+254';
  String _countryCode = 'KE';
  String? _existingUserId;

  // ── controllers ────────────────────────────
  final _phoneFormKey = GlobalKey<FormState>();
  final _otpFormKey = GlobalKey<FormState>();
  final _phoneCtrl = TextEditingController();
  final _otpCtrl = TextEditingController();
  final _pinCtrl = TextEditingController();
  final _pinConfirmCtrl = TextEditingController();

  // ── OTP / PIN ──────────────────────────────
  String? _verificationId;
  String _verifiedPhone = '';

  // PIN visibility toggles
  bool _pinObscure = true;
  bool _pinConfirmObscure = true;

  static const _baseUrl = 'https://clash-api-m5mr.onrender.com/api/auth';

  @override
  void dispose() {
    _phoneCtrl.dispose();
    _otpCtrl.dispose();
    _pinCtrl.dispose();
    _pinConfirmCtrl.dispose();
    super.dispose();
  }

  // ─────────────────────────────────────────
  //  HELPERS
  // ─────────────────────────────────────────
  String _buildE164(String raw) {
    String s = raw.trim().replaceAll(RegExp(r'[\s\-\(\)\.]'), '');
    if (s.startsWith('+')) return s;
    if (s.startsWith('00')) return '+${s.substring(2)}';
    final dialDigits = _dialCode.replaceFirst('+', '');
    if (s.startsWith(dialDigits) && s.length > dialDigits.length + 4)
      return '+$s';
    if (s.startsWith('0')) s = s.substring(1);
    return '$_dialCode$s';
  }

  Map<String, String> _headers() => {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      };

  Map<String, dynamic>? _parseJson(String raw) {
    try {
      final d = jsonDecode(raw);
      return d is Map<String, dynamic> ? d : null;
    } catch (_) {
      return null;
    }
  }

  void _toast(String msg, {bool error = false, bool warn = false}) {
    final overlay = Navigator.of(context).overlay;
    if (overlay == null) return;
    late OverlayEntry entry;
    entry = OverlayEntry(
      builder: (_) => Positioned(
        top: MediaQuery.of(context).padding.top + 60,
        left: 16,
        right: 16,
        child: Material(
          color: Colors.transparent,
          child: TweenAnimationBuilder<double>(
            tween: Tween(begin: 0.0, end: 1.0),
            duration: const Duration(milliseconds: 300),
            builder: (_, v, child) => Opacity(
              opacity: v,
              child: Transform.translate(
                  offset: Offset(0, (1 - v) * -20), child: child),
            ),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: error
                    ? SocialTheme.destructive
                    : warn
                        ? SocialTheme.warning
                        : SocialTheme.success,
                borderRadius: BorderRadius.circular(SocialTheme.radius),
                boxShadow: const [
                  BoxShadow(
                      color: Colors.black26,
                      blurRadius: 12,
                      offset: Offset(0, 4))
                ],
              ),
              child: Row(
                children: [
                  Icon(
                    error
                        ? Icons.error_outline
                        : warn
                            ? Icons.warning_amber_outlined
                            : Icons.check_circle_outline,
                    color: Colors.white,
                    size: 18,
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      msg,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 13,
                          fontWeight: FontWeight.w500),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
    overlay.insert(entry);
    Future.delayed(const Duration(seconds: 3), entry.remove);
  }

  // ─────────────────────────────────────────
  //  BACKEND CALLS
  // ─────────────────────────────────────────

  // Uses the dedicated check_user_exists endpoint (normalized match
  // happens server-side now) instead of fetching the whole user list.
  // ⚠️ CONFIRM THIS PATH against your routes::auth file.

  // Uses the dedicated get_user_by_username endpoint instead of fetching
  // the whole user list. A 404 means the username is free.
  // ⚠️ CONFIRM THIS PATH against your routes::auth file.
  // Uses the dedicated check_user_exists endpoint (normalized match
  // happens server-side now) instead of fetching the whole user list.
  Future<Map<String, dynamic>?> _getUserByPhoneFull(String e164) async {
    try {
      final res = await http
          .get(
            Uri.parse('$_baseUrl/check-user/${Uri.encodeComponent(e164)}'),
            headers: _headers(),
          )
          .timeout(const Duration(seconds: 10));

      if (res.statusCode == 200) {
        final data = _parseJson(res.body);
        if (data?['exists'] == true) {
          final user = data?['user'] as Map<String, dynamic>?;
          return {
            ...?user,
            'has_pin': data?['has_pin'],
          };
        }
      }
    } catch (e) {
      developer.log('getUserByPhoneFull: $e');
    }
    return null;
  }

  // Uses the dedicated get_user_by_username endpoint instead of fetching
  // the whole user list. A 404 means the username is free.
  Future<bool> _isUsernameTaken(String username) async {
    try {
      final res = await http
          .get(
            Uri.parse(
                '$_baseUrl/user/username/${Uri.encodeComponent(username)}'),
            headers: _headers(),
          )
          .timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = _parseJson(res.body);
        return data?['success'] == true && data?['user'] != null;
      }
      // 404 = not found = username available
      return false;
    } catch (e) {
      developer.log('isUsernameTaken: $e');
    }
    return false;
  }

  Future<void> _saveSession(
      String userId, String username, String token, String phone) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('usertoken', token);
    await prefs.setString('user',
        jsonEncode({'id': userId, 'username': username, 'phone': phone}));
    await prefs.setBool('isLoggedIn', true);
  }

  // ─────────────────────────────────────────
  //  STEP 1 — SEND OTP (with PIN fallback)
  // ─────────────────────────────────────────
  Future<void> _sendOtp() async {
    if (!_phoneFormKey.currentState!.validate()) return;
    if (!_acceptTerms) {
      _toast('Please accept Terms & Conditions', warn: true);
      return;
    }

    setState(() => _loading = true);
    final e164 = _buildE164(_phoneCtrl.text);
    _verifiedPhone = e164;

    try {
      await FirebaseAuth.instance.verifyPhoneNumber(
        phoneNumber: e164,
        timeout: const Duration(seconds: 60),
        verificationCompleted: (cred) => _signIn(cred),
        verificationFailed: (e) {
          developer.log('verificationFailed: code=${e.code} msg=${e.message}');
          if (_isPlayIntegrityError(e)) {
            _switchToPinFlow(e164);
          } else {
            _toast(_friendlyAuthError(e), error: true);
            setState(() => _loading = false);
          }
        },
        codeSent: (vid, _) {
          _verificationId = vid;
          _toast('OTP sent to $e164');
          setState(() {
            _showOtp = true;
            _loading = false;
          });
        },
        codeAutoRetrievalTimeout: (vid) => _verificationId = vid,
      );
    } on FirebaseAuthException catch (e) {
      developer.log('verifyPhoneNumber threw: code=${e.code} msg=${e.message}');
      if (_isPlayIntegrityError(e)) {
        _switchToPinFlow(e164);
      } else {
        _toast(_friendlyAuthError(e), error: true);
        setState(() => _loading = false);
      }
    } catch (e) {
      developer.log('verifyPhoneNumber unexpected error: $e');
      if (_isNetworkError(e)) {
        _toast('Network error. Check your connection and try again.',
            error: true);
        setState(() => _loading = false);
      } else if (_looksLikePlayIntegrityFailure(e)) {
        _switchToPinFlow(e164);
      } else {
        _toast('Something went wrong. Please try again.', error: true);
        setState(() => _loading = false);
      }
    }
  }
  // Firebase error codes that indicate Play Integrity / uncertified device
  // — these get silently routed to PIN, never shown as raw errors to the user
  // ─────────────────────────────────────────
  //  ERROR CLASSIFICATION
  // ─────────────────────────────────────────

  // Confirmed real-world signature (from Firebase/FlutterFire issue reports):
  // code is always 'app-not-authorized', message always contains
  // 'play_integrity_token' or 'play integrity'. This fires on emulators,
  // uncertified devices, and devices where Play Integrity attestation fails.
  bool _isPlayIntegrityError(FirebaseAuthException e) {
    if (e.code == 'app-not-authorized') return true;
    final msg = e.message?.toLowerCase() ?? '';
    return msg.contains('play_integrity_token') ||
        msg.contains('play integrity');
  }

  // For the generic/non-FirebaseAuthException catch block only.
  // Narrow on purpose — do NOT add generic codes like 'internal-error'
  // or 'unknown_error', they also fire on unrelated failures.
  bool _looksLikePlayIntegrityFailure(Object e) {
    final text = e.toString().toLowerCase();
    return text.contains('play_integrity_token') ||
        text.contains('play integrity') ||
        text.contains(
            'recaptcha'); // reCAPTCHA-fallback failures on old WebViews
  }

  // Must be checked BEFORE _looksLikePlayIntegrityFailure in the generic
  // catch — a real network failure should never fall back to PIN, since
  // the PIN-login HTTP call would fail for the same reason.
  bool _isNetworkError(Object e) {
    final text = e.toString().toLowerCase();
    return text.contains('network-request-failed') ||
        text.contains('socketexception') ||
        text.contains('failed host lookup') ||
        text.contains('connection refused') ||
        text.contains('timeoutexception') ||
        text.contains('handshakeexception');
  }

  static const _rateLimitCodes = {
    'too-many-requests',
    'quota-exceeded',
  };

  static const _badInputCodes = {
    'invalid-phone-number',
    'missing-phone-number',
  };

  static const _configOrAccountCodes = {
    'operation-not-allowed',
    'user-disabled',
  };

  String _friendlyAuthError(FirebaseAuthException e) {
    if (_rateLimitCodes.contains(e.code)) {
      return 'Too many attempts. Please wait a few minutes and try again.';
    }
    if (_badInputCodes.contains(e.code)) {
      return 'That phone number looks invalid. Please check and try again.';
    }
    if (_configOrAccountCodes.contains(e.code)) {
      return e.code == 'user-disabled'
          ? 'This account has been disabled.'
          : 'Phone sign-in is temporarily unavailable. Please try again later.';
    }
    if (e.code == 'network-request-failed') {
      return 'Network error. Check your connection and try again.';
    }
    return 'Failed to send OTP: ${e.message ?? 'unknown error'}';
  }

  // ─────────────────────────────────────────
  //  PIN FALLBACK FLOW
  // ─────────────────────────────────────────
  Future<void> _switchToPinFlow(String e164) async {
    _verifiedPhone = e164;
    final userData = await _getUserByPhoneFull(e164);
    final exists = userData != null;
    final hasPin = userData?['has_pin'] == true;

    setState(() {
      _existingUserId = exists ? userData!['id']?.toString() : null;
      // true = show "Set PIN" screen (covers brand-new AND
      // existing-account-without-a-PIN cases)
      // false = show "Enter PIN" screen (account already has a PIN)
      _isNewPinUser = !hasPin;
      _showPinFallback = true;
      _loading = false;
    });
  }

  String? validateUsername(String username) {
    if (username.isEmpty) return 'Username is required';
    final trimmed = username.trim();
    if (trimmed.length < 3) return 'Username must be at least 3 characters';
    if (trimmed.length > 20) return 'Username must be less than 20 characters';

    // 🔥 CHANGE THIS - Only allow alphabetical characters
    if (!RegExp(r'^[a-zA-Z]+$').hasMatch(trimmed)) {
      return 'Username must contain only letters (a-z)';
    }

    // Remove these checks since they're no longer needed with letters only
    // if (RegExp(r'^[0-9]+$').hasMatch(trimmed)) return 'Username cannot be only numbers';
    // final numCount = trimmed.replaceAll(RegExp(r'[^0-9]'), '').length;
    // if (numCount > trimmed.length / 2) return 'Username cannot contain mostly numbers';
    // if (!RegExp(r'^[a-zA-Z0-9_]+$').hasMatch(trimmed)) return 'Use only letters, numbers, and underscores';
    // if (!RegExp(r'[a-zA-Z]').hasMatch(trimmed)) return 'Username must contain at least one letter';

    // You can keep these checks if you want, but they're redundant now
    final lowerUsername = trimmed.toLowerCase();
    final blockedPatterns = [
      r'^admin$',
      r'^administrator$',
      r'^superadmin$',
      r'^root$',
      r'^sysadmin$',
      r'^moderator$',
      r'^mod$',
      r'^staff$',
      r'^support$',
      r'^helpdesk$',
      r'^webmaster$',
      r'^master$',
      r'^system$',
      r'^test$',
      r'^user$',
      r'^guest$',
      r'^anonymous$',
      r'^default$',
      r'^example$',
      r'^null$',
      r'^undefined$',
      r'^service$',
      r'^api$',
      r'^bot$',
      r'^cron$',
      r'^daemon$',
      r'^clash$',
      r'^fanclash$',
      r'^clashfan$',
      r'^clashadmin$',
      r'^clashmod$',
      r'^clashstaff$',
      r'.*admin.*',
      r'.*root.*',
      r'.*super.*',
      r'.*mod.*',
    ];
    for (final pattern in blockedPatterns) {
      if (RegExp(pattern, caseSensitive: false).hasMatch(lowerUsername)) {
        return 'This username is not allowed';
      }
    }

    // These checks aren't relevant anymore but you can keep them
    if (RegExp(r'^[0-9+\-\s()]{8,}$').hasMatch(trimmed))
      return 'Username cannot be a phone number';
    if (RegExp(r'^(.)\1{2,}$').hasMatch(trimmed))
      return 'Username cannot have repeated characters only';

    final sequential = RegExp(
      r'(?:abc|bcd|cde|def|efg|fgh|ghi|hij|ijk|jkl|klm|lmn|mno|nop|opq|pqr|qrs|rst|stu|tuv|uvw|vwx|wxy|xyz)',
    );
    if (sequential.hasMatch(trimmed.toLowerCase()))
      return 'Username cannot contain sequential patterns (abc, 123)';

    final keyboardPatterns = RegExp(
      r'(?:qwerty|asdfgh|zxcvbn|qwert|asdf|zxcv|qwe|asd|zxc|poiu|poi|lkj|mnb)',
    );
    if (keyboardPatterns.hasMatch(trimmed.toLowerCase()))
      return 'Username cannot contain keyboard patterns';

    return null;
  }

  Future<void> _submitPin() async {
    final pin = _pinCtrl.text.trim();

    if (pin.length != 4 || !RegExp(r'^\d{4}$').hasMatch(pin)) {
      _toast('Enter a 4-digit PIN', error: true);
      return;
    }

    if (_isNewPinUser) {
      // ── setting a PIN: either a brand-new account, or an existing
      // account (e.g. originally signed up via Firebase OTP on another
      // device) that just doesn't have a PIN yet ──
      if (_pinConfirmCtrl.text.trim() != pin) {
        _toast('PINs do not match', error: true);
        return;
      }

      if (_existingUserId != null) {
        // existing account — attach PIN directly, skip username dialog
        await _attachPinToExistingUser(_existingUserId!, pin);
      } else {
        // genuinely new account — need a username first
        _showUsernameDialog(pin: pin);
      }
    } else {
      // ── existing user with a PIN already set: verify with backend ──
      setState(() => _loading = true);
      try {
        final res = await http
            .post(
              Uri.parse('$_baseUrl/pin-login'),
              headers: _headers(),
              body: jsonEncode({'phone': _verifiedPhone, 'pin': pin}),
            )
            .timeout(const Duration(seconds: 15));

        final body = _parseJson(res.body);
        if (res.statusCode == 200) {
          final token = body?['token'] as String?;
          final user = body?['user'] as Map<String, dynamic>?;
          final userId = user?['id']?.toString();
          final username = user?['username']?.toString() ?? 'User';
          if (userId != null && token != null) {
            await _saveSession(userId, username, token, _verifiedPhone);
            await AuthService()
                .login(userId, username, token, phone: _verifiedPhone);
            _toast('Welcome back, $username! 🎉');
            widget.onLoginSuccess?.call(userId, username);
            if (mounted) Navigator.pop(context);
          } else {
            _toast('Login failed', error: true);
            setState(() => _loading = false);
          }
        } else {
          _toast(body?['message'] ?? 'Incorrect PIN', error: true);
          setState(() => _loading = false);
        }
      } catch (_) {
        _toast('Connection error', error: true);
        setState(() => _loading = false);
      }
    }
  }

  // ⚠️ CONFIRM THIS PATH against your routes::auth file / router wiring
  Future<void> _attachPinToExistingUser(String userId, String pin) async {
    setState(() => _loading = true);
    try {
      final res = await http
          .post(
            Uri.parse('$_baseUrl/user/$userId/set-pin'),
            headers: _headers(),
            body: jsonEncode({'pin': pin}),
          )
          .timeout(const Duration(seconds: 15));

      final body = _parseJson(res.body);
      if (res.statusCode == 200) {
        final token = body?['token'] as String?;
        final user = body?['user'] as Map<String, dynamic>?;
        final username = user?['username']?.toString() ?? 'User';
        if (token != null) {
          await _saveSession(userId, username, token, _verifiedPhone);
          await AuthService()
              .login(userId, username, token, phone: _verifiedPhone);
          _toast('PIN set! Welcome back, $username 🎉');
          widget.onLoginSuccess?.call(userId, username);
          if (mounted) Navigator.pop(context);
        } else {
          _toast('PIN set, but login failed. Please try again.', error: true);
          setState(() => _loading = false);
        }
      } else {
        _toast(body?['message'] ?? 'Failed to set PIN', error: true);
        setState(() => _loading = false);
      }
    } catch (_) {
      _toast('Connection error', error: true);
      setState(() => _loading = false);
    }
  }

  // ─────────────────────────────────────────
  //  STEP 2 — VERIFY OTP (Firebase path)
  // ─────────────────────────────────────────
  Future<void> _verifyOtp() async {
    if (!_otpFormKey.currentState!.validate()) return;
    setState(() => _loading = true);
    try {
      final cred = PhoneAuthProvider.credential(
        verificationId: _verificationId!,
        smsCode: _otpCtrl.text.trim(),
      );
      await _signIn(cred);
    } catch (_) {
      _toast('Invalid OTP', error: true);
      setState(() => _loading = false);
    }
  }

  // ─────────────────────────────────────────
  //  STEP 3 — SIGN IN (Firebase path)
  // ─────────────────────────────────────────
  Future<void> _signIn(PhoneAuthCredential cred) async {
    try {
      final uc = await FirebaseAuth.instance.signInWithCredential(cred);
      final fUser = uc.user!;
      final token = await fUser.getIdToken();
      final phone = fUser.phoneNumber ?? _verifiedPhone;

      final existing = await _getUserByPhoneFull(phone);

      if (existing != null) {
        final uid = existing['id']?.toString() ?? '';
        final username = existing['username']?.toString() ?? 'User';
        await _saveSession(uid, username, token!, phone);
        await AuthService().login(uid, username, token, phone: phone);
        _toast('Welcome back, $username! 🎉');
        widget.onLoginSuccess?.call(uid, username);
        if (mounted) Navigator.pop(context);
      } else {
        setState(() => _loading = false);
        _showUsernameDialog();
      }
    } catch (e) {
      _toast('Authentication failed', error: true);
      setState(() => _loading = false);
    }
  }

  // ─────────────────────────────────────────
  //  NEW USER — USERNAME DIALOG
  // ─────────────────────────────────────────
  void _showUsernameDialog({String? pin}) {
    final ctrl = TextEditingController();
    String? err;

    String? validateUsername(String username) {
      if (username.isEmpty) return 'Username is required';
      final trimmed = username.trim();
      if (trimmed.length < 3) return 'Username must be at least 3 characters';
      if (trimmed.length > 20)
        return 'Username must be less than 20 characters';

      // Only allow alphabetical characters
      if (!RegExp(r'^[a-zA-Z]+$').hasMatch(trimmed)) {
        return 'Username must contain only letters (a-z)';
      }

      // Blocked patterns (admin, root, etc.)
      final lowerUsername = trimmed.toLowerCase();
      final blockedPatterns = [
        r'^admin$',
        r'^administrator$',
        r'^superadmin$',
        r'^root$',
        r'^sysadmin$',
        r'^moderator$',
        r'^mod$',
        r'^staff$',
        r'^support$',
        r'^helpdesk$',
        r'^webmaster$',
        r'^master$',
        r'^system$',
        r'^test$',
        r'^user$',
        r'^guest$',
        r'^anonymous$',
        r'^default$',
        r'^example$',
        r'^null$',
        r'^undefined$',
        r'^service$',
        r'^api$',
        r'^bot$',
        r'^cron$',
        r'^daemon$',
        r'^clash$',
        r'^fanclash$',
        r'^clashfan$',
        r'^clashadmin$',
        r'^clashmod$',
        r'^clashstaff$',
        r'.*admin.*',
        r'.*root.*',
        r'.*super.*',
        r'.*mod.*',
      ];
      for (final pattern in blockedPatterns) {
        if (RegExp(pattern, caseSensitive: false).hasMatch(lowerUsername)) {
          return 'This username is not allowed';
        }
      }

      // Prevent repeated characters only (aaaa, bbbb)
      if (RegExp(r'^(.)\1{2,}$').hasMatch(trimmed))
        return 'Username cannot have repeated characters only';

      // Prevent alphabetical sequences (abc, bcd, xyz)
      final sequential = RegExp(
        r'(?:abc|bcd|cde|def|efg|fgh|ghi|hij|ijk|jkl|klm|lmn|mno|nop|opq|pqr|qrs|rst|stu|tuv|uvw|vwx|wxy|xyz)',
      );
      if (sequential.hasMatch(trimmed.toLowerCase()))
        return 'Username cannot contain sequential patterns (abc, xyz)';

      // Prevent keyboard patterns (qwerty, asdf, zxcv)
      final keyboardPatterns = RegExp(
        r'(?:qwerty|asdfgh|zxcvbn|qwert|asdf|zxcv|qwe|asd|zxc|poiu|poi|lkj|mnb)',
      );
      if (keyboardPatterns.hasMatch(trimmed.toLowerCase()))
        return 'Username cannot contain keyboard patterns';

      return null;
    }

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          backgroundColor: SocialTheme.card,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(SocialTheme.radius)),
          title: Text('Create Username', style: SocialTheme.headline),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Choose a username for your account (letters only)',
                  style: SocialTheme.small),
              const SizedBox(height: 16),
              TextField(
                controller: ctrl,
                autofocus: true,
                style: SocialTheme.body.copyWith(fontSize: 14),
                decoration: InputDecoration(
                  hintText: 'e.g. JohnDoe',
                  hintStyle: SocialTheme.small,
                  errorText: err,
                  filled: true,
                  fillColor: SocialTheme.background,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(SocialTheme.radius - 4),
                    borderSide: BorderSide.none,
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(SocialTheme.radius - 4),
                    borderSide: BorderSide(color: SocialTheme.border),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(SocialTheme.radius - 4),
                    borderSide:
                        BorderSide(color: SocialTheme.primary, width: 1.5),
                  ),
                ),
                onChanged: (value) {
                  if (err != null) {
                    final newErr = validateUsername(value);
                    if (newErr != err) setD(() => err = newErr);
                  }
                },
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(ctx);
                _resetPhone();
              },
              child: Text('Cancel',
                  style: TextStyle(color: SocialTheme.mutedForeground)),
            ),
            ElevatedButton(
              style: SocialTheme.primaryBtn,
              onPressed: () async {
                final name = ctrl.text.trim();
                final validationError = validateUsername(name);
                if (validationError != null) {
                  setD(() => err = validationError);
                  return;
                }
                setD(() => err = null);
                Navigator.pop(ctx);
                setState(() => _loading = true);
                if (await _isUsernameTaken(name)) {
                  _toast('Username already taken', error: true);
                  setState(() => _loading = false);
                  _showUsernameDialog(pin: pin);
                  return;
                }
                await _registerUser(name, pin: pin);
              },
              child: const Text('Create Account'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _registerUser(String username, {String? pin}) async {
    try {
      final body = {'username': username, 'phone': _verifiedPhone};
      if (pin != null) body['pin'] = pin; // store PIN for fallback users

      final res = await http
          .post(
            Uri.parse('$_baseUrl/register'),
            headers: _headers(),
            body: jsonEncode(body),
          )
          .timeout(const Duration(seconds: 30));

      final respBody = _parseJson(res.body);
      if (res.statusCode == 200 || res.statusCode == 201) {
        final token = respBody?['token'] as String?;
        final user = respBody?['user'] as Map<String, dynamic>?;
        final userId = user?['id']?.toString();
        if (userId != null && token != null) {
          await _saveSession(userId, username, token, _verifiedPhone);
          await AuthService()
              .login(userId, username, token, phone: _verifiedPhone);
          _toast('Welcome to Clash, $username! 🎉');
          widget.onLoginSuccess?.call(userId, username);
          if (mounted) Navigator.pop(context);
        } else {
          _toast('Registration failed', error: true);
          setState(() => _loading = false);
        }
      } else {
        _toast(respBody?['message'] ?? 'Registration failed', error: true);
        setState(() => _loading = false);
      }
    } catch (_) {
      _toast('Connection error', error: true);
      setState(() => _loading = false);
    }
  }

  void _resetPhone() => setState(() {
        _showOtp = false;
        _showPinFallback = false;
        _isNewPinUser = false;
        _existingUserId = null;
        _verificationId = null;
        _otpCtrl.clear();
        _pinCtrl.clear();
        _pinConfirmCtrl.clear();
      });

  Future<void> _launch(String url) async {
    try {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } catch (_) {
      _toast('Could not open link', error: true);
    }
  }

  // ─────────────────────────────────────────
  //  REUSABLE INPUT
  // ─────────────────────────────────────────
  Widget _input({
    required TextEditingController ctrl,
    required String hint,
    TextInputType? keyType,
    String? Function(String?)? validator,
    TextInputAction action = TextInputAction.next,
    void Function(String)? onSubmit,
    Widget? prefix,
    Widget? suffix,
    bool obscure = false,
    GlobalKey<FormState>? formKey,
  }) {
    final field = TextFormField(
      controller: ctrl,
      keyboardType: keyType,
      textInputAction: action,
      onFieldSubmitted: onSubmit,
      validator: validator,
      obscureText: obscure,
      style: SocialTheme.body.copyWith(fontSize: 14),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: SocialTheme.small,
        prefixIcon: prefix,
        suffixIcon: suffix,
        filled: true,
        fillColor: SocialTheme.card.withValues(alpha: 0.3),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(SocialTheme.radius - 4),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(SocialTheme.radius - 4),
          borderSide: BorderSide(color: SocialTheme.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(SocialTheme.radius - 4),
          borderSide: BorderSide(color: SocialTheme.primary, width: 1.5),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(SocialTheme.radius - 4),
          borderSide: BorderSide(color: SocialTheme.destructive),
        ),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
      ),
    );
    return formKey != null ? Form(key: formKey, child: field) : field;
  }

  Widget _btn(
          {required String label,
          required VoidCallback onTap,
          IconData? icon}) =>
      SizedBox(
        width: double.infinity,
        child: ElevatedButton(
          onPressed: _loading ? null : onTap,
          style: SocialTheme.primaryBtn.copyWith(
            padding: WidgetStateProperty.all(
                const EdgeInsets.symmetric(vertical: 13)),
            shape: WidgetStateProperty.all(
              RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(SocialTheme.radius - 4)),
            ),
          ),
          child: _loading
              ? const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(
                      strokeWidth: 2, color: Colors.white),
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    if (icon != null) ...[
                      Icon(icon, size: 16),
                      const SizedBox(width: 8)
                    ],
                    Text(label,
                        style: const TextStyle(
                            fontSize: 13, fontWeight: FontWeight.w600)),
                  ],
                ),
        ),
      );

  // ─────────────────────────────────────────
  //  PHONE SCREEN
  // ─────────────────────────────────────────
  Widget _phoneScreen() => Form(
        key: _phoneFormKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 8),
            Text('Enter your phone number to continue',
                style: SocialTheme.body),
            const SizedBox(height: 20),
            Text('PHONE NUMBER', style: SocialTheme.label),
            const SizedBox(height: 6),
            Container(
              decoration: BoxDecoration(
                color: SocialTheme.card.withValues(alpha: 0.3),
                borderRadius: BorderRadius.circular(SocialTheme.radius - 4),
                border: Border.all(color: SocialTheme.border),
              ),
              child: Row(
                children: [
                  CountryCodePicker(
                    onChanged: (code) => setState(() {
                      _dialCode = code.dialCode ?? '+254';
                      _countryCode = code.code ?? 'KE';
                    }),
                    initialSelection: 'KE',
                    favorite: const [
                      '+254',
                      'US',
                      'GB',
                      'NG',
                      'GH',
                      'ZA',
                      'TZ',
                      'UG'
                    ],
                    showCountryOnly: false,
                    showOnlyCountryWhenClosed: false,
                    alignLeft: false,
                    textStyle: SocialTheme.body.copyWith(fontSize: 14),
                    dialogBackgroundColor: SocialTheme.card,
                    searchDecoration: InputDecoration(
                      hintText: 'Search country…',
                      hintStyle: SocialTheme.small,
                      prefixIcon: const Icon(Icons.search, size: 18),
                      filled: true,
                      fillColor: SocialTheme.background,
                      border: OutlineInputBorder(
                        borderRadius:
                            BorderRadius.circular(SocialTheme.radius - 4),
                        borderSide: BorderSide.none,
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 10),
                    ),
                  ),
                  Container(width: 1, height: 28, color: SocialTheme.border),
                  Expanded(
                    child: TextFormField(
                      controller: _phoneCtrl,
                      keyboardType: TextInputType.phone,
                      textInputAction: TextInputAction.done,
                      onFieldSubmitted: (_) => _sendOtp(),
                      style: SocialTheme.body.copyWith(fontSize: 14),
                      decoration: InputDecoration(
                        hintText: 'Phone number',
                        hintStyle: SocialTheme.small,
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 13),
                      ),
                      validator: (v) {
                        if (v == null || v.trim().isEmpty) return 'Required';
                        final cleaned =
                            v.trim().replaceAll(RegExp(r'[\s\-\(\)]'), '');
                        if (cleaned.length < 5) return 'Too short';
                        if (cleaned.length > 15) return 'Too long';
                        if (!RegExp(r'^[0-9+]+$').hasMatch(cleaned))
                          return 'Digits only';
                        return null;
                      },
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 6),
            ValueListenableBuilder<TextEditingValue>(
              valueListenable: _phoneCtrl,
              builder: (context, val, _) {
                if (val.text.trim().isEmpty) return const SizedBox.shrink();
                return Padding(
                  padding: const EdgeInsets.only(left: 4, bottom: 4),
                  child: Text(
                    'Will send to: ${_buildE164(val.text)}',
                    style:
                        SocialTheme.tiny.copyWith(color: SocialTheme.primary),
                  ),
                );
              },
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                SizedBox(
                  width: 18,
                  height: 18,
                  child: Checkbox(
                    value: _acceptTerms,
                    onChanged: (v) => setState(() => _acceptTerms = v ?? false),
                    activeColor: SocialTheme.primary,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(3)),
                    side: BorderSide(color: SocialTheme.border),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: RichText(
                    text: TextSpan(
                      style: SocialTheme.tiny,
                      children: [
                        const TextSpan(text: 'I agree to the '),
                        TextSpan(
                          text: 'Terms',
                          style: TextStyle(color: SocialTheme.primary),
                          recognizer: TapGestureRecognizer()
                            ..onTap = () =>
                                _launch('https://clash-privacy.netlify.app/'),
                        ),
                        const TextSpan(text: ' and '),
                        TextSpan(
                          text: 'Privacy Policy',
                          style: TextStyle(color: SocialTheme.primary),
                          recognizer: TapGestureRecognizer()
                            ..onTap = () =>
                                _launch('https://clash-privacy.netlify.app/'),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 22),
            _btn(label: 'Send OTP', onTap: _sendOtp, icon: Icons.send_outlined),
          ],
        ),
      );

  // ─────────────────────────────────────────
  //  OTP SCREEN
  // ─────────────────────────────────────────
  Widget _otpScreen() => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: SocialTheme.card.withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(SocialTheme.radius),
            ),
            child: Column(
              children: [
                Icon(Icons.sms_outlined, size: 44, color: SocialTheme.primary),
                const SizedBox(height: 10),
                Text('Verify Your Phone',
                    style: SocialTheme.headline.copyWith(fontSize: 17)),
                const SizedBox(height: 6),
                Text('OTP sent to $_verifiedPhone',
                    style: SocialTheme.small, textAlign: TextAlign.center),
              ],
            ),
          ),
          const SizedBox(height: 22),
          Form(
            key: _otpFormKey,
            child: _input(
              ctrl: _otpCtrl,
              hint: 'Enter 6-digit code',
              keyType: TextInputType.number,
              action: TextInputAction.done,
              onSubmit: (_) => _verifyOtp(),
              prefix: Icon(Icons.pin_outlined,
                  size: 18, color: SocialTheme.primary),
              validator: (v) {
                if (v == null || v.isEmpty) return 'Required';
                if (v.trim().length != 6) return 'Enter 6 digits';
                return null;
              },
            ),
          ),
          const SizedBox(height: 18),
          _btn(
              label: 'Verify & Continue',
              onTap: _verifyOtp,
              icon: Icons.verified_outlined),
          const SizedBox(height: 12),
          Center(
            child: GestureDetector(
              onTap: _resetPhone,
              child: RichText(
                text: TextSpan(
                  style: SocialTheme.tiny,
                  children: [
                    TextSpan(
                        text: 'Wrong number? ',
                        style: TextStyle(color: SocialTheme.mutedForeground)),
                    TextSpan(
                        text: 'Go back',
                        style: TextStyle(
                            color: SocialTheme.primary,
                            fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
            ),
          ),
        ],
      );

  // ─────────────────────────────────────────
  //  PIN FALLBACK SCREEN
  // ─────────────────────────────────────────
  Widget _pinScreen() => StatefulBuilder(
        builder: (ctx, setS) => Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 8),

            // ── info banner ──
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: SocialTheme.card.withValues(alpha: 0.3),
                borderRadius: BorderRadius.circular(SocialTheme.radius),
              ),
              child: Column(
                children: [
                  Icon(
                    _isNewPinUser
                        ? Icons.lock_outline
                        : Icons.lock_open_outlined,
                    size: 44,
                    color: SocialTheme.primary,
                  ),
                  const SizedBox(height: 10),
                  Text(
                    _isNewPinUser ? 'Set Your PIN' : 'Enter Your PIN',
                    style: SocialTheme.headline.copyWith(fontSize: 17),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    _isNewPinUser
                        ? 'Create a 4-digit PIN to secure your account'
                        : 'Enter your 4-digit PIN for $_verifiedPhone',
                    style: SocialTheme.small,
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),

            const SizedBox(height: 22),

            // ── PIN input ──
            _input(
              ctrl: _pinCtrl,
              hint: _isNewPinUser ? 'Create 4-digit PIN' : 'Enter your PIN',
              keyType: TextInputType.number,
              obscure: _pinObscure,
              action:
                  _isNewPinUser ? TextInputAction.next : TextInputAction.done,
              onSubmit: _isNewPinUser ? null : (_) => _submitPin(),
              prefix: Icon(Icons.pin_outlined,
                  size: 18, color: SocialTheme.primary),
              suffix: IconButton(
                icon: Icon(
                  _pinObscure
                      ? Icons.visibility_outlined
                      : Icons.visibility_off_outlined,
                  size: 18,
                  color: SocialTheme.mutedForeground,
                ),
                onPressed: () => setS(() => _pinObscure = !_pinObscure),
              ),
            ),

            // ── confirm PIN (new users only) ──
            if (_isNewPinUser) ...[
              const SizedBox(height: 12),
              _input(
                ctrl: _pinConfirmCtrl,
                hint: 'Confirm PIN',
                keyType: TextInputType.number,
                obscure: _pinConfirmObscure,
                action: TextInputAction.done,
                onSubmit: (_) => _submitPin(),
                prefix: Icon(Icons.pin_outlined,
                    size: 18, color: SocialTheme.primary),
                suffix: IconButton(
                  icon: Icon(
                    _pinConfirmObscure
                        ? Icons.visibility_outlined
                        : Icons.visibility_off_outlined,
                    size: 18,
                    color: SocialTheme.mutedForeground,
                  ),
                  onPressed: () =>
                      setS(() => _pinConfirmObscure = !_pinConfirmObscure),
                ),
              ),
            ],

            const SizedBox(height: 18),
            _btn(
              label: _isNewPinUser ? 'Set PIN & Continue' : 'Login with PIN',
              onTap: _submitPin,
              icon: _isNewPinUser
                  ? Icons.check_circle_outline
                  : Icons.login_outlined,
            ),

            const SizedBox(height: 12),
            Center(
              child: GestureDetector(
                onTap: _resetPhone,
                child: RichText(
                  text: TextSpan(
                    style: SocialTheme.tiny,
                    children: [
                      TextSpan(
                          text: 'Wrong number? ',
                          style: TextStyle(color: SocialTheme.mutedForeground)),
                      TextSpan(
                        text: 'Go back',
                        style: TextStyle(
                            color: SocialTheme.primary,
                            fontWeight: FontWeight.w600),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      );

  // ─────────────────────────────────────────
  //  ROOT BUILD
  // ─────────────────────────────────────────
  String get _title {
    if (_showPinFallback) return _isNewPinUser ? 'Set PIN' : 'Enter PIN';
    if (_showOtp) return 'Verify Phone';
    return 'Join Clash';
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: SocialTheme.darkGradient,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          Center(
            child: Container(
              margin: const EdgeInsets.only(top: 12, bottom: 8),
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: SocialTheme.border,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
            child: Row(
              children: [
                Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    color: SocialTheme.primary.withValues(alpha: 0.1),
                    shape: BoxShape.circle,
                    border: Border.all(
                        color: SocialTheme.primary.withValues(alpha: 0.3)),
                  ),
                  child: const Center(
                      child: Text('⚔️', style: TextStyle(fontSize: 16))),
                ),
                const SizedBox(width: 10),
                Text(_title, style: SocialTheme.display.copyWith(fontSize: 20)),
              ],
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              controller: widget.scrollController,
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
              child: _showPinFallback
                  ? _pinScreen()
                  : _showOtp
                      ? _otpScreen()
                      : _phoneScreen(),
            ),
          ),
        ],
      ),
    );
  }
}
