// chat_modal.dart
import 'package:flutter/material.dart';
import '../../pages/social_theme.dart';
import 'package:intl/intl.dart'; // ADD THIS IMPORT

class ChatModal extends StatefulWidget {
  final String voteId;
  final String username;
  final String homeTeam;
  final String awayTeam;
  final String selection;

  const ChatModal({
    super.key,
    required this.voteId,
    required this.username,
    required this.homeTeam,
    required this.awayTeam,
    required this.selection,
  });

  @override
  State<ChatModal> createState() => _ChatModalState();
}

class _ChatModalState extends State<ChatModal> {
  final TextEditingController _messageController = TextEditingController();
  final List<Map<String, dynamic>> _messages = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadChatMessages();
  }

  @override
  void dispose() {
    _messageController.dispose();
    super.dispose();
  }

  Future<void> _loadChatMessages() async {
    // Simulate loading
    await Future.delayed(const Duration(seconds: 1));

    // Sample messages
    _messages.addAll([
      {
        'id': '1',
        'sender': widget.username,
        'message':
            'I think ${widget.selection == 'home_team' ? widget.homeTeam : widget.awayTeam} will win!',
        'time': DateTime.now().subtract(const Duration(minutes: 30)),
        'isMe': false,
      },
      {
        'id': '2',
        'sender': 'Fan123',
        'message': 'I disagree, the other team has better form',
        'time': DateTime.now().subtract(const Duration(minutes: 25)),
        'isMe': false,
      },
      {
        'id': '3',
        'sender': 'You',
        'message': 'What are your predictions for the score?',
        'time': DateTime.now().subtract(const Duration(minutes: 15)),
        'isMe': true,
      },
    ]);

    setState(() {
      _isLoading = false;
    });
  }

  void _sendMessage() {
    if (_messageController.text.trim().isEmpty) return;

    final newMessage = {
      'id': DateTime.now().millisecondsSinceEpoch.toString(),
      'sender': 'You',
      'message': _messageController.text.trim(),
      'time': DateTime.now(),
      'isMe': true,
    };

    setState(() {
      _messages.add(newMessage);
      _messageController.clear();
    });

    // In a real app, you would send this to your backend
  }

  String _formatTime(DateTime time) {
    final now = DateTime.now();
    final difference = now.difference(time);

    if (difference.inMinutes < 1) return 'Just now';
    if (difference.inHours < 1) return '${difference.inMinutes}m ago';
    if (difference.inDays < 1) return '${difference.inHours}h ago';
    if (difference.inDays == 1) return 'Yesterday';
    if (difference.inDays < 7) return '${difference.inDays}d ago';
    return DateFormat('MMM d').format(time);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: SocialTheme.background,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: SocialTheme.text),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Chat: ${widget.username}',
          style: SocialTheme.body.copyWith(color: SocialTheme.text),
        ),
        elevation: 0,
      ),
      backgroundColor: SocialTheme.background,
      body: Column(
        children: [
          // Match info header
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: SocialTheme.surface,
              borderRadius: const BorderRadius.vertical(
                bottom: Radius.circular(12),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.homeTeam,
                      style: SocialTheme.small.copyWith(
                        color: SocialTheme.text,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Text(
                      'vs',
                      style: SocialTheme.tiny.copyWith(
                        color: SocialTheme.textSecondary,
                      ),
                    ),
                    Text(
                      widget.awayTeam,
                      style: SocialTheme.small.copyWith(
                        color: SocialTheme.text,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: widget.selection == 'home_team'
                        ? SocialTheme.primary
                        : const Color(0xFF2563EB),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    widget.selection == 'home_team'
                        ? 'Home'
                        : widget.selection == 'away_team'
                        ? 'Away'
                        : 'Draw',
                    style: SocialTheme.tiny.copyWith(color: Colors.white),
                  ),
                ),
              ],
            ),
          ),

          // Messages list
          Expanded(
            child: _isLoading
                ? Center(
                    child: CircularProgressIndicator(
                      color: SocialTheme.primary,
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.all(12),
                    reverse: true,
                    itemCount: _messages.length,
                    itemBuilder: (context, index) {
                      final message = _messages[_messages.length - 1 - index];
                      final isMe = message['isMe'] as bool;

                      return Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: Row(
                          mainAxisAlignment: isMe
                              ? MainAxisAlignment.end
                              : MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            if (!isMe)
                              CircleAvatar(
                                radius: 16,
                                backgroundColor: SocialTheme.primary.withValues(
                                  alpha: 0.2,
                                ),
                                child: Icon(
                                  Icons.person,
                                  size: 16,
                                  color: SocialTheme.primary,
                                ),
                              ),
                            if (!isMe) const SizedBox(width: 8),
                            Flexible(
                              child: Container(
                                constraints: BoxConstraints(
                                  maxWidth:
                                      MediaQuery.of(context).size.width * 0.7,
                                ),
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: isMe
                                      ? SocialTheme.primary
                                      : SocialTheme.surface,
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                    color: SocialTheme.surface,
                                    width: 1,
                                  ),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    if (!isMe)
                                      Text(
                                        message['sender'],
                                        style: SocialTheme.tiny.copyWith(
                                          color: SocialTheme.primary,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    if (!isMe) const SizedBox(height: 4),
                                    Text(
                                      message['message'],
                                      style: SocialTheme.small.copyWith(
                                        color: isMe
                                            ? Colors.white
                                            : SocialTheme.text,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      _formatTime(message['time']),
                                      style: SocialTheme.tiny.copyWith(
                                        color: isMe
                                            ? Colors.white.withValues(
                                                alpha: 0.8,
                                              )
                                            : SocialTheme.textSecondary,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            if (isMe) const SizedBox(width: 8),
                            if (isMe)
                              CircleAvatar(
                                radius: 16,
                                backgroundColor: SocialTheme.primary,
                                child: Icon(
                                  Icons.person,
                                  size: 16,
                                  color: Colors.white,
                                ),
                              ),
                          ],
                        ),
                      );
                    },
                  ),
          ),

          // Message input
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: SocialTheme.surface,
              border: Border(
                top: BorderSide(color: SocialTheme.surface, width: 1),
              ),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      color: SocialTheme.background,
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: TextField(
                      controller: _messageController,
                      style: SocialTheme.small.copyWith(
                        color: SocialTheme.text,
                      ),
                      decoration: InputDecoration(
                        hintText: 'Type a message...',
                        hintStyle: SocialTheme.small.copyWith(
                          color: SocialTheme.textSecondary,
                        ),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 12,
                        ),
                        suffixIcon: IconButton(
                          icon: Icon(
                            Icons.send,
                            color: SocialTheme.primary,
                            size: 20,
                          ),
                          onPressed: _sendMessage,
                        ),
                      ),
                      onSubmitted: (_) => _sendMessage(),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
