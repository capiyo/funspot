import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../../models/post_models.dart';
import '../../models/chat_message.dart';
import '../../pages/social_theme.dart';
import '../../services/notification_service.dart'; // Import your notification service

class ChatModal extends StatefulWidget {
  final bool isOpen;
  final VoidCallback onClose;
  final Post post;
  final String currentUserId;
  final String currentUserName;
  final String? authToken;
  final String? fcmToken; // Add FCM token

  const ChatModal({
    super.key,
    required this.isOpen,
    required this.onClose,
    required this.post,
    required this.currentUserId,
    required this.currentUserName,
    this.authToken,
    this.fcmToken, // Add this
  });

  @override
  State<ChatModal> createState() => _ChatModalState();
}

class _ChatModalState extends State<ChatModal> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final List<ChatMessage> _messages = [];
  bool _isLoading = false;
  bool _isSending = false;
  bool _isDisposed = false;
  String? _authToken;
  bool _isLoadingToken = true;

  // Your API URL
  static const String _baseUrl = 'https://clash-api-m5mr.onrender.com/api';

  @override
  void initState() {
    super.initState();
    _initializeChat();
    _messageController.addListener(_updateSendButtonState);
  }

  Future<void> _initializeChat() async {
    await _loadAuthToken();
    if (widget.isOpen && mounted) {
      _fetchMessages();
    }
  }

  Future<void> _loadAuthToken() async {
    try {
      if (widget.authToken != null && widget.authToken!.isNotEmpty) {
        print('✅ Using auth token passed from parent');
        _authToken = widget.authToken;
      } else {
        print('📱 Loading auth token from SharedPreferences');
        final prefs = await SharedPreferences.getInstance();
        _authToken = prefs.getString('usertoken');

        if (_authToken != null && _authToken!.isNotEmpty) {
          print('✅ Successfully loaded token from SharedPreferences');
        } else {
          print('❌ No auth token found in SharedPreferences');
        }
      }
    } catch (e) {
      print('❌ Error loading auth token: $e');
      _authToken = null;
    } finally {
      if (mounted) {
        setState(() {
          _isLoadingToken = false;
        });
      }
    }
  }

  void _updateSendButtonState() {
    if (!_isDisposed && mounted) {
      setState(() {});
    }
  }

  @override
  void didUpdateWidget(covariant ChatModal oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isOpen && !oldWidget.isOpen) {
      _fetchMessages();
    }
  }

  void _safeSetState(VoidCallback fn) {
    if (!_isDisposed && mounted) {
      setState(fn);
    }
  }

  // ========== API METHODS ==========

  Map<String, String> _getHeaders() {
    final headers = {'Content-Type': 'application/json'};

    if (_authToken != null && _authToken!.isNotEmpty) {
      headers['Authorization'] = 'Bearer $_authToken';
      print(
        '🔑 Added auth header: Bearer ${_authToken!.substring(0, min(20, _authToken!.length))}...',
      );
    } else {
      print('⚠️ No auth token available for headers');
    }

    return headers;
  }

  Future<void> _fetchMessages() async {
    if (_isLoading || _isLoadingToken) return;

    _safeSetState(() => _isLoading = true);

    try {
      print('=' * 50);
      print('🔍 FETCHING MESSAGES');
      print('=' * 50);
      print('📌 Post ID: ${widget.post.id}');
      print('👤 Current User ID: ${widget.currentUserId}');

      final url = '$_baseUrl/chats/chat/${widget.post.id}/messages';
      print('🌐 URL: $url');

      final headers = _getHeaders();
      final response = await http.get(Uri.parse(url), headers: headers);

      print('📡 Response Status: ${response.statusCode}');

      if (response.statusCode == 200) {
        final dynamic data = json.decode(response.body);

        List<ChatMessage> messages = [];

        void extractMessages(dynamic responseData) {
          if (responseData is Map) {
            if (responseData.containsKey('data') &&
                responseData['data'] is Map) {
              final apiData = responseData['data'] as Map;
              if (apiData.containsKey('messages') &&
                  apiData['messages'] is List) {
                final messageList = apiData['messages'] as List;
                for (var msgJson in messageList) {
                  try {
                    final msg = ChatMessage.fromJson(msgJson);
                    messages.add(msg);
                  } catch (e) {
                    print('❌ Error parsing message: $e');
                  }
                }
              }
            } else if (responseData.containsKey('messages') &&
                responseData['messages'] is List) {
              final messageList = responseData['messages'] as List;
              for (var msgJson in messageList) {
                try {
                  final msg = ChatMessage.fromJson(msgJson);
                  messages.add(msg);
                } catch (e) {
                  print('❌ Error parsing message: $e');
                }
              }
            }
          } else if (responseData is List) {
            for (var msgJson in responseData) {
              try {
                final msg = ChatMessage.fromJson(msgJson);
                messages.add(msg);
              } catch (e) {
                print('❌ Error parsing message: $e');
              }
            }
          }
        }

        extractMessages(data);

        final relevantMessages = messages.where((msg) {
          return msg.senderId == widget.currentUserId ||
              msg.receiverId == widget.currentUserId;
        }).toList();

        relevantMessages.sort((a, b) => a.createdAt.compareTo(b.createdAt));

        _safeSetState(() {
          _messages.clear();
          _messages.addAll(relevantMessages);
        });

        print('✅ Loaded ${_messages.length} relevant messages');

        _scrollToBottom();
        _markMessagesAsSeen();
      } else {
        print('❌ Failed to load messages. Status: ${response.statusCode}');
        _showError('Failed to load messages (${response.statusCode})');
      }
    } catch (e, stackTrace) {
      print('❌ Error fetching messages: $e');
      print('📋 Stack trace: $stackTrace');
      _showError('Network error: $e');
    } finally {
      _safeSetState(() => _isLoading = false);
    }
  }

  Future<void> _sendMessage() async {
    final message = _messageController.text.trim();
    if (message.isEmpty || _isSending) return;

    if (_authToken == null || _authToken!.isEmpty) {
      print('❌ No auth token available! Cannot send message.');
      _showError('Please log in to send messages');
      return;
    }

    print('=' * 50);
    print('📤 SENDING MESSAGE');
    print('=' * 50);
    print('📝 Message: "$message"');
    print('👤 Sender ID: ${widget.currentUserId}');
    print('👤 Sender Name: ${widget.currentUserName}');
    print('👥 Receiver ID: ${widget.post.userId}');
    print('👥 Receiver Name: ${widget.post.userName}');

    final tempMessage = ChatMessage(
      id: 'temp_${DateTime.now().millisecondsSinceEpoch}',
      postId: widget.post.id ?? '',
      senderId: widget.currentUserId,
      receiverId: widget.post.userId ?? '',
      senderName: widget.currentUserName,
      receiverName: widget.post.userName ?? 'User',
      message: message,
      createdAt: DateTime.now(),
      seen: false,
    );

    _safeSetState(() {
      _messages.add(tempMessage);
      _isSending = true;
    });

    _messageController.clear();
    _scrollToBottom();

    try {
      final url = '$_baseUrl/chats/chat/${widget.post.id}/messages';
      final headers = _getHeaders();
      final body = json.encode({
        'sender_id': widget.currentUserId,
        'receiver_id': widget.post.userId ?? '',
        'message': message,
        'sender_name': widget.currentUserName,
        'receiver_name': widget.post.userName ?? 'User',
      });

      print('🌐 URL: $url');
      print('📦 Headers: $headers');
      print('📦 Body: $body');

      final response = await http.post(
        Uri.parse(url),
        headers: headers,
        body: body,
      );

      print('📡 Response Status: ${response.statusCode}');

      if (response.statusCode == 201 || response.statusCode == 200) {
        final data = json.decode(response.body);
        print('✅ Message sent successfully');

        ChatMessage savedMessage;
        if (data is Map && data.containsKey('data')) {
          savedMessage = ChatMessage.fromJson(data['data']);
        } else {
          savedMessage = ChatMessage.fromJson(data);
        }

        // Send push notification to receiver
        await _sendPushNotification(savedMessage);

        _safeSetState(() {
          final index = _messages.indexWhere((m) => m.id == tempMessage.id);
          if (index != -1) {
            _messages[index] = savedMessage;
          }
        });
      } else if (response.statusCode == 401) {
        print('❌ Unauthorized! Token may be expired');
        _showError('Session expired. Please log in again.');
        _safeSetState(() {
          _messages.removeWhere((m) => m.id == tempMessage.id);
        });
      } else {
        print('❌ Failed to send message. Status: ${response.statusCode}');
        _safeSetState(() {
          _messages.removeWhere((m) => m.id == tempMessage.id);
        });
        _showError('Failed to send message (${response.statusCode})');
      }
    } catch (e, stackTrace) {
      print('❌ Error sending message: $e');
      print('📋 Stack trace: $stackTrace');
      _safeSetState(() {
        _messages.removeWhere((m) => m.id == tempMessage.id);
      });
      _showError('Network error: $e');
    } finally {
      _safeSetState(() => _isSending = false);
    }
  }

  // NEW: Send push notification when message is sent
  Future<void> _sendPushNotification(ChatMessage message) async {
    try {
      print('📱 Sending push notification to receiver: ${message.receiverId}');

      final notificationData = {
        'post_id': message.postId,
        'message_id': message.id,
        'sender_id': message.senderId,
        'sender_name': message.senderName,
        'receiver_id': message.receiverId,
        'message_preview': message.message.length > 50
            ? '${message.message.substring(0, 50)}...'
            : message.message,
        'type': 'chat_message',
        'timestamp': DateTime.now().toIso8601String(),
      };

      final success = await NotificationService.sendNotification(
        userId: message.receiverId,
        notificationType: 'chat_message',
        title: 'New message from ${message.senderName}',
        body: message.message.length > 100
            ? '${message.message.substring(0, 100)}...'
            : message.message,
        data: notificationData,
      );

      if (success) {
        print('✅ Push notification sent successfully');
      } else {
        print('⚠️ Push notification may not have been delivered');
      }
    } catch (e) {
      print('❌ Error sending push notification: $e');
      // Don't show error to user - message was already sent successfully
    }
  }

  Future<void> _markMessagesAsSeen() async {
    if (_authToken == null || _authToken!.isEmpty) return;

    try {
      final url = '$_baseUrl/chats/chat/messages/mark-seen';
      final headers = _getHeaders();
      final body = json.encode({
        'post_id': widget.post.id ?? '',
        'user_id': widget.currentUserId,
      });

      await http.post(Uri.parse(url), headers: headers, body: body);
    } catch (e) {
      print('Error marking as seen: $e');
    }
  }

  // ========== HELPER METHODS ==========

  void _scrollToBottom() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _showError(String message) {
    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: SocialTheme.small),
        backgroundColor: Colors.red,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }

  void _showSuccess(String message) {
    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: SocialTheme.small),
        backgroundColor: Colors.green,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  // ========== UI BUILDING METHODS ==========

  Widget _buildMessageBubble(ChatMessage message) {
    final isCurrentUser = message.senderId == widget.currentUserId;

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment:
            isCurrentUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          if (!isCurrentUser) ...[
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: SocialTheme.surface,
                shape: BoxShape.circle,
              ),
              child: Center(
                child: Text(
                  message.senderName.isNotEmpty
                      ? message.senderName[0].toUpperCase()
                      : '?',
                  style: SocialTheme.small.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            Flexible(
              child: Container(
                constraints: BoxConstraints(
                  maxWidth: MediaQuery.of(context).size.width * 0.7,
                ),
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 10,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFFF5F5F5),
                  borderRadius: const BorderRadius.only(
                    topRight: Radius.circular(16),
                    bottomRight: Radius.circular(16),
                    bottomLeft: Radius.circular(16),
                    topLeft: Radius.circular(4),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (message.senderName.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 2),
                        child: Text(
                          message.senderName,
                          style: SocialTheme.tiny.copyWith(
                            color: SocialTheme.primary,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    Text(
                      message.message,
                      style: SocialTheme.body.copyWith(color: Colors.black87),
                    ),
                    const SizedBox(height: 2),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          message.formattedTime,
                          style: SocialTheme.tiny.copyWith(
                            color: Colors.grey[600],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 40),
          ],
          if (isCurrentUser) ...[
            const SizedBox(width: 40),
            Flexible(
              child: Container(
                constraints: BoxConstraints(
                  maxWidth: MediaQuery.of(context).size.width * 0.7,
                ),
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 10,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFFE8F5E9),
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(16),
                    bottomLeft: Radius.circular(16),
                    bottomRight: Radius.circular(16),
                    topRight: Radius.circular(4),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      message.message,
                      style: SocialTheme.body.copyWith(color: Colors.black87),
                    ),
                    const SizedBox(height: 2),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(
                          message.formattedTime,
                          style: SocialTheme.tiny.copyWith(
                            color: Colors.grey[600],
                          ),
                        ),
                        const SizedBox(width: 4),
                        Icon(
                          message.seen ? Icons.done_all : Icons.done,
                          size: 12,
                          color: Colors.grey[600],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 8),
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: const Color(0xFFE8F5E9),
                shape: BoxShape.circle,
              ),
              child: Center(
                child: Text(
                  widget.currentUserName.isNotEmpty
                      ? widget.currentUserName[0].toUpperCase()
                      : 'Y',
                  style: SocialTheme.small.copyWith(
                    color: Colors.black87,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildInputField() {
    final hasText = _messageController.text.trim().isNotEmpty;
    final isLoggedIn = _authToken != null && _authToken!.isNotEmpty;

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: SocialTheme.background,
        border: Border(top: BorderSide(color: SocialTheme.surface)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: SocialTheme.surface,
                borderRadius: BorderRadius.circular(24),
              ),
              child: Row(
                children: [
                  const SizedBox(width: 16),
                  Expanded(
                    child: TextField(
                      controller: _messageController,
                      enabled: isLoggedIn,
                      style: SocialTheme.body,
                      decoration: InputDecoration(
                        hintText: isLoggedIn
                            ? 'Type your message...'
                            : 'Please log in to chat',
                        hintStyle: SocialTheme.small.copyWith(
                          color: SocialTheme.textSecondary,
                        ),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(
                          vertical: 12,
                        ),
                      ),
                      maxLines: 5,
                      minLines: 1,
                      onChanged: (text) {
                        setState(() {});
                      },
                      onSubmitted: (_) {
                        if (hasText && !_isSending && isLoggedIn) {
                          _sendMessage();
                        }
                      },
                    ),
                  ),
                  if (hasText && isLoggedIn)
                    IconButton(
                      icon: Icon(
                        Icons.clear,
                        size: 18,
                        color: SocialTheme.textSecondary,
                      ),
                      onPressed: () {
                        _messageController.clear();
                        setState(() {});
                      },
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: (hasText && !_isSending && isLoggedIn) ? _sendMessage : null,
            child: Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: hasText && !_isSending && isLoggedIn
                    ? SocialTheme.primary
                    : SocialTheme.surface.withValues(alpha: 0.5),
                shape: BoxShape.circle,
              ),
              child: Center(
                child: _isSending
                    ? SizedBox(
                        width: 24,
                        height: 24,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor: AlwaysStoppedAnimation<Color>(
                            SocialTheme.text,
                          ),
                        ),
                      )
                    : Icon(
                        Icons.send,
                        color: hasText && isLoggedIn
                            ? Colors.white
                            : SocialTheme.textSecondary,
                        size: 20,
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: SocialTheme.background,
        border: Border(bottom: BorderSide(color: SocialTheme.surface)),
      ),
      child: Row(
        children: [
          IconButton(
            icon: Icon(Icons.close, color: SocialTheme.text),
            onPressed: widget.onClose,
          ),
          const SizedBox(width: 12),
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: SocialTheme.surface,
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                (widget.post.userName?.isNotEmpty ?? false)
                    ? widget.post.userName![0].toUpperCase()
                    : 'U',
                style: SocialTheme.body.copyWith(fontWeight: FontWeight.bold),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Chat with ${widget.post.userName ?? "User"}',
                  style: SocialTheme.teamName.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 2),
                if (widget.post.caption != null &&
                    widget.post.caption!.isNotEmpty)
                  Text(
                    'Post: ${widget.post.caption!}',
                    style: SocialTheme.tiny,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
              ],
            ),
          ),
          if (_isLoadingToken)
            Padding(
              padding: EdgeInsets.only(right: 8.0),
              child: SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: SocialTheme.primary,
                ),
              ),
            )
          else if (_isLoading)
            Padding(
              padding: EdgeInsets.only(right: 8.0),
              child: SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: SocialTheme.primary,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    final isLoggedIn = _authToken != null && _authToken!.isNotEmpty;

    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              color: SocialTheme.surface,
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Icon(
                Icons.chat_bubble_outline,
                color: SocialTheme.textSecondary,
                size: 40,
              ),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            isLoggedIn ? 'No messages yet' : 'Not logged in',
            style: SocialTheme.headline,
          ),
          const SizedBox(height: 8),
          Text(
            isLoggedIn
                ? 'Start the conversation!'
                : 'Please log in to view messages',
            style: SocialTheme.body.copyWith(color: SocialTheme.textSecondary),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.isOpen) return const SizedBox.shrink();

    return Material(
      color: Colors.transparent,
      child: DraggableScrollableSheet(
        initialChildSize: 0.8,
        minChildSize: 0.5,
        maxChildSize: 0.95,
        expand: false,
        builder: (context, scrollController) {
          return Container(
            decoration: BoxDecoration(
              color: SocialTheme.background,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Column(
              children: [
                Container(
                  width: 40,
                  height: 4,
                  margin: const EdgeInsets.only(top: 12, bottom: 8),
                  decoration: BoxDecoration(
                    color: SocialTheme.surface,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                _buildHeader(),
                Expanded(
                  child: _isLoadingToken
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              CircularProgressIndicator(
                                color: SocialTheme.primary,
                              ),
                              const SizedBox(height: 16),
                              Text(
                                'Loading...',
                                style: SocialTheme.body.copyWith(
                                  color: SocialTheme.textSecondary,
                                ),
                              ),
                            ],
                          ),
                        )
                      : _messages.isEmpty && !_isLoading
                          ? _buildEmptyState()
                          : ListView.builder(
                              controller: _scrollController,
                              padding: const EdgeInsets.symmetric(vertical: 8),
                              itemCount: _messages.length,
                              itemBuilder: (context, index) {
                                return _buildMessageBubble(_messages[index]);
                              },
                            ),
                ),
                _buildInputField(),
              ],
            ),
          );
        },
      ),
    );
  }

  @override
  void dispose() {
    _isDisposed = true;
    _messageController.removeListener(_updateSendButtonState);
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }
}

int min(int a, int b) => a < b ? a : b;
