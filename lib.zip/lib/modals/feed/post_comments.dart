import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../../models/post_models.dart';
import '../../pages/social_theme.dart';
import '../../services/notification_service.dart';

class PostComments extends StatefulWidget {
  final bool isOpen;
  final VoidCallback onClose;
  final Post post;
  final String currentUserId;
  final String currentUsername;
  final String? authToken;
  final String? fcmToken;

  const PostComments({
    super.key,
    required this.isOpen,
    required this.onClose,
    required this.post,
    required this.currentUserId,
    required this.currentUsername,
    this.authToken,
    this.fcmToken,
  });

  @override
  State<PostComments> createState() => _PostCommentsState();
}

class _PostCommentsState extends State<PostComments> {
  final TextEditingController _commentController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final FocusNode _commentFocusNode = FocusNode();

  bool _isSubmitting = false;
  bool _isLoading = false;
  String _error = '';
  bool _showError = false;
  bool _isDisposed = false;

  final String _apiBaseUrl = 'https://clash-api-m5mr.onrender.com/api';
  final List<Map<String, dynamic>> _comments = [];

  @override
  void initState() {
    super.initState();
    print('🚀 PostComments initState - isOpen: ${widget.isOpen}');
    print(
      '👤 Current User: ${widget.currentUsername} (${widget.currentUserId})',
    );
    print('📌 Post ID: ${widget.post.id}');
    print('🔑 Auth Token Present: ${widget.authToken != null}');

    _commentFocusNode.addListener(_handleFocusChange);

    if (widget.isOpen) {
      _loadComments();
    }
  }

  @override
  void didUpdateWidget(covariant PostComments oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isOpen && !oldWidget.isOpen) {
      print('🔄 Modal opened, loading comments...');
      _loadComments();
    }
  }

  @override
  void dispose() {
    print('🧹 Disposing PostComments');
    _isDisposed = true;
    _commentController.dispose();
    _scrollController.dispose();
    _commentFocusNode.dispose();
    super.dispose();
  }

  void _handleFocusChange() {
    if (_commentFocusNode.hasFocus) {
      print('🔍 Comment field focused');
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_scrollController.hasClients) {
          _scrollController.animateTo(
            _scrollController.position.maxScrollExtent,
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeOut,
          );
        }
      });
    }
  }

  void _safeSetState(VoidCallback fn) {
    if (!_isDisposed && mounted) {
      setState(fn);
    }
  }

  Map<String, String> _getHeaders() {
    final headers = {'Content-Type': 'application/json'};
    if (widget.authToken != null && widget.authToken!.isNotEmpty) {
      headers['Authorization'] = 'Bearer ${widget.authToken}';
      print('🔑 Auth header added');
    } else {
      print('⚠️ No auth token available');
    }
    return headers;
  }

  Map<String, dynamic> _createCommentRequest(String comment) {
    return {
      'user_id': widget.currentUserId,
      'user_name': widget.currentUsername,
      'comment': comment,
    };
  }

  Map<String, dynamic> _parseCommentFromJson(Map<String, dynamic> json) {
    return {
      'id': json['id']?.toString() ?? '',
      'post_id': json['post_id']?.toString() ?? '',
      'user_id': json['user_id']?.toString() ?? '',
      'user_name': json['user_name']?.toString() ?? 'Anonymous',
      'comment': json['comment']?.toString() ?? '',
      'likes_count': json['likes_count'] ?? 0,
      'liked_by': List<String>.from(json['liked_by'] ?? []),
      'created_at':
          json['created_at']?.toString() ?? DateTime.now().toIso8601String(),
      'updated_at': json['updated_at']?.toString() ?? '',
      'last_modified': json['last_modified']?.toString() ?? '',
      'timestamp': json['timestamp'] ?? 0,
    };
  }

  Future<void> _loadComments() async {
    if (!mounted || _isLoading) return;

    print('=' * 50);
    print('📥 LOADING COMMENTS');
    print('=' * 50);

    _safeSetState(() {
      _isLoading = true;
      _error = '';
      _showError = false;
    });

    try {
      final url = '$_apiBaseUrl/posts/${widget.post.id}/comments';
      final headers = _getHeaders();

      print('🌐 URL: $url');
      print('📋 Headers: $headers');

      final response = await http
          .get(Uri.parse(url), headers: headers)
          .timeout(const Duration(seconds: 10));

      print('📡 Response Status: ${response.statusCode}');

      if (response.statusCode == 200) {
        final Map<String, dynamic> jsonResponse = jsonDecode(response.body);
        final List<Map<String, dynamic>> newComments = [];

        if (jsonResponse.containsKey('success') &&
            jsonResponse['success'] == true) {
          print('✅ API returned success: true');

          if (jsonResponse.containsKey('comments') &&
              jsonResponse['comments'] is List) {
            final List<dynamic> commentsList = jsonResponse['comments'];
            print('📋 Found ${commentsList.length} comments in response');

            for (var comment in commentsList) {
              if (comment is Map<String, dynamic>) {
                final parsedComment = _parseCommentFromJson(comment);
                newComments.add(parsedComment);
              }
            }
          }
        }

        print('✅ Successfully processed ${newComments.length} comments');

        _safeSetState(() {
          _comments.clear();
          _comments.addAll(newComments);
        });

        if (newComments.isEmpty) {
          print('📭 No comments to display');
        } else {
          print('📊 Total comments in state: ${_comments.length}');
          print('🎉 Comments loaded successfully!');
        }
      } else {
        print('❌ Failed to load comments. Status: ${response.statusCode}');
        String errorMessage = 'Failed to load comments';

        try {
          final errorJson = jsonDecode(response.body);
          if (errorJson is Map && errorJson.containsKey('message')) {
            errorMessage = errorJson['message'];
          } else if (errorJson is Map && errorJson.containsKey('error')) {
            errorMessage = errorJson['error'];
          }
        } catch (e) {
          print('Could not parse error response: $e');
        }

        throw Exception(errorMessage);
      }
    } on TimeoutException catch (e) {
      print('❌ Request timeout: $e');
      _safeSetState(() {
        _error = 'Request timed out. Please check your connection.';
        _showError = true;
      });
    } catch (e, stackTrace) {
      print('❌ Error loading comments: $e');
      print('📋 Stack trace: $stackTrace');

      _safeSetState(() {
        _error = e.toString().replaceAll('Exception: ', '');
        if (_error.isEmpty || _error == 'null') {
          _error = 'Failed to load comments';
        }
        _showError = true;
      });
    } finally {
      _safeSetState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _sendPushNotification(Map<String, dynamic> comment) async {
    try {
      if (widget.post.userId == widget.currentUserId) {
        print('📱 User commented on own post - skipping notification');
        return;
      }

      print(
        '📱 Sending push notification to post owner: ${widget.post.userId}',
      );

      final commentText = comment['comment'] as String? ?? '';

      final notificationData = {
        'post_id': widget.post.id ?? '',
        'post_caption': widget.post.caption ?? '',
        'comment_id': comment['id'] ?? '',
        'comment_preview': commentText.length > 50
            ? '${commentText.substring(0, 50)}...'
            : commentText,
        'commenter_id': widget.currentUserId,
        'commenter_name': widget.currentUsername,
        'post_owner_id': widget.post.userId ?? '',
        'type': 'post_comment',
        'timestamp': DateTime.now().toIso8601String(),
      };

      final success = await NotificationService.sendNotification(
        userId: widget.post.userId ?? '',
        notificationType: 'post_comment',
        title: '${widget.currentUsername} commented on your post',
        body: commentText.length > 100
            ? '${commentText.substring(0, 100)}...'
            : commentText,
        data: notificationData,
      );

      if (success) {
        print('✅ Push notification sent successfully to post owner');
      } else {
        print('⚠️ Push notification may not have been delivered');
      }
    } catch (e) {
      print('❌ Error sending push notification: $e');
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  String _formatDateTime(String? isoString) {
    if (isoString == null || isoString.isEmpty) return 'Just now';

    try {
      final date = DateTime.parse(isoString).toLocal();
      final now = DateTime.now();
      final difference = now.difference(date);

      if (difference.inMinutes < 1) return 'Just now';
      if (difference.inMinutes < 60) return '${difference.inMinutes}m';
      if (difference.inHours < 24) return '${difference.inHours}h';
      if (difference.inDays < 7) return '${difference.inDays}d';
      if (difference.inDays < 30) return '${difference.inDays} days ago';
      if (difference.inDays < 365) {
        return '${(difference.inDays / 30).floor()}mo';
      }
      return '${date.month}/${date.year}';
    } catch (e) {
      print('Error parsing date: $e');
      return isoString;
    }
  }

  String _getInitials(String name) =>
      name.isNotEmpty ? name[0].toUpperCase() : 'U';

  // ========== BUILD COMMENT BUBBLE ==========
  Widget _buildCommentItem(int index) {
    final comment = _comments[index];
    final username = comment['user_name']?.toString() ?? 'Anonymous';
    final userId = comment['user_id']?.toString() ?? '';
    final content = comment['comment']?.toString() ?? '';
    final timestamp = comment['created_at']?.toString() ?? '';
    final isMe = userId == widget.currentUserId;

    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Row(
        mainAxisAlignment:
            isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!isMe) ...[
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: SocialTheme.primary.withValues(alpha: 0.1),
                shape: BoxShape.circle,
                border: Border.all(
                  color: SocialTheme.primary.withValues(alpha: 0.4),
                  width: 1,
                ),
              ),
              child: Center(
                child: Text(
                  _getInitials(username),
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: SocialTheme.primary,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: Column(
              crossAxisAlignment:
                  isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(bottom: 3, left: 4, right: 4),
                  child: Text(
                    isMe ? '' : username,
                    style: const TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 10,
                  ),
                  decoration: BoxDecoration(
                    color: isMe
                        ? SocialTheme.primary.withValues(alpha: 0.1)
                        : SocialTheme.surface,
                    borderRadius: BorderRadius.only(
                      topLeft: const Radius.circular(16),
                      topRight: const Radius.circular(16),
                      bottomLeft: Radius.circular(isMe ? 16 : 4),
                      bottomRight: Radius.circular(isMe ? 4 : 16),
                    ),
                  ),
                  child: Text(
                    content,
                    style: SocialTheme.body.copyWith(fontSize: 13),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 3, left: 6, right: 6),
                  child: Text(
                    _formatDateTime(timestamp),
                    style: TextStyle(
                      fontSize: 9,
                      color: SocialTheme.textSecondary,
                    ),
                  ),
                ),
              ],
            ),
          ),
          if (isMe) ...[
            const SizedBox(width: 8),
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: SocialTheme.primary,
                shape: BoxShape.circle,
              ),
              child: Center(
                child: Text(
                  _getInitials(widget.currentUsername),
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  // ========== DRAG HANDLE ==========
  Widget _buildHandle() => Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Center(
          child: Container(
            width: 36,
            height: 4,
            decoration: BoxDecoration(
              color: SocialTheme.border,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
        ),
      );

  // ========== HEADER ==========
  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(color: SocialTheme.divider, width: 0.5),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: SocialTheme.primary.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Center(child: Icon(Icons.comment, size: 18)),
              ),
              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Comments',
                    style: SocialTheme.body.copyWith(
                      fontWeight: FontWeight.w600,
                      fontSize: 15,
                    ),
                  ),
                  Text(
                    '${_comments.length} responses',
                    style: SocialTheme.small.copyWith(
                      color: SocialTheme.textSecondary,
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ],
          ),
          GestureDetector(
            onTap: widget.onClose,
            child: Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: SocialTheme.surface,
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.close,
                size: 18,
                color: SocialTheme.textSecondary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.chat_bubble_outline_rounded,
            size: 36,
            color: SocialTheme.border,
          ),
          const SizedBox(height: 10),
          Text('No comments yet', style: SocialTheme.small),
          const SizedBox(height: 4),
          Text(
            'Be the first to comment!',
            style: TextStyle(fontSize: 11, color: SocialTheme.textSecondary),
          ),
        ],
      ),
    );
  }

  // ========== INPUT FIELD (FIXED - LIKE COMRADE VOTING MODAL) ==========
  Widget _buildInputField({required double bottomPadding}) {
    final hasText = _commentController.text.trim().isNotEmpty;

    return Container(
      padding: EdgeInsets.fromLTRB(12, 10, 12, bottomPadding),
      decoration: BoxDecoration(
        color: SocialTheme.card,
        border: Border(top: BorderSide(color: SocialTheme.divider, width: 0.5)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: SocialTheme.primary,
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                _getInitials(widget.currentUsername),
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: ConstrainedBox(
              constraints: const BoxConstraints(minHeight: 42, maxHeight: 120),
              child: TextField(
                controller: _commentController,
                focusNode: _commentFocusNode,
                maxLines: null,
                textInputAction: TextInputAction.send,
                enabled: !_isSubmitting,
                style: SocialTheme.body.copyWith(fontSize: 13),
                decoration: InputDecoration(
                  hintText: 'Write a comment…',
                  hintStyle: SocialTheme.small.copyWith(
                    fontStyle: FontStyle.normal,
                  ),
                  filled: true,
                  fillColor: SocialTheme.background,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(24),
                    borderSide: BorderSide.none,
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(24),
                    borderSide: BorderSide.none,
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(24),
                    borderSide: BorderSide(
                      color: SocialTheme.primary,
                      width: 1.5,
                    ),
                  ),
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 10,
                  ),
                  isDense: true,
                  suffixIcon: Padding(
                    padding: const EdgeInsets.only(right: 4),
                    child: _isSubmitting
                        ? const SizedBox(
                            width: 36,
                            height: 36,
                            child: Padding(
                              padding: EdgeInsets.all(10),
                              child: CircularProgressIndicator(strokeWidth: 2),
                            ),
                          )
                        : ValueListenableBuilder<TextEditingValue>(
                            valueListenable: _commentController,
                            builder: (context, value, _) {
                              final hasTextLocal = value.text.trim().isNotEmpty;
                              return IconButton(
                                icon: Icon(
                                  Icons.send_rounded,
                                  size: 20,
                                  color: hasTextLocal
                                      ? SocialTheme.primary
                                      : SocialTheme.border,
                                ),
                                onPressed: hasTextLocal ? _createComment : null,
                                padding: EdgeInsets.zero,
                                constraints: const BoxConstraints(
                                  minWidth: 36,
                                  minHeight: 36,
                                ),
                              );
                            },
                          ),
                  ),
                ),
                onChanged: (_) => _safeSetState(() {}),
                onSubmitted: (_) => _createComment(),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _createComment() async {
    final content = _commentController.text.trim();

    print('=' * 50);
    print('📝 CREATE COMMENT ATTEMPT');
    print('=' * 50);
    print('📝 Content: "$content"');

    if (content.isEmpty) {
      print('❌ Cannot submit empty comment');
      _safeSetState(() {
        _error = 'Comment cannot be empty';
        _showError = true;
      });
      Future.delayed(const Duration(seconds: 2), () {
        _safeSetState(() => _showError = false);
      });
      return;
    }

    if (_isSubmitting) return;

    _safeSetState(() {
      _isSubmitting = true;
      _error = '';
      _showError = false;
    });

    try {
      final url = '$_apiBaseUrl/posts/${widget.post.id}/comments';
      final headers = _getHeaders();
      final requestBody = _createCommentRequest(content);

      final response = await http
          .post(Uri.parse(url), headers: headers, body: jsonEncode(requestBody))
          .timeout(const Duration(seconds: 10));

      print('📥 Response Status: ${response.statusCode}');

      if (response.statusCode == 201 || response.statusCode == 200) {
        final dynamic data = jsonDecode(response.body);
        print('✅ Comment created successfully');

        Map<String, dynamic> newCommentData = {};

        if (data is Map) {
          if (data['success'] == true && data['data'] != null) {
            newCommentData = data['data'] is Map ? Map.from(data['data']) : {};
          } else if (data['comment'] != null) {
            newCommentData =
                data['comment'] is Map ? Map.from(data['comment']) : {};
          } else {
            newCommentData = Map.from(data);
          }
        }

        final newComment = _parseCommentFromJson(newCommentData);
        await _sendPushNotification(newComment);

        _safeSetState(() {
          _comments.insert(0, newComment);
          _commentController.clear();
        });

        _commentFocusNode.unfocus();
        _scrollToBottom();

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Comment posted!', style: SocialTheme.small),
            backgroundColor: Colors.green,
            duration: const Duration(seconds: 1),
            behavior: SnackBarBehavior.floating,
          ),
        );
      } else {
        String errorMsg = 'Failed to create comment';
        try {
          final errorData = jsonDecode(response.body);
          errorMsg = errorData['message'] ?? errorData['error'] ?? errorMsg;
        } catch (_) {}
        throw Exception(errorMsg);
      }
    } on TimeoutException catch (e) {
      print('❌ Timeout: $e');
      _safeSetState(() {
        _error = 'Request timeout - try again';
        _showError = true;
      });
    } catch (e) {
      print('❌ Error creating comment: $e');
      _safeSetState(() {
        _error = e.toString().replaceFirst('Exception: ', '');
        _showError = true;
      });
    } finally {
      _safeSetState(() => _isSubmitting = false);
    }
  }

  // ========== MAIN BUILD (FIXED - LIKE COMRADE VOTING MODAL) ==========
  @override
  Widget build(BuildContext context) {
    if (!widget.isOpen) return const SizedBox.shrink();

    final mq = MediaQuery.of(context);
    final keyboardH = mq.viewInsets.bottom;
    final bottomPad = mq.padding.bottom;

    return Stack(
      children: [
        // Backdrop
        Positioned.fill(
          child: GestureDetector(
            onTap: () {
              _commentFocusNode.unfocus();
              widget.onClose();
            },
            child: Container(color: Colors.black.withValues(alpha: 0.5)),
          ),
        ),

        // Sheet - With AnimatedPadding for keyboard (LIKE COMRADE VOTING MODAL)
        AnimatedPadding(
          padding: EdgeInsets.only(bottom: keyboardH),
          duration: const Duration(milliseconds: 150),
          curve: Curves.easeOut,
          child: Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              height: mq.size.height * 0.88,
              decoration: BoxDecoration(
                color: SocialTheme.background,
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(20),
                  topRight: Radius.circular(20),
                ),
              ),
              child: Column(
                children: [
                  _buildHandle(),
                  _buildHeader(),
                  Expanded(
                    child: _isLoading
                        ? Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                CircularProgressIndicator(
                                  color: SocialTheme.primary,
                                  strokeWidth: 2,
                                ),
                                const SizedBox(height: 12),
                                Text(
                                  'Loading comments...',
                                  style: SocialTheme.small,
                                ),
                              ],
                            ),
                          )
                        : _comments.isEmpty && !_isLoading
                            ? _buildEmptyState()
                            : ListView.builder(
                                controller: _scrollController,
                                padding:
                                    const EdgeInsets.fromLTRB(16, 8, 16, 16),
                                itemCount: _comments.length,
                                itemBuilder: (context, index) =>
                                    _buildCommentItem(index),
                              ),
                  ),
                  _buildInputField(
                    bottomPadding: keyboardH > 0 ? 12 : bottomPad + 12,
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}
