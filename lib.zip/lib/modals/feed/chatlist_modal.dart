import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../../pages/social_theme.dart';
import '../../models/post_models.dart';
import 'chat_modal.dart';

// Chat list item model
class ChatListItem {
  final String chatId;
  final String postId;
  final String otherUserId;
  final String otherUserName;
  final String? otherUserAvatar;
  final String lastMessage;
  final DateTime lastMessageTime;
  final int unreadCount;
  final bool isOnline;
  final String? postCaption;

  ChatListItem({
    required this.chatId,
    required this.postId,
    required this.otherUserId,
    required this.otherUserName,
    this.otherUserAvatar,
    required this.lastMessage,
    required this.lastMessageTime,
    required this.unreadCount,
    required this.isOnline,
    this.postCaption,
  });
}

class ChatListModal extends StatefulWidget {
  final bool isOpen;
  final VoidCallback onClose;
  final String? currentUserId;
  final String? currentUserName;
  final String? authToken;

  const ChatListModal({
    super.key,
    required this.isOpen,
    required this.onClose,
    this.currentUserId,
    this.currentUserName,
    this.authToken,
  });

  @override
  State<ChatListModal> createState() => _ChatListModalState();
}

class _ChatListModalState extends State<ChatListModal>
    with SingleTickerProviderStateMixin {
  List<ChatListItem> _chats = [];
  bool _isLoading = true;
  String? _authToken;
  String? _currentUserId;
  String? _currentUserName;
  final TextEditingController _searchController = TextEditingController();
  List<ChatListItem> _filteredChats = [];
  bool _isSearching = false;

  static const String _baseUrl = 'https://clash-api-m5mr.onrender.com/api';

  @override
  void initState() {
    super.initState();
    _initializeData();
    _searchController.addListener(_filterChats);
  }

  Future<void> _initializeData() async {
    await _loadAuthData();
    if (widget.isOpen) {
      _fetchChats();
    }
  }

  Future<void> _loadAuthData() async {
    setState(() => _isLoading = true);

    try {
      if (widget.authToken != null && widget.authToken!.isNotEmpty) {
        _authToken = widget.authToken;
      } else {
        final prefs = await SharedPreferences.getInstance();
        _authToken = prefs.getString('usertoken');
      }

      if (widget.currentUserId != null && widget.currentUserId!.isNotEmpty) {
        _currentUserId = widget.currentUserId;
        _currentUserName = widget.currentUserName;
      } else {
        final prefs = await SharedPreferences.getInstance();
        _currentUserId = prefs.getString('userid');
        _currentUserName = prefs.getString('username');
      }

      print(
        '✅ Auth loaded - User: $_currentUserName, Token exists: ${_authToken != null}',
      );
    } catch (e) {
      print('❌ Error loading auth data: $e');
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  void didUpdateWidget(covariant ChatListModal oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isOpen && !oldWidget.isOpen) {
      _fetchChats();
    }
  }

  Map<String, String> _getHeaders() {
    return {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $_authToken',
    };
  }

  Future<void> _fetchChats() async {
    if (_authToken == null || _currentUserId == null) {
      print('❌ Missing auth data for fetching chats');
      setState(() => _isLoading = false);
      return;
    }

    setState(() => _isLoading = true);

    try {
      // Use the correct endpoint: /chat/users/:user_id/messages
      final url = '$_baseUrl/chat/users/$_currentUserId/messages';
      print('📡 Fetching chats from: $url');

      final response = await http.get(Uri.parse(url), headers: _getHeaders());

      print('📡 Response status: ${response.statusCode}');

      if (response.statusCode == 200) {
        final dynamic data = json.decode(response.body);
        print('📦 Response data: $data');

        List<ChatListItem> chats = [];

        // Parse the response based on your API response structure
        if (data is Map) {
          // Check if response has a data field (your ApiResponse wrapper)
          if (data.containsKey('data')) {
            final responseData = data['data'];

            if (responseData is Map && responseData.containsKey('messages')) {
              final messagesList = responseData['messages'] as List;

              // Group messages by post_id and get the latest for each
              Map<String, List<dynamic>> messagesByPost = {};

              for (var msg in messagesList) {
                final postId = msg['postId'] ?? msg['post_id'];
                if (postId != null) {
                  messagesByPost.putIfAbsent(postId, () => []).add(msg);
                }
              }

              // For each post, create a chat item from the latest message
              messagesByPost.forEach((postId, msgs) {
                // Sort by date (newest first)
                msgs.sort((a, b) {
                  final aTime = DateTime.parse(
                    a['createdAt'] ?? a['created_at'],
                  );
                  final bTime = DateTime.parse(
                    b['createdAt'] ?? b['created_at'],
                  );
                  return bTime.compareTo(aTime);
                });

                final latestMsg = msgs.first;

                // Determine the other user (not the current user)
                final senderId =
                    latestMsg['senderId'] ?? latestMsg['sender_id'];
                final receiverId =
                    latestMsg['receiverId'] ?? latestMsg['receiver_id'];

                final otherUserId =
                    senderId == _currentUserId ? receiverId : senderId;
                final otherUserName = senderId == _currentUserId
                    ? (latestMsg['receiverName'] ??
                        latestMsg['receiver_name'] ??
                        'Unknown')
                    : (latestMsg['senderName'] ??
                        latestMsg['sender_name'] ??
                        'Unknown');

                // Count unread messages
                final unreadCount = msgs.where((msg) {
                  final msgSeen = msg['seen'] ?? false;
                  final msgSenderId = msg['senderId'] ?? msg['sender_id'];
                  return !msgSeen && msgSenderId != _currentUserId;
                }).length;

                chats.add(
                  ChatListItem(
                    chatId: postId,
                    postId: postId,
                    otherUserId: otherUserId,
                    otherUserName: otherUserName,
                    otherUserAvatar:
                        null, // You might need to fetch this separately
                    lastMessage: latestMsg['message'] ?? 'No message',
                    lastMessageTime: DateTime.parse(
                      latestMsg['createdAt'] ??
                          latestMsg['created_at'] ??
                          DateTime.now().toIso8601String(),
                    ),
                    unreadCount: unreadCount,
                    isOnline:
                        false, // You'd need a separate endpoint for online status
                    postCaption: null, // You might need to fetch post details
                  ),
                );
              });
            }
          }
        }

        // Sort by last message time (most recent first)
        chats.sort((a, b) => b.lastMessageTime.compareTo(a.lastMessageTime));

        setState(() {
          _chats = chats;
          _filteredChats = chats;
        });

        print('✅ Loaded ${chats.length} chats');
      } else {
        print('❌ Failed to fetch chats: ${response.statusCode}');
        print('📦 Response body: ${response.body}');
      }
    } catch (e, stackTrace) {
      print('❌ Error fetching chats: $e');
      print('📋 Stack trace: $stackTrace');
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  void _filterChats() {
    final query = _searchController.text.toLowerCase().trim();

    setState(() {
      _isSearching = query.isNotEmpty;

      if (query.isEmpty) {
        _filteredChats = List.from(_chats);
      } else {
        _filteredChats = _chats.where((chat) {
          return chat.otherUserName.toLowerCase().contains(query) ||
              (chat.postCaption?.toLowerCase().contains(query) ?? false) ||
              chat.lastMessage.toLowerCase().contains(query);
        }).toList();
      }
    });
  }

  String _formatTime(DateTime time) {
    final now = DateTime.now();
    final difference = now.difference(time);

    if (difference.inMinutes < 1) {
      return 'now';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes}m';
    } else if (difference.inHours < 24) {
      return '${difference.inHours}h';
    } else if (difference.inDays < 7) {
      return '${difference.inDays}d';
    } else if (difference.inDays < 30) {
      return '${(difference.inDays / 7).floor()}w';
    } else {
      return '${(difference.inDays / 30).floor()}mo';
    }
  }

  void _openChat(ChatListItem chat) {
    // Create a minimal post object for the chat modal
    final post = Post(
      id: chat.postId,
      userId: chat.otherUserId,
      userName: chat.otherUserName,
      caption: chat.postCaption,
      // mediaUrl: '',
      // mediaType: 'none',
      // likes: [],
      // comments: [],
      createdAt: DateTime.now().toIso8601String(),
    );

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => ChatModal(
        isOpen: true,
        onClose: () => Navigator.pop(context),
        post: post,
        currentUserId: _currentUserId ?? '',
        currentUserName: _currentUserName ?? 'You',
        authToken: _authToken,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.isOpen) return const SizedBox.shrink();

    return Material(
      color: Colors.transparent,
      child: GestureDetector(
        onTap: widget.onClose,
        child: Container(
          color: Colors.black54,
          child: GestureDetector(
            onTap: () {},
            child: Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                width: double.infinity,
                constraints: BoxConstraints(
                  maxHeight: MediaQuery.of(context).size.height * 0.8,
                  minHeight: 100,
                ),
                margin: const EdgeInsets.only(bottom: 0),
                decoration: BoxDecoration(
                  color: SocialTheme.background,
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(20),
                    topRight: Radius.circular(20),
                  ),
                ),
                child: _buildContent(),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildContent() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Drag handle
        Container(
          width: 40,
          height: 4,
          margin: const EdgeInsets.only(top: 12, bottom: 8),
          decoration: BoxDecoration(
            color: SocialTheme.surface,
            borderRadius: BorderRadius.circular(2),
          ),
        ),

        // Header
        _buildHeader(),

        // Search bar
        if (_chats.isNotEmpty) _buildSearchBar(),

        // Content
        _buildBody(),
      ],
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: SocialTheme.background,
        border: Border(
          bottom: BorderSide(
            color: SocialTheme.divider.withValues(alpha: 0.3),
            width: 0.5,
          ),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text('Messages', style: SocialTheme.headline.copyWith(fontSize: 18)),
          Row(
            children: [
              IconButton(
                icon: Icon(Icons.edit, color: SocialTheme.primary, size: 18),
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('New message feature coming soon!'),
                      backgroundColor: SocialTheme.primary,
                      behavior: SnackBarBehavior.floating,
                    ),
                  );
                },
                tooltip: 'New message',
                padding: const EdgeInsets.all(6),
                constraints: const BoxConstraints(),
                splashRadius: 24,
              ),
              const SizedBox(width: 4),
              IconButton(
                icon: Icon(
                  Icons.close,
                  color: SocialTheme.textSecondary,
                  size: 18,
                ),
                onPressed: widget.onClose,
                tooltip: 'Close',
                padding: const EdgeInsets.all(6),
                constraints: const BoxConstraints(),
                splashRadius: 24,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
      child: Container(
        decoration: BoxDecoration(
          color: SocialTheme.surface,
          borderRadius: BorderRadius.circular(20),
        ),
        child: TextField(
          controller: _searchController,
          decoration: InputDecoration(
            hintText: 'Search messages...',
            hintStyle: SocialTheme.small.copyWith(
              color: SocialTheme.textSecondary,
            ),
            prefixIcon: Icon(
              Icons.search,
              color: SocialTheme.textSecondary,
              size: 16,
            ),
            suffixIcon: _isSearching
                ? IconButton(
                    icon: Icon(
                      Icons.clear,
                      color: SocialTheme.textSecondary,
                      size: 16,
                    ),
                    onPressed: _searchController.clear,
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                  )
                : null,
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 12,
              vertical: 8,
            ),
            isDense: true,
          ),
          style: SocialTheme.small,
        ),
      ),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Flexible(
        child: Center(
          child: Padding(
            padding: EdgeInsets.all(32.0),
            child: CircularProgressIndicator(),
          ),
        ),
      );
    }

    if (_chats.isEmpty) {
      return Flexible(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(32.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    color: SocialTheme.surface,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.chat_bubble_outline,
                    color: SocialTheme.textSecondary,
                    size: 30,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  'No messages yet',
                  style: SocialTheme.body.copyWith(fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 4),
                Text(
                  'Start a conversation by chatting on a post',
                  style: SocialTheme.small.copyWith(
                    color: SocialTheme.textSecondary,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      );
    }

    if (_filteredChats.isEmpty && _isSearching) {
      return Flexible(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(32.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.search_off,
                  color: SocialTheme.textSecondary,
                  size: 40,
                ),
                const SizedBox(height: 8),
                Text(
                  'No chats found',
                  style: SocialTheme.body.copyWith(
                    color: SocialTheme.textSecondary,
                  ),
                ),
                Text(
                  'Try a different search term',
                  style: SocialTheme.tiny.copyWith(
                    color: SocialTheme.textSecondary,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Flexible(
      child: ListView.builder(
        shrinkWrap: true,
        padding: const EdgeInsets.symmetric(vertical: 4),
        itemCount: _filteredChats.length,
        itemBuilder: (context, index) {
          final chat = _filteredChats[index];
          return _buildChatTile(chat);
        },
      ),
    );
  }

  Widget _buildChatTile(ChatListItem chat) {
    final bool hasUnread = chat.unreadCount > 0;

    return ListTile(
      onTap: () => _openChat(chat),
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
      leading: Stack(
        children: [
          CircleAvatar(
            radius: 22,
            backgroundColor: SocialTheme.surface,
            backgroundImage: chat.otherUserAvatar != null
                ? NetworkImage(chat.otherUserAvatar!)
                : null,
            child: chat.otherUserAvatar == null
                ? Text(
                    chat.otherUserName.isNotEmpty
                        ? chat.otherUserName[0].toUpperCase()
                        : '?',
                    style: SocialTheme.body.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  )
                : null,
          ),
          if (chat.isOnline)
            Positioned(
              bottom: 0,
              right: 0,
              child: Container(
                width: 10,
                height: 10,
                decoration: BoxDecoration(
                  color: Colors.green,
                  shape: BoxShape.circle,
                  border: Border.all(color: SocialTheme.background, width: 2),
                ),
              ),
            ),
        ],
      ),
      title: Row(
        children: [
          Expanded(
            child: Text(
              chat.otherUserName,
              style: SocialTheme.body.copyWith(
                fontWeight: hasUnread ? FontWeight.w600 : FontWeight.normal,
                fontSize: 14,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          Text(
            _formatTime(chat.lastMessageTime),
            style: SocialTheme.tiny.copyWith(
              color:
                  hasUnread ? SocialTheme.primary : SocialTheme.textSecondary,
              fontSize: 10,
            ),
          ),
        ],
      ),
      subtitle: Row(
        children: [
          Expanded(
            child: Text(
              chat.lastMessage,
              style: SocialTheme.small.copyWith(
                fontWeight: hasUnread ? FontWeight.w500 : FontWeight.normal,
                color: hasUnread ? SocialTheme.text : SocialTheme.textSecondary,
                fontSize: 12,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          if (hasUnread)
            Container(
              margin: const EdgeInsets.only(left: 4),
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: SocialTheme.primary,
                shape: BoxShape.circle,
              ),
              constraints: const BoxConstraints(minWidth: 18, minHeight: 18),
              child: Center(
                child: Text(
                  chat.unreadCount > 9 ? '9+' : chat.unreadCount.toString(),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 9,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _searchController.removeListener(_filterChats);
    _searchController.dispose();
    super.dispose();
  }
}
