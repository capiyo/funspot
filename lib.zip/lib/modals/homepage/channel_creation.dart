import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../../pages/fan_clash_design.dart';
import '../../main.dart';

// ============================================================================
// CHANNEL CREATION MODAL
// ============================================================================
class CreateChannelModal extends StatefulWidget {
  final String userId;
  final String username;
  final String? authToken;
  final VoidCallback onChannelCreated;

  const CreateChannelModal({
    super.key,
    required this.userId,
    required this.username,
    this.authToken,
    required this.onChannelCreated,
  });

  @override
  State<CreateChannelModal> createState() => _CreateChannelModalState();
}

class _CreateChannelModalState extends State<CreateChannelModal> {
  // ==========================================================================
  // CONTROLLERS
  // ==========================================================================
  final TextEditingController _channelNameController = TextEditingController();
  final TextEditingController _searchController = TextEditingController();
  final FocusNode _searchFocusNode = FocusNode();

  // ==========================================================================
  // STATE
  // ==========================================================================
  List<UserProfile> _allUsers = [];
  List<UserProfile> _filteredUsers = [];
  List<UserProfile> _selectedMembers = [];
  bool _isLoading = true;
  bool _isCreating = false;
  String _searchQuery = '';
  bool _showOnlyAvailable = false;

  // ==========================================================================
  // CONSTANTS
  // ==========================================================================
  static const String API_BASE_URL = 'https://clash-api-m5mr.onrender.com/api';

  // ==========================================================================
  // LIFECYCLE
  // ==========================================================================
  @override
  void initState() {
    super.initState();
    _loadUsers();
  }

  @override
  void dispose() {
    _channelNameController.dispose();
    _searchController.dispose();
    _searchFocusNode.dispose();
    super.dispose();
  }

  // ==========================================================================
  // LOAD USERS FROM /profile/profiles
  // ==========================================================================
  Future<void> _loadUsers() async {
    setState(() => _isLoading = true);

    try {
      final headers = <String, String>{'Content-Type': 'application/json'};
      if (widget.authToken != null && widget.authToken!.isNotEmpty) {
        headers['Authorization'] = 'Bearer ${widget.authToken}';
      }

      final response = await http
          .get(
            Uri.parse('$API_BASE_URL/profile/profiles'),
            headers: headers,
          )
          .timeout(const Duration(seconds: 15));

      if (response.statusCode == 200 && mounted) {
        final List<dynamic> data = json.decode(response.body);
        final List<UserProfile> users = data
            .map((item) => UserProfile.fromJson(item as Map<String, dynamic>))
            .where((user) => user.id != widget.userId) // ✅ Changed
            .toList();

        setState(() {
          _allUsers = users;
          _filteredUsers = users;
          _isLoading = false;
        });
      } else {
        setState(() => _isLoading = false);
        _showToast('Failed to load users', isError: true);
      }
    } catch (e) {
      setState(() => _isLoading = false);
      _showToast('Error loading users: $e', isError: true);
    }
  }

  // ==========================================================================
  // FILTER USERS
  // ==========================================================================
  void _filterUsers(String query) {
    setState(() {
      _searchQuery = query;
      _filteredUsers = _allUsers.where((user) {
        final matchesSearch = query.isEmpty ||
            user.nickname.toLowerCase().contains(query.toLowerCase()) ||
            user.username.toLowerCase().contains(query.toLowerCase()) ||
            user.clubFan.toLowerCase().contains(query.toLowerCase()) ||
            user.countryFan.toLowerCase().contains(query.toLowerCase());

        final isAvailable =
            !_selectedMembers.any((m) => m.userId == user.userId);

        return matchesSearch && (_showOnlyAvailable ? isAvailable : true);
      }).toList();
    });
  }

  // ==========================================================================
  // TOGGLE MEMBER SELECTION
  // ==========================================================================
  void _toggleMember(UserProfile user) {
    setState(() {
      if (_selectedMembers.any((m) => m.userId == user.userId)) {
        _selectedMembers.removeWhere((m) => m.userId == user.userId);
      } else {
        _selectedMembers.add(user);
      }
      _filterUsers(_searchQuery);
    });
  }

  // ==========================================================================
  // CREATE CHANNEL - MATCHES BACKEND API EXACTLY
  // ==========================================================================
  // In your Flutter modal - use 'id' NOT 'userId'
  Future<void> _createChannel() async {
    final channelName = _channelNameController.text.trim();

    if (channelName.isEmpty) {
      _showToast('Please enter a channel name', isError: true);
      return;
    }

    if (_selectedMembers.isEmpty) {
      _showToast('Please select at least one member', isError: true);
      return;
    }

    setState(() => _isCreating = true);

    try {
      final members = _selectedMembers.map((user) {
        return {
          'user_id': user.id,
          'username': user.username,
        };
      }).toList();

      final requestBody = {
        'name': channelName,
        'created_by': widget.userId,
        'created_by_username': widget.username,
        'season': '2024',
        'members': members,
      };

      print('SENDING: ${json.encode(requestBody)}'); // <-- add this

      final headers = <String, String>{
        'Content-Type': 'application/json',
      };
      if (widget.authToken != null && widget.authToken!.isNotEmpty) {
        headers['Authorization'] = 'Bearer ${widget.authToken}';
      }

      final response = await http.post(
        Uri.parse('$API_BASE_URL/channels/create'),
        headers: headers,
        body: json.encode(requestBody),
      );

      print('STATUS: ${response.statusCode}'); // <-- add this
      print('BODY: ${response.body}'); // <-- add this

      if (response.statusCode == 200 || response.statusCode == 201) {
        final data = json.decode(response.body);
        _showToast('✅ Channel created! Invite: ${data['invite_code']}');
        widget.onChannelCreated();
        if (mounted) Navigator.pop(context);
      } else {
        final error = json.decode(response.body);
        _showToast('Error: ${error['message'] ?? response.body}',
            isError: true);
      }
    } catch (e) {
      print('CAUGHT EXCEPTION: $e'); // <-- add this too, very important
      _showToast('Error: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isCreating = false);
    }
  }

  // =========================================================================
  // TOAST
  // ==========================================================================
  void _showToast(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: const TextStyle(fontSize: 13)),
        backgroundColor: isError ? FanColors.away : FanColors.primary,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 3),
        margin: const EdgeInsets.all(12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }

  // ==========================================================================
  // BUILD
  // ==========================================================================
  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.all(12),
      child: Container(
        width: double.infinity,
        height: MediaQuery.of(context).size.height * 0.85,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF0A0A0A), Color(0xFF000000)],
          ),
          borderRadius: BorderRadius.circular(24),
        ),
        child: Column(
          children: [
            _buildHandle(),
            _buildHeader(),
            _buildChannelNameInput(),
            _buildMemberSection(),
            _buildActionButtons(),
          ],
        ),
      ),
    );
  }

  // ==========================================================================
  // BUILD: HANDLE
  // ==========================================================================
  Widget _buildHandle() {
    return Center(
      child: Container(
        margin: const EdgeInsets.only(top: 12, bottom: 8),
        width: 40,
        height: 4,
        decoration: BoxDecoration(
          color: const Color(0xFF1F2937),
          borderRadius: BorderRadius.circular(2),
        ),
      ),
    );
  }

  // ==========================================================================
  // BUILD: HEADER
  // ==========================================================================
  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 12),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  FanColors.primary,
                  FanColors.primary.withValues(alpha: 0.7),
                ],
              ),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.group_add, color: Colors.white, size: 24),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Create Channel',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                Text(
                  'Add members to your group',
                  style: TextStyle(
                    fontSize: 11,
                    color: const Color(0xFF94A3B8),
                  ),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: const Color(0xFF1F2937),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.close, color: Colors.white, size: 18),
            ),
          ),
        ],
      ),
    );
  }

  // ==========================================================================
  // BUILD: CHANNEL NAME INPUT
  // ==========================================================================
  Widget _buildChannelNameInput() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF111827),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFF1F2937), width: 1),
        ),
        child: TextField(
          controller: _channelNameController,
          style: const TextStyle(color: Colors.white, fontSize: 14),
          decoration: InputDecoration(
            hintText: 'Enter channel name...',
            hintStyle: TextStyle(
              color: const Color(0xFF94A3B8).withValues(alpha: 0.5),
              fontSize: 13,
            ),
            prefixIcon: const Icon(
              Icons.groups,
              color: Color(0xFF94A3B8),
              size: 18,
            ),
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 14,
              vertical: 12,
            ),
          ),
        ),
      ),
    );
  }

  // ==========================================================================
  // BUILD: MEMBER SECTION
  // ==========================================================================
  Widget _buildMemberSection() {
    return Expanded(
      child: Column(
        children: [
          // Member count & filter
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
            child: Row(
              children: [
                Text(
                  'Add Members (${_selectedMembers.length})',
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF94A3B8),
                  ),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: () {
                    setState(() {
                      _showOnlyAvailable = !_showOnlyAvailable;
                      _filterUsers(_searchQuery);
                    });
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: _showOnlyAvailable
                          ? FanColors.primary.withValues(alpha: 0.2)
                          : const Color(0xFF1F2937),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: _showOnlyAvailable
                            ? FanColors.primary.withValues(alpha: 0.3)
                            : const Color(0xFF1F2937),
                        width: 1,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          _showOnlyAvailable
                              ? Icons.visibility
                              : Icons.visibility_off,
                          size: 14,
                          color: _showOnlyAvailable
                              ? FanColors.primary
                              : const Color(0xFF94A3B8),
                        ),
                        const SizedBox(width: 4),
                        Text(
                          _showOnlyAvailable ? 'Available' : 'All',
                          style: TextStyle(
                            fontSize: 10,
                            color: _showOnlyAvailable
                                ? FanColors.primary
                                : const Color(0xFF94A3B8),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Search bar
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xFF111827),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFF1F2937), width: 1),
              ),
              child: TextField(
                controller: _searchController,
                focusNode: _searchFocusNode,
                style: const TextStyle(color: Colors.white, fontSize: 14),
                onChanged: _filterUsers,
                decoration: InputDecoration(
                  hintText: 'Search by name, club, or country...',
                  hintStyle: TextStyle(
                    color: const Color(0xFF94A3B8).withValues(alpha: 0.5),
                    fontSize: 13,
                  ),
                  prefixIcon: const Icon(
                    Icons.search,
                    color: Color(0xFF94A3B8),
                    size: 18,
                  ),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 12,
                  ),
                ),
              ),
            ),
          ),

          // User list
          Expanded(
            child: _isLoading
                ? _buildLoadingState()
                : _filteredUsers.isEmpty
                    ? _buildEmptyState()
                    : ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        itemCount: _filteredUsers.length,
                        itemBuilder: (context, index) =>
                            _buildUserTile(_filteredUsers[index]),
                      ),
          ),
        ],
      ),
    );
  }

  // ==========================================================================
  // BUILD: USER TILE
  // ==========================================================================
  Widget _buildUserTile(UserProfile user) {
    final isSelected = _selectedMembers.any((m) => m.userId == user.userId);

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: isSelected
            ? FanColors.primary.withValues(alpha: 0.1)
            : const Color(0xFF111827),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isSelected
              ? FanColors.primary.withValues(alpha: 0.3)
              : const Color(0xFF1F2937),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          // Avatar
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  FanColors.primary.withValues(alpha: 0.2),
                  FanColors.primary.withValues(alpha: 0.1),
                ],
              ),
              shape: BoxShape.circle,
              border: Border.all(
                color: FanColors.primary.withValues(alpha: 0.3),
                width: 1,
              ),
            ),
            child: Center(
              child: Text(
                user.nickname[0].toUpperCase(),
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: FanColors.primary,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),

          // User info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  user.nickname,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 2),
                Row(
                  children: [
                    Icon(
                      Icons.sports_soccer,
                      size: 10,
                      color: const Color(0xFF94A3B8),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      user.clubFan,
                      style: const TextStyle(
                        fontSize: 10,
                        color: Color(0xFF94A3B8),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Icon(
                      Icons.flag,
                      size: 10,
                      color: const Color(0xFF94A3B8),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      user.countryFan,
                      style: const TextStyle(
                        fontSize: 10,
                        color: Color(0xFF94A3B8),
                      ),
                    ),
                  ],
                ),
                Text(
                  '@${user.username}',
                  style: const TextStyle(
                    fontSize: 9,
                    color: Color(0xFF6B7280),
                  ),
                ),
              ],
            ),
          ),

          // Select button
          GestureDetector(
            onTap: () => _toggleMember(user),
            child: Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: isSelected ? FanColors.primary : const Color(0xFF1F2937),
                shape: BoxShape.circle,
              ),
              child: Icon(
                isSelected ? Icons.check : Icons.add,
                size: 16,
                color: isSelected ? Colors.white : const Color(0xFF94A3B8),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==========================================================================
  // BUILD: SELECTED MEMBERS CHIPS
  // ==========================================================================
  Widget _buildSelectedMembersChips() {
    if (_selectedMembers.isEmpty) return const SizedBox.shrink();

    return Container(
      height: 40,
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: _selectedMembers.length,
        separatorBuilder: (_, __) => const SizedBox(width: 6),
        itemBuilder: (context, index) {
          final user = _selectedMembers[index];
          return Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: FanColors.primary.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: FanColors.primary.withValues(alpha: 0.3),
                width: 0.5,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  user.nickname,
                  style: const TextStyle(
                    fontSize: 11,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(width: 4),
                GestureDetector(
                  onTap: () => _toggleMember(user),
                  child: const Icon(
                    Icons.close,
                    size: 12,
                    color: Colors.white70,
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  // ==========================================================================
  // BUILD: ACTION BUTTONS
  // ==========================================================================
  Widget _buildActionButtons() {
    return Column(
      children: [
        _buildSelectedMembersChips(),
        Container(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
          decoration: BoxDecoration(
            border: Border(
              top: BorderSide(color: const Color(0xFF1F2937), width: 1),
            ),
          ),
          child: Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: _isCreating ? null : () => Navigator.pop(context),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: const Color(0xFF94A3B8),
                    side: const BorderSide(color: Color(0xFF1F2937)),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Text('Cancel', style: TextStyle(fontSize: 13)),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton(
                  onPressed: _isCreating ? null : _createChannel,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _selectedMembers.isEmpty
                        ? const Color(0xFF1F2937)
                        : FanColors.primary,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: _isCreating
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : Text(
                          _selectedMembers.isEmpty
                              ? 'Select Members'
                              : 'Create Channel (${_selectedMembers.length})',
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: _selectedMembers.isEmpty
                                ? const Color(0xFF94A3B8)
                                : Colors.white,
                          ),
                        ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ==========================================================================
  // BUILD: LOADING STATE
  // ==========================================================================
  Widget _buildLoadingState() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(
            color: FanColors.primary,
            strokeWidth: 2.5,
          ),
          SizedBox(height: 12),
          Text(
            'Loading users...',
            style: TextStyle(fontSize: 12, color: Color(0xFF94A3B8)),
          ),
        ],
      ),
    );
  }

  // ==========================================================================
  // BUILD: EMPTY STATE
  // ==========================================================================
  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              color: const Color(0xFF111827),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.people_outline,
              size: 32,
              color: Color(0xFF94A3B8),
            ),
          ),
          const SizedBox(height: 12),
          Text(
            _searchQuery.isNotEmpty
                ? 'No matching users found'
                : 'No users available',
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            _searchQuery.isNotEmpty
                ? 'Try a different search term'
                : 'Check back later',
            style: const TextStyle(fontSize: 11, color: Color(0xFF94A3B8)),
          ),
        ],
      ),
    );
  }
}

// ============================================================================
// USER PROFILE MODEL
// ============================================================================
class UserProfile {
  final String id;
  final String userId;
  final String username;
  final String nickname;
  final String clubFan;
  final String countryFan;
  final String phone;
  final double balance;
  final int numberOfBets;

  UserProfile({
    required this.id,
    required this.userId,
    required this.username,
    required this.nickname,
    required this.clubFan,
    required this.countryFan,
    required this.phone,
    required this.balance,
    required this.numberOfBets,
  });

  factory UserProfile.fromJson(Map<String, dynamic> json) {
    return UserProfile(
      id: json['_id']?.toString() ?? json['id']?.toString() ?? '',
      userId: json['user_id']?.toString() ?? '',
      username: json['username']?.toString() ?? '',
      nickname: json['nickname']?.toString() ??
          json['username']?.toString() ??
          'User',
      clubFan: json['club_fan']?.toString() ?? 'Football Fan',
      countryFan: json['country_fan']?.toString() ?? 'World',
      phone: json['phone']?.toString() ?? '',
      balance: (json['balance'] as num?)?.toDouble() ?? 0.0,
      numberOfBets: (json['number_of_bets'] as num?)?.toInt() ?? 0,
    );
  }
}
