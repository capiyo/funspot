import 'package:flutter/material.dart';
import '../../pages/social_theme.dart';

class ComradeUser {
  final String id;
  final String userId;
  final String username;
  final String nickname;
  final String club;
  final String country;
  final String? avatarUrl;
  final bool isSelected;
  final bool isMutual;

  ComradeUser({
    required this.id,
    required this.userId,
    required this.username,
    required this.nickname,
    required this.club,
    required this.country,
    this.avatarUrl,
    this.isSelected = false,
    this.isMutual = false,
  });

  ComradeUser copyWith({bool? isSelected, bool? isMutual}) {
    return ComradeUser(
      id: id,
      userId: userId,
      username: username,
      nickname: nickname,
      club: club,
      country: country,
      avatarUrl: avatarUrl,
      isSelected: isSelected ?? this.isSelected,
      isMutual: isMutual ?? this.isMutual,
    );
  }
}

// 30 MOCK USERS
final List<ComradeUser> mockUsers = [
  // East Africa
  ComradeUser(
    id: '1',
    userId: 'u1',
    username: 'capiyo_fan',
    nickname: 'Capiyo',
    club: 'Manchester United',
    country: 'France',
    isMutual: false,
  ),
  ComradeUser(
    id: '2',
    userId: 'u2',
    username: 'gunner_king',
    nickname: 'GunnersKing',
    club: 'Arsenal',
    country: 'Kenya',
    isMutual: true,
  ),
  ComradeUser(
    id: '3',
    userId: 'u3',
    username: 'liver_bird',
    nickname: 'RedBird',
    club: 'Liverpool',
    country: 'Kenya',
    isMutual: false,
  ),
  ComradeUser(
    id: '4',
    userId: 'u4',
    username: 'chelsea_blue',
    nickname: 'BlueLion',
    club: 'Chelsea',
    country: 'Tanzania',
    isMutual: false,
  ),
  ComradeUser(
    id: '5',
    userId: 'u5',
    username: 'spur_hero',
    nickname: 'SpurHero',
    club: 'Tottenham',
    country: 'Uganda',
    isMutual: false,
  ),
  ComradeUser(
    id: '6',
    userId: 'u6',
    username: 'city_zen',
    nickname: 'CityZen',
    club: 'Manchester City',
    country: 'Rwanda',
    isMutual: true,
  ),
  ComradeUser(
    id: '7',
    userId: 'u7',
    username: 'barca_mes',
    nickname: 'BarcaMes',
    club: 'Barcelona',
    country: 'Ethiopia',
    isMutual: false,
  ),
  ComradeUser(
    id: '8',
    userId: 'u8',
    username: 'madrid_gal',
    nickname: 'MadridGal',
    club: 'Real Madrid',
    country: 'Kenya',
    isMutual: false,
  ),

  // West Africa
  ComradeUser(
    id: '9',
    userId: 'u9',
    username: 'super_eagle',
    nickname: 'SuperEagle',
    club: 'Arsenal',
    country: 'Nigeria',
    isMutual: true,
  ),
  ComradeUser(
    id: '10',
    userId: 'u10',
    username: 'black_star',
    nickname: 'BlackStar',
    club: 'Manchester United',
    country: 'Ghana',
    isMutual: false,
  ),
  ComradeUser(
    id: '11',
    userId: 'u11',
    username: 'lion_teranga',
    nickname: 'TerangaLion',
    club: 'Chelsea',
    country: 'Senegal',
    isMutual: false,
  ),
  ComradeUser(
    id: '12',
    userId: 'u12',
    username: 'elephant_ci',
    nickname: 'ElephantCI',
    club: 'Liverpool',
    country: 'Ivory Coast',
    isMutual: false,
  ),

  // Europe
  ComradeUser(
    id: '13',
    userId: 'u13',
    username: 'red_devil',
    nickname: 'RedDevil',
    club: 'Manchester United',
    country: 'England',
    isMutual: true,
  ),
  ComradeUser(
    id: '14',
    userId: 'u14',
    username: 'blaugrana',
    nickname: 'Blaugrana',
    club: 'Barcelona',
    country: 'Spain',
    isMutual: false,
  ),
  ComradeUser(
    id: '15',
    userId: 'u15',
    username: 'die_mannschaft',
    nickname: 'DieMannschaft',
    club: 'Bayern Munich',
    country: 'Germany',
    isMutual: false,
  ),
  ComradeUser(
    id: '16',
    userId: 'u16',
    username: 'rossoneri',
    nickname: 'Rossoneri',
    club: 'AC Milan',
    country: 'Italy',
    isMutual: false,
  ),
  ComradeUser(
    id: '17',
    userId: 'u17',
    username: 'les_bleus',
    nickname: 'LesBleus',
    club: 'Paris Saint-Germain',
    country: 'France',
    isMutual: true,
  ),

  // South America
  ComradeUser(
    id: '18',
    userId: 'u18',
    username: 'selecao',
    nickname: 'Selecao',
    club: 'Real Madrid',
    country: 'Brazil',
    isMutual: false,
  ),
  ComradeUser(
    id: '19',
    userId: 'u19',
    username: 'albiceleste',
    nickname: 'Albiceleste',
    club: 'Barcelona',
    country: 'Argentina',
    isMutual: false,
  ),
  ComradeUser(
    id: '20',
    userId: 'u20',
    username: 'charrua',
    nickname: 'Charrua',
    club: 'Liverpool',
    country: 'Uruguay',
    isMutual: false,
  ),
  ComradeUser(
    id: '21',
    userId: 'u21',
    username: 'cafetero',
    nickname: 'Cafetero',
    club: 'Manchester United',
    country: 'Colombia',
    isMutual: true,
  ),

  // Asia
  ComradeUser(
    id: '22',
    userId: 'u22',
    username: 'samurai_blue',
    nickname: 'SamuraiBlue',
    club: 'Arsenal',
    country: 'Japan',
    isMutual: false,
  ),
  ComradeUser(
    id: '23',
    userId: 'u23',
    username: 'tiger_red',
    nickname: 'TigerRed',
    club: 'Tottenham',
    country: 'South Korea',
    isMutual: false,
  ),
  ComradeUser(
    id: '24',
    userId: 'u24',
    username: 'green_falcon',
    nickname: 'GreenFalcon',
    club: 'Manchester City',
    country: 'Saudi Arabia',
    isMutual: false,
  ),
  ComradeUser(
    id: '25',
    userId: 'u25',
    username: 'blue_tiger',
    nickname: 'BlueTiger',
    club: 'Chelsea',
    country: 'India',
    isMutual: true,
  ),

  // North America
  ComradeUser(
    id: '26',
    userId: 'u26',
    username: 'stars_stripes',
    nickname: 'StarsStripes',
    club: 'Manchester United',
    country: 'USA',
    isMutual: false,
  ),
  ComradeUser(
    id: '27',
    userId: 'u27',
    username: 'el_tri',
    nickname: 'ElTri',
    club: 'Real Madrid',
    country: 'Mexico',
    isMutual: false,
  ),
  ComradeUser(
    id: '28',
    userId: 'u28',
    username: 'maple_leaf',
    nickname: 'MapleLeaf',
    club: 'Liverpool',
    country: 'Canada',
    isMutual: false,
  ),

  // More Africans
  ComradeUser(
    id: '29',
    userId: 'u29',
    username: 'pharaoh_king',
    nickname: 'PharaohKing',
    club: 'Arsenal',
    country: 'Egypt',
    isMutual: true,
  ),
  ComradeUser(
    id: '30',
    userId: 'u30',
    username: 'bafana_boy',
    nickname: 'BafanaBoy',
    club: 'Manchester City',
    country: 'South Africa',
    isMutual: false,
  ),
];

class RecruitComradesModal extends StatefulWidget {
  final String userId;
  final String nickname;
  final String club;
  final String country;
  final VoidCallback? onComplete;
  final VoidCallback? onSkip;

  const RecruitComradesModal({
    super.key,
    required this.userId,
    required this.nickname,
    required this.club,
    required this.country,
    this.onComplete,
    this.onSkip,
  });

  @override
  State<RecruitComradesModal> createState() => _RecruitComradesModalState();
}

class _RecruitComradesModalState extends State<RecruitComradesModal> {
  List<ComradeUser> _users = [];
  final List<String> _selectedComradeIds = [];
  bool _isLoading = true;
  String _searchQuery = '';
  final int _maxComrades = 50;

  @override
  void initState() {
    super.initState();
    _loadMockData();
  }

  void _loadMockData() {
    Future.delayed(const Duration(milliseconds: 500), () {
      setState(() {
        _users = List.from(mockUsers);
        _isLoading = false;
      });
    });
  }

  List<ComradeUser> get _filteredUsers {
    var filtered = List<ComradeUser>.from(_users);

    if (_searchQuery.isNotEmpty) {
      filtered = filtered.where((user) {
        return user.nickname.toLowerCase().contains(
              _searchQuery.toLowerCase(),
            ) ||
            user.username.toLowerCase().contains(_searchQuery.toLowerCase()) ||
            user.club.toLowerCase().contains(_searchQuery.toLowerCase()) ||
            user.country.toLowerCase().contains(_searchQuery.toLowerCase());
      }).toList();
    }

    filtered.sort((a, b) {
      final aSameClub = a.club == widget.club;
      final bSameClub = b.club == widget.club;
      if (aSameClub && !bSameClub) return -1;
      if (!aSameClub && bSameClub) return 1;
      if (a.isMutual != b.isMutual) return b.isMutual ? 1 : -1;
      return a.nickname.compareTo(b.nickname);
    });

    return filtered;
  }

  void _toggleSelection(ComradeUser user) {
    if (_selectedComradeIds.contains(user.userId)) {
      setState(() {
        _selectedComradeIds.remove(user.userId);
        final index = _users.indexWhere((u) => u.userId == user.userId);
        if (index != -1) {
          _users[index] = user.copyWith(isSelected: false);
        }
      });
    } else {
      if (_selectedComradeIds.length >= _maxComrades) {
        _showToast(
          'Your battalion is full. Upgrade to add more comrades.',
          isWarning: true,
        );
        return;
      }
      setState(() {
        _selectedComradeIds.add(user.userId);
        final index = _users.indexWhere((u) => u.userId == user.userId);
        if (index != -1) {
          _users[index] = user.copyWith(isSelected: true);
        }
      });
    }
  }

  void _showToast(String message, {bool isWarning = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: const TextStyle(fontSize: 13)),
        backgroundColor: isWarning
            ? const Color(0xFFD97706)
            : const Color(0xFF10B981),
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
        margin: const EdgeInsets.all(12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }

  void _handleComplete() {
    _showToast(
      '${_selectedComradeIds.length} comrades added to your battalion!',
    );
    widget.onComplete?.call();
  }

  void _handleSkip() {
    widget.onSkip?.call();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.all(12),
      child: Container(
        width: double.infinity,
        height: MediaQuery.of(context).size.height * 0.85,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF0A0A0A), Color(0xFF000000)],
          ),
          borderRadius: BorderRadius.circular(24),
        ),
        child: Column(
          children: [
            Center(
              child: Container(
                margin: const EdgeInsets.only(top: 12, bottom: 8),
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: const Color(0xFF1F2937),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            _buildHeader(),
            _buildBattalionProgress(),
            _buildSearchBar(),
            Expanded(
              child: _isLoading
                  ? _buildLoadingState()
                  : _filteredUsers.isEmpty
                  ? _buildEmptyState()
                  : ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      itemCount: _filteredUsers.length,
                      itemBuilder: (context, index) =>
                          _buildUserTile(_filteredUsers[index]),
                    ),
            ),
            _buildActionButtons(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 12),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  SocialTheme.primary,
                  SocialTheme.primary.withValues(alpha: 0.7),
                ],
              ),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.groups, color: Colors.white, size: 24),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Build Your Battalion',
                  style: SocialTheme.headline.copyWith(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  'Add comrades to see their votes',
                  style: TextStyle(
                    fontSize: 11,
                    color: const Color(0xFF94A3B8),
                  ),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: const Color(0xFF1F2937),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.close, color: Colors.white, size: 18),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBattalionProgress() {
    final progress = _selectedComradeIds.length / _maxComrades;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF111827),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF1F2937), width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Your Battalion',
                style: TextStyle(fontSize: 12, color: const Color(0xFF94A3B8)),
              ),
              Text(
                '${_selectedComradeIds.length}/$_maxComrades',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: const Color(0xFF10B981),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: progress,
              backgroundColor: const Color(0xFF1F2937),
              valueColor: const AlwaysStoppedAnimation<Color>(
                Color(0xFF10B981),
              ),
              minHeight: 4,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 12),
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF111827),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFF1F2937), width: 1),
        ),
        child: TextField(
          style: const TextStyle(color: Colors.white, fontSize: 14),
          onChanged: (value) => setState(() => _searchQuery = value),
          decoration: InputDecoration(
            hintText: 'Search by name, club, or country...',
            hintStyle: TextStyle(
              color: const Color(0xFF94A3B8).withValues(alpha: 0.5),
              fontSize: 13,
            ),
            prefixIcon: const Icon(
              Icons.search,
              color: Color(0xFF94A3B8),
              size: 18,
            ),
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 14,
              vertical: 12,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildUserTile(ComradeUser user) {
    final isSelected = _selectedComradeIds.contains(user.userId);
    final isSameClub = user.club == widget.club;
    final isSameCountry = user.country == widget.country;

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: isSelected
            ? const Color(0xFF10B981).withValues(alpha: 0.1)
            : const Color(0xFF111827),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isSelected
              ? const Color(0xFF10B981).withValues(alpha: 0.3)
              : const Color(0xFF1F2937),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  SocialTheme.primary.withValues(alpha: 0.2),
                  SocialTheme.primary.withValues(alpha: 0.1),
                ],
              ),
              shape: BoxShape.circle,
              border: Border.all(
                color: SocialTheme.primary.withValues(alpha: 0.3),
                width: 1,
              ),
            ),
            child: Center(
              child: Text(
                user.nickname.substring(0, 1).toUpperCase(),
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF10B981),
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      user.nickname,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                    if (user.isMutual) ...[
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 6,
                          vertical: 2,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0xFF10B981).withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Text(
                          'Mutual',
                          style: TextStyle(
                            fontSize: 8,
                            color: Color(0xFF10B981),
                          ),
                        ),
                      ),
                    ],
                    if (isSameClub && !isSelected) ...[
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 6,
                          vertical: 2,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0xFF10B981).withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Text(
                          'Same Club',
                          style: TextStyle(
                            fontSize: 8,
                            color: Color(0xFF10B981),
                          ),
                        ),
                      ),
                    ],
                    if (isSameCountry && !isSelected && !isSameClub) ...[
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 6,
                          vertical: 2,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0xFF10B981).withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Text(
                          'Same Country',
                          style: TextStyle(
                            fontSize: 8,
                            color: Color(0xFF10B981),
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    const Icon(
                      Icons.sports_soccer,
                      size: 10,
                      color: Color(0xFF94A3B8),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      user.club,
                      style: const TextStyle(
                        fontSize: 11,
                        color: Color(0xFF94A3B8),
                      ),
                    ),
                    const SizedBox(width: 12),
                    const Icon(Icons.flag, size: 10, color: Color(0xFF94A3B8)),
                    const SizedBox(width: 4),
                    Text(
                      user.country,
                      style: const TextStyle(
                        fontSize: 11,
                        color: Color(0xFF94A3B8),
                      ),
                    ),
                  ],
                ),
                Text(
                  '@${user.username}',
                  style: const TextStyle(
                    fontSize: 10,
                    color: Color(0xFF6B7280),
                  ),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: () => _toggleSelection(user),
            child: Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: isSelected
                    ? const Color(0xFF10B981)
                    : const Color(0xFF1F2937),
                shape: BoxShape.circle,
              ),
              child: Icon(
                isSelected ? Icons.check : Icons.add,
                size: 18,
                color: isSelected ? Colors.white : const Color(0xFF94A3B8),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingState() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(color: Color(0xFF10B981), strokeWidth: 2.5),
          SizedBox(height: 12),
          Text(
            'Finding comrades...',
            style: TextStyle(fontSize: 12, color: Color(0xFF94A3B8)),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              color: const Color(0xFF111827),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.people_outline,
              size: 32,
              color: Color(0xFF94A3B8),
            ),
          ),
          const SizedBox(height: 12),
          Text(
            _searchQuery.isNotEmpty
                ? 'No matching users found'
                : 'No comrades available',
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            _searchQuery.isNotEmpty
                ? 'Try a different search term'
                : 'Check back later',
            style: const TextStyle(fontSize: 11, color: Color(0xFF94A3B8)),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons() {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
      decoration: BoxDecoration(
        border: Border(
          top: BorderSide(color: const Color(0xFF1F2937), width: 1),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: OutlinedButton(
              onPressed: _handleSkip,
              style: OutlinedButton.styleFrom(
                foregroundColor: const Color(0xFF94A3B8),
                side: const BorderSide(color: Color(0xFF1F2937)),
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: const Text('Skip for now', style: TextStyle(fontSize: 13)),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: ElevatedButton(
              onPressed: _handleComplete,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF10B981),
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: Text(
                'Add ${_selectedComradeIds.isEmpty ? 'Comrades' : '${_selectedComradeIds.length} Comrades'}',
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
