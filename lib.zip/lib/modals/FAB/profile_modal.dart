// modals/profile/swipeable_profile_modal.dart

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../pages/fan_clash_design.dart';
import '../../services/auth_service.dart';
import '../../screens/home_page.dart' show UserChannel, ChannelMember;
import '../../services/toast_helper.dart';
import 'dart:async';
import "../../models/user_channel.dart";

// ============================================================================
// USER DATA MODEL
// ============================================================================

class UserData {
  final String userId;
  final String username;
  final String phone;
  final String nickname;
  final String clubFan;
  final String countryFan;
  final int numberOfBets;
  final double balance;

  UserData({
    required this.userId,
    required this.username,
    required this.phone,
    required this.nickname,
    required this.clubFan,
    required this.countryFan,
    required this.numberOfBets,
    required this.balance,
  });

  factory UserData.fromJson(Map<String, dynamic> json) => UserData(
        userId: json['user_id']?.toString() ?? json['userId']?.toString() ?? '',
        username: json['username']?.toString() ?? '',
        phone: json['phone']?.toString() ?? '',
        nickname: json['nickname']?.toString() ?? '',
        clubFan: json['club_fan']?.toString() ?? '',
        countryFan: json['country_fan']?.toString() ?? '',
        numberOfBets: json['number_of_bets'] ?? 0,
        balance: (json['balance'] ?? 0.0).toDouble(),
      );

  Map<String, dynamic> toJson() => {
        'user_id': userId,
        'username': username,
        'phone': phone,
        'nickname': nickname,
        'club_fan': clubFan,
        'country_fan': countryFan,
        'number_of_bets': numberOfBets,
        'balance': balance,
      };
}

// ============================================================================
// CHANNEL MEMBER MODEL
// ============================================================================

class ChannelMember {
  final String userId;
  final String username;
  final String nickname;
  final String role;
  final int seasonPoints;
  final int correctVotes;
  final int totalVotes;
  final String clubFan;
  final String countryFan;

  ChannelMember({
    required this.userId,
    required this.username,
    required this.nickname,
    required this.role,
    required this.seasonPoints,
    required this.correctVotes,
    required this.totalVotes,
    required this.clubFan,
    required this.countryFan,
  });

  factory ChannelMember.fromJson(Map<String, dynamic> json) {
    return ChannelMember(
      userId: json['user_id']?.toString() ?? '',
      username: json['username']?.toString() ?? 'Anonymous',
      nickname:
          json['nickname']?.toString() ?? json['username']?.toString() ?? 'Fan',
      role: json['role']?.toString()?.toLowerCase() ?? 'member',
      seasonPoints: json['season_points'] ?? 0,
      correctVotes: json['correct_votes'] ?? 0,
      totalVotes: json['total_votes'] ?? 0,
      clubFan: json['club_fan']?.toString() ?? 'Football Fan',
      countryFan: json['country_fan']?.toString() ?? 'World',
    );
  }

  Map<String, dynamic> toJson() => {
        'user_id': userId,
        'username': username,
        'nickname': nickname,
        'role': role,
        'season_points': seasonPoints,
        'correct_votes': correctVotes,
        'total_votes': totalVotes,
        'club_fan': clubFan,
        'country_fan': countryFan,
      };

  bool get isAdmin => role == 'admin';
}

// ============================================================================
// MAIN MODAL
// ============================================================================

class SwipeableProfileModal extends StatefulWidget {
  final String apiBaseUrl;
  final String userId;
  final String username;
  final String phone;
  final Function(UserData)? onUserUpdated;
  final VoidCallback? onLogout;
  final List<UserChannel> userChannels;

  const SwipeableProfileModal({
    super.key,
    required this.apiBaseUrl,
    required this.userId,
    required this.username,
    required this.phone,
    this.onUserUpdated,
    this.onLogout,
    this.userChannels = const [],
  });

  @override
  State<SwipeableProfileModal> createState() => _SwipeableProfileModalState();
}

class _SwipeableProfileModalState extends State<SwipeableProfileModal>
    with SingleTickerProviderStateMixin {
  // ==========================================================================
  // STATE
  // ==========================================================================

  late TabController _tabController;
  int _selectedTab = 0;

  // Profile data
  UserData? _userData;
  bool _isLoading = true;
  bool _isEditing = false;
  bool _isSaving = false;
  bool _isLoggingOut = false;

  // Text controllers
  late TextEditingController _nicknameController;
  late TextEditingController _clubController;
  late TextEditingController _countryController;
  final FocusNode _nicknameFocus = FocusNode();
  final FocusNode _clubFocus = FocusNode();
  final FocusNode _countryFocus = FocusNode();

  // Balance
  double _balance = 0.0;
  bool _isBalanceLoading = true;

  // Payment
  bool _isProcessingPayment = false;
  String? _currentCheckoutRequestId;
  Timer? _pollingTimer;

  // Top up phone
  String? _savedTopUpPhone;
  String? _savedWithdrawPhone;

  final AuthService _authService = AuthService();

  static const String _api = 'https://clash-api-m5mr.onrender.com/api';
  static const Duration _timeout = Duration(seconds: 15);

  bool get _isCurrentUser => widget.userId == _authService.userId;

  // Local channels list
  List<UserChannel> _userChannels = [];

  // ==========================================================================
  // INIT
  // ==========================================================================

  @override
  void initState() {
    super.initState();

    // Initialize with widget.userChannels
    _userChannels = List.from(widget.userChannels);

    final channelCount = _userChannels.length.clamp(0, 3);
    _tabController = TabController(length: channelCount, vsync: this);
    _tabController.addListener(() {
      if (_tabController.indexIsChanging) {
        setState(() => _selectedTab = _tabController.index);
      }
    });

    _nicknameController = TextEditingController();
    _clubController = TextEditingController();
    _countryController = TextEditingController();

    _loadUserData();
    if (_isCurrentUser) {
      _fetchBalance();
      _fetchSavedPhones();
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    _nicknameController.dispose();
    _clubController.dispose();
    _countryController.dispose();
    _nicknameFocus.dispose();
    _clubFocus.dispose();
    _countryFocus.dispose();
    _pollingTimer?.cancel();
    super.dispose();
  }

  // ==========================================================================
  // DATA LOADING
  // ==========================================================================

  Map<String, String> _headers() => {
        'Content-Type': 'application/json',
      };

  Future<void> _loadUserData() async {
    setState(() => _isLoading = true);
    try {
      final response = await http
          .get(
            Uri.parse(
                '${widget.apiBaseUrl}/api/profile/profile/${widget.userId}'),
            headers: _headers(),
          )
          .timeout(_timeout);

      if (response.statusCode == 200 && mounted) {
        final decoded = jsonDecode(response.body);
        final Map<String, dynamic> userMap = decoded is List
            ? Map<String, dynamic>.from(decoded.first as Map)
            : Map<String, dynamic>.from(decoded);
        final user = UserData.fromJson(userMap);
        setState(() {
          _userData = user;
          _balance = user.balance;
          _nicknameController.text = user.nickname;
          _clubController.text = user.clubFan;
          _countryController.text = user.countryFan;
          _isLoading = false;
        });
      } else if (response.statusCode == 404) {
        setState(() {
          _isLoading = false;
          _isEditing = true;
        });
      } else {
        setState(() => _isLoading = false);
      }
    } catch (e) {
      debugPrint('❌ Load user error: $e');
      setState(() => _isLoading = false);
    }
  }

  Future<void> _fetchBalance() async {
    if (!_isCurrentUser) return;
    setState(() => _isBalanceLoading = true);
    try {
      final response = await http
          .get(
            Uri.parse('$_api/auth/user/id/${widget.userId}'),
            headers: _headers(),
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200 && mounted) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          final balance = (data['user']['balance'] ?? 0.0).toDouble();
          setState(() {
            _balance = balance;
            if (_userData != null) {
              _userData = UserData(
                userId: _userData!.userId,
                username: _userData!.username,
                phone: _userData!.phone,
                nickname: _userData!.nickname,
                clubFan: _userData!.clubFan,
                countryFan: _userData!.countryFan,
                numberOfBets: _userData!.numberOfBets,
                balance: balance,
              );
            }
          });
        }
      }
    } catch (e) {
      debugPrint('❌ Fetch balance error: $e');
    } finally {
      if (mounted) setState(() => _isBalanceLoading = false);
    }
  }

  Future<void> _fetchSavedPhones() async {
    if (!_isCurrentUser) return;
    try {
      final topUpRes = await http
          .get(
            Uri.parse('$_api/auth/user/${widget.userId}/topup-phone'),
            headers: _headers(),
          )
          .timeout(const Duration(seconds: 5));
      if (topUpRes.statusCode == 200) {
        final data = jsonDecode(topUpRes.body);
        if (data['success'] == true) {
          setState(() => _savedTopUpPhone = data['phone']?.toString());
        }
      }

      final withdrawRes = await http
          .get(
            Uri.parse('$_api/auth/user/${widget.userId}/withdraw-phone'),
            headers: _headers(),
          )
          .timeout(const Duration(seconds: 5));
      if (withdrawRes.statusCode == 200) {
        final data = jsonDecode(withdrawRes.body);
        if (data['success'] == true) {
          setState(() => _savedWithdrawPhone = data['phone']?.toString());
        }
      }
    } catch (e) {
      debugPrint('❌ Fetch phones error: $e');
    }
  }

  // ==========================================================================
  // SAVE PROFILE
  // ==========================================================================

  Future<void> _saveProfile() async {
    if (!_isCurrentUser) return;

    final nickname = _nicknameController.text.trim();
    final club = _clubController.text.trim();
    final country = _countryController.text.trim();

    if (nickname.isEmpty) {
      ToastHelper.showWarning('Nickname is required');
      return;
    }
    if (club.isEmpty) {
      ToastHelper.showWarning('Favorite club is required');
      return;
    }
    if (country.isEmpty) {
      ToastHelper.showWarning('Country is required');
      return;
    }

    setState(() => _isSaving = true);

    try {
      final body = {
        'user_id': widget.userId,
        'username': widget.username,
        'phone': widget.phone,
        'nickname': nickname,
        'club_fan': club,
        'country_fan': country,
        'balance': _balance,
        'number_of_bets': _userData?.numberOfBets ?? 0,
      };

      final url = _userData == null
          ? '${widget.apiBaseUrl}/api/profile/create_profile'
          : '${widget.apiBaseUrl}/api/profile/profiles/${widget.userId}';

      final response = await http
          .post(
            Uri.parse(url),
            headers: _headers(),
            body: jsonEncode(body),
          )
          .timeout(_timeout);

      if ((response.statusCode == 200 || response.statusCode == 201) &&
          mounted) {
        final decoded = jsonDecode(response.body);
        final Map<String, dynamic> userMap = decoded is List
            ? Map<String, dynamic>.from(decoded.first as Map)
            : Map<String, dynamic>.from(decoded);

        final user = UserData.fromJson(userMap);
        setState(() {
          _userData = user;
          _balance = user.balance;
          _isEditing = false;
        });
        widget.onUserUpdated?.call(user);
        ToastHelper.showSuccess('Profile saved!');
        _unfocusAll();
        Future.delayed(const Duration(milliseconds: 300), () {
          if (mounted) Navigator.pop(context);
        });
      } else {
        ToastHelper.showError('Save failed. Please try again.');
      }
    } catch (e) {
      debugPrint('❌ Save profile error: $e');
      ToastHelper.showError('Network error. Please try again.');
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  void _unfocusAll() {
    _nicknameFocus.unfocus();
    _clubFocus.unfocus();
    _countryFocus.unfocus();
    FocusScope.of(context).unfocus();
  }

  // ==========================================================================
  // LOGOUT
  // ==========================================================================

  Future<void> _logout() async {
    if (!_isCurrentUser || _isLoggingOut) return;
    setState(() => _isLoggingOut = true);

    try {
      await FirebaseAuth.instance.signOut();
      await _authService.logout();
      widget.onLogout?.call();
      if (mounted) {
        Navigator.pop(context);
        ToastHelper.showSuccess('Logged out');
      }
    } catch (e) {
      debugPrint('❌ Logout error: $e');
      ToastHelper.showError('Logout failed');
    } finally {
      if (mounted) setState(() => _isLoggingOut = false);
    }
  }

  // ==========================================================================
  // STK PUSH - TOP UP (Only for current user)
  // ==========================================================================

  Future<void> _showTopUpDialog() async {
    if (!_isCurrentUser) return;

    final amountController = TextEditingController();
    final phoneController = TextEditingController();
    bool useSaved = true;

    if (_savedTopUpPhone != null && _savedTopUpPhone!.isNotEmpty) {
      phoneController.text = _savedTopUpPhone!;
    }

    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          backgroundColor: FanColors.surfaceElevated,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(FanRadius.lg),
            side: const BorderSide(color: FanColors.border),
          ),
          title: Row(
            children: [
              Icon(Icons.add_circle, color: FanColors.secondary, size: 24),
              const SizedBox(width: 8),
              const Text('Top Up Balance'),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildBalanceDisplay(),
              const SizedBox(height: 16),
              TextField(
                controller: amountController,
                decoration: const InputDecoration(
                  labelText: 'Amount (KES)',
                  hintText: 'Enter amount to top up',
                  prefixIcon: Icon(Icons.monetization_on),
                ),
                keyboardType: TextInputType.number,
                autofocus: true,
              ),
              const SizedBox(height: 12),
              TextField(
                controller: phoneController,
                decoration: InputDecoration(
                  labelText: 'M-Pesa Phone Number',
                  hintText: 'e.g., 0712345678',
                  prefixIcon: const Icon(Icons.phone_android),
                  suffixIcon: IconButton(
                    icon: const Icon(Icons.clear, size: 18),
                    onPressed: () => phoneController.clear(),
                  ),
                ),
                keyboardType: TextInputType.phone,
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Checkbox(
                    value: useSaved,
                    onChanged: (val) {
                      setState(() {
                        useSaved = val ?? true;
                        if (useSaved && _savedTopUpPhone != null) {
                          phoneController.text = _savedTopUpPhone!;
                        } else {
                          phoneController.clear();
                        }
                      });
                    },
                    activeColor: FanColors.primary,
                  ),
                  Expanded(
                    child: Text(
                      'Save this number for future top-ups',
                      style: TextStyle(
                        fontSize: 12,
                        color: FanColors.textSecondary,
                      ),
                    ),
                  ),
                ],
              ),
              _buildInfoBox(
                icon: Icons.info_outline,
                color: FanColors.primary,
                text: 'You will receive a prompt to enter your PIN',
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel',
                  style: TextStyle(color: FanColors.textSecondary)),
            ),
            ElevatedButton(
              onPressed: () async {
                final amount = double.tryParse(amountController.text.trim());
                final phone = phoneController.text.trim();

                if (amount == null || amount <= 0) {
                  ToastHelper.showWarning('Enter a valid amount');
                  return;
                }
                if (phone.isEmpty || !_isValidPhone(phone)) {
                  ToastHelper.showWarning('Enter a valid phone number');
                  return;
                }

                Navigator.pop(context);
                final success = await _initiateSTKPush(amount, phone);
                if (success && mounted) {
                  if (useSaved) await _saveTopUpPhone(phone);
                  await _fetchBalance();
                  ToastHelper.showSuccess('Balance updated!');
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: FanColors.primary,
              ),
              child: _isProcessingPayment
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : const Text('Pay via M-Pesa'),
            ),
          ],
        ),
      ),
    );
  }

  Future<bool> _initiateSTKPush(double amount, String phone) async {
    if (_isProcessingPayment || !_isCurrentUser) return false;
    setState(() => _isProcessingPayment = true);

    try {
      final response = await http
          .post(
            Uri.parse('$_api/lipaclash/stk-push'),
            headers: _headers(),
            body: jsonEncode({
              'phone_number': phone,
              'amount': amount.toString(),
              'account_reference': widget.username,
              'transaction_desc': 'Top up balance',
            }),
          )
          .timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          _currentCheckoutRequestId = data['checkout_request_id'];
          final completed =
              await _waitForSTKCompletion(_currentCheckoutRequestId!);
          setState(() => _isProcessingPayment = false);
          return completed;
        }
      }
      ToastHelper.showError('Payment initiation failed');
      setState(() => _isProcessingPayment = false);
      return false;
    } catch (e) {
      debugPrint('❌ STK Push error: $e');
      ToastHelper.showError('Failed to initiate payment');
      setState(() => _isProcessingPayment = false);
      return false;
    }
  }

  Future<bool> _waitForSTKCompletion(String checkoutRequestId) async {
    final completer = Completer<bool>();

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: FanColors.surfaceElevated,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(FanRadius.lg),
        ),
        title: const Text('Processing Payment'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const CircularProgressIndicator(color: FanColors.primary),
            const SizedBox(height: 16),
            Text(
              'Enter PIN on your phone to complete payment',
              style: TextStyle(color: Colors.white.withOpacity(0.7)),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                _pollingTimer?.cancel();
                completer.complete(false);
              },
              child: const Text('Cancel'),
            ),
          ],
        ),
      ),
    );

    int attempts = 0;
    while (attempts < 60) {
      await Future.delayed(const Duration(seconds: 1));
      attempts++;

      try {
        final status = await _checkSTKStatus(checkoutRequestId);
        if (status == 'completed') {
          if (mounted) Navigator.pop(context);
          ToastHelper.showSuccess('Payment successful!');
          completer.complete(true);
          return true;
        } else if (status == 'failed' || status == 'cancelled') {
          if (mounted) Navigator.pop(context);
          ToastHelper.showError(
              'Payment ${status == 'cancelled' ? 'cancelled' : 'failed'}');
          completer.complete(false);
          return false;
        }
      } catch (e) {
        debugPrint('❌ Status check error: $e');
      }
    }

    if (mounted) Navigator.pop(context);
    ToastHelper.showWarning('Payment timeout - check your phone');
    completer.complete(false);
    return false;
  }

  Future<String> _checkSTKStatus(String checkoutRequestId) async {
    try {
      final response = await http
          .post(
            Uri.parse('$_api/lipaclash/check-payment-status'),
            headers: _headers(),
            body: jsonEncode({'checkout_request_id': checkoutRequestId}),
          )
          .timeout(const Duration(seconds: 5));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) return 'completed';
        if (data['failed'] == true) return 'failed';
        if (data['cancelled'] == true) return 'cancelled';
      }
      return 'pending';
    } catch (e) {
      return 'pending';
    }
  }

  // ==========================================================================
  // B2C WITHDRAWAL (Only for current user)
  // ==========================================================================

  Future<void> _showWithdrawDialog() async {
    if (!_isCurrentUser) return;

    final amountController = TextEditingController();
    final phoneController = TextEditingController();
    bool useSaved = true;

    if (_savedWithdrawPhone != null && _savedWithdrawPhone!.isNotEmpty) {
      phoneController.text = _savedWithdrawPhone!;
    }

    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          backgroundColor: FanColors.surfaceElevated,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(FanRadius.lg),
            side: const BorderSide(color: FanColors.border),
          ),
          title: Row(
            children: [
              Icon(Icons.account_balance, color: Colors.orange, size: 24),
              const SizedBox(width: 8),
              const Text('Withdraw Funds'),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildBalanceDisplay(),
              const SizedBox(height: 16),
              TextField(
                controller: amountController,
                decoration: const InputDecoration(
                  labelText: 'Amount (KES)',
                  hintText: 'Enter amount to withdraw',
                  prefixIcon: Icon(Icons.monetization_on),
                ),
                keyboardType: TextInputType.number,
                autofocus: true,
              ),
              const SizedBox(height: 12),
              TextField(
                controller: phoneController,
                decoration: InputDecoration(
                  labelText: 'M-Pesa Phone Number',
                  hintText: 'e.g., 0712345678',
                  prefixIcon: const Icon(Icons.phone_android),
                  suffixIcon: IconButton(
                    icon: const Icon(Icons.clear, size: 18),
                    onPressed: () => phoneController.clear(),
                  ),
                ),
                keyboardType: TextInputType.phone,
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Checkbox(
                    value: useSaved,
                    onChanged: (val) {
                      setState(() {
                        useSaved = val ?? true;
                        if (useSaved && _savedWithdrawPhone != null) {
                          phoneController.text = _savedWithdrawPhone!;
                        } else {
                          phoneController.clear();
                        }
                      });
                    },
                    activeColor: FanColors.primary,
                  ),
                  Expanded(
                    child: Text(
                      'Save this number for future withdrawals',
                      style: TextStyle(
                        fontSize: 12,
                        color: FanColors.textSecondary,
                      ),
                    ),
                  ),
                ],
              ),
              _buildInfoBox(
                icon: Icons.warning_amber_rounded,
                color: Colors.orange,
                text: 'Withdrawals are processed within 24 hours',
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel',
                  style: TextStyle(color: FanColors.textSecondary)),
            ),
            ElevatedButton(
              onPressed: () async {
                final amount = double.tryParse(amountController.text.trim());
                final phone = phoneController.text.trim();

                if (amount == null || amount <= 0) {
                  ToastHelper.showWarning('Enter a valid amount');
                  return;
                }
                if (amount > _balance) {
                  ToastHelper.showWarning('Insufficient balance');
                  return;
                }
                if (phone.isEmpty || !_isValidPhone(phone)) {
                  ToastHelper.showWarning('Enter a valid phone number');
                  return;
                }

                Navigator.pop(context);
                final success = await _processWithdrawal(amount, phone);
                if (success && mounted) {
                  if (useSaved) await _saveWithdrawPhone(phone);
                  await _fetchBalance();
                  ToastHelper.showSuccess('Withdrawal submitted!');
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange,
              ),
              child: _isWithdrawing
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : const Text('Withdraw'),
            ),
          ],
        ),
      ),
    );
  }

  bool _isWithdrawing = false;

  Future<bool> _processWithdrawal(double amount, String phone) async {
    if (!_isCurrentUser) return false;
    setState(() => _isWithdrawing = true);
    try {
      final response = await http
          .post(
            Uri.parse('$_api/transactions/withdraw'),
            headers: _headers(),
            body: jsonEncode({
              'user_id': widget.userId,
              'username': widget.username,
              'amount': amount,
              'phone_number': phone,
            }),
          )
          .timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          setState(() => _isWithdrawing = false);
          return true;
        }
      }
      ToastHelper.showError('Withdrawal failed');
      setState(() => _isWithdrawing = false);
      return false;
    } catch (e) {
      debugPrint('❌ Withdrawal error: $e');
      ToastHelper.showError('Failed to process withdrawal');
      setState(() => _isWithdrawing = false);
      return false;
    }
  }

  // ==========================================================================
  // HELPERS
  // ==========================================================================

  bool _isValidPhone(String phone) {
    final cleaned = phone.replaceAll(RegExp(r'[^0-9]'), '');
    return RegExp(r'^(0|254)?[7-9][0-9]{8}$').hasMatch(cleaned);
  }

  Future<bool> _saveTopUpPhone(String phone) async {
    if (!_isCurrentUser) return false;
    try {
      final response = await http
          .post(
            Uri.parse('$_api/auth/user/${widget.userId}/topup-phone'),
            headers: _headers(),
            body: jsonEncode({'phone': phone}),
          )
          .timeout(const Duration(seconds: 5));
      return response.statusCode == 200;
    } catch (e) {
      return false;
    }
  }

  Future<bool> _saveWithdrawPhone(String phone) async {
    if (!_isCurrentUser) return false;
    try {
      final response = await http
          .post(
            Uri.parse('$_api/auth/user/${widget.userId}/withdraw-phone'),
            headers: _headers(),
            body: jsonEncode({'phone': phone}),
          )
          .timeout(const Duration(seconds: 5));
      return response.statusCode == 200;
    } catch (e) {
      return false;
    }
  }

  String _getInitials() {
    final name = _userData?.nickname ?? widget.username;
    return name.isNotEmpty ? name[0].toUpperCase() : '?';
  }

  // ==========================================================================
  // UI BUILDERS
  // ==========================================================================

  Widget _buildBalanceDisplay() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: FanColors.surface,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: FanColors.border.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Icon(Icons.account_balance_wallet,
              size: 16, color: FanColors.primary),
          const SizedBox(width: 8),
          Text(
            _isBalanceLoading
                ? 'Loading...'
                : 'Balance: KES ${_balance.toStringAsFixed(2)}',
            style: TextStyle(
              fontSize: 13,
              color: _isBalanceLoading
                  ? FanColors.textSecondary
                  : FanColors.textPrimary,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoBox(
      {required IconData icon, required Color color, required String text}) {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.05),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Icon(icon, size: 14, color: color),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: TextStyle(fontSize: 10, color: color),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHandleBar() => Container(
        margin: const EdgeInsets.only(top: 10, bottom: 6),
        width: 40,
        height: 4,
        decoration: BoxDecoration(
          color: FanColors.border.withOpacity(0.3),
          borderRadius: BorderRadius.circular(2),
        ),
      );

  Widget _buildHeader() => Padding(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 12),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: FanColors.primary.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Center(
                child: Text(
                  _getInitials(),
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    color: FanColors.primary,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _userData?.nickname ?? widget.username,
                    style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                  Text(
                    _userChannels.length == 0
                        ? 'No channels'
                        : '${_userChannels.length} ${_userChannels.length == 1 ? 'Channel' : 'Channels'}',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.white.withOpacity(0.6),
                    ),
                  ),
                ],
              ),
            ),
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: FanColors.surface,
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.close, size: 18, color: Colors.white),
              ),
            ),
          ],
        ),
      );

  // ==========================================================================
  // PROFILE SECTION
  // ==========================================================================

  Widget _buildProfileSection() {
    if (_isLoading) {
      return const Center(
        child: SizedBox(
          width: 24,
          height: 24,
          child: CircularProgressIndicator(
            strokeWidth: 2,
            color: FanColors.primary,
          ),
        ),
      );
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        children: [
          // ✅ Balance Card - ONLY for current user
          if (_isCurrentUser) ...[
            _buildBalanceCard(),
            const SizedBox(height: 16),
          ],

          // Profile Info
          _userData == null ? _buildNoProfileView() : _buildProfileView(),
        ],
      ),
    );
  }

  Widget _buildBalanceCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            const Color(0xFFFFD700), // Gold/Yellow
            const Color(0xFFFFA500), // Orange
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: [
          const Icon(Icons.account_balance_wallet,
              size: 24, color: Color(0xFF1A1A2E)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Available Balance',
                  style: TextStyle(
                    fontSize: 11,
                    color: const Color(0xFF1A1A2E).withOpacity(0.7),
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Text(
                  _isBalanceLoading
                      ? 'Loading...'
                      : 'KES ${_balance.toStringAsFixed(2)}',
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF1A1A2E),
                  ),
                ),
              ],
            ),
          ),
          Row(
            children: [
              _buildActionButton(
                icon: Icons.add,
                label: 'Deposit',
                color: const Color(0xFF1A1A2E),
                bgColor: const Color(0xFF1A1A2E).withOpacity(0.15),
                onTap: _showTopUpDialog,
              ),
              const SizedBox(width: 8),
              _buildActionButton(
                icon: Icons.remove,
                label: 'Withdraw',
                color: const Color(0xFF1A1A2E),
                bgColor: const Color(0xFF1A1A2E).withOpacity(0.15),
                onTap: _showWithdrawDialog,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildActionButton({
    required IconData icon,
    required String label,
    required Color color,
    required Color bgColor,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: _isProcessingPayment || _isWithdrawing ? null : onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 14, color: color),
            const SizedBox(width: 4),
            Text(
              label,
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w600,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileView() {
    if (_isEditing) return _buildEditMode();

    return Column(
      children: [
        // Username
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          decoration: BoxDecoration(
            color: FanColors.surface,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: FanColors.border.withOpacity(0.2)),
          ),
          child: Row(
            children: [
              Icon(Icons.person_outline, size: 16, color: FanColors.primary),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Username',
                      style: TextStyle(
                        fontSize: 9,
                        color: FanColors.textSecondary,
                      ),
                    ),
                    Text(
                      '@${_userData!.username}',
                      style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),

        // Team/Club
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          decoration: BoxDecoration(
            color: FanColors.surface,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: FanColors.border.withOpacity(0.2)),
          ),
          child: Row(
            children: [
              Icon(Icons.sports_soccer_outlined,
                  size: 16, color: FanColors.primary),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Team/Club',
                      style: TextStyle(
                        fontSize: 9,
                        color: FanColors.textSecondary,
                      ),
                    ),
                    Text(
                      _userData!.clubFan.isNotEmpty
                          ? _userData!.clubFan
                          : 'Not set',
                      style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),

        // Country
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          decoration: BoxDecoration(
            color: FanColors.surface,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: FanColors.border.withOpacity(0.2)),
          ),
          child: Row(
            children: [
              Icon(Icons.flag_outlined, size: 16, color: FanColors.primary),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Country',
                      style: TextStyle(
                        fontSize: 9,
                        color: FanColors.textSecondary,
                      ),
                    ),
                    Text(
                      _userData!.countryFan.isNotEmpty
                          ? _userData!.countryFan
                          : 'Not set',
                      style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),

        // Phone
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          decoration: BoxDecoration(
            color: FanColors.surface,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: FanColors.border.withOpacity(0.2)),
          ),
          child: Row(
            children: [
              Icon(Icons.phone_outlined, size: 16, color: FanColors.primary),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Phone',
                      style: TextStyle(
                        fontSize: 9,
                        color: FanColors.textSecondary,
                      ),
                    ),
                    Text(
                      _userData!.phone.isNotEmpty
                          ? _userData!.phone
                          : 'Not set',
                      style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),

        // ✅ Edit & Logout buttons - ONLY for current user
        if (_isCurrentUser)
          Row(
            children: [
              Expanded(
                child: _buildActionButtonLarge(
                  label: 'Edit Profile',
                  icon: Icons.edit_outlined,
                  onTap: () => setState(() => _isEditing = true),
                  isPrimary: true,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildActionButtonLarge(
                  label: 'Logout',
                  icon: Icons.logout_outlined,
                  onTap: _logout,
                  isPrimary: false,
                  isLoading: _isLoggingOut,
                ),
              ),
            ],
          ),
      ],
    );
  }

  Widget _buildNoProfileView() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Center(
          child: Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(
              color: FanColors.primary.withOpacity(0.08),
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Icon(
                Icons.person_add_alt_1_outlined,
                size: 32,
                color: FanColors.primary,
              ),
            ),
          ),
        ),
        const SizedBox(height: 16),
        Center(
          child: Text(
            'Complete Your Profile',
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: Colors.white,
            ),
          ),
        ),
        const SizedBox(height: 6),
        Center(
          child: Text(
            'Tell us about yourself',
            style: TextStyle(fontSize: 11, color: FanColors.textSecondary),
          ),
        ),
        const SizedBox(height: 24),
        _buildTextField(
          controller: _nicknameController,
          focusNode: _nicknameFocus,
          label: 'NICKNAME',
          hint: 'How should we call you?',
          icon: Icons.tag_outlined,
          onSubmitted: () => _clubFocus.requestFocus(),
        ),
        const SizedBox(height: 16),
        _buildTextField(
          controller: _clubController,
          focusNode: _clubFocus,
          label: 'FAVORITE CLUB',
          hint: 'Which club do you support?',
          icon: Icons.sports_soccer_outlined,
          onSubmitted: () => _countryFocus.requestFocus(),
        ),
        const SizedBox(height: 16),
        _buildTextField(
          controller: _countryController,
          focusNode: _countryFocus,
          label: 'COUNTRY',
          hint: 'Where are you from?',
          icon: Icons.flag_outlined,
          onSubmitted: _unfocusAll,
        ),
        const SizedBox(height: 24),
        _buildActionButtonLarge(
          label: 'Complete Profile',
          icon: Icons.check_circle_outline,
          onTap: _saveProfile,
          isPrimary: true,
          isLoading: _isSaving,
        ),
      ],
    );
  }

  Widget _buildEditMode() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Center(
          child: Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              color: FanColors.primary.withOpacity(0.08),
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Icon(
                Icons.person_outline,
                size: 28,
                color: FanColors.primary,
              ),
            ),
          ),
        ),
        const SizedBox(height: 20),
        _buildTextField(
          controller: _nicknameController,
          focusNode: _nicknameFocus,
          label: 'NICKNAME',
          hint: 'How should we call you?',
          icon: Icons.tag_outlined,
          onSubmitted: () => _clubFocus.requestFocus(),
        ),
        const SizedBox(height: 16),
        _buildTextField(
          controller: _clubController,
          focusNode: _clubFocus,
          label: 'FAVORITE CLUB',
          hint: 'Which club do you support?',
          icon: Icons.sports_soccer_outlined,
          onSubmitted: () => _countryFocus.requestFocus(),
        ),
        const SizedBox(height: 16),
        _buildTextField(
          controller: _countryController,
          focusNode: _countryFocus,
          label: 'COUNTRY',
          hint: 'Where are you from?',
          icon: Icons.flag_outlined,
          onSubmitted: _unfocusAll,
        ),
        const SizedBox(height: 24),
        Row(
          children: [
            Expanded(
              child: _buildActionButtonLarge(
                label: 'Cancel',
                icon: Icons.close_outlined,
                onTap: () {
                  setState(() => _isEditing = false);
                  _unfocusAll();
                },
                isPrimary: false,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _buildActionButtonLarge(
                label: 'Save',
                icon: Icons.save_outlined,
                onTap: _saveProfile,
                isPrimary: true,
                isLoading: _isSaving,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required FocusNode focusNode,
    required String label,
    required String hint,
    IconData? icon,
    VoidCallback? onSubmitted,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 10,
            color: FanColors.textSecondary,
            letterSpacing: 0.5,
          ),
        ),
        const SizedBox(height: 6),
        Container(
          decoration: BoxDecoration(
            color: FanColors.surface,
            borderRadius: BorderRadius.circular(10),
          ),
          child: TextFormField(
            controller: controller,
            focusNode: focusNode,
            textInputAction: TextInputAction.next,
            onFieldSubmitted: (_) => onSubmitted?.call(),
            style: const TextStyle(fontSize: 13, color: Colors.white),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle:
                  TextStyle(fontSize: 11, color: FanColors.textSecondary),
              prefixIcon: icon != null
                  ? Icon(icon, size: 14, color: FanColors.textSecondary)
                  : null,
              border: InputBorder.none,
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              isDense: true,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildActionButtonLarge({
    required String label,
    required IconData icon,
    required VoidCallback onTap,
    bool isPrimary = true,
    bool isLoading = false,
  }) {
    return GestureDetector(
      onTap: isLoading ? null : onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: isPrimary ? FanColors.primary : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
          border: !isPrimary
              ? Border.all(color: FanColors.border.withOpacity(0.3))
              : null,
        ),
        child: Center(
          child: isLoading
              ? const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Colors.white,
                  ),
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      icon,
                      size: 14,
                      color: isPrimary ? Colors.white : FanColors.primary,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      label,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                        color: isPrimary ? Colors.white : FanColors.primary,
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  // ==========================================================================
  // CHANNEL FRAGMENT (Swipable Tabs)
  // ==========================================================================

  Widget _buildChannelFragment(int channelIndex) {
    if (_userChannels.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.group_off_outlined,
              size: 40,
              color: FanColors.textSecondary.withOpacity(0.4),
            ),
            const SizedBox(height: 12),
            Text(
              _isCurrentUser
                  ? 'No channels joined'
                  : '${widget.username} has no channels',
              style: TextStyle(
                fontSize: 13,
                color: FanColors.textSecondary.withOpacity(0.5),
              ),
            ),
            const SizedBox(height: 4),
            Text(
              _isCurrentUser
                  ? 'Join a channel to see members'
                  : 'They haven\'t joined any channels yet',
              style: TextStyle(
                fontSize: 10,
                color: FanColors.textSecondary.withOpacity(0.3),
              ),
            ),
          ],
        ),
      );
    }

    final channel = _userChannels[channelIndex];
    final members = channel.members;

    // Sort members by season points (highest first)
    final sortedMembers = List<ChannelMember>.from(members)
      ..sort((a, b) => b.seasonPoints.compareTo(a.seasonPoints));

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Channel header
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  const Color(0xFFFFD700).withOpacity(0.15),
                  const Color(0xFFFFA500).withOpacity(0.05),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: const Color(0xFFFFD700).withOpacity(0.2),
                width: 1,
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFD700).withOpacity(0.15),
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Text(
                      channel.name.isNotEmpty
                          ? channel.name[0].toUpperCase()
                          : '?',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFFFFD700),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        channel.name,
                        style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                      Row(
                        children: [
                          Icon(
                            Icons.people,
                            size: 12,
                            color: const Color(0xFFFFD700).withOpacity(0.6),
                          ),
                          const SizedBox(width: 4),
                          Text(
                            '${channel.memberCount} members',
                            style: TextStyle(
                              fontSize: 10,
                              color: const Color(0xFFFFD700).withOpacity(0.6),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Icon(
                            Icons.emoji_events,
                            size: 12,
                            color: const Color(0xFFFFD700).withOpacity(0.6),
                          ),
                          const SizedBox(width: 4),
                          Text(
                            'Season ${channel.season}',
                            style: TextStyle(
                              fontSize: 10,
                              color: const Color(0xFFFFD700).withOpacity(0.6),
                            ),
                          ),
                          if (channel.isAdmin) ...[
                            const SizedBox(width: 12),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 2,
                              ),
                              decoration: BoxDecoration(
                                color:
                                    const Color(0xFFFFD700).withOpacity(0.15),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: const Text(
                                '👑 Admin',
                                style: TextStyle(
                                  fontSize: 8,
                                  fontWeight: FontWeight.w600,
                                  color: Color(0xFFFFD700),
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),

          // Members list
          Expanded(
            child: sortedMembers.isEmpty
                ? Center(
                    child: Text(
                      'No members yet',
                      style: TextStyle(
                        fontSize: 12,
                        color: FanColors.textSecondary.withOpacity(0.4),
                      ),
                    ),
                  )
                : ListView.builder(
                    itemCount: sortedMembers.length,
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    itemBuilder: (context, index) {
                      final member = sortedMembers[index];
                      final isTop3 = index < 3;
                      final rankColors = [
                        const Color(0xFFFFD700), // Gold
                        const Color(0xFFC0C0C0), // Silver
                        const Color(0xFFCD7F32), // Bronze
                      ];
                      final rankEmojis = ['🥇', '🥈', '🥉'];

                      return Container(
                        margin: const EdgeInsets.only(bottom: 4),
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: isTop3
                              ? const Color(0xFFFFD700).withOpacity(0.08)
                              : FanColors.surface.withOpacity(0.5),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            color: isTop3
                                ? rankColors[index].withOpacity(0.3)
                                : FanColors.border.withOpacity(0.1),
                            width: isTop3 ? 1 : 0.5,
                          ),
                        ),
                        child: Row(
                          children: [
                            // Rank or position
                            Container(
                              width: 28,
                              height: 28,
                              alignment: Alignment.center,
                              child: isTop3
                                  ? Text(
                                      rankEmojis[index],
                                      style: const TextStyle(fontSize: 16),
                                    )
                                  : Text(
                                      '#${index + 1}',
                                      style: TextStyle(
                                        fontSize: 10,
                                        fontWeight: FontWeight.w600,
                                        color: FanColors.textSecondary
                                            .withOpacity(0.4),
                                      ),
                                    ),
                            ),
                            const SizedBox(width: 8),

                            // Avatar
                            Container(
                              width: 32,
                              height: 32,
                              decoration: BoxDecoration(
                                color: FanColors.primary.withOpacity(0.08),
                                shape: BoxShape.circle,
                              ),
                              child: Center(
                                child: Text(
                                  member.nickname.isNotEmpty
                                      ? member.nickname[0].toUpperCase()
                                      : '?',
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                    color: isTop3
                                        ? rankColors[index]
                                        : FanColors.primary,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 10),

                            // Name and team
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Text(
                                        member.nickname,
                                        style: const TextStyle(
                                          fontSize: 12,
                                          fontWeight: FontWeight.w600,
                                          color: Colors.white,
                                        ),
                                      ),
                                      if (member.userId == widget.userId &&
                                          _isCurrentUser) ...[
                                        const SizedBox(width: 4),
                                        Container(
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 4,
                                            vertical: 1,
                                          ),
                                          decoration: BoxDecoration(
                                            color: const Color(0xFFFFD700)
                                                .withOpacity(0.15),
                                            borderRadius:
                                                BorderRadius.circular(4),
                                          ),
                                          child: const Text(
                                            'You',
                                            style: TextStyle(
                                              fontSize: 7,
                                              fontWeight: FontWeight.w600,
                                              color: Color(0xFFFFD700),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ],
                                  ),
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.sports_soccer,
                                        size: 10,
                                        color: FanColors.textSecondary
                                            .withOpacity(0.5),
                                      ),
                                      const SizedBox(width: 4),
                                      Text(
                                        member.clubFan.isNotEmpty
                                            ? member.clubFan
                                            : 'No club',
                                        style: TextStyle(
                                          fontSize: 9,
                                          color: FanColors.textSecondary
                                              .withOpacity(0.6),
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      Icon(
                                        Icons.flag,
                                        size: 10,
                                        color: FanColors.textSecondary
                                            .withOpacity(0.5),
                                      ),
                                      const SizedBox(width: 4),
                                      Text(
                                        member.countryFan.isNotEmpty
                                            ? member.countryFan
                                            : 'Unknown',
                                        style: TextStyle(
                                          fontSize: 9,
                                          color: FanColors.textSecondary
                                              .withOpacity(0.6),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),

                            // Points
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: isTop3
                                    ? rankColors[index].withOpacity(0.15)
                                    : FanColors.primary.withOpacity(0.08),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.star,
                                    size: 10,
                                    color: isTop3
                                        ? rankColors[index]
                                        : FanColors.primary.withOpacity(0.5),
                                  ),
                                  const SizedBox(width: 4),
                                  Text(
                                    '${member.seasonPoints} pts',
                                    style: TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.w600,
                                      color: isTop3
                                          ? rankColors[index]
                                          : FanColors.primary,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 8),

                            // Profile button - ONLY for current user viewing their own profile
                            if (_isCurrentUser)
                              GestureDetector(
                                onTap: () {
                                  _showMemberProfile(member);
                                },
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 10,
                                    vertical: 4,
                                  ),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFFFD700)
                                        .withOpacity(0.15),
                                    borderRadius: BorderRadius.circular(8),
                                    border: Border.all(
                                      color: const Color(0xFFFFD700)
                                          .withOpacity(0.2),
                                      width: 0.5,
                                    ),
                                  ),
                                  child: const Text(
                                    'Profile',
                                    style: TextStyle(
                                      fontSize: 9,
                                      fontWeight: FontWeight.w600,
                                      color: Color(0xFFFFD700),
                                    ),
                                  ),
                                ),
                              ),
                          ],
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  void _showMemberProfile(ChannelMember member) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => SwipeableProfileModal(
        apiBaseUrl: widget.apiBaseUrl,
        userId: member.userId,
        username: member.username,
        phone: '',
        userChannels: _userChannels,
        onUserUpdated: (_) {},
        onLogout: () {},
      ),
    );
  }

  // ==========================================================================
  // CHANNEL TAB BAR
  // ==========================================================================

  Widget _buildChannelTabBar() {
    final channelCount = _userChannels.length.clamp(0, 3);

    if (channelCount == 0) {
      return Container(
        margin: const EdgeInsets.symmetric(horizontal: 20),
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: FanColors.surface,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Center(
          child: Text(
            _isCurrentUser ? 'No Channels' : 'No Channels to show',
            style: TextStyle(
              fontSize: 13,
              color: FanColors.textSecondary,
            ),
          ),
        ),
      );
    }

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: FanColors.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: const Color(0xFFFFD700).withOpacity(0.15),
          width: 0.5,
        ),
      ),
      child: TabBar(
        controller: _tabController,
        indicator: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              const Color(0xFFFFD700).withOpacity(0.15),
              const Color(0xFFFFA500).withOpacity(0.1),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: const Color(0xFFFFD700).withOpacity(0.2),
            width: 0.5,
          ),
        ),
        indicatorSize: TabBarIndicatorSize.tab,
        labelColor: const Color(0xFFFFD700),
        unselectedLabelColor: FanColors.textSecondary,
        labelStyle: const TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w600,
        ),
        unselectedLabelStyle: const TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w400,
        ),
        tabs: _userChannels.take(3).map((channel) {
          return Tab(
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 20,
                  height: 20,
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFD700).withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Text(
                      channel.name.isNotEmpty
                          ? channel.name[0].toUpperCase()
                          : '?',
                      style: const TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFFFFD700),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 6),
                Text(
                  channel.name.length > 12
                      ? '${channel.name.substring(0, 12)}...'
                      : channel.name,
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }

  // ==========================================================================
  // MAIN BUILD
  // ==========================================================================

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;
    final channelCount = _userChannels.length.clamp(0, 3);

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: EdgeInsets.zero,
      child: Container(
        width: screenWidth,
        height: screenHeight * 0.85,
        decoration: BoxDecoration(
          color: FanColors.background,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildHandleBar(),
            _buildHeader(),

            // Fixed Profile Section
            Expanded(
              flex: 3,
              child: _buildProfileSection(),
            ),

            // Divider with gold/yellow accent
            Container(
              height: 1,
              margin: const EdgeInsets.symmetric(horizontal: 20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.transparent,
                    const Color(0xFFFFD700).withOpacity(0.3),
                    const Color(0xFFFFA500).withOpacity(0.2),
                    Colors.transparent,
                  ],
                ),
              ),
            ),

            // Channel Tabs (Swipable)
            if (channelCount > 0) ...[
              const SizedBox(height: 8),
              _buildChannelTabBar(),
              const SizedBox(height: 6),
              Expanded(
                flex: 3,
                child: TabBarView(
                  controller: _tabController,
                  physics: const BouncingScrollPhysics(),
                  children: List.generate(
                    channelCount,
                    (index) => _buildChannelFragment(index),
                  ),
                ),
              ),
            ] else ...[
              const SizedBox(height: 20),
              Expanded(
                flex: 3,
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.group_off_outlined,
                        size: 48,
                        color: FanColors.textSecondary.withOpacity(0.3),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        _isCurrentUser
                            ? 'No Channels Joined'
                            : '${widget.username} has no channels',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: FanColors.textSecondary.withOpacity(0.5),
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        _isCurrentUser
                            ? 'Join a channel to see members here'
                            : 'They haven\'t joined any channels yet',
                        style: TextStyle(
                          fontSize: 11,
                          color: FanColors.textSecondary.withOpacity(0.3),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],

            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }
}
