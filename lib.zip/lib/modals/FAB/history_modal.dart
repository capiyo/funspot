// ========== HISTORY GAMES MODAL ==========

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../../models/fixture_models.dart';
import '../../pages/social_theme.dart';

class HistoryGameModal extends StatefulWidget {
  final String userId;
  final String username;
  final String? authToken;

  const HistoryGameModal({
    super.key,
    required this.userId,
    required this.username,
    this.authToken,
  });

  @override
  State<HistoryGameModal> createState() => _HistoryGameModalState();
}

class _HistoryGameModalState extends State<HistoryGameModal> {
  List<HistoryGame> _historyGames = [];
  bool _loading = true;
  bool _loadingMore = false;
  String _error = '';
  int _currentPage = 0;
  int _totalGames = 0;
  final int _limit = 20;

  // Filters
  String? _selectedLeague;
  String? _searchQuery;
  DateTime? _fromDate;
  DateTime? _toDate;

  final List<String> _leagues = [
    'Premier League',
    'Champions League',
    'Europa League',
    'FA Cup',
    'Serie A',
    'La Liga',
  ];

  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _fetchHistoryGames();
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent - 100) {
      if (!_loadingMore && !_loading && _historyGames.length < _totalGames) {
        _fetchHistoryGames(loadMore: true);
      }
    }
  }

  Future<void> _fetchHistoryGames({bool loadMore = false}) async {
    if (loadMore) {
      if (_loadingMore) return;
      setState(() => _loadingMore = true);
    } else {
      setState(() => _loading = true);
    }

    try {
      final skip = loadMore ? (_currentPage + 1) * _limit : 0;
      const String apiBaseUrl = "https://clash-api-m5mr.onrender.com/api";

      final Map<String, String> queryParams = {
        'limit': _limit.toString(),
        'skip': skip.toString(),
        if (_selectedLeague != null) 'league': _selectedLeague!,
        if (_searchQuery != null && _searchQuery!.isNotEmpty)
          'home_team': _searchQuery!,
        if (_fromDate != null)
          'from_date': _fromDate!.toIso8601String().split('T')[0],
        if (_toDate != null)
          'to_date': _toDate!.toIso8601String().split('T')[0],
      };

      final url = Uri.parse('$apiBaseUrl/games/history')
          .replace(queryParameters: queryParams);

      final headers = <String, String>{
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      };
      if (widget.authToken != null && widget.authToken!.isNotEmpty) {
        headers['Authorization'] = 'Bearer ${widget.authToken}';
      }

      final response = await http.get(url, headers: headers).timeout(
            const Duration(seconds: 15),
          );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        // Handle both List and Map response
        List<dynamic> gamesData = [];
        if (data['data'] is List) {
          gamesData = data['data'] as List;
        } else if (data is List) {
          gamesData = data;
        }

        final games =
            gamesData.map((json) => HistoryGame.fromJson(json)).toList();

        setState(() {
          if (loadMore) {
            _historyGames.addAll(games);
          } else {
            _historyGames = games;
          }
          _totalGames = data['total'] ?? games.length;
          _currentPage = skip ~/ _limit;
          _loading = false;
          _loadingMore = false;
          _error = '';
        });
      } else {
        setState(() {
          _error = 'Failed to load history games';
          _loading = false;
          _loadingMore = false;
        });
      }
    } catch (e) {
      setState(() {
        _error = 'Connection error';
        _loading = false;
        _loadingMore = false;
      });
    }
  }

  void _showFilterSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => StatefulBuilder(
        builder: (context, setSheetState) {
          String? tempLeague = _selectedLeague;
          String? tempSearch = _searchQuery;
          DateTime? tempFromDate = _fromDate;
          DateTime? tempToDate = _toDate;

          return Container(
            decoration: BoxDecoration(
              color: SocialTheme.background,
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(20)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  margin: const EdgeInsets.only(top: 12),
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: SocialTheme.divider,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(height: 16),
                const Text(
                  'Filter History',
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                      color: Colors.white),
                ),
                const SizedBox(height: 20),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Column(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          color: SocialTheme.surface,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: DropdownButtonFormField<String>(
                          initialValue: tempLeague,
                          dropdownColor: SocialTheme.surface,
                          decoration: const InputDecoration(
                            labelText: 'League',
                            border: InputBorder.none,
                            contentPadding: EdgeInsets.symmetric(
                                horizontal: 16, vertical: 12),
                          ),
                          style: const TextStyle(color: Colors.white),
                          items: [
                            const DropdownMenuItem(
                                value: null, child: Text('All Leagues')),
                            ..._leagues.map((league) => DropdownMenuItem(
                                  value: league,
                                  child: Text(league),
                                )),
                          ],
                          onChanged: (value) {
                            setSheetState(() => tempLeague = value);
                          },
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        style: const TextStyle(color: Colors.white),
                        decoration: InputDecoration(
                          hintText: 'Search by team name',
                          hintStyle:
                              TextStyle(color: SocialTheme.textSecondary),
                          prefixIcon: Icon(Icons.search,
                              color: SocialTheme.textSecondary),
                          filled: true,
                          fillColor: SocialTheme.surface,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide.none,
                          ),
                        ),
                        onChanged: (value) {
                          setSheetState(() => tempSearch = value);
                        },
                      ),
                      const SizedBox(height: 12),
                      GestureDetector(
                        onTap: () async {
                          final date = await showDatePicker(
                            context: context,
                            initialDate: tempFromDate ?? DateTime.now(),
                            firstDate: DateTime(2020),
                            lastDate: DateTime.now(),
                            builder: (context, child) {
                              return Theme(
                                data: Theme.of(context).copyWith(
                                  colorScheme: ColorScheme.dark(
                                    primary: SocialTheme.primary,
                                    surface: SocialTheme.surface,
                                  ),
                                ),
                                child: child!,
                              );
                            },
                          );
                          if (date != null) {
                            setSheetState(() => tempFromDate = date);
                          }
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 14),
                          decoration: BoxDecoration(
                            color: SocialTheme.surface,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Row(
                            children: [
                              Icon(Icons.calendar_today,
                                  size: 18, color: SocialTheme.textSecondary),
                              const SizedBox(width: 12),
                              Text(
                                tempFromDate != null
                                    ? 'From: ${_formatDate(tempFromDate)}'
                                    : 'From date',
                                style: TextStyle(
                                  color: tempFromDate != null
                                      ? Colors.white
                                      : SocialTheme.textSecondary,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      GestureDetector(
                        onTap: () async {
                          final date = await showDatePicker(
                            context: context,
                            initialDate: tempToDate ?? DateTime.now(),
                            firstDate: DateTime(2020),
                            lastDate: DateTime.now(),
                            builder: (context, child) {
                              return Theme(
                                data: Theme.of(context).copyWith(
                                  colorScheme: ColorScheme.dark(
                                    primary: SocialTheme.primary,
                                    surface: SocialTheme.surface,
                                  ),
                                ),
                                child: child!,
                              );
                            },
                          );
                          if (date != null) {
                            setSheetState(() => tempToDate = date);
                          }
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 14),
                          decoration: BoxDecoration(
                            color: SocialTheme.surface,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Row(
                            children: [
                              Icon(Icons.calendar_today,
                                  size: 18, color: SocialTheme.textSecondary),
                              const SizedBox(width: 12),
                              Text(
                                tempToDate != null
                                    ? 'To: ${_formatDate(tempToDate)}'
                                    : 'To date',
                                style: TextStyle(
                                  color: tempToDate != null
                                      ? Colors.white
                                      : SocialTheme.textSecondary,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: TextButton(
                        onPressed: () {
                          setSheetState(() {
                            tempLeague = null;
                            tempSearch = null;
                            tempFromDate = null;
                            tempToDate = null;
                          });
                        },
                        child: const Text('Clear All'),
                      ),
                    ),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () {
                          setState(() {
                            _selectedLeague = tempLeague;
                            _searchQuery = tempSearch;
                            _fromDate = tempFromDate;
                            _toDate = tempToDate;
                          });
                          Navigator.pop(context);
                          _fetchHistoryGames();
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: SocialTheme.primary,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: const Text('Apply Filters'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
              ],
            ),
          );
        },
      ),
    );
  }

  String _formatDate(DateTime date) {
    return '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
  }

  String _formatDateTime(DateTime date) {
    return '${date.day}/${date.month}/${date.year} ${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.6,
      decoration: BoxDecoration(
        color: SocialTheme.background,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          // Drag handle
          Container(
            margin: const EdgeInsets.only(top: 12),
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: SocialTheme.divider,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          // Header
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Icon(Icons.history, size: 20, color: SocialTheme.primary),
                    const SizedBox(width: 10),
                    Text(
                      'Match History',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
                Row(
                  children: [
                    IconButton(
                      onPressed: _showFilterSheet,
                      icon: Icon(Icons.filter_list,
                          color: SocialTheme.primary, size: 20),
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                    ),
                    const SizedBox(width: 16),
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: Icon(Icons.close,
                          color: SocialTheme.textSecondary, size: 20),
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                    ),
                  ],
                ),
              ],
            ),
          ),
          // Filter chips
          if (_selectedLeague != null ||
              _searchQuery != null ||
              _fromDate != null ||
              _toDate != null)
            Container(
              height: 40,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  if (_selectedLeague != null)
                    _buildFilterChip('League: $_selectedLeague', () {
                      setState(() => _selectedLeague = null);
                      _fetchHistoryGames();
                    }),
                  if (_searchQuery != null)
                    _buildFilterChip('Team: $_searchQuery', () {
                      setState(() => _searchQuery = null);
                      _fetchHistoryGames();
                    }),
                  if (_fromDate != null)
                    _buildFilterChip('From: ${_formatDate(_fromDate!)}', () {
                      setState(() => _fromDate = null);
                      _fetchHistoryGames();
                    }),
                  if (_toDate != null)
                    _buildFilterChip('To: ${_formatDate(_toDate!)}', () {
                      setState(() => _toDate = null);
                      _fetchHistoryGames();
                    }),
                  GestureDetector(
                    onTap: () {
                      setState(() {
                        _selectedLeague = null;
                        _searchQuery = null;
                        _fromDate = null;
                        _toDate = null;
                      });
                      _fetchHistoryGames();
                    },
                    child: Padding(
                      padding: const EdgeInsets.only(left: 8, right: 16),
                      child: Text(
                        'Clear all',
                        style:
                            TextStyle(fontSize: 11, color: SocialTheme.primary),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          // Content
          Expanded(
            child: _loading
                ? Center(
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: SocialTheme.primary),
                  )
                : _error.isNotEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.error_outline,
                                size: 48, color: SocialTheme.textSecondary),
                            const SizedBox(height: 12),
                            Text(_error,
                                style: TextStyle(
                                    color: SocialTheme.textSecondary)),
                            const SizedBox(height: 16),
                            ElevatedButton(
                              onPressed: _fetchHistoryGames,
                              child: const Text('Retry'),
                            ),
                          ],
                        ),
                      )
                    : _historyGames.isEmpty
                        ? Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.history,
                                    size: 48, color: SocialTheme.textSecondary),
                                const SizedBox(height: 12),
                                Text('No completed matches',
                                    style: TextStyle(
                                        color: SocialTheme.textSecondary)),
                              ],
                            ),
                          )
                        : ListView.builder(
                            controller: _scrollController,
                            padding: const EdgeInsets.all(12),
                            itemCount:
                                _historyGames.length + (_loadingMore ? 1 : 0),
                            itemBuilder: (context, index) {
                              if (index == _historyGames.length) {
                                return Padding(
                                  padding: EdgeInsets.all(16),
                                  child: Center(
                                    child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        color: SocialTheme.primary),
                                  ),
                                );
                              }
                              return _buildHistoryCard(_historyGames[index]);
                            },
                          ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChip(String label, VoidCallback onDelete) {
    return Container(
      margin: const EdgeInsets.only(right: 8),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: SocialTheme.primary.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: SocialTheme.primary.withValues(alpha: 0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(label,
              style: TextStyle(fontSize: 11, color: SocialTheme.primary)),
          const SizedBox(width: 4),
          GestureDetector(
            onTap: onDelete,
            child: Icon(Icons.close, size: 12, color: SocialTheme.primary),
          ),
        ],
      ),
    );
  }

  Widget _buildHistoryCard(HistoryGame history) {
    final game = history.game;
    final homeScore = game.homeScore ?? 0;
    final awayScore = game.awayScore ?? 0;

    String winnerText = '';
    Color winnerColor = SocialTheme.textSecondary;

    if (homeScore > awayScore) {
      winnerText = '${game.homeTeam} won';
      winnerColor = SocialTheme.primary;
    } else if (awayScore > homeScore) {
      winnerText = '${game.awayTeam} won';
      winnerColor = const Color(0xFF2563EB);
    } else {
      winnerText = 'Draw';
      winnerColor = const Color(0xFF8B5CF6);
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: SocialTheme.surface,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    width: 24,
                    height: 24,
                    decoration: BoxDecoration(
                      color: SocialTheme.primary.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Center(
                      child: Text(
                        game.league.isNotEmpty
                            ? game.league[0].toUpperCase()
                            : '⚽',
                        style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                            color: SocialTheme.primary),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    game.league,
                    style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                        color: SocialTheme.textSecondary),
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: Colors.grey.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  game.date,
                  style:
                      TextStyle(fontSize: 9, color: SocialTheme.textSecondary),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Text(
                  game.homeTeam,
                  style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: Colors.white),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.05),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      '$homeScore',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: homeScore > awayScore
                            ? SocialTheme.primary
                            : Colors.white,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text('-',
                        style: TextStyle(
                            fontSize: 14, color: SocialTheme.textSecondary)),
                    const SizedBox(width: 6),
                    Text(
                      '$awayScore',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: awayScore > homeScore
                            ? const Color(0xFF2563EB)
                            : Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Text(
                  game.awayTeam,
                  style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: Colors.white),
                  textAlign: TextAlign.right,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color: winnerColor.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  homeScore > awayScore
                      ? Icons.emoji_events
                      : awayScore > homeScore
                          ? Icons.emoji_events
                          : Icons.handshake,
                  size: 12,
                  color: winnerColor,
                ),
                const SizedBox(width: 4),
                Text(winnerText,
                    style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        color: winnerColor)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
