import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import '../../services/api_services.dart';
import '../../services/notification_service.dart';
import '../../pages/social_theme.dart';

class AddPostModal extends StatelessWidget {
  final VoidCallback? onPostCreated;
  final String? userId;
  final String? username;

  const AddPostModal({
    super.key,
    this.onPostCreated,
    this.userId,
    this.username,
  });

  @override
  Widget build(BuildContext context) {
    return _AddPostModalContent(
      onPostCreated: onPostCreated,
      userId: userId,
      username: username,
    );
  }
}

class _AddPostModalContent extends StatefulWidget {
  final VoidCallback? onPostCreated;
  final String? userId;
  final String? username;

  const _AddPostModalContent({this.onPostCreated, this.userId, this.username});

  @override
  State<_AddPostModalContent> createState() => __AddPostModalContentState();
}

class __AddPostModalContentState extends State<_AddPostModalContent> {
  File? _selectedImage;
  String? _imagePreview;
  bool _isPosting = false;
  final TextEditingController _captionController = TextEditingController();
  String _message = "";

  final ImagePicker _picker = ImagePicker();

  Future<void> _pickImage() async {
    try {
      final XFile? image = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 85,
      );

      if (image != null) {
        setState(() {
          _selectedImage = File(image.path);
          _imagePreview = image.path;
        });
      }
    } catch (e) {
      setState(() => _message = "Error picking image");
    }
  }

  /// Send notification to all followers about the new post
  Future<void> _sendNewPostNotification({
    required String postId,
    required String userId,
    required String userName,
    required String caption,
    required bool hasImage,
  }) async {
    try {
      // Fetch all followers of the user
      final followers = await ApiService.getUserFollowers(userId);

      if (followers.isEmpty) {
        debugPrint('📭 No followers to notify about new post');
        return;
      }

      // Create post preview for notification body
      String postPreview;
      if (caption.isNotEmpty) {
        postPreview = caption.length > 60
            ? '${caption.substring(0, 60)}...'
            : caption;
      } else if (hasImage) {
        postPreview = '📷 Shared a photo';
      } else {
        postPreview = 'Shared a new post';
      }

      final String postType = hasImage
          ? (caption.isNotEmpty ? 'photo and caption' : 'photo')
          : (caption.isNotEmpty ? 'update' : 'post');

      // Send notification to each follower
      int successCount = 0;
      for (var follower in followers) {
        final followerId =
            follower['user_id']?.toString() ?? follower['id']?.toString();

        if (followerId != null && followerId != userId) {
          try {
            final success = await NotificationService.sendNotification(
              userId: followerId,
              notificationType: 'new_post',
              title: '📱 New Post from @$userName',
              body: '@$userName shared a new $postType: $postPreview',
              data: {
                'post_id': postId,
                'post_author_id': userId,
                'post_author_name': userName,
                'post_caption': caption,
                'has_image': hasImage,
                'type': 'new_post',
                'timestamp': DateTime.now().toIso8601String(),
              },
            );
            if (success) successCount++;

            // Small delay to avoid overwhelming the server
            await Future.delayed(const Duration(milliseconds: 50));
          } catch (e) {
            debugPrint('❌ Failed to send notification to $followerId: $e');
          }
        }
      }

      debugPrint(
        '✅ Sent new post notifications to $successCount/${followers.length} followers',
      );
    } catch (e) {
      debugPrint('❌ Error sending new post notifications: $e');
    }
  }

  Future<void> _submitPost() async {
    if (widget.userId == null || widget.userId!.isEmpty) {
      setState(() => _message = "Please login first");
      return;
    }

    final caption = _captionController.text.trim();

    // Check if either caption or image is provided
    if (caption.isEmpty && _selectedImage == null) {
      setState(() => _message = "Please add a caption or select an image");
      return;
    }

    setState(() {
      _isPosting = true;
      _message = "Creating post...";
    });

    try {
      // Create the post and get the response with post data
      final postData = await ApiService.createPost(
        userId: widget.userId!,
        userName: widget.username ?? 'User',
        caption: caption.isNotEmpty ? caption : null,
        image: _selectedImage,
      );

      // Extract post ID from response
      final String? postId =
          postData['post_id']?.toString() ??
          postData['id']?.toString() ??
          postData['_id']?.toString();

      final bool hasImage = _selectedImage != null;
      final String successMessage = caption.isNotEmpty && hasImage
          ? "Post with image and caption created!"
          : hasImage
          ? "Image post created successfully!"
          : "Text post created successfully!";

      setState(() {
        _message = successMessage;
      });

      // Send notifications to followers
      if (postId != null && postId.isNotEmpty) {
        await _sendNewPostNotification(
          postId: postId,
          userId: widget.userId!,
          userName: widget.username ?? 'User',
          caption: caption,
          hasImage: hasImage,
        );
      }

      // ✅ TRIGGER REFRESH OF POSTS PAGE
      // Call the onPostCreated callback to refresh the feed
      if (widget.onPostCreated != null) {
        widget.onPostCreated!();
        debugPrint('✅ Triggered posts page refresh');
      }

      // Close modal after successful post
      Future.delayed(const Duration(seconds: 1), () {
        if (mounted) Navigator.pop(context);
      });
    } catch (e) {
      setState(() {
        _isPosting = false;
        _message =
            "Failed to create post: ${e.toString().replaceAll('Exception: ', '')}";
      });
    }
  }

  void _clearForm() {
    _captionController.clear();
    setState(() {
      _selectedImage = null;
      _imagePreview = null;
      _message = "";
    });
  }

  bool get _isPostButtonEnabled {
    final bool hasCaption = _captionController.text.trim().isNotEmpty;
    final bool hasImage = _selectedImage != null;
    return !_isPosting && (hasCaption || hasImage);
  }

  String _getPostButtonText() {
    final bool hasCaption = _captionController.text.trim().isNotEmpty;
    final bool hasImage = _selectedImage != null;

    if (hasCaption && hasImage) {
      return "Post";
    } else if (hasImage) {
      return "Post Image";
    } else {
      return "Post Text";
    }
  }

  IconData _getPostButtonIcon() {
    final bool hasCaption = _captionController.text.trim().isNotEmpty;
    final bool hasImage = _selectedImage != null;

    if (hasCaption && hasImage) {
      return Icons.send_rounded;
    } else if (hasImage) {
      return Icons.image;
    } else {
      return Icons.text_fields;
    }
  }

  String _getPostTypeText() {
    final bool hasCaption = _captionController.text.trim().isNotEmpty;
    final bool hasImage = _selectedImage != null;

    if (hasCaption && hasImage) {
      return "Post with image & text";
    } else if (hasImage) {
      return "Image post";
    } else if (hasCaption) {
      return "Text post";
    } else {
      return "";
    }
  }

  @override
  Widget build(BuildContext context) {
    final bool hasCaption = _captionController.text.trim().isNotEmpty;
    final bool hasImage = _selectedImage != null;

    return Container(
      height: MediaQuery.of(context).size.height * 0.6,
      decoration: BoxDecoration(
        color: SocialTheme.background,
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(24),
          topRight: Radius.circular(24),
        ),
      ),
      child: Column(
        children: [
          // Drag handle
          Center(
            child: Container(
              width: 40,
              height: 4,
              margin: const EdgeInsets.only(top: 12, bottom: 8),
              decoration: BoxDecoration(
                color: SocialTheme.surface,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),

          // Header
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            child: Row(
              children: [
                // User avatar
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: SocialTheme.primary,
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: SocialTheme.fixtureCard,
                        shape: BoxShape.circle,
                      ),
                      child: Center(
                        child: Icon(
                          Icons.add_a_photo,
                          color: SocialTheme.primary,
                          size: 20,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 16),

                // Title and username
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Create Post",
                        style: SocialTheme.headline.copyWith(fontSize: 20),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        widget.username?.isNotEmpty == true
                            ? "@${widget.username}"
                            : "Share your moment",
                        style: SocialTheme.small.copyWith(
                          color: SocialTheme.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ),

                // Close button
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: SocialTheme.surface,
                      shape: BoxShape.circle,
                    ),
                    child: Icon(Icons.close, color: SocialTheme.text, size: 18),
                  ),
                ),
              ],
            ),
          ),

          // Content
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: ListView(
                children: [
                  // Caption field
                  Container(
                    decoration: BoxDecoration(
                      color: SocialTheme.surface.withValues(alpha: 0.7),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: TextField(
                      controller: _captionController,
                      maxLines: 4,
                      style: SocialTheme.body.copyWith(
                        fontSize: 15,
                        height: 1.4,
                      ),
                      decoration: SocialTheme.input.copyWith(
                        hintText: "What's on your mind? (Optional)",
                        hintStyle: SocialTheme.body.copyWith(
                          color: SocialTheme.textSecondary,
                        ),
                        contentPadding: const EdgeInsets.all(16),
                      ),
                      onChanged: (value) {
                        setState(() {});
                      },
                    ),
                  ),

                  const SizedBox(height: 20),

                  // Image picker section (optional)
                  GestureDetector(
                    onTap: _pickImage,
                    child: Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: SocialTheme.surface.withValues(alpha: 0.3),
                        borderRadius: BorderRadius.circular(16),
                        border: !hasCaption && !hasImage
                            ? Border.all(
                                color: Colors.orange.withValues(alpha: 0.5),
                                width: 1,
                              )
                            : null,
                      ),
                      child: Column(
                        children: [
                          Icon(
                            hasImage
                                ? Icons.photo_library
                                : Icons.add_photo_alternate_outlined,
                            color: !hasCaption && !hasImage
                                ? Colors.orange
                                : SocialTheme.primary,
                            size: 32,
                          ),
                          const SizedBox(height: 12),
                          Text(
                            hasImage ? "Change Image" : "Add Photo (Optional)",
                            style: SocialTheme.body.copyWith(
                              fontWeight: FontWeight.w600,
                              color: !hasCaption && !hasImage
                                  ? Colors.orange
                                  : null,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            hasImage
                                ? "Tap to change image"
                                : "Tap to select from gallery",
                            style: SocialTheme.small.copyWith(
                              color: !hasCaption && !hasImage
                                  ? Colors.orange
                                  : SocialTheme.textSecondary,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  // Image preview
                  if (hasImage) ...[
                    const SizedBox(height: 20),
                    Container(
                      height: 140,
                      decoration: SocialTheme.cardDecoration.copyWith(
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Stack(
                        children: [
                          // Image
                          ClipRRect(
                            borderRadius: BorderRadius.circular(16),
                            child: Image.file(
                              File(_imagePreview!),
                              fit: BoxFit.cover,
                              width: double.infinity,
                              height: double.infinity,
                            ),
                          ),

                          // Remove button
                          Positioned(
                            top: 12,
                            right: 12,
                            child: GestureDetector(
                              onTap: () => setState(() {
                                _selectedImage = null;
                                _imagePreview = null;
                              }),
                              child: Container(
                                width: 32,
                                height: 32,
                                decoration: BoxDecoration(
                                  color: Colors.black.withValues(alpha: 0.7),
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(
                                  Icons.close,
                                  color: SocialTheme.text,
                                  size: 18,
                                ),
                              ),
                            ),
                          ),

                          // Gradient overlay
                          Positioned(
                            bottom: 0,
                            left: 0,
                            right: 0,
                            child: Container(
                              height: 40,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  begin: Alignment.bottomCenter,
                                  end: Alignment.topCenter,
                                  colors: [
                                    Colors.black.withValues(alpha: 0.6),
                                    Colors.transparent,
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],

                  // Post type indicator
                  if (hasCaption || hasImage) ...[
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 8,
                      ),
                      decoration: BoxDecoration(
                        color: SocialTheme.primary.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            hasCaption && hasImage
                                ? Icons.image_outlined
                                : hasImage
                                ? Icons.image
                                : Icons.text_fields,
                            color: SocialTheme.primary,
                            size: 16,
                          ),
                          const SizedBox(width: 6),
                          Text(
                            _getPostTypeText(),
                            style: SocialTheme.small.copyWith(
                              color: SocialTheme.primary,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],

                  // Message status
                  if (_message.isNotEmpty) ...[
                    const SizedBox(height: 20),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color:
                            _message.contains("successfully") ||
                                _message.contains("created")
                            ? SocialTheme.primary.withValues(alpha: 0.1)
                            : Colors.red.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            _message.contains("successfully") ||
                                    _message.contains("created")
                                ? Icons.check_circle_outline
                                : Icons.error_outline,
                            color:
                                _message.contains("successfully") ||
                                    _message.contains("created")
                                ? SocialTheme.primary
                                : Colors.red,
                            size: 22,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              _message,
                              style: SocialTheme.body.copyWith(
                                color:
                                    _message.contains("successfully") ||
                                        _message.contains("created")
                                    ? SocialTheme.primary
                                    : Colors.red,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],

                  const SizedBox(height: 20),

                  // Action buttons
                  Row(
                    children: [
                      // Clear button
                      Expanded(
                        child: ElevatedButton(
                          onPressed: _clearForm,
                          style: SocialTheme.secondaryBtn.copyWith(
                            backgroundColor: WidgetStateProperty.all(
                              SocialTheme.surface.withValues(alpha: 0.3),
                            ),
                            foregroundColor: WidgetStateProperty.all(
                              SocialTheme.textSecondary,
                            ),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Icon(Icons.refresh, size: 18),
                              const SizedBox(width: 8),
                              Text(
                                "Clear",
                                style: SocialTheme.body.copyWith(
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(width: 16),

                      // Post button
                      Expanded(
                        flex: 2,
                        child: ElevatedButton(
                          onPressed: _isPostButtonEnabled ? _submitPost : null,
                          style: SocialTheme.primaryBtn.copyWith(
                            backgroundColor: !_isPostButtonEnabled
                                ? WidgetStateProperty.all(SocialTheme.surface)
                                : null,
                          ),
                          child: _isPosting
                              ? SizedBox(
                                  width: 24,
                                  height: 24,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: SocialTheme.text,
                                  ),
                                )
                              : Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(_getPostButtonIcon(), size: 18),
                                    const SizedBox(width: 10),
                                    Text(
                                      _getPostButtonText(),
                                      style: SocialTheme.body.copyWith(
                                        fontWeight: FontWeight.w700,
                                        letterSpacing: 0.5,
                                      ),
                                    ),
                                  ],
                                ),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 30),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
