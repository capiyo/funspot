import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:clash/pages/social_theme.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart' show kIsWeb, kDebugMode, compute;
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:developer' as developer;
import 'dart:io' show Platform;
import 'firebase_options.dart';
import 'dart:async';
import 'dart:convert';
import 'package:clash/pages/fixture_page.dart';
import 'package:app_links/app_links.dart';
import 'package:http/http.dart' as http;

import 'screens/home_page.dart';
import 'services/notification_service.dart';
import 'services/auth_service.dart';
import 'models/fixture_models.dart';
import 'models/user_channel.dart';
import 'modals/clash/comrades_modal.dart';

// ============================================================================
// GLOBAL KEYS & COMPLETERS
// ============================================================================

class _JoinChannelDialog extends StatefulWidget {
  final String inviteCode;
  final String channelName;
  final int memberCount;

  const _JoinChannelDialog({
    required this.inviteCode,
    required this.channelName,
    required this.memberCount,
  });

  @override
  State<_JoinChannelDialog> createState() => _JoinChannelDialogState();
}

class ChannelMember {
  final String userId;
  final String username;
  final String role;
  final DateTime joinedAt;
  final int seasonPoints;
  final int correctVotes;
  final int totalVotes;
  final int msgCount;

  ChannelMember({
    required this.userId,
    required this.username,
    required this.role,
    required this.joinedAt,
    required this.seasonPoints,
    required this.correctVotes,
    required this.totalVotes,
    required this.msgCount,
  });

  factory ChannelMember.fromJson(Map<String, dynamic> json) {
    return ChannelMember(
      userId: json['user_id']?.toString() ?? '',
      username: json['username']?.toString() ?? 'Anonymous',
      role: json['role']?.toString()?.toLowerCase() ?? 'member',
      joinedAt: DateTime.tryParse(json['joined_at']?.toString() ?? '') ??
          DateTime.now(),
      seasonPoints: json['season_points'] ?? 0,
      correctVotes: json['correct_votes'] ?? 0,
      totalVotes: json['total_votes'] ?? 0,
      msgCount: json['msg_count'] ?? 0,
    );
  }

  Map<String, dynamic> toJson() => {
        'user_id': userId,
        'username': username,
        'role': role,
        'joined_at': joinedAt.toIso8601String(),
        'season_points': seasonPoints,
        'correct_votes': correctVotes,
        'total_votes': totalVotes,
        'msg_count': msgCount,
      };

  bool get isAdmin => role == 'admin';
}

class _JoinChannelDialogState extends State<_JoinChannelDialog> {
  bool _isJoining = false;

  Future<void> _join() async {
    final authService = AuthService();
    if (!authService.isLoggedIn) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please login first to join a channel'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    setState(() => _isJoining = true);

    try {
      final response = await http.post(
        Uri.parse(
            'https://clash-api-m5mr.onrender.com/api/channels/join-by-code'),
        headers: {
          'Content-Type': 'application/json',
          if (authService.authToken != null)
            'Authorization': 'Bearer ${authService.authToken}',
        },
        body: json.encode({
          'invite_code': widget.inviteCode,
          'user_id': authService.userId,
          'username': authService.username,
        }),
      );

      if (!mounted) return;
      Navigator.pop(context);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final name = data['channel_name'] ?? widget.channelName;

        ScaffoldMessenger.of(messengerKey.currentContext!).showSnackBar(
          SnackBar(
            content: Text('✅ You joined "$name" 🎉'),
            backgroundColor: const Color(0xFF7F6FDD),
            duration: const Duration(seconds: 3),
          ),
        );
      } else {
        final data = json.decode(response.body);
        ScaffoldMessenger.of(messengerKey.currentContext!).showSnackBar(
          SnackBar(
            content: Text(data['message'] ?? 'Failed to join channel'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 3),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(messengerKey.currentContext!).showSnackBar(
          SnackBar(
            content: Text('Error: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: const Color(0xFF161525),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: const Color(0xFF7F6FDD).withValues(alpha: 0.15),
              shape: BoxShape.circle,
            ),
            child:
                const Center(child: Text('⚔️', style: TextStyle(fontSize: 28))),
          ),
          const SizedBox(height: 16),
          Text(
            'Join Channel',
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            widget.channelName,
            style: const TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w600,
              color: Color(0xFF7F6FDD),
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 4),
          Text(
            '${widget.memberCount} members',
            style: TextStyle(
              fontSize: 12,
              color: Colors.white.withValues(alpha: 0.5),
            ),
          ),
          const SizedBox(height: 24),
          Row(
            children: [
              Expanded(
                child: GestureDetector(
                  onTap: _isJoining ? null : () => Navigator.pop(context),
                  child: Container(
                    height: 44,
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.white24),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Center(
                      child: Text(
                        'Cancel',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: GestureDetector(
                  onTap: _isJoining ? null : _join,
                  child: Container(
                    height: 44,
                    decoration: BoxDecoration(
                      color: const Color(0xFF7F6FDD),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: _isJoining
                        ? const Center(
                            child: SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            ),
                          )
                        : const Center(
                            child: Text(
                              'Join',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w700,
                                fontSize: 15,
                              ),
                            ),
                          ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();
final GlobalKey<ScaffoldMessengerState> messengerKey =
    GlobalKey<ScaffoldMessengerState>();
final Completer<void> adsInitCompleter = Completer<void>();

// ============================================================================
// APPCACHE - COMPLETE WITH ALL METHODS PRESERVED
// ============================================================================

class AppCache {
  // ==========================================================================
  // STATIC DATA - ALREADY IN MEMORY (0ms access)
  // ==========================================================================
  static List<Map<String, dynamic>> comrades = [];
  static List<UserChannel> channels = [];
  static List<Fixture> fixtures = [];
  static Map<String, String?> userVotes = {};
  static Map<String, ChannelFixtureData> channelFixtures = {};
  static Map<String, Map<String, int>> perChannelVoteCounts = {};
  static Set<String> userComrades = {};
  static Map<String, List<ComradeWithProfile>> comradeVoters = {};
  static Set<String> addedComradeIds = {};

  // ==========================================================================
  // STREAM NOTIFIER
  // ==========================================================================
  static final _fixturesController =
      StreamController<List<Fixture>>.broadcast();
  static Stream<List<Fixture>> get fixturesStream => _fixturesController.stream;

  // ==========================================================================
  // TIMESTAMP TRACKING
  // ==========================================================================
  static final Map<String, DateTime> _lastVoteUpdate = {};
  static final Map<String, DateTime> _lastCommentUpdate = {};
  static final Map<String, DateTime> _lastLikeUpdate = {};
  static final Map<String, DateTime> _lastLatestCommentUpdate = {};
  static final Map<String, DateTime> _lastPledgeUpdate = {};
  static final Map<String, DateTime> _lastBetUpdate = {};
  static final Map<String, DateTime> _lastUnreadUpdate = {};

  static DateTime? getLastVoteUpdate(String fixtureId) =>
      _lastVoteUpdate[fixtureId];
  static DateTime? getLastCommentUpdate(String fixtureId) =>
      _lastCommentUpdate[fixtureId];
  static DateTime? getLastLikeUpdate(String fixtureId) =>
      _lastLikeUpdate[fixtureId];
  static DateTime? getLastLatestCommentUpdate(String fixtureId) =>
      _lastLatestCommentUpdate[fixtureId];
  static DateTime? getLastPledgeUpdate(String fixtureId) =>
      _lastPledgeUpdate[fixtureId];
  static DateTime? getLastBetUpdate(String fixtureId) =>
      _lastBetUpdate[fixtureId];

  // ==========================================================================
  // VOTE COUNTS
  // ==========================================================================
  static final Map<String, int> _voteCounts = {};
  static int? getVoteCount(String fixtureId) => _voteCounts[fixtureId];

  // ==========================================================================
  // COMMENT COUNTS
  // ==========================================================================
  static final Map<String, int> _commentCounts = {};
  static int? getCommentCount(String fixtureId) => _commentCounts[fixtureId];

  // ==========================================================================
  // LIKE COUNTS
  // ==========================================================================
  static final Map<String, int> _likeCounts = {};
  static int? getLikeCount(String fixtureId) => _likeCounts[fixtureId];

  // ==========================================================================
  // PLEDGE COUNTS (NEW)
  // ==========================================================================
  static final Map<String, int> _pledgeCounts = {};
  static int? getPledgeCount(String fixtureId) => _pledgeCounts[fixtureId];

  // ==========================================================================
  // BET COUNTS (NEW)
  // ==========================================================================
  static final Map<String, int> _betCounts = {};
  static int? getBetCount(String fixtureId) => _betCounts[fixtureId];

  // ==========================================================================
  // USER LIKES (NEW)
  // ==========================================================================
  static final Map<String, bool> _userLikes = {};
  static bool? getUserLike(String fixtureId) => _userLikes[fixtureId];

  // ==========================================================================
  // UNREAD COUNTS
  // ==========================================================================
  static final Map<String, int> _unreadCounts = {};
  static int? getUnreadCount(String fixtureId) => _unreadCounts[fixtureId];

  // ==========================================================================
  // LATEST COMMENTS
  // ==========================================================================
  static final Map<String, String?> _latestComments = {};
  static final Map<String, String?> _latestCommentAuthors = {};
  static final Map<String, DateTime?> _latestCommentTimestamps = {};

  static String? getLatestComment(String fixtureId) =>
      _latestComments[fixtureId];
  static String? getLatestCommentAuthor(String fixtureId) =>
      _latestCommentAuthors[fixtureId];
  static DateTime? getLatestCommentTimestamp(String fixtureId) =>
      _latestCommentTimestamps[fixtureId];

  // ==========================================================================
  // LIVE EVENTS (NEW)
  // ==========================================================================
  static final Map<String, List<Map<String, dynamic>>> _liveEvents = {};
  static List<Map<String, dynamic>>? getLiveEvents(String fixtureId) =>
      _liveEvents[fixtureId];

  // ==========================================================================
  // VOTERS LIST (NEW)
  // ==========================================================================
  static final Map<String, List<Map<String, dynamic>>> _voters = {};
  static List<Map<String, dynamic>>? getVoters(String fixtureId) =>
      _voters[fixtureId];

  // ==========================================================================
  // MESSAGE CACHE
  // ==========================================================================
  static final Map<String, List<Map<String, dynamic>>> _cachedMessages = {};
  static Map<String, List<Map<String, dynamic>>> get cachedMessages =>
      _cachedMessages;

  // ==========================================================================
  // ADMIN DASHBOARD CACHES
  // ==========================================================================
  static final Map<String, Map<String, dynamic>> _cachedChannelStats = {};
  static final Map<String, List<Map<String, dynamic>>> _cachedChannelMembers =
      {};
  static Map<String, Map<String, dynamic>> get cachedChannelStats =>
      _cachedChannelStats;
  static Map<String, List<Map<String, dynamic>>> get cachedChannelMembers =>
      _cachedChannelMembers;

  // ==========================================================================
  // LINEUP CACHES
  // ==========================================================================
  static final Map<String, Map<String, dynamic>> _cachedLineups = {};
  static Map<String, Map<String, dynamic>> get cachedLineups => _cachedLineups;

  // ==========================================================================
  // COMRADE MODAL CACHES
  // ==========================================================================
  static final Map<String, List<Map<String, dynamic>>>
      _cachedComradeLeaderboard = {};
  static final Map<String, List<Map<String, dynamic>>>
      _cachedComradeVotersData = {};
  static Map<String, List<Map<String, dynamic>>> get cachedComradeLeaderboard =>
      _cachedComradeLeaderboard;
  static Map<String, List<Map<String, dynamic>>> get cachedComradeVotersData =>
      _cachedComradeVotersData;

  static bool isLoaded = false;

  // ==========================================================================
  // SINGLE UPDATE METHOD - ALL UPDATES GO THROUGH THIS
  // ==========================================================================
  static void applyUpdate({
    required String fixtureId,
    required String updateType,
    required int value,
    Map<String, dynamic>? extraData,
    DateTime? timestamp,
  }) {
    final now = timestamp ?? DateTime.now();

    final lastUpdate = _getLastUpdate(fixtureId, updateType);
    if (lastUpdate != null && now.isBefore(lastUpdate)) {
      debugPrint('⏭️ Stale update ignored: $fixtureId $updateType');
      return;
    }

    debugPrint('📥 AppCache update: $fixtureId $updateType = $value');

    switch (updateType) {
      case 'vote':
        _lastVoteUpdate[fixtureId] = now;
        _voteCounts[fixtureId] = value;
        final channelId = extraData?['channelId'] as String? ?? 'default';
        perChannelVoteCounts[fixtureId] ??= {};
        perChannelVoteCounts[fixtureId]![channelId] = value;

        if (channelFixtures.containsKey(fixtureId)) {
          final existing = channelFixtures[fixtureId]!;
          channelFixtures[fixtureId] = ChannelFixtureData(
            fixtureId: existing.fixtureId,
            channelId: existing.channelId,
            matchName: existing.matchName,
            kickoffTime: existing.kickoffTime,
            status: existing.status,
            homeVotes: extraData?['homeVotes'] ?? existing.homeVotes,
            awayVotes: extraData?['awayVotes'] ?? existing.awayVotes,
            drawVotes: extraData?['drawVotes'] ?? existing.drawVotes,
            lastMessage: existing.lastMessage,
            lastMessageAt: existing.lastMessageAt,
            lastSender: existing.lastSender,
            userVote: existing.userVote,
            commentCount: existing.commentCount,
            unreadCounts: existing.unreadCounts,
          );
        }
        break;

      case 'comment':
        _lastCommentUpdate[fixtureId] = now;
        _commentCounts[fixtureId] = value;

        if (channelFixtures.containsKey(fixtureId)) {
          final existing = channelFixtures[fixtureId]!;
          channelFixtures[fixtureId] = ChannelFixtureData(
            fixtureId: existing.fixtureId,
            channelId: existing.channelId,
            matchName: existing.matchName,
            kickoffTime: existing.kickoffTime,
            status: existing.status,
            homeVotes: existing.homeVotes,
            awayVotes: existing.awayVotes,
            drawVotes: existing.drawVotes,
            lastMessage: existing.lastMessage,
            lastMessageAt: existing.lastMessageAt,
            lastSender: existing.lastSender,
            userVote: existing.userVote,
            commentCount: value,
            unreadCounts: existing.unreadCounts,
          );
        }
        break;

      case 'like':
        _lastLikeUpdate[fixtureId] = now;
        _likeCounts[fixtureId] = value;
        if (extraData != null) {
          _userLikes[fixtureId] = extraData['liked'] as bool? ?? false;
        }
        break;

      case 'pledge':
        _lastPledgeUpdate[fixtureId] = now;
        _pledgeCounts[fixtureId] = value;
        break;

      case 'bet':
        _lastBetUpdate[fixtureId] = now;
        _betCounts[fixtureId] = value;
        break;

      case 'unread':
        _lastUnreadUpdate[fixtureId] = now;
        _unreadCounts[fixtureId] = value;
        break;

      case 'latest_comment':
        _lastLatestCommentUpdate[fixtureId] = now;
        _latestComments[fixtureId] = extraData?['comment'] as String?;
        _latestCommentAuthors[fixtureId] = extraData?['username'] as String?;
        _latestCommentTimestamps[fixtureId] = now;
        break;

      case 'live_event':
        final event = extraData?['event'] as Map<String, dynamic>?;
        if (event != null) {
          final events = _liveEvents[fixtureId] ?? [];
          events.insert(0, event);
          if (events.length > 20) events.removeLast();
          _liveEvents[fixtureId] = events;
        }
        break;

      case 'voters':
        final votersList = extraData?['voters'] as List<Map<String, dynamic>>?;
        if (votersList != null) {
          _voters[fixtureId] = votersList;
        }
        break;
    }

    _saveToDisk(fixtureId, updateType, value, extraData);
    _fixturesController.add(fixtures);
  }

  static DateTime? _getLastUpdate(String fixtureId, String type) {
    switch (type) {
      case 'vote':
        return _lastVoteUpdate[fixtureId];
      case 'comment':
        return _lastCommentUpdate[fixtureId];
      case 'like':
        return _lastLikeUpdate[fixtureId];
      case 'latest_comment':
        return _lastLatestCommentUpdate[fixtureId];
      case 'pledge':
        return _lastPledgeUpdate[fixtureId];
      case 'bet':
        return _lastBetUpdate[fixtureId];
      case 'unread':
        return _lastUnreadUpdate[fixtureId];
      default:
        return null;
    }
  }

  // ==========================================================================
  // NOTIFY FIXTURES CHANGED
  // ==========================================================================
  static void notifyFixturesChanged() {
    _fixturesController.add(fixtures);
    debugPrint('📢 AppCache notified listeners of fixture update');
  }

  // ==========================================================================
  // BACKGROUND SAVE TO DISK
  // ==========================================================================
  static Future<void> _saveToDisk(
    String fixtureId,
    String type,
    int value,
    Map<String, dynamic>? extraData,
  ) async {
    try {
      final prefs = await SharedPreferences.getInstance();

      switch (type) {
        case 'vote':
          final voteData = prefs.getString('per_channel_vote_counts') ?? '{}';
          final Map<String, dynamic> data = json.decode(voteData);
          final channelId = extraData?['channelId'] as String? ?? 'default';
          data[fixtureId] ??= {};
          data[fixtureId][channelId] = value;
          await prefs.setString('per_channel_vote_counts', json.encode(data));
          break;

        case 'comment':
          final commentData = prefs.getString('comment_counts_cache') ?? '{}';
          final Map<String, dynamic> data = json.decode(commentData);
          data[fixtureId] = value;
          await prefs.setString('comment_counts_cache', json.encode(data));
          break;

        case 'like':
          final likeData = prefs.getString('like_counts_cache') ?? '{}';
          final Map<String, dynamic> data = json.decode(likeData);
          data[fixtureId] = value;
          await prefs.setString('like_counts_cache', json.encode(data));
          break;

        case 'pledge':
          final pledgeData = prefs.getString('pledge_counts_cache') ?? '{}';
          final Map<String, dynamic> data = json.decode(pledgeData);
          data[fixtureId] = value;
          await prefs.setString('pledge_counts_cache', json.encode(data));
          break;

        case 'bet':
          final betData = prefs.getString('bet_counts_cache') ?? '{}';
          final Map<String, dynamic> data = json.decode(betData);
          data[fixtureId] = value;
          await prefs.setString('bet_counts_cache', json.encode(data));
          break;

        case 'unread':
          final unreadData = prefs.getString('unread_counts_cache') ?? '{}';
          final Map<String, dynamic> data = json.decode(unreadData);
          data[fixtureId] = value;
          await prefs.setString('unread_counts_cache', json.encode(data));
          break;

        case 'latest_comment':
          final latestData = prefs.getString('latest_comments_cache') ?? '{}';
          final Map<String, dynamic> data = json.decode(latestData);
          data[fixtureId] = {
            'comment': extraData?['comment'],
            'author': extraData?['username'],
            'timestamp': DateTime.now().toIso8601String(),
          };
          await prefs.setString('latest_comments_cache', json.encode(data));
          break;

        case 'live_event':
          final liveData = prefs.getString('live_events_cache') ?? '{}';
          final Map<String, dynamic> data = json.decode(liveData);
          final events = data[fixtureId] as List? ?? [];
          final event = extraData?['event'] as Map<String, dynamic>?;
          if (event != null) {
            events.insert(0, event);
            if (events.length > 20) events.removeLast();
            data[fixtureId] = events;
            await prefs.setString('live_events_cache', json.encode(data));
          }
          break;

        case 'voters':
          final votersData = prefs.getString('voters_cache') ?? '{}';
          final Map<String, dynamic> data = json.decode(votersData);
          final votersList =
              extraData?['voters'] as List<Map<String, dynamic>>?;
          if (votersList != null) {
            data[fixtureId] = votersList;
            await prefs.setString('voters_cache', json.encode(data));
          }
          break;
      }
    } catch (e) {
      debugPrint('⚠️ Failed to save update to disk: $e');
    }
  }

  // ==========================================================================
  // LOAD - ASYNCHRONOUS, NON-BLOCKING
  // ==========================================================================
  static Future<void> load() async {
    if (isLoaded) return;

    // Start loading in background, don't wait
    _loadInBackground();

    // Return immediately so app starts
    isLoaded = true;
    debugPrint('⚡ AppCache load started (background) - UI already ready');
  }

  static Future<void> _loadInBackground() async {
    try {
      final prefs = await SharedPreferences.getInstance();

      // Load fixtures (most important)
      final fixturesJson = prefs.getString('fixtures_cache');
      if (fixturesJson != null) {
        final List<dynamic> data = jsonDecode(fixturesJson);
        fixtures = data
            .map((f) => Fixture.fromJson(f as Map<String, dynamic>))
            .toList();
        debugPrint('📦 Background: ${fixtures.length} fixtures loaded');
        _fixturesController.add(fixtures);
      }

      // Load channels
      final channelsJson = prefs.getString('cached_channels');
      if (channelsJson != null) {
        final List<dynamic> data = jsonDecode(channelsJson);
        channels = data
            .map((c) => UserChannel.fromJson(c as Map<String, dynamic>))
            .toList();
        debugPrint('📦 Background: ${channels.length} channels loaded');
      }

      // Load user votes
      final votesJson = prefs.getString('cached_user_votes');
      if (votesJson != null) {
        final Map<String, dynamic> data = jsonDecode(votesJson);
        userVotes = Map<String, String?>.from(data);
        debugPrint('📦 Background: ${userVotes.length} votes loaded');
      }

      // Load channel fixtures
      final channelFixturesJson = prefs.getString('channel_fixtures_cache');
      if (channelFixturesJson != null) {
        final Map<String, dynamic> data = jsonDecode(channelFixturesJson);
        for (var entry in data.entries) {
          channelFixtures[entry.key] =
              ChannelFixtureData.fromJson(entry.value as Map<String, dynamic>);
        }
        debugPrint(
            '📦 Background: ${channelFixtures.length} channel fixtures loaded');
      }

      // Load comrades
      final comradesJson = prefs.getString('cached_comrades');
      if (comradesJson != null) {
        final List<dynamic> data = jsonDecode(comradesJson);
        comrades = data.cast<Map<String, dynamic>>();
        debugPrint('📦 Background: ${comrades.length} comrades loaded');
      }

      // Load user comrades
      final userComradesList = prefs.getStringList('cached_user_comrades');
      if (userComradesList != null) {
        userComrades = Set<String>.from(userComradesList);
        debugPrint(
            '📦 Background: ${userComrades.length} user comrades loaded');
      }

      // Load comrade voters
      final comradeVotersJson = prefs.getString('cached_comrade_voters');
      if (comradeVotersJson != null) {
        final Map<String, dynamic> data = jsonDecode(comradeVotersJson);
        for (var entry in data.entries) {
          final List<dynamic> votersList = entry.value;
          comradeVoters[entry.key] = votersList
              .map(
                  (v) => ComradeWithProfile.fromJson(v as Map<String, dynamic>))
              .toList();
        }
        debugPrint(
            '📦 Background: ${comradeVoters.length} comrade voters loaded');
      }

      // Load vote counts
      final voteCountsJson = prefs.getString('per_channel_vote_counts');
      if (voteCountsJson != null) {
        final Map<String, dynamic> data = jsonDecode(voteCountsJson);
        for (var entry in data.entries) {
          perChannelVoteCounts[entry.key] =
              Map<String, int>.from(entry.value as Map);
        }
        debugPrint(
            '📦 Background: ${perChannelVoteCounts.length} vote counts loaded');
      }

      // Load vote counts (fast)
      final voteCountsFastJson = prefs.getString('vote_counts_cache');
      if (voteCountsFastJson != null) {
        final Map<String, dynamic> data = jsonDecode(voteCountsFastJson);
        for (var entry in data.entries) {
          _voteCounts[entry.key] = entry.value as int;
        }
        debugPrint('📦 Background: ${_voteCounts.length} vote counts loaded');
      }

      // Load comment counts
      final commentCountsJson = prefs.getString('comment_counts_cache');
      if (commentCountsJson != null) {
        final Map<String, dynamic> data = jsonDecode(commentCountsJson);
        for (var entry in data.entries) {
          _commentCounts[entry.key] = entry.value as int;
        }
        debugPrint(
            '📦 Background: ${_commentCounts.length} comment counts loaded');
      }

      // Load like counts
      final likeCountsJson = prefs.getString('like_counts_cache');
      if (likeCountsJson != null) {
        final Map<String, dynamic> data = jsonDecode(likeCountsJson);
        for (var entry in data.entries) {
          _likeCounts[entry.key] = entry.value as int;
        }
        debugPrint('📦 Background: ${_likeCounts.length} like counts loaded');
      }

      // Load pledge counts (NEW)
      final pledgeCountsJson = prefs.getString('pledge_counts_cache');
      if (pledgeCountsJson != null) {
        final Map<String, dynamic> data = jsonDecode(pledgeCountsJson);
        for (var entry in data.entries) {
          _pledgeCounts[entry.key] = entry.value as int;
        }
        debugPrint(
            '📦 Background: ${_pledgeCounts.length} pledge counts loaded');
      }

      // Load bet counts (NEW)
      final betCountsJson = prefs.getString('bet_counts_cache');
      if (betCountsJson != null) {
        final Map<String, dynamic> data = jsonDecode(betCountsJson);
        for (var entry in data.entries) {
          _betCounts[entry.key] = entry.value as int;
        }
        debugPrint('📦 Background: ${_betCounts.length} bet counts loaded');
      }

      // Load unread counts
      final unreadJson = prefs.getString('unread_counts_cache');
      if (unreadJson != null) {
        final Map<String, dynamic> data = jsonDecode(unreadJson);
        for (var entry in data.entries) {
          _unreadCounts[entry.key] = entry.value as int;
        }
        debugPrint(
            '📦 Background: ${_unreadCounts.length} unread counts loaded');
      }

      // Load latest comments
      final latestCommentsJson = prefs.getString('latest_comments_cache');
      if (latestCommentsJson != null) {
        final Map<String, dynamic> data = jsonDecode(latestCommentsJson);
        for (var entry in data.entries) {
          final item = entry.value as Map<String, dynamic>;
          _latestComments[entry.key] = item['comment'] as String?;
          _latestCommentAuthors[entry.key] = item['author'] as String?;
          if (item['timestamp'] != null) {
            _latestCommentTimestamps[entry.key] =
                DateTime.tryParse(item['timestamp']);
          }
        }
        debugPrint(
            '📦 Background: ${_latestComments.length} latest comments loaded');
      }

      // Load live events (NEW)
      final liveEventsJson = prefs.getString('live_events_cache');
      if (liveEventsJson != null) {
        final Map<String, dynamic> data = jsonDecode(liveEventsJson);
        for (var entry in data.entries) {
          _liveEvents[entry.key] = List<Map<String, dynamic>>.from(entry.value);
        }
        debugPrint('📦 Background: ${_liveEvents.length} live events loaded');
      }

      // Load voters (NEW)
      final votersJson = prefs.getString('voters_cache');
      if (votersJson != null) {
        final Map<String, dynamic> data = jsonDecode(votersJson);
        for (var entry in data.entries) {
          _voters[entry.key] = List<Map<String, dynamic>>.from(entry.value);
        }
        debugPrint('📦 Background: ${_voters.length} voters lists loaded');
      }

      // Load messages (largest - load last)
      final messagesJson = prefs.getString('cached_messages');
      if (messagesJson != null) {
        final Map<String, dynamic> data = jsonDecode(messagesJson);
        for (var entry in data.entries) {
          _cachedMessages[entry.key] =
              List<Map<String, dynamic>>.from(entry.value);
        }
        debugPrint(
            '📦 Background: ${_cachedMessages.length} message groups loaded');
      }

      // Load admin caches
      final channelStatsJson = prefs.getString('cached_channel_stats');
      if (channelStatsJson != null) {
        final Map<String, dynamic> data = jsonDecode(channelStatsJson);
        for (var entry in data.entries) {
          _cachedChannelStats[entry.key] =
              Map<String, dynamic>.from(entry.value);
        }
      }

      final channelMembersJson = prefs.getString('cached_channel_members');
      if (channelMembersJson != null) {
        final Map<String, dynamic> data = jsonDecode(channelMembersJson);
        for (var entry in data.entries) {
          _cachedChannelMembers[entry.key] =
              List<Map<String, dynamic>>.from(entry.value);
        }
      }

      final lineupsJson = prefs.getString('cached_lineups');
      if (lineupsJson != null) {
        final Map<String, dynamic> data = jsonDecode(lineupsJson);
        for (var entry in data.entries) {
          _cachedLineups[entry.key] = Map<String, dynamic>.from(entry.value);
        }
      }

      final comradeLeaderboardJson =
          prefs.getString('cached_comrade_leaderboard');
      if (comradeLeaderboardJson != null) {
        final Map<String, dynamic> data = jsonDecode(comradeLeaderboardJson);
        for (var entry in data.entries) {
          _cachedComradeLeaderboard[entry.key] =
              List<Map<String, dynamic>>.from(entry.value);
        }
      }

      final comradeVotersDataJson =
          prefs.getString('cached_comrade_voters_data');
      if (comradeVotersDataJson != null) {
        final Map<String, dynamic> data = jsonDecode(comradeVotersDataJson);
        for (var entry in data.entries) {
          _cachedComradeVotersData[entry.key] =
              List<Map<String, dynamic>>.from(entry.value);
        }
      }

      debugPrint('✅ AppCache background load complete');
    } catch (e) {
      debugPrint('❌ AppCache background load error: $e');
    }
  }

  // ==========================================================================
  // MESSAGE CACHE METHODS
  // ==========================================================================
  static void cacheMessages(
    String channelId,
    String? fixtureId,
    List<Map<String, dynamic>> messages,
  ) {
    final key =
        fixtureId != null ? '${channelId}_$fixtureId' : '${channelId}_overall';
    _cachedMessages[key] = messages;
    debugPrint('💾 Cached ${messages.length} messages for $key');
    _saveMessagesToDisk();
  }

  static List<Map<String, dynamic>>? getCachedMessages(
    String channelId,
    String? fixtureId,
  ) {
    final key =
        fixtureId != null ? '${channelId}_$fixtureId' : '${channelId}_overall';
    return _cachedMessages[key];
  }

  static Future<void> _saveMessagesToDisk() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('cached_messages', json.encode(_cachedMessages));
  }

  // ==========================================================================
  // ADMIN DASHBOARD CACHE METHODS
  // ==========================================================================
  static void cacheChannelStats(String channelId, Map<String, dynamic> stats) {
    _cachedChannelStats[channelId] = stats;
    _saveChannelStatsToDisk();
  }

  static Map<String, dynamic>? getCachedChannelStats(String channelId) {
    return _cachedChannelStats[channelId];
  }

  static Future<void> _saveChannelStatsToDisk() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      'cached_channel_stats',
      json.encode(_cachedChannelStats),
    );
  }

  static void cacheChannelMembers(
    String channelId,
    List<Map<String, dynamic>> members,
  ) {
    _cachedChannelMembers[channelId] = members;
    _saveChannelMembersToDisk();
  }

  static List<Map<String, dynamic>>? getCachedChannelMembers(
    String channelId,
  ) {
    return _cachedChannelMembers[channelId];
  }

  static Future<void> _saveChannelMembersToDisk() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      'cached_channel_members',
      json.encode(_cachedChannelMembers),
    );
  }

  // ==========================================================================
  // LINEUP CACHE METHODS
  // ==========================================================================
  static void cacheLineup(String fixtureId, Map<String, dynamic> lineupData) {
    _cachedLineups[fixtureId] = lineupData;
    _saveLineupsToDisk();
  }

  static Map<String, dynamic>? getCachedLineup(String fixtureId) {
    return _cachedLineups[fixtureId];
  }

  static Future<void> _saveLineupsToDisk() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('cached_lineups', json.encode(_cachedLineups));
  }

  // ==========================================================================
  // COMRADE MODAL CACHE METHODS
  // ==========================================================================
  static void cacheComradeLeaderboard(
    String userId,
    List<Map<String, dynamic>> comrades,
  ) {
    _cachedComradeLeaderboard[userId] = comrades;
    _saveComradeLeaderboardToDisk();
  }

  static List<Map<String, dynamic>>? getCachedComradeLeaderboard(
    String userId,
  ) {
    return _cachedComradeLeaderboard[userId];
  }

  static Future<void> _saveComradeLeaderboardToDisk() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      'cached_comrade_leaderboard',
      json.encode(_cachedComradeLeaderboard),
    );
  }

  static void cacheComradeVotersData(
    String fixtureId,
    List<Map<String, dynamic>> voters,
  ) {
    _cachedComradeVotersData[fixtureId] = voters;
    _saveComradeVotersDataToDisk();
  }

  static List<Map<String, dynamic>>? getCachedComradeVotersData(
    String fixtureId,
  ) {
    return _cachedComradeVotersData[fixtureId];
  }

  static Future<void> _saveComradeVotersDataToDisk() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      'cached_comrade_voters_data',
      json.encode(_cachedComradeVotersData),
    );
  }

  // ==========================================================================
  // SAVE METHODS
  // ==========================================================================
  static Future<void> saveFixtures(List<Fixture> newFixtures) async {
    fixtures = newFixtures;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      'fixtures_cache',
      json.encode(fixtures.map((f) => f.toJson()).toList()),
    );
    await prefs.setInt(
      'fixtures_timestamp',
      DateTime.now().millisecondsSinceEpoch ~/ 1000,
    );
    debugPrint('💾 Saved ${fixtures.length} fixtures to disk');
  }

  static Future<void> saveChannelFixtures(
    Map<String, ChannelFixtureData> data,
  ) async {
    channelFixtures = data;
    final prefs = await SharedPreferences.getInstance();
    final serialized = <String, dynamic>{};
    for (var entry in data.entries) {
      serialized[entry.key] = {
        'fixtureId': entry.value.fixtureId,
        'channelId': entry.value.channelId,
        'matchName': entry.value.matchName,
        'kickoffTime': entry.value.kickoffTime.toIso8601String(),
        'status': entry.value.status,
        'homeVotes': entry.value.homeVotes,
        'awayVotes': entry.value.awayVotes,
        'drawVotes': entry.value.drawVotes,
        'lastMessage': entry.value.lastMessage,
        'lastMessageAt': entry.value.lastMessageAt?.toIso8601String(),
        'lastSender': entry.value.lastSender,
        'userVote': entry.value.userVote,
        'commentCount': entry.value.commentCount,
        'unreadCounts': entry.value.unreadCounts,
      };
    }
    await prefs.setString('channel_fixtures_cache', json.encode(serialized));
  }

  static Future<void> saveChannels(List<UserChannel> newChannels) async {
    channels = newChannels;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      'cached_channels',
      json.encode(channels.map((c) => c.toJson()).toList()),
    );
  }

  static Future<void> saveUserComrades(Set<String> comrades) async {
    userComrades = comrades;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('cached_user_comrades', comrades.toList());
  }

  static Future<void> saveComradeVoters(
    Map<String, List<ComradeWithProfile>> voters,
  ) async {
    comradeVoters = voters;
    final prefs = await SharedPreferences.getInstance();

    final serialized = <String, List<Map<String, dynamic>>>{};
    for (var entry in voters.entries) {
      serialized[entry.key] = entry.value.map((c) => c.toJson()).toList();
    }

    await prefs.setString('cached_comrade_voters', json.encode(serialized));
  }

  // ==========================================================================
  // CLEAR ALL CACHE
  // ==========================================================================
  static Future<void> clear() async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.remove('cached_comrades');
    await prefs.remove('cached_channels');
    await prefs.remove('fixtures_cache');
    await prefs.remove('cached_user_votes');
    await prefs.remove('channel_fixtures_cache');
    await prefs.remove('cached_user_comrades');
    await prefs.remove('cached_comrade_voters');
    await prefs.remove('cached_messages');
    await prefs.remove('cached_channel_stats');
    await prefs.remove('cached_channel_members');
    await prefs.remove('cached_lineups');
    await prefs.remove('cached_comrade_leaderboard');
    await prefs.remove('cached_comrade_voters_data');
    await prefs.remove('per_channel_vote_counts');
    await prefs.remove('comment_counts_cache');
    await prefs.remove('like_counts_cache');
    await prefs.remove('pledge_counts_cache');
    await prefs.remove('bet_counts_cache');
    await prefs.remove('latest_comments_cache');
    await prefs.remove('unread_counts_cache');
    await prefs.remove('live_events_cache');
    await prefs.remove('voters_cache');
    await prefs.remove('vote_counts_cache');

    comrades.clear();
    channels.clear();
    fixtures.clear();
    userVotes.clear();
    channelFixtures.clear();
    userComrades.clear();
    comradeVoters.clear();
    _cachedMessages.clear();
    _cachedChannelStats.clear();
    _cachedChannelMembers.clear();
    _cachedLineups.clear();
    _cachedComradeLeaderboard.clear();
    _cachedComradeVotersData.clear();
    perChannelVoteCounts.clear();
    _commentCounts.clear();
    _likeCounts.clear();
    _pledgeCounts.clear();
    _betCounts.clear();
    _userLikes.clear();
    _latestComments.clear();
    _latestCommentAuthors.clear();
    _latestCommentTimestamps.clear();
    _unreadCounts.clear();
    _liveEvents.clear();
    _voters.clear();
    _voteCounts.clear();
    _lastVoteUpdate.clear();
    _lastCommentUpdate.clear();
    _lastLikeUpdate.clear();
    _lastLatestCommentUpdate.clear();
    _lastPledgeUpdate.clear();
    _lastBetUpdate.clear();
    _lastUnreadUpdate.clear();
    isLoaded = false;

    debugPrint('🗑️ AppCache cleared completely');
  }

  // ==========================================================================
  // HELPER METHOD TO GET MESSAGES BY CHANNEL AND FIXTURE
  // ==========================================================================
  static List<Map<String, dynamic>>? getMessages(
    String channelId,
    String? fixtureId,
  ) {
    final key =
        fixtureId != null ? '${channelId}_$fixtureId' : '${channelId}_overall';
    return _cachedMessages[key];
  }
}

// ============================================================================
// FCM BACKGROUND HANDLER
// ============================================================================

@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  developer.log(
    '🔔 Background message: ${message.messageId}',
    name: 'FCM-Background',
  );
  final type =
      message.data['type'] ?? message.data['notificationType'] ?? 'general';
  if (type == 'comrade_added') {
    final prefs = await SharedPreferences.getInstance();
    final pendingNotifications =
        prefs.getStringList('pending_notifications') ?? [];
    pendingNotifications.add(message.data.toString());
    await prefs.setStringList('pending_notifications', pendingNotifications);
  }
}

// ============================================================================
// EMULATOR DETECTION
// ============================================================================

bool get isEmulator {
  if (kIsWeb) return false;
  if (Platform.isAndroid) {
    return Platform.environment['ANDROID_EMULATOR'] != null ||
        Platform.environment['ro.kernel.qemu'] != null ||
        Platform.environment['ro.hardware']?.contains('ranchu') == true ||
        Platform.environment['ro.product.device']?.contains('generic') ==
            true ||
        Platform.environment['ro.product.model']?.contains('sdk') == true;
  }
  if (Platform.isIOS) {
    return Platform.environment['SIMULATOR_DEVICE_NAME'] != null;
  }
  return false;
}

// ============================================================================
// MAIN ENTRY POINT
// ============================================================================

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // ✅ LOAD CACHE - RETURNS IMMEDIATELY (0ms)
  await AppCache.load();

  FlutterError.onError = (FlutterErrorDetails details) {
    FlutterError.dumpErrorToConsole(details);
    developer.log(
      '🔥 Flutter Error: ${details.exception}',
      name: 'ClashApp',
      error: details.exception,
    );
  };

  await initializeApp();
  runApp(const ClashApp());
}

Future<void> initializeDeepLinks() async {
  final appLinks = AppLinks();

  final initialUri = await appLinks.getInitialLink();
  if (initialUri != null) {
    _handleDeepLink(initialUri);
  }

  appLinks.uriLinkStream.listen((uri) {
    _handleDeepLink(uri);
  });
}

void _handleDeepLink(Uri uri) {
  if (uri.scheme == 'clash' && uri.host == 'join') {
    final segments = uri.pathSegments;
    if (segments.isEmpty) return;
    final inviteCode = segments.first.toUpperCase();

    developer.log('🔗 Deep link: invite code $inviteCode', name: 'ClashApp');

    Future.delayed(const Duration(milliseconds: 500), () {
      _showJoinChannelDialog(inviteCode);
    });
  }
}

Future<void> _showJoinChannelDialog(String inviteCode) async {
  final context = navigatorKey.currentContext;
  if (context == null) return;

  Map<String, dynamic>? channelData;
  try {
    final response = await http.get(
      Uri.parse(
          'https://clash-api-m5mr.onrender.com/api/channels/invite/$inviteCode'),
    );
    if (response.statusCode == 200) {
      channelData = json.decode(response.body);
    }
  } catch (e) {
    developer.log('❌ Failed to fetch channel: $e', name: 'ClashApp');
  }

  if (!context.mounted) return;

  final channelName = channelData?['channel_name'] ?? 'Unknown Channel';
  final memberCount = channelData?['member_count'] ?? 0;

  showDialog(
    context: context,
    barrierDismissible: false,
    builder: (dialogContext) => _JoinChannelDialog(
      inviteCode: inviteCode,
      channelName: channelName,
      memberCount: memberCount,
    ),
  );
}

// ============================================================================
// APP INITIALIZATION
// ============================================================================

Future<void> initializeApp() async {
  try {
    developer.log('🔥 Initializing Firebase…', name: 'ClashApp');
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
    developer.log('✅ Firebase initialized', name: 'ClashApp');
    await initializeDeepLinks();

    await AuthService().initialize();
    developer.log('✅ AuthService initialized', name: 'ClashApp');

    if (!kIsWeb) {
      await initializeFCM();
    }

    if (!kIsWeb) {
      try {
        developer.log('📱 Initializing Google Mobile Ads…', name: 'ClashApp');
        await MobileAds.instance.initialize();
        developer.log('✅ Google Mobile Ads SDK initialized', name: 'ClashApp');

        if (kDebugMode) {
          final testDeviceIds = <String>[];

          if (isEmulator) {
            testDeviceIds.add('EMULATOR');
            developer.log(
              '📱 Emulator detected - adding EMULATOR test device',
              name: 'ClashApp',
            );
          }

          testDeviceIds.add('33BE2250B43518CCDA7DE426D04EE231');
          testDeviceIds.add('2077EF9A63D014AE3BC54155AD0A9A3B');

          await MobileAds.instance.updateRequestConfiguration(
            RequestConfiguration(testDeviceIds: testDeviceIds),
          );
          developer.log(
            '✅ Test mode configured with ${testDeviceIds.length} test devices',
            name: 'ClashApp',
          );
        }

        adsInitCompleter.complete();
        developer.log('✅ adsInitCompleter completed', name: 'ClashApp');

        if (kDebugMode) {
          await Future.delayed(const Duration(seconds: 1));

          final testAd = NativeAd(
            adUnitId: 'ca-app-pub-3940256099942544/2247696110',
            factoryId: 'nativeAdFactory',
            request: const AdRequest(),
            listener: NativeAdListener(
              onAdLoaded: (ad) {
                developer.log(
                  '🎯✅ TEST AD LOADED SUCCESSFULLY!',
                  name: 'ClashApp',
                );
                ad.dispose();
              },
              onAdFailedToLoad: (ad, error) {
                developer.log(
                  '🎯❌ TEST AD FAILED: ${error.code} - ${error.message}',
                  name: 'ClashApp',
                );
                ad.dispose();
              },
            ),
          );
          testAd.load();
        }
      } catch (e) {
        developer.log('⚠️ Ads initialization error: $e', name: 'ClashApp');
        if (!adsInitCompleter.isCompleted) {
          adsInitCompleter.completeError(e);
        }
      }
    } else {
      developer.log('🌐 Web platform - ads not supported', name: 'ClashApp');
      adsInitCompleter.complete();
    }
  } catch (e) {
    developer.log('❌ Initialization error: $e', name: 'ClashApp');
    if (!adsInitCompleter.isCompleted) {
      adsInitCompleter.completeError(e);
    }
  }
}

// ============================================================================
// FCM SETUP
// ============================================================================

Future<void> initializeFCM() async {
  try {
    developer.log('🔔 Initializing FCM…', name: 'ClashApp');
    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

    final settings = await FirebaseMessaging.instance.requestPermission();
    if (settings.authorizationStatus != AuthorizationStatus.authorized) {
      developer.log('⚠️ FCM permission denied', name: 'ClashApp');
      return;
    }

    developer.log('✅ FCM permissions granted', name: 'ClashApp');

    final token = await FirebaseMessaging.instance.getToken();
    if (token != null) {
      developer.log(
        '📱 FCM Token: ${token.substring(0, token.length > 20 ? 20 : token.length)}…',
        name: 'ClashApp',
      );
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('fcm_token', token);
    }

    FirebaseMessaging.instance.onTokenRefresh.listen((newToken) {
      developer.log('🔄 FCM Token refreshed', name: 'ClashApp');
      SharedPreferences.getInstance().then((prefs) {
        prefs.setString('fcm_token', newToken);
      });
    });

    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      developer.log('🔔 Foreground FCM message', name: 'ClashApp');
      final payload = _buildPayload(message);

      if (payload['type'] == 'comrade_added') {
        final username = message.data['username'] ?? 'Someone';
        if (messengerKey.currentContext != null) {
          ScaffoldMessenger.of(messengerKey.currentContext!).showSnackBar(
            SnackBar(
              content: Text('🎉 $username added you as a comrade!'),
              backgroundColor: const Color(0xFF10B981),
              behavior: SnackBarBehavior.floating,
              duration: const Duration(seconds: 3),
              action: SnackBarAction(
                label: 'View',
                textColor: Colors.white,
                onPressed: () =>
                    navigatorKey.currentState?.pushNamed('/profile'),
              ),
            ),
          );
        }
      }
      NotificationService.pushToStream(payload);
    });

    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      developer.log('🔔 App resumed from notification tap', name: 'ClashApp');
      _handleNotificationClick(message.data);
    });

    final initialMessage = await FirebaseMessaging.instance.getInitialMessage();
    if (initialMessage != null) {
      developer.log(
        '🔔 App launched from terminated state via notification',
        name: 'ClashApp',
      );
      Future.delayed(
        const Duration(milliseconds: 500),
        () => _handleNotificationClick(initialMessage.data),
      );
    }
  } catch (e) {
    developer.log('❌ FCM initialization error: $e', name: 'ClashApp');
  }
}

Map<String, dynamic> _buildPayload(RemoteMessage message) {
  final type =
      message.data['type'] ?? message.data['notificationType'] ?? 'general';
  return {
    'type': type,
    'title': message.notification?.title ??
        message.data['title'] ??
        'New Notification',
    'body': message.notification?.body ?? message.data['body'] ?? '',
    'data': message.data,
    'notificationId': message.messageId ?? '',
    'timestamp': DateTime.now().toIso8601String(),
  };
}

void _handleNotificationClick(Map<String, dynamic> data) {
  final type = data['type'] as String? ?? '';
  if (type == 'comrade_added') {
    navigatorKey.currentState?.pushNamed('/profile');
  } else if (type.contains('vote') ||
      type.contains('sub_fixture') ||
      data.containsKey('fixture_id')) {
    navigatorKey.currentState?.pushNamed('/fixtures');
  } else if (type == 'comment' ||
      type == 'like' ||
      data.containsKey('post_id')) {
    navigatorKey.currentState?.pushNamed('/feed');
  }
}

// ============================================================================
// MAIN APP WIDGET
// ============================================================================

class ClashApp extends StatefulWidget {
  const ClashApp({super.key});

  @override
  State<ClashApp> createState() => _ClashAppState();
}

class _ClashAppState extends State<ClashApp> {
  final AuthService _authService = AuthService();
  bool _isLoggedIn = false;
  String? _userId;
  String? _username;

  @override
  void initState() {
    super.initState();
    _authService.addListener(_onAuthStateChanged);
    _isLoggedIn = _authService.isLoggedIn;
    _userId = _authService.userId;
    _username = _authService.username;
    _checkPendingNotifications();
  }

  Future<void> _checkPendingNotifications() async {
    final prefs = await SharedPreferences.getInstance();
    final pending = prefs.getStringList('pending_notifications') ?? [];
    if (pending.isNotEmpty) {
      developer.log(
        '📱 Found ${pending.length} pending notifications',
        name: 'ClashApp',
      );
      await prefs.remove('pending_notifications');
    }
  }

  void _onAuthStateChanged() {
    if (mounted) {
      setState(() {
        _isLoggedIn = _authService.isLoggedIn;
        _userId = _authService.userId;
        _username = _authService.username;
      });
    }
  }

  @override
  void dispose() {
    _authService.removeListener(_onAuthStateChanged);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final interTextTheme = GoogleFonts.interTextTheme(
      ThemeData.dark().textTheme.copyWith(
            displayLarge: SocialTheme.display,
            displayMedium: SocialTheme.display,
            displaySmall: SocialTheme.display,
            headlineMedium: SocialTheme.headline,
            headlineSmall: SocialTheme.headline,
            titleLarge: SocialTheme.headline,
            titleMedium: SocialTheme.body,
            titleSmall: SocialTheme.body,
            bodyLarge: SocialTheme.body,
            bodyMedium: SocialTheme.body,
            bodySmall: SocialTheme.small,
            labelLarge: SocialTheme.label,
            labelMedium: SocialTheme.label,
            labelSmall: SocialTheme.tiny,
          ),
    );

    return MaterialApp(
      builder: SocialTheme.builder,
      title: 'clash',
      debugShowCheckedModeBanner: false,
      navigatorKey: navigatorKey,
      scaffoldMessengerKey: messengerKey,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: SocialTheme.primary,
          brightness: Brightness.dark,
          background: SocialTheme.background,
          surface: SocialTheme.card,
          primary: SocialTheme.primary,
          secondary: SocialTheme.secondary,
          error: SocialTheme.destructive,
        ),
        useMaterial3: true,
        textTheme: interTextTheme,
        primaryTextTheme: interTextTheme,
        scaffoldBackgroundColor: SocialTheme.background,
        iconTheme: IconThemeData(color: SocialTheme.primary, size: 24),
        appBarTheme: AppBarTheme(
          backgroundColor: SocialTheme.background,
          surfaceTintColor: Colors.transparent,
          elevation: 0,
          titleTextStyle: SocialTheme.headline.copyWith(fontSize: 18),
          iconTheme: IconThemeData(color: SocialTheme.foreground),
        ),
        bottomSheetTheme: const BottomSheetThemeData(
          backgroundColor: Colors.transparent,
        ),
        dividerTheme: DividerThemeData(
          color: SocialTheme.border.withValues(alpha: 0.5),
          thickness: 1,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: SocialTheme.primaryBtn,
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: SocialTheme.secondaryBtn,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: SocialTheme.card.withValues(alpha: 0.5),
          hintStyle: SocialTheme.small,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(SocialTheme.radius - 4),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(SocialTheme.radius - 4),
            borderSide: BorderSide(color: SocialTheme.inputColor),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(SocialTheme.radius - 4),
            borderSide: BorderSide(color: SocialTheme.primary, width: 2),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(SocialTheme.radius - 4),
            borderSide: BorderSide(color: SocialTheme.destructive),
          ),
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 12,
          ),
          prefixIconColor: SocialTheme.mutedForeground,
        ),
      ),
      home: HomePage(
        key: ValueKey('home_${_userId ?? 'guest'}'),
        initialTab: 0,
      ),
      routes: {
        '/feed': (context) => const HomePage(initialTab: 0),
        '/fixtures': (context) => const HomePage(initialTab: 1),
        '/profile': (context) => const HomePage(initialTab: 0),
      },
    );
  }
}
