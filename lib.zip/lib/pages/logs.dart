import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../services/auth_service.dart';
import 'fan_clash_design.dart';
import '../modals/login_modal.dart';
import '../modals/clash/comrades_modal.dart';
import '../modals/FAB/voting_bottom_sheet.dart';
import '../models/fixture_models.dart';
import '../main.dart';
import '../services/comrade_service.dart';

// ========== ARCHIVE ACTIVITY MODEL ==========
class ArchiveActivity {
  final String id;
  final String userId;
  final String username;
  final String fixtureId;
  final String homeTeam;
  final String awayTeam;
  final String activityType;
  final String? selection;
  final bool? isLiked;
  final String? comment;
  final DateTime timestamp;
  final DateTime createdAt;

  ArchiveActivity({
    required this.id,
    required this.userId,
    required this.username,
    required this.fixtureId,
    required this.homeTeam,
    required this.awayTeam,
    required this.activityType,
    this.selection,
    this.isLiked,
    this.comment,
    required this.timestamp,
    required this.createdAt,
  });

  factory ArchiveActivity.fromJson(Map<String, dynamic> json) {
    String id = '';
    if (json['_id'] != null) {
      if (json['_id'] is Map) {
        id = json['_id']['\$oid']?.toString() ?? '';
      } else {
        id = json['_id'].toString();
      }
    } else if (json['id'] != null) {
      id = json['id'].toString();
    }

    return ArchiveActivity(
      id: id,
      userId: json['user_id']?.toString() ?? json['userId']?.toString() ?? '',
      username: json['username']?.toString() ?? 'Anonymous',
      fixtureId:
          json['fixture_id']?.toString() ?? json['fixtureId']?.toString() ?? '',
      homeTeam: json['home_team']?.toString() ??
          json['homeTeam']?.toString() ??
          'Unknown',
      awayTeam: json['away_team']?.toString() ??
          json['awayTeam']?.toString() ??
          'Unknown',
      activityType: json['activity_type']?.toString() ??
          json['activityType']?.toString() ??
          'vote',
      selection: json['selection']?.toString(),
      isLiked: json['is_liked'] as bool? ?? json['isLiked'] as bool?,
      comment: json['comment']?.toString(),
      timestamp: _parseDateTime(json['timestamp']),
      createdAt: _parseDateTime(json['created_at'] ?? json['createdAt']),
    );
  }

  static DateTime _parseDateTime(dynamic value) {
    if (value == null) return DateTime.now();
    if (value is DateTime) return value;
    if (value is num) {
      if (value > 10000000000) {
        return DateTime.fromMillisecondsSinceEpoch(value.toInt());
      } else {
        return DateTime.fromMillisecondsSinceEpoch(value.toInt() * 1000);
      }
    }
    if (value is String) {
      try {
        return DateTime.parse(value);
      } catch (e) {
        return DateTime.now();
      }
    }
    return DateTime.now();
  }
}

// ========== ACTIVE FIXTURE MODEL ==========
class ActiveFixture {
  final String fixtureId;
  final String homeTeam;
  final String awayTeam;
  final String league;
  final String date;
  final int commentCount;
  final int voteCount;
  final String? latestComment;
  final String? latestCommenter;
  bool hasUserJoined;

  ActiveFixture({
    required this.fixtureId,
    required this.homeTeam,
    required this.awayTeam,
    required this.league,
    required this.date,
    this.commentCount = 0,
    this.voteCount = 0,
    this.latestComment,
    this.latestCommenter,
    this.hasUserJoined = false,
  });
}

// ========== FIXTURES CACHE MANAGER ==========
class FixturesCacheManager {
  static const String _fixturesCacheKey = 'cached_active_fixtures';
  static const String _fixturesTimestampKey = 'fixtures_cache_timestamp';
  static const Duration _cacheDuration = Duration(minutes: 5);

  static Future<void> saveFixtures(List<ActiveFixture> fixtures) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final jsonList = fixtures
          .map(
            (f) => {
              'fixtureId': f.fixtureId,
              'homeTeam': f.homeTeam,
              'awayTeam': f.awayTeam,
              'league': f.league,
              'date': f.date,
              'commentCount': f.commentCount,
              'voteCount': f.voteCount,
              'latestComment': f.latestComment,
              'latestCommenter': f.latestCommenter,
              'hasUserJoined': f.hasUserJoined,
            },
          )
          .toList();

      await prefs.setString(_fixturesCacheKey, jsonEncode(jsonList));
      await prefs.setInt(
        _fixturesTimestampKey,
        DateTime.now().millisecondsSinceEpoch,
      );
      debugPrint('💾 Cached ${fixtures.length} fixtures');
    } catch (e) {
      debugPrint('❌ Error caching fixtures: $e');
    }
  }

  static Future<List<ActiveFixture>> loadFixtures() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final cachedJson = prefs.getString(_fixturesCacheKey);
      final timestamp = prefs.getInt(_fixturesTimestampKey);

      if (cachedJson == null || timestamp == null) return [];

      final cacheAge = DateTime.now().millisecondsSinceEpoch - timestamp;
      if (cacheAge > _cacheDuration.inMilliseconds) return [];

      final List<dynamic> jsonList = jsonDecode(cachedJson);
      return jsonList
          .map(
            (json) => ActiveFixture(
              fixtureId: json['fixtureId'],
              homeTeam: json['homeTeam'],
              awayTeam: json['awayTeam'],
              league: json['league'],
              date: json['date'],
              commentCount: json['commentCount'] ?? 0,
              voteCount: json['voteCount'] ?? 0,
              latestComment: json['latestComment'],
              latestCommenter: json['latestCommenter'],
              hasUserJoined: json['hasUserJoined'] ?? false,
            ),
          )
          .toList();
    } catch (e) {
      debugPrint('❌ Error loading cached fixtures: $e');
      return [];
    }
  }

  static Future<bool> isCacheValid() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final timestamp = prefs.getInt(_fixturesTimestampKey);
      if (timestamp == null) return false;
      final cacheAge = DateTime.now().millisecondsSinceEpoch - timestamp;
      return cacheAge < _cacheDuration.inMilliseconds;
    } catch (e) {
      return false;
    }
  }
}

// ========== LOGS PAGE ==========
class LogsPage extends StatefulWidget {
  final String currentUserId;
  final String currentUsername;
  final String? authToken;
  final ScrollController? scrollController;
  final bool isLoggedIn;

  const LogsPage({
    super.key,
    required this.currentUserId,
    required this.currentUsername,
    this.authToken,
    this.scrollController,
    this.isLoggedIn = false,
  });

  @override
  State<LogsPage> createState() => _LogsPageState();
}

class _LogsPageState extends State<LogsPage> with WidgetsBindingObserver {
  late final AuthService _authService;

  List<ArchiveActivity> _activities = [];
  List<ActiveFixture> _activeFixtures = [];
  Set<String> _joinedFixtureIds = {};

  bool _isLoading = true;
  bool _isRefreshing = false;
  bool _isFetching = false;
  String _error = '';
  bool _isLoggingOut = false;
  bool _isDisposed = false;
  bool _isModalOpen = false;

  // For the voting modal
  final Set<String> _userComrades = {};
  final Map<String, Map<String, String>> _comradesVoteMap = {};
  final Map<String, String> _userVotes = {};

  // Store unread counts per fixture
  final Map<String, int> _unreadCounts = {};

  static const String API_BASE_URL = 'https://clash-api-m5mr.onrender.com/api';
  static const String _logsCacheKey = 'archive_logs_cache';
  static const String _logsTimestampKey = 'archive_logs_timestamp';
  static const String _unreadCountsCacheKey = 'unread_counts_cache';
  static const String _joinedFixturesKey = 'joined_fixtures_cache';

  bool get _isUserLoggedIn => widget.isLoggedIn;
  String get _userId => widget.currentUserId;
  String get _username => widget.currentUsername;
  String? get _authToken => widget.authToken;

  @override
  void initState() {
    super.initState();
    _authService = AuthService();
    _authService.addListener(_onAuthStateChanged);
    WidgetsBinding.instance.addObserver(this);

    // Load everything in parallel for faster startup
    _initializeData();
  }

  Future<void> _initializeData() async {
    // Load cached data first (instant display)
    await Future.wait([_loadJoinedFixtures(), _loadCachedFixtures()]);

    // Then fetch fresh data in background
    Future.wait([
      _fetchFreshFixtures(),
      _loadUserComrades(),
      _loadData(),
      _loadUnreadCounts(),
    ]);
  }

  Future<void> _loadCachedFixtures() async {
    final cachedFixtures = await FixturesCacheManager.loadFixtures();
    if (cachedFixtures.isNotEmpty) {
      _safeSetState(() {
        _activeFixtures = cachedFixtures;
        _isLoading = false;
      });
      debugPrint('📦 Loaded ${cachedFixtures.length} fixtures from cache');
    }
  }

  Future<void> _fetchFreshFixtures() async {
    if (_isFetching) return;
    await _fetchActiveFixtures();
  }

  @override
  void dispose() {
    _isDisposed = true;
    _authService.removeListener(_onAuthStateChanged);
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  void _safeSetState(VoidCallback fn) {
    if (!_isDisposed && mounted) setState(fn);
  }

  void _listenForNewComments() {
    _startUnreadCountPolling();
  }

  Timer? _pollingTimer;

  void _startUnreadCountPolling() {
    _pollingTimer?.cancel();
    _pollingTimer = Timer.periodic(Duration(seconds: 30), (timer) {
      if (_isUserLoggedIn && mounted) {
        _fetchUnreadCounts();
      }
    });
  }

  void _stopPolling() {
    _pollingTimer?.cancel();
    _pollingTimer = null;
  }

  void _onAuthStateChanged() {
    if (!mounted) return;
    if (!_authService.isLoggedIn && !_isLoggingOut) {
      _forceLogout();
    } else if (_authService.isLoggedIn) {
      _refreshLogs();
      _fetchActiveFixtures();
    }
  }

  void _forceLogout() {
    if (_isLoggingOut) return;
    _isLoggingOut = true;

    _safeSetState(() {
      _activities.clear();
      _userVotes.clear();
      _unreadCounts.clear();
      _joinedFixtureIds.clear();
      _activeFixtures.clear();
      _isRefreshing = false;
      _isFetching = false;
      _isLoading = false;
      _error = '';
    });

    _fetchActiveFixtures();
    _isLoggingOut = false;
  }

  Future<void> _loadJoinedFixtures() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final joined = prefs.getStringList(_joinedFixturesKey) ?? [];
      _joinedFixtureIds = joined.toSet();
      debugPrint('📦 Loaded ${_joinedFixtureIds.length} joined fixtures');
    } catch (e) {
      debugPrint('❌ Error loading joined fixtures: $e');
    }
  }

  Future<void> _saveJoinedFixture(String fixtureId) async {
    try {
      _joinedFixtureIds.add(fixtureId);
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList(_joinedFixturesKey, _joinedFixtureIds.toList());
      debugPrint('💾 Saved joined fixture: $fixtureId');
    } catch (e) {
      debugPrint('❌ Error saving joined fixture: $e');
    }
  }

  // Optimized: Fetch comment and vote count in a single parallel call
  Future<Map<String, dynamic>> _fetchFixtureDetails(String fixtureId) async {
    try {
      final headers = {'Content-Type': 'application/json'};
      if (_authToken != null && _authToken!.isNotEmpty) {
        headers['Authorization'] = 'Bearer $_authToken';
      }

      // Parallel requests
      final results = await Future.wait([
        http
            .get(
              Uri.parse(
                '$API_BASE_URL/votes/comments?fixtureId=$fixtureId&limit=1',
              ),
              headers: headers,
            )
            .timeout(const Duration(seconds: 10)),
        http.get(
          Uri.parse('$API_BASE_URL/votes/stats/$fixtureId'),
          headers: {'Content-Type': 'application/json'},
        ).timeout(const Duration(seconds: 10)),
      ]);

      // Parse comment
      int commentCount = 0;
      String? latestComment;
      String? latestCommenter;

      if (results[0].statusCode == 200) {
        final jsonData = json.decode(results[0].body);
        List<dynamic> commentsList = [];

        if (jsonData is Map<String, dynamic>) {
          if (jsonData.containsKey('data')) {
            final data = jsonData['data'];
            if (data is Map && data.containsKey('recentComments')) {
              commentsList = data['recentComments'] as List? ?? [];
            } else if (data is List) {
              commentsList = data;
            }
          } else if (jsonData.containsKey('comments')) {
            commentsList = jsonData['comments'] as List? ?? [];
          }
        } else if (jsonData is List) {
          commentsList = jsonData;
        }

        commentCount = commentsList.length;
        if (commentsList.isNotEmpty) {
          final latest = commentsList.first as Map<String, dynamic>;
          latestComment = latest['comment']?.toString();
          latestCommenter = latest['username']?.toString();
        }
      }

      // Parse vote count
      int voteCount = 0;
      if (results[1].statusCode == 200) {
        final data = json.decode(results[1].body);
        voteCount = data['totalVotes'] ?? data['total_votes'] ?? 0;
      }

      return {
        'commentCount': commentCount,
        'voteCount': voteCount,
        'latestComment': latestComment,
        'latestCommenter': latestCommenter,
      };
    } catch (e) {
      debugPrint('❌ Error fetching details for fixture $fixtureId: $e');
      // Return random mock data for demo
      final random = Random();
      final sampleComments = [
        "Can't wait for this match! 🔥",
        "Home team looking strong today 💪",
        "Away team has been in great form lately 📈",
      ];
      final sampleUsers = [
        "⚽ GoalMachine",
        "🔥 FireStriker",
        "🛡️ DefenseWall",
      ];

      return {
        'commentCount': random.nextInt(50) + 1,
        'voteCount': random.nextInt(100) + 10,
        'latestComment': sampleComments[random.nextInt(sampleComments.length)],
        'latestCommenter': sampleUsers[random.nextInt(sampleUsers.length)],
      };
    }
  }

  // ========== OPTIMIZED FETCH ACTIVE FIXTURES ==========
  Future<void> _fetchActiveFixtures() async {
    if (_isFetching) return;
    _isFetching = true;

    try {
      debugPrint('🌐 Fetching active fixtures...');

      final headers = {'Content-Type': 'application/json'};
      if (_isUserLoggedIn && _authToken != null && _authToken!.isNotEmpty) {
        headers['Authorization'] = 'Bearer $_authToken';
      }

      final response = await http
          .get(Uri.parse('$API_BASE_URL/games'), headers: headers)
          .timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        List<Fixture> fixtures = [];

        if (jsonData is Map<String, dynamic>) {
          if (jsonData['success'] == true && jsonData['data'] is List) {
            fixtures = _parseFixtures(jsonData['data'] as List);
          } else if (jsonData.containsKey('fixtures') &&
              jsonData['fixtures'] is List) {
            fixtures = _parseFixtures(jsonData['fixtures'] as List);
          } else if (jsonData.containsKey('games') &&
              jsonData['games'] is List) {
            fixtures = _parseFixtures(jsonData['games'] as List);
          }
        } else if (jsonData is List) {
          fixtures = _parseFixtures(jsonData);
        }

        debugPrint('📋 Found ${fixtures.length} fixtures');

        if (fixtures.isEmpty) {
          _safeSetState(() => _isLoading = false);
          _isFetching = false;
          return;
        }

        // OPTIMIZATION: Load ALL fixture details in PARALLEL
        final List<Future<Map<String, dynamic>>> detailFutures = [];
        for (var fixture in fixtures) {
          detailFutures.add(_fetchFixtureDetails(fixture.matchId));
        }

        final allDetails = await Future.wait(detailFutures);

        // Build active fixtures list
        final List<ActiveFixture> activeFixtures = [];
        for (int i = 0; i < fixtures.length; i++) {
          final fixture = fixtures[i];
          final details = allDetails[i];

          activeFixtures.add(
            ActiveFixture(
              fixtureId: fixture.matchId,
              homeTeam: fixture.homeTeam,
              awayTeam: fixture.awayTeam,
              league: fixture.league,
              date: fixture.date,
              commentCount: details['commentCount'] ?? 0,
              voteCount: details['voteCount'] ?? 0,
              latestComment: details['latestComment'],
              latestCommenter: details['latestCommenter'],
              hasUserJoined: _joinedFixtureIds.contains(fixture.matchId),
            ),
          );
        }

        // Sort by date
        activeFixtures.sort((a, b) {
          final aDate = _parseFixtureDate(a.date);
          final bDate = _parseFixtureDate(b.date);
          return aDate.compareTo(bDate);
        });

        // Cache the results
        await FixturesCacheManager.saveFixtures(activeFixtures);

        _safeSetState(() {
          _activeFixtures = activeFixtures;
          _isLoading = false;
          _isRefreshing = false;
          _error = '';
        });

        debugPrint('✅ Loaded ${_activeFixtures.length} active fixtures');
      } else {
        debugPrint('⚠️ Failed to load fixtures: ${response.statusCode}');
        if (_activeFixtures.isEmpty) {
          _safeSetState(() => _isLoading = false);
        }
      }
    } catch (e) {
      debugPrint('❌ Error fetching fixtures: $e');
      if (_activeFixtures.isEmpty) {
        _safeSetState(() {
          _isLoading = false;
          _error = 'Failed to load fixtures. Pull to refresh.';
        });
      }
    } finally {
      _isFetching = false;
    }
  }

  List<Fixture> _parseFixtures(List<dynamic> dataList) {
    final fixtures = <Fixture>[];
    for (var i = 0; i < dataList.length; i++) {
      try {
        fixtures.add(Fixture.fromJson(dataList[i] as Map<String, dynamic>));
      } catch (e) {
        debugPrint('❌ Error parsing fixture at index $i: $e');
      }
    }
    return fixtures;
  }

  DateTime _parseFixtureDate(String dateString) {
    if (dateString.isEmpty) return DateTime.now();

    // Try ISO format
    try {
      return DateTime.parse(dateString);
    } catch (e) {}

    // Try "day month" format (e.g., "10 May")
    try {
      final parts = dateString.trim().split(' ');
      if (parts.length == 2) {
        final day = int.parse(parts[0]);
        final monthStr = parts[1];
        final monthMap = {
          'Jan': 1,
          'Feb': 2,
          'Mar': 3,
          'Apr': 4,
          'May': 5,
          'Jun': 6,
          'Jul': 7,
          'Aug': 8,
          'Sep': 9,
          'Oct': 10,
          'Nov': 11,
          'Dec': 12,
        };
        final month = monthMap[monthStr] ?? 1;
        int year = DateTime.now().year;
        DateTime testDate = DateTime(year, month, day);
        if (testDate.isBefore(
          DateTime.now().subtract(const Duration(days: 30)),
        )) {
          year++;
          testDate = DateTime(year, month, day);
        }
        return testDate;
      }
    } catch (e) {}

    return DateTime.now();
  }

  void _showLoginModalForJoin(ActiveFixture fixture) {
    if (_isModalOpen) return;
    _isModalOpen = true;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => LoginModal(
        messengerKey: messengerKey,
        onLoginSuccess: (String userId, String username) async {
          debugPrint('✅ User logged in, joining fixture: ${fixture.fixtureId}');
          if (mounted) Navigator.pop(context);
          await _openFixtureAndJoin(fixture);
        },
      ),
    ).then((_) => _isModalOpen = false);
  }

  Future<void> _openFixtureAndJoin(ActiveFixture fixture) async {
    if (!_joinedFixtureIds.contains(fixture.fixtureId)) {
      await _saveJoinedFixture(fixture.fixtureId);
      _safeSetState(() {
        final index = _activeFixtures.indexWhere(
          (f) => f.fixtureId == fixture.fixtureId,
        );
        if (index != -1) {
          _activeFixtures[index].hasUserJoined = true;
        }
      });
      // Update cache
      await FixturesCacheManager.saveFixtures(_activeFixtures);
    }

    final fixtureObj = Fixture(
      id: fixture.fixtureId,
      matchId: fixture.fixtureId,
      homeTeam: fixture.homeTeam,
      awayTeam: fixture.awayTeam,
      homeWin: 0.0,
      awayWin: 0.0,
      draw: 0.0,
      date: fixture.date,
      time: fixture.date,
      dateIso: fixture.date,
      homeScore: 0,
      awayScore: 0,
      status: 'upcoming',
      league: fixture.league,
      isLive: false,
      availableForVoting: true,
      source: 'active',
      scrapedAt: DateTime.now(),
    );

    _openComradeVotingModal(fixtureObj, fixture.fixtureId);
  }

  Future<void> _loadUserComrades() async {
    if (!_isUserLoggedIn) return;
    try {
      final comradesList = await ComradeService.getUserComrades(
        userId: _userId,
        authToken: _authToken,
      );
      _userComrades.clear();
      for (var comrade in comradesList) {
        final comradeId = comrade['comrade_id']?.toString();
        if (comradeId != null && comradeId.isNotEmpty) {
          _userComrades.add(comradeId);
        }
      }
      debugPrint('✅ Loaded ${_userComrades.length} comrades');
    } catch (e) {
      debugPrint('Error loading comrades: $e');
    }
  }

  Future<void> _fetchUnreadCounts() async {
    if (!_isUserLoggedIn || _userId.isEmpty) return;

    try {
      final headers = {'Content-Type': 'application/json'};
      if (_authToken != null && _authToken!.isNotEmpty) {
        headers['Authorization'] = 'Bearer $_authToken';
      }

      final response = await http
          .get(
            Uri.parse('$API_BASE_URL/comments/unread/$_userId'),
            headers: headers,
          )
          .timeout(Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final counts = data['unread_counts'] as Map<String, dynamic>? ?? {};

        _safeSetState(() {
          _unreadCounts.clear();
          counts.forEach((fixtureId, count) {
            if (count is int && count > 0) {
              _unreadCounts[fixtureId] = count;
            } else if (count is num) {
              _unreadCounts[fixtureId] = count.toInt();
            }
          });
        });

        await _saveUnreadCountsToCache();
      }
    } catch (e) {
      debugPrint('❌ Failed to fetch unread counts: $e');
    }
  }

  Future<void> _saveUnreadCountsToCache() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_unreadCountsCacheKey, jsonEncode(_unreadCounts));
    } catch (e) {
      debugPrint('❌ Failed to cache unread counts: $e');
    }
  }

  Future<void> _loadUnreadCounts() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final cached = prefs.getString(_unreadCountsCacheKey);
      if (cached != null) {
        final decoded = jsonDecode(cached) as Map<String, dynamic>;
        _safeSetState(() {
          _unreadCounts.clear();
          decoded.forEach((fixtureId, count) {
            _unreadCounts[fixtureId] = count as int;
          });
        });
      }
    } catch (e) {}

    if (_isUserLoggedIn) {
      _fetchUnreadCounts();
    }
  }

  Future<void> _loadData() async {
    if (!_isUserLoggedIn) {
      _safeSetState(() {
        _isLoading = false;
        _activities = [];
        _error = '';
      });
      return;
    }

    final loadedFromCache = await _loadFromCache();
    if (!loadedFromCache) {
      await _fetchLogsFromNetwork();
    }
  }

  Future<bool> _loadFromCache() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final cachedJson = prefs.getString(_logsCacheKey);
      final cachedTimestamp = prefs.getInt(_logsTimestampKey);

      if (cachedJson != null && cachedTimestamp != null) {
        final currentTime = DateTime.now().millisecondsSinceEpoch ~/ 1000;
        final cacheAge = currentTime - cachedTimestamp;
        final isCacheFresh = cacheAge < (24 * 60 * 60);

        final List<dynamic> jsonList = jsonDecode(cachedJson);
        final cachedLogs =
            jsonList.map((j) => ArchiveActivity.fromJson(j)).toList();

        if (cachedLogs.isNotEmpty) {
          _safeSetState(() {
            _activities = cachedLogs;
            _isLoading = false;
            _error = '';
          });

          if (!isCacheFresh) {
            _fetchLogsFromNetwork();
          }
          return true;
        }
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<void> _saveToCache(List<ArchiveActivity> logs) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final timestamp = DateTime.now().millisecondsSinceEpoch ~/ 1000;

      final jsonList = logs
          .map(
            (l) => {
              '_id': l.id,
              'user_id': l.userId,
              'username': l.username,
              'fixture_id': l.fixtureId,
              'home_team': l.homeTeam,
              'away_team': l.awayTeam,
              'activity_type': l.activityType,
              'selection': l.selection,
              'is_liked': l.isLiked,
              'comment': l.comment,
              'created_at': l.createdAt.toIso8601String(),
            },
          )
          .toList();

      await prefs.setString(_logsCacheKey, jsonEncode(jsonList));
      await prefs.setInt(_logsTimestampKey, timestamp);
    } catch (e) {}
  }

  Future<void> _fetchLogsFromNetwork() async {
    if (_isFetching || _isLoggingOut) return;
    if (!_isUserLoggedIn) return;

    _isFetching = true;

    try {
      final headers = {'Content-Type': 'application/json'};
      if (_authToken != null && _authToken!.isNotEmpty) {
        headers['Authorization'] = 'Bearer $_authToken';
      }

      final response = await http
          .get(
            Uri.parse(
              '$API_BASE_URL/archive/user/${widget.currentUserId}?limit=100',
            ),
            headers: headers,
          )
          .timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        final newActivities =
            data.map((j) => ArchiveActivity.fromJson(j)).toList();
        newActivities.sort((a, b) => b.createdAt.compareTo(a.createdAt));

        _safeSetState(() {
          _activities = newActivities;
          _isLoading = false;
          _isRefreshing = false;
          _error = '';
        });

        await _saveToCache(newActivities);
      } else if (response.statusCode == 404) {
        _safeSetState(() {
          _activities = [];
          _isLoading = false;
          _isRefreshing = false;
          _error = '';
        });
      }
    } catch (e) {
      if (_activities.isEmpty) {
        _safeSetState(() {
          _isLoading = false;
          _error = '';
        });
      }
    } finally {
      _isFetching = false;
    }
  }

  Future<void> _refreshLogs() async {
    if (_isUserLoggedIn) {
      await _fetchLogsFromNetwork();
      await _loadUserComrades();
      await _fetchUnreadCounts();
    }
    await _fetchActiveFixtures();
    _safeSetState(() => _isRefreshing = false);
  }

  Future<void> _markAsRead(String fixtureId) async {
    if (!_isUserLoggedIn) return;

    try {
      final headers = {'Content-Type': 'application/json'};
      if (_authToken != null && _authToken!.isNotEmpty) {
        headers['Authorization'] = 'Bearer $_authToken';
      }

      final response = await http
          .post(
            Uri.parse('$API_BASE_URL/comments/mark-seen'),
            headers: headers,
            body: jsonEncode({'fixtureId': fixtureId, 'userId': _userId}),
          )
          .timeout(Duration(seconds: 10));

      if (response.statusCode == 200) {
        _safeSetState(() => _unreadCounts.remove(fixtureId));
        await _saveUnreadCountsToCache();
      }
    } catch (e) {}
  }

  String _formatTime(DateTime time) {
    final now = DateTime.now();
    final diff = now.difference(time);

    if (diff.inMinutes < 1) return 'now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m';
    if (diff.inHours < 24) return '${diff.inHours}h';
    if (diff.inDays < 7) return '${diff.inDays}d';
    return '${time.day}/${time.month}';
  }

  String _getActivityIcon(String type) {
    switch (type.toLowerCase()) {
      case 'vote':
        return '🗳️';
      case 'like':
        return '❤️';
      case 'comment':
        return '💬';
      default:
        return '📋';
    }
  }

  Color _getActivityColor(String type) {
    switch (type.toLowerCase()) {
      case 'vote':
        return FanColors.draw;
      case 'like':
        return FanColors.away;
      case 'comment':
        return FanColors.primary;
      default:
        return FanColors.primary;
    }
  }

  String _getActivityText(ArchiveActivity activity) {
    switch (activity.activityType.toLowerCase()) {
      case 'vote':
        final voteText = activity.selection == 'home_team'
            ? activity.homeTeam
            : activity.selection == 'away_team'
                ? activity.awayTeam
                : 'Draw';
        return 'voted for $voteText';
      case 'like':
        return activity.isLiked == true
            ? 'liked this fixture'
            : 'unliked this fixture';
      case 'comment':
        final comment = activity.comment ?? '';
        final preview =
            comment.length > 60 ? '${comment.substring(0, 60)}...' : comment;
        return 'commented: "$preview"';
      default:
        return 'interacted with this fixture';
    }
  }

  Future<void> _fetchUserVotes() async {
    if (!_isUserLoggedIn) return;

    try {
      final headers = {'Content-Type': 'application/json'};
      if (_authToken != null && _authToken!.isNotEmpty) {
        headers['Authorization'] = 'Bearer $_authToken';
      }

      final response = await http
          .get(Uri.parse('$API_BASE_URL/votes/user/$_userId'), headers: headers)
          .timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        final Map<String, String> userVotes = {};

        if (jsonData is Map && jsonData['success'] == true) {
          final votesList = jsonData['data'] as List? ?? [];
          for (var voteData in votesList) {
            if (voteData is Map) {
              final fixtureId = voteData['fixtureId']?.toString() ?? '';
              final selection = voteData['selection']?.toString() ?? '';
              if (fixtureId.isNotEmpty && selection.isNotEmpty) {
                userVotes[fixtureId] = selection;
              }
            }
          }
        }

        _safeSetState(() {
          _userVotes.clear();
          _userVotes.addAll(userVotes);
        });
      } else if (response.statusCode == 404) {
        _safeSetState(() => _userVotes.clear());
      }
    } catch (e) {}
  }

  void _openComradeVotingModal(Fixture fixture, String fixtureId) {
    if (_isModalOpen) return;
    _isModalOpen = true;

    final hasVoted = _userVotes.containsKey(fixtureId);
    final userVoteSelection = _userVotes[fixtureId];

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => ComradeVotingModal(
        isOpen: true,
        onClose: () {
          _isModalOpen = false;
          Navigator.pop(context);
        },
        fixture: fixture,
        userId: _userId,
        username: _username,
        authToken: _authToken,
        isLoggedIn: _isUserLoggedIn,
        hasUserVoted: hasVoted,
        userVoteSelection: userVoteSelection,
        comradesList: _userComrades,
        comradesVoteMap: _comradesVoteMap,
      ),
    ).then((_) {
      _isModalOpen = false;
      _fetchUnreadCounts();
      _fetchUserVotes();
    });
  }

  void _openArchiveComradeModal(ArchiveActivity activity) async {
    if (_isModalOpen) return;
    if (!_isUserLoggedIn) {
      _showLoginModal();
      return;
    }

    final fixtureId = activity.fixtureId;
    final hasExistingVote = _userVotes.containsKey(fixtureId) ||
        activity.activityType.toLowerCase() == 'vote';

    if (!hasExistingVote) {
      _isModalOpen = true;

      showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (context) => VotingBottomSheet(
          fixtureId: fixtureId,
          homeTeam: activity.homeTeam,
          awayTeam: activity.awayTeam,
          homeOdds: 2.10,
          drawOdds: 3.40,
          awayOdds: 2.80,
          userId: _userId,
          username: _username,
          authToken: _authToken,
          onVoteSuccess: () async {
            _isModalOpen = false;
            await _fetchUserVotes();
            await _openArchiveModalAfterVote(activity);
          },
        ),
      ).then((_) => _isModalOpen = false);
      return;
    }

    await _openArchiveModalAfterVote(activity);
  }

  Future<void> _openArchiveModalAfterVote(ArchiveActivity activity) async {
    final fixture = Fixture(
      id: activity.fixtureId,
      matchId: activity.fixtureId,
      homeTeam: activity.homeTeam,
      awayTeam: activity.awayTeam,
      homeWin: 0.0,
      awayWin: 0.0,
      draw: 0.0,
      date: activity.createdAt.toIso8601String(),
      time: activity.createdAt.toIso8601String(),
      dateIso: activity.createdAt.toIso8601String(),
      homeScore: 0,
      awayScore: 0,
      status: 'past',
      league: '',
      isLive: false,
      availableForVoting: false,
      source: 'archive',
      scrapedAt: DateTime.now(),
    );

    _isModalOpen = true;
    await _markAsRead(activity.fixtureId);

    final hasUserVoted = _userVotes.containsKey(activity.fixtureId) ||
        activity.activityType.toLowerCase() == 'vote';
    final userVoteSelection =
        _userVotes[activity.fixtureId] ?? activity.selection;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => ComradeVotingModal(
        isOpen: true,
        onClose: () {
          _isModalOpen = false;
          Navigator.pop(context);
        },
        fixture: fixture,
        userId: _userId,
        username: _username,
        authToken: _authToken,
        isLoggedIn: _isUserLoggedIn,
        hasUserVoted: hasUserVoted,
        userVoteSelection: userVoteSelection,
        comradesList: _userComrades,
        comradesVoteMap: _comradesVoteMap,
      ),
    ).then((_) {
      _isModalOpen = false;
      _fetchUnreadCounts();
      _fetchUserVotes();
    });
  }

  void _showLoginModal() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => LoginModal(
        messengerKey: messengerKey,
        onLoginSuccess: (String userId, String username) async {
          if (mounted) Navigator.pop(context);
          await _refreshLogs();
          await _loadUserComrades();
          await _fetchUnreadCounts();
        },
      ),
    );
  }

  // ========== ACTIVITY CARD ==========
  Widget _buildLogCard(ArchiveActivity activity) {
    final icon = _getActivityIcon(activity.activityType);
    final iconColor = _getActivityColor(activity.activityType);
    final activityText = _getActivityText(activity);
    final timeAgo = _formatTime(activity.createdAt);
    final unreadCount = _unreadCounts[activity.fixtureId] ?? 0;

    return GestureDetector(
      onTap: () => _openArchiveComradeModal(activity),
      child: Container(
        margin: const EdgeInsets.only(bottom: 0),
        decoration: BoxDecoration(
          color: unreadCount > 0
              ? FanColors.primary.withValues(alpha: 0.04)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(FanRadius.md),
        ),
        child: Stack(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 32,
                            height: 32,
                            decoration: BoxDecoration(
                              color: iconColor.withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Center(
                              child: Text(
                                icon,
                                style: const TextStyle(fontSize: 14),
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Text(
                                    activity.username,
                                    style: FanTypography.body.copyWith(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 13,
                                    ),
                                  ),
                                  const SizedBox(width: 6),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 8,
                                      vertical: 2,
                                    ),
                                    decoration: BoxDecoration(
                                      color: iconColor.withValues(alpha: 0.1),
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: Text(
                                      activity.activityType.toUpperCase(),
                                      style: FanTypography.tag.copyWith(
                                        fontSize: 9,
                                        fontWeight: FontWeight.w500,
                                        color: iconColor,
                                      ),
                                    ),
                                  ),
                                  if (unreadCount > 0) ...[
                                    const SizedBox(width: 6),
                                    Container(
                                      width: 8,
                                      height: 8,
                                      decoration: const BoxDecoration(
                                        color: Colors.red,
                                        shape: BoxShape.circle,
                                      ),
                                    ),
                                  ],
                                ],
                              ),
                              Text(
                                timeAgo,
                                style: FanTypography.tag.copyWith(
                                  color: FanColors.textSecondary,
                                  fontSize: 10,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      Text(
                        timeAgo,
                        style: FanTypography.tag.copyWith(
                          color: FanColors.textSecondary,
                          fontSize: 10,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(
                    '${activity.homeTeam} vs ${activity.awayTeam}',
                    style: FanTypography.body.copyWith(
                      fontWeight: FontWeight.w500,
                      fontSize: 15,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    activityText,
                    style: FanTypography.caption.copyWith(
                      color: FanColors.textSecondary,
                      fontSize: 12,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      GestureDetector(
                        onTap: () => _openArchiveComradeModal(activity),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 14,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: FanColors.border.withValues(alpha: 0.4),
                              width: 0.8,
                            ),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.remove_red_eye,
                                size: 14,
                                color: FanColors.textSecondary,
                              ),
                              const SizedBox(width: 6),
                              Text(
                                'View activity',
                                style: FanTypography.tag.copyWith(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w500,
                                  color: FanColors.textSecondary,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Divider(
                color: FanColors.border.withValues(alpha: 0.25),
                height: 0.5,
                thickness: 0.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ========== ACTIVE FIXTURE CARD with SMALLER JOIN BUTTON ==========
  Widget _buildActiveFixtureCard(ActiveFixture fixture) {
    final hasJoined = _joinedFixtureIds.contains(fixture.fixtureId);
    final fixtureDate = _parseFixtureDate(fixture.date);
    final timeDisplay = _formatTime(fixtureDate);
    final commentPreview =
        fixture.latestComment ?? "Be the first to comment! 💬";
    final commenterName = fixture.latestCommenter ?? "Football Fan";

    return Container(
      margin: const EdgeInsets.only(bottom: 0),
      decoration: BoxDecoration(
        color: hasJoined
            ? FanColors.primary.withValues(alpha: 0.04)
            : Colors.transparent,
        borderRadius: BorderRadius.circular(FanRadius.md),
      ),
      child: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 32,
                          height: 32,
                          decoration: BoxDecoration(
                            color: FanColors.primary.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Center(
                            child: Text('🔥', style: TextStyle(fontSize: 14)),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Text(
                                  fixture.league,
                                  style: FanTypography.body.copyWith(
                                    fontWeight: FontWeight.w500,
                                    fontSize: 13,
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 8,
                                    vertical: 2,
                                  ),
                                  decoration: BoxDecoration(
                                    color: FanColors.primary.withValues(
                                      alpha: 0.1,
                                    ),
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: Text(
                                    'DISCUSSION',
                                    style: FanTypography.tag.copyWith(
                                      fontSize: 9,
                                      fontWeight: FontWeight.w500,
                                      color: FanColors.primary,
                                    ),
                                  ),
                                ),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 6,
                                    vertical: 2,
                                  ),
                                  decoration: BoxDecoration(
                                    color: FanColors.draw.withValues(
                                      alpha: 0.1,
                                    ),
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(
                                        Icons.how_to_vote,
                                        size: 8,
                                        color: FanColors.draw,
                                      ),
                                      const SizedBox(width: 2),
                                      Text(
                                        '${fixture.voteCount}',
                                        style: FanTypography.tag.copyWith(
                                          fontSize: 8,
                                          color: FanColors.draw,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                if (hasJoined) ...[
                                  const SizedBox(width: 6),
                                  Icon(
                                    Icons.check_circle,
                                    size: 10,
                                    color: FanColors.primary,
                                  ),
                                ],
                              ],
                            ),
                            Text(
                              timeDisplay,
                              style: FanTypography.tag.copyWith(
                                color: FanColors.textSecondary,
                                fontSize: 10,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 3,
                      ),
                      decoration: BoxDecoration(
                        color: FanColors.primary.withValues(alpha: 0.08),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.comment,
                            size: 10,
                            color: FanColors.primary,
                          ),
                          const SizedBox(width: 3),
                          Text(
                            '${fixture.commentCount}',
                            style: FanTypography.tag.copyWith(
                              fontSize: 9,
                              color: FanColors.primary,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  '${fixture.homeTeam} vs ${fixture.awayTeam}',
                  style: FanTypography.body.copyWith(
                    fontWeight: FontWeight.w500,
                    fontSize: 15,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 20,
                      height: 20,
                      decoration: BoxDecoration(
                        color: FanColors.primary.withValues(alpha: 0.1),
                        shape: BoxShape.circle,
                      ),
                      child: Center(
                        child: Text(
                          commenterName.isNotEmpty
                              ? commenterName[0].toUpperCase()
                              : '?',
                          style: const TextStyle(
                            fontSize: 9,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            commenterName,
                            style: FanTypography.tag.copyWith(
                              fontSize: 9,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          Text(
                            commentPreview,
                            style: FanTypography.caption.copyWith(
                              color: FanColors.textSecondary,
                              fontSize: 11,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    if (!hasJoined)
                      GestureDetector(
                        onTap: () async {
                          if (!_isUserLoggedIn) {
                            _showLoginModalForJoin(fixture);
                          } else {
                            if (!_userVotes.containsKey(fixture.fixtureId)) {
                              _isModalOpen = true;
                              showModalBottomSheet(
                                context: context,
                                isScrollControlled: true,
                                backgroundColor: Colors.transparent,
                                builder: (context) => VotingBottomSheet(
                                  fixtureId: fixture.fixtureId,
                                  homeTeam: fixture.homeTeam,
                                  awayTeam: fixture.awayTeam,
                                  homeOdds: 2.10,
                                  drawOdds: 3.40,
                                  awayOdds: 2.80,
                                  userId: _userId,
                                  username: _username,
                                  authToken: _authToken,
                                  onVoteSuccess: () async {
                                    _isModalOpen = false;
                                    await _saveJoinedFixture(fixture.fixtureId);
                                    await _fetchUserVotes();
                                    await _fetchActiveFixtures();
                                    await _openFixtureAfterJoin(fixture);
                                  },
                                ),
                              ).then((_) => _isModalOpen = false);
                            } else {
                              await _saveJoinedFixture(fixture.fixtureId);
                              await _fetchActiveFixtures();
                              await _openFixtureAfterJoin(fixture);
                            }
                          }
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                FanColors.primary,
                                FanColors.primaryMuted,
                              ],
                            ),
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.group_add,
                                size: 12,
                                color: Colors.white,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                'JOIN',
                                style: FanTypography.tag.copyWith(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 10,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    if (hasJoined)
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: FanColors.primary.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.check_circle,
                              size: 10,
                              color: FanColors.primary,
                            ),
                            const SizedBox(width: 3),
                            Text(
                              'Joined',
                              style: FanTypography.tag.copyWith(
                                color: FanColors.primary,
                                fontSize: 10,
                              ),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              ],
            ),
          ),
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Divider(
              color: FanColors.border.withValues(alpha: 0.25),
              height: 0.5,
              thickness: 0.5,
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _openFixtureAfterJoin(ActiveFixture fixture) async {
    final fixtureObj = Fixture(
      id: fixture.fixtureId,
      matchId: fixture.fixtureId,
      homeTeam: fixture.homeTeam,
      awayTeam: fixture.awayTeam,
      homeWin: 0.0,
      awayWin: 0.0,
      draw: 0.0,
      date: fixture.date,
      time: fixture.date,
      dateIso: fixture.date,
      homeScore: 0,
      awayScore: 0,
      status: 'upcoming',
      league: fixture.league,
      isLive: false,
      availableForVoting: true,
      source: 'active',
      scrapedAt: DateTime.now(),
    );

    _isModalOpen = true;
    final hasVoted = _userVotes.containsKey(fixture.fixtureId);
    final userVoteSelection = _userVotes[fixture.fixtureId];

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => ComradeVotingModal(
        isOpen: true,
        onClose: () {
          _isModalOpen = false;
          Navigator.pop(context);
        },
        fixture: fixtureObj,
        userId: _userId,
        username: _username,
        authToken: _authToken,
        isLoggedIn: _isUserLoggedIn,
        hasUserVoted: hasVoted,
        userVoteSelection: userVoteSelection,
        comradesList: _userComrades,
        comradesVoteMap: _comradesVoteMap,
      ),
    ).then((_) {
      _isModalOpen = false;
      _fetchUnreadCounts();
      _fetchUserVotes();
    });
  }

  // ========== BUILD METHOD ==========
  @override
  Widget build(BuildContext context) {
    final bool shouldShowHotDiscussions =
        !_isUserLoggedIn || (_isUserLoggedIn && _activities.length < 10);
    final bool shouldShowActivities = _isUserLoggedIn && _activities.isNotEmpty;
    final bool hasFixtures = _activeFixtures.isNotEmpty;
    final bool isLoading = _isLoading;
    final bool showError = _error.isNotEmpty &&
        !isLoading &&
        !hasFixtures &&
        !shouldShowActivities;

    return Scaffold(
      backgroundColor: FanColors.background,
      body: RefreshIndicator(
        onRefresh: _refreshLogs,
        color: FanColors.primary,
        backgroundColor: FanColors.surface,
        child: CustomScrollView(
          controller: widget.scrollController,
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: FanSpacing.base,
                ),
                child: Column(
                  children: [
                    if (shouldShowActivities) ...[
                      for (int i = 0; i < _activities.length; i++)
                        _buildLogCard(_activities[i]),
                      if (shouldShowHotDiscussions && hasFixtures)
                        const SizedBox(height: FanSpacing.md),
                    ],
                    if (shouldShowHotDiscussions && hasFixtures)
                      _buildHotDiscussionsSection(),
                    if (isLoading &&
                        _activeFixtures.isEmpty &&
                        _activities.isEmpty)
                      _buildLoadingState(),
                    if (showError) _buildErrorState(),
                    if (_isRefreshing)
                      const Padding(
                        padding: EdgeInsets.all(FanSpacing.base),
                        child: Center(
                          child: CircularProgressIndicator(strokeWidth: 2),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHotDiscussionsSection() {
    if (_activeFixtures.isEmpty) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 50),
        child: Center(
          child: Column(
            children: [
              Icon(
                Icons.sports_soccer,
                size: 48,
                color: FanColors.textSecondary,
              ),
              const SizedBox(height: 12),
              Text(
                'No active discussions',
                style: FanTypography.body.copyWith(
                  color: FanColors.textSecondary,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Check back later for hot matches!',
                style: FanTypography.caption.copyWith(
                  color: FanColors.textSecondary,
                ),
              ),
            ],
          ),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: FanSpacing.md),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: FanColors.primary.withValues(alpha: 0.1),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.fireplace,
                  size: 18,
                  color: FanColors.primary,
                ),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '🔥 Hot Discussions',
                    style: FanTypography.headline.copyWith(fontSize: 16),
                  ),
                  Text(
                    'Join these active conversations',
                    style: FanTypography.caption.copyWith(
                      color: FanColors.textSecondary,
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        ..._activeFixtures.map((fixture) => _buildActiveFixtureCard(fixture)),
      ],
    );
  }

  Widget _buildLoadingState() {
    return SizedBox(
      width: double.infinity,
      height: 250,
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(color: FanColors.primary, strokeWidth: 2),
            const SizedBox(height: FanSpacing.md),
            Text(
              'Loading...',
              style: FanTypography.body.copyWith(
                color: FanColors.textSecondary,
                fontSize: 13,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildErrorState() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(FanSpacing.xl),
      decoration: BoxDecoration(
        color: FanColors.background,
        borderRadius: BorderRadius.circular(FanRadius.lg),
        border: Border.all(color: FanColors.border.withValues(alpha: 0.3)),
      ),
      child: Column(
        children: [
          Icon(Icons.error_outline, size: 48, color: FanColors.primary),
          const SizedBox(height: FanSpacing.base),
          Text('Failed to load content', style: FanTypography.headline),
          const SizedBox(height: FanSpacing.sm),
          Text(
            _error,
            style: FanTypography.caption,
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: FanSpacing.base),
          ElevatedButton(
            onPressed: _refreshLogs,
            style: ElevatedButton.styleFrom(
              backgroundColor: FanColors.primary,
              foregroundColor: FanColors.textInverse,
              shape: RoundedRectangleBorder(borderRadius: FanRadius.pillAll),
            ),
            child: const Text('Try Again'),
          ),
        ],
      ),
    );
  }

  @override
  void deactivate() {
    _stopPolling();
    super.deactivate();
  }
}
