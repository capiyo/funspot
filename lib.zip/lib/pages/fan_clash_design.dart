import 'package:flutter/material.dart';

// ─────────────────────────────────────────────────────────────
//  FanClash Design System  ·  v4.0
//  Dark-only, football social + fixture-voting platform
//  CARDLESS AESTHETIC - cards blend into background
//  Distinguished only by subtle borders and spacing
//
//  PRIMARY COLOR: #C0E6BA (Mint/Sage Green)
//  ACCENT: Warm amber + red for vote outcomes
//
//  Fonts (add to pubspec.yaml):
//    google_fonts: ^6.x
//    Usage: GoogleFonts.sairaCondensedTextTheme() for display
//           GoogleFonts.dmSansTextTheme()          for body
// ─────────────────────────────────────────────────────────────

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 1 ▸ COLOUR PALETTE
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class FanColors {
  FanColors._();

  // ── Canvas ────────────────────────────────────────────────
  /// Deep purple-black app background - single source of truth
  static const background = Color(0xFF0D0B1E);
  static const surface = Color(0xFF121028);
  static const surfaceElevated = Color(0xFF181530);
  static const surfaceOverlay = Color(0xFF1E1A3A);

  /// Stroke / divider — barely visible (0.5px borders)
  static const border = Color(0xFF1E1A3A);

  /// Strong border — active states (1px)
  static const borderActive = Color(0xFF2E2855);

  /// Focus border - mint accent
  static const borderFocus = Color(0xFFC0E6BA);

  // ── Primary: Mint/Sage Green (#C0E6BA) ────────────────────
  static const primary = Color(0xFFC0E6BA);
  static const primaryMuted = Color(0xFF2A3A28);
  static const primaryDim = Color(0xFF1A2A18);
  static const primaryGlow = Color(0x1AC0E6BA);

  // ── Secondary: Lighter Mint variant ──────────────────────
  static const secondary = Color(0xFFD4F0CF);
  static const secondaryDim = Color(0xFF2A3A28);
  static const secondaryGlow = Color(0x1AD4F0CF);

  // ── Amber — draw / neutral vote ──────────────────────────
  static const draw = Color(0xFFFFC107);
  static const drawDim = Color(0xFF3D2E00);
  static const drawGlow = Color(0x1AFFC107);

  // ── Red — away / destructive ─────────────────────────────
  static const away = Color(0xFFFF3D57);
  static const awayDim = Color(0xFF3D0010);
  static const awayGlow = Color(0x1AFF3D57);

  // ── Live pulse ───────────────────────────────────────────
  static const live = Color(0xFFFF3D57);

  // ── Text hierarchy ───────────────────────────────────────
  static const textPrimary = Color(0xFFF0F4FF);
  static const textSecondary = Color(0xFF9896C8);
  static const textTertiary = Color(0xFF4A4875);
  static const textInverse = Color(0xFF0D0B1E); // Dark bg for light text

  // ── Score / numeral accent ───────────────────────────────
  static const scoreHome = Color(0xFFC0E6BA); // Mint for home score
  static const scoreAway = Color(0xFFFF3D57); // Red for away score
  static const scoreDash = Color(0xFF4A4875);

  // ── Social reactions ─────────────────────────────────────
  static const reactionLike = Color(0xFFFF6B6B);
  static const reactionPredict = Color(0xFFC0E6BA); // Mint for predict
  static const reactionShare = Color(0xFFD4F0CF); // Light mint for share
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 2 ▸ TYPOGRAPHY SCALE
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class FanTypography {
  FanTypography._();

  // ── Score / hero number (biggest on screen) ──────────────
  static const scoreHero = TextStyle(
    fontFamily: 'SairaCondensed',
    fontSize: 48,
    fontWeight: FontWeight.w800,
    letterSpacing: -1,
    height: 1.0,
    color: FanColors.textPrimary,
  );

  // ── Score compact (inside fixture card) ──────────────────
  static const scoreCompact = TextStyle(
    fontFamily: 'SairaCondensed',
    fontSize: 32,
    fontWeight: FontWeight.w800,
    letterSpacing: -0.5,
    height: 1.0,
    color: FanColors.textPrimary,
  );

  // ── Scoreline dash ───────────────────────────────────────
  static const scoreDash = TextStyle(
    fontFamily: 'SairaCondensed',
    fontSize: 24,
    fontWeight: FontWeight.w600,
    color: FanColors.scoreDash,
    height: 1.0,
  );

  // ── Page / section headline ──────────────────────────────
  static const headline = TextStyle(
    fontFamily: 'SairaCondensed',
    fontSize: 24,
    fontWeight: FontWeight.w700,
    letterSpacing: 0.2,
    color: FanColors.textPrimary,
  );

  // ── Card title / team name ───────────────────────────────
  static const title = TextStyle(
    fontFamily: 'DM Sans',
    fontSize: 15,
    fontWeight: FontWeight.w700,
    letterSpacing: 0.1,
    color: FanColors.textPrimary,
  );

  // ── Body text ────────────────────────────────────────────
  static const body = TextStyle(
    fontFamily: 'DM Sans',
    fontSize: 14,
    fontWeight: FontWeight.w400,
    height: 1.55,
    color: FanColors.textSecondary,
  );

  // ── Caption / meta ───────────────────────────────────────
  static const caption = TextStyle(
    fontFamily: 'DM Sans',
    fontSize: 10,
    fontWeight: FontWeight.w500,
    letterSpacing: 0.2,
    color: FanColors.textTertiary,
  );

  // ── All-caps tag / badge label ───────────────────────────
  static const tag = TextStyle(
    fontFamily: 'DM Sans',
    fontSize: 8,
    fontWeight: FontWeight.w700,
    letterSpacing: 1.2,
    color: FanColors.textSecondary,
  );

  // ── Button label ─────────────────────────────────────────
  static const button = TextStyle(
    fontFamily: 'DM Sans',
    fontSize: 10,
    fontWeight: FontWeight.w700,
    letterSpacing: 0.4,
    color: FanColors.textInverse,
  );

  // ── Stat chip — big number ────────────────────────────────
  static const statValue = TextStyle(
    fontFamily: 'SairaCondensed',
    fontSize: 16,
    fontWeight: FontWeight.w800,
    color: FanColors.textPrimary,
    height: 1.0,
  );

  // ── Stat chip — delta label ───────────────────────────────
  static const statDelta = TextStyle(
    fontFamily: 'DM Sans',
    fontSize: 19,
    fontWeight: FontWeight.w300,
    letterSpacing: 0.3,
    height: 1.2,
  );

  // ── Vote percentage ───────────────────────────────────────
  static const votePct = TextStyle(
    fontFamily: 'SairaCondensed',
    fontSize: 16,
    fontWeight: FontWeight.w300,
    height: 1.0,
  );

  // ── Competition / league label ────────────────────────────
  static const competition = TextStyle(
    fontFamily: 'DM Sans',
    fontSize: 9,
    fontWeight: FontWeight.w300,
    letterSpacing: 1.4,
    color: FanColors.textTertiary,
  );
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 3 ▸ SPACING SCALE - TIGHTER SPACING
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class FanSpacing {
  FanSpacing._();

  static const xs = 2.0;
  static const sm = 4.0;
  static const md = 8.0;
  static const base = 12.0;
  static const lg = 16.0;
  static const xl = 20.0;
  static const xxl = 24.0;
  static const xxxl = 32.0;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 4 ▸ BORDER RADIUS SCALE
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class FanRadius {
  FanRadius._();

  static const sm = 4.0;
  static const md = 8.0;
  static const lg = 12.0;
  static const xl = 16.0;
  static const pill = 999.0;

  static const smAll = BorderRadius.all(Radius.circular(sm));
  static const mdAll = BorderRadius.all(Radius.circular(md));
  static const lgAll = BorderRadius.all(Radius.circular(lg));
  static const xlAll = BorderRadius.all(Radius.circular(xl));
  static const pillAll = BorderRadius.all(Radius.circular(pill));
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 5 ▸ SHADOWS & GLOWS - MINIMAL (cardless)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class FanShadows {
  FanShadows._();

  // Minimal shadow for depth (barely visible)
  static const subtle = [
    BoxShadow(color: Color(0x08000000), blurRadius: 4, offset: Offset(0, 1)),
  ];

  // Slightly more for elevated elements
  static const elevated = [
    BoxShadow(color: Color(0x10000000), blurRadius: 8, offset: Offset(0, 2)),
  ];

  // For live/pulsing elements
  static const glow = [
    BoxShadow(color: Color(0x1AFF3D57), blurRadius: 12, spreadRadius: -2),
  ];

  // Keep for compatibility
  static const cardBase = subtle;
  static const cardPrimary = elevated;
  static const cardLive = glow;
  static const primaryGlow = [
    BoxShadow(color: FanColors.primaryGlow, blurRadius: 12, spreadRadius: -2),
  ];
  static const button = elevated;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 6 ▸ DECORATION TOKENS - CARDLESS AESTHETIC
//    Cards have NO background fill - only borders
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class FanDecorations {
  FanDecorations._();

  // ── Base border width ─────────────────────────────────────
  static const double _borderWidth = 0.5;
  static const double _borderWidthActive = 1.0;

  // ── Standard card (no background, just border) ────────────
  static BoxDecoration card({bool isActive = false, Color? borderColor}) =>
      BoxDecoration(
        color: Colors.transparent,
        borderRadius: FanRadius.lgAll,
        border: Border.all(
          color: borderColor ??
              (isActive ? FanColors.borderActive : FanColors.border),
          width: isActive ? _borderWidthActive : _borderWidth,
        ),
      );

  // ── Standard fixture card (cardless) ─────────────────────
  static BoxDecoration fixtureCard({bool isLive = false}) => BoxDecoration(
        color: Colors.transparent,
        borderRadius: FanRadius.lgAll,
        border: Border.all(
          color:
              isLive ? FanColors.live.withValues(alpha: 0.4) : FanColors.border,
          width: isLive ? _borderWidthActive : _borderWidth,
        ),
      );

  // ── Elevated card (modals, sheets) - still no background ──
  static BoxDecoration elevatedCard({bool isActive = false}) => BoxDecoration(
        color: Colors.transparent,
        borderRadius: FanRadius.xlAll,
        border: Border.all(
          color: isActive ? FanColors.borderActive : FanColors.border,
          width: _borderWidth,
        ),
      );

  // ── Post / feed card (cardless) ──────────────────────────
  static BoxDecoration postCard({bool isActive = false}) => BoxDecoration(
        color: Colors.transparent,
        borderRadius: FanRadius.lgAll,
        border: Border.all(
          color: isActive ? FanColors.borderActive : FanColors.border,
          width: _borderWidth,
        ),
      );

  // ── Borderless card (no border at all) ───────────────────
  static BoxDecoration borderlessCard({bool hasUnread = false}) =>
      BoxDecoration(
        color: Colors.transparent,
        borderRadius: FanRadius.mdAll,
      );

  // ── Vote bar container ────────────────────────────────────
  static BoxDecoration voteBarTrack = BoxDecoration(
    color: FanColors.border.withValues(alpha: 0.3),
    borderRadius: FanRadius.pillAll,
  );

  // ── Primary pill button (MINT) ────────────────────────────
  static BoxDecoration primaryButton = BoxDecoration(
    color: FanColors.primary,
    borderRadius: FanRadius.pillAll,
    boxShadow: FanShadows.button,
  );

  // ── Ghost / outline button ────────────────────────────────
  static BoxDecoration ghostButton = BoxDecoration(
    borderRadius: FanRadius.pillAll,
    border:
        Border.all(color: FanColors.borderActive, width: _borderWidthActive),
  );

  // ── Stat chip (cardless) ─────────────────────────────────
  static BoxDecoration statChip = BoxDecoration(
    color: Colors.transparent,
    borderRadius: FanRadius.mdAll,
    border: Border.all(color: FanColors.border, width: _borderWidth),
  );

  // ── Team crest frame ─────────────────────────────────────
  static BoxDecoration crestFrame = BoxDecoration(
    color: FanColors.border.withValues(alpha: 0.2),
    shape: BoxShape.circle,
    border: Border.all(color: FanColors.border, width: _borderWidth),
  );

  // ── Floating bottom nav pill ─────────────────────────────
  static BoxDecoration floatingNav = BoxDecoration(
    color: FanColors.background.withValues(alpha: 0.8),
    borderRadius: FanRadius.pillAll,
    border: Border.all(color: FanColors.border, width: _borderWidth),
    boxShadow: FanShadows.elevated,
  );

  // ── League / competition header band (cardless) ──────────
  static BoxDecoration competitionBand = BoxDecoration(
    color: Colors.transparent,
    borderRadius: BorderRadius.only(
      topLeft: Radius.circular(FanRadius.lg),
      topRight: Radius.circular(FanRadius.lg),
    ),
    border: Border(
        bottom: BorderSide(color: FanColors.border, width: _borderWidth)),
  );

  // ── Gradient mesh app background ─────────────────────────
  static const appBackground = BoxDecoration(
    gradient: LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [Color(0xFF0D0B1E), Color(0xFF0A0820)],
    ),
  );

  // ── Speech bubble (cardless) ─────────────────────────────
  static BoxDecoration speechBubble({Color? color}) => BoxDecoration(
        color: color ?? Colors.transparent,
        borderRadius: FanRadius.lgAll,
        border: Border.all(color: FanColors.border, width: _borderWidth),
      );
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 7 ▸ GRADIENT TOKENS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class FanGradients {
  FanGradients._();

  // Three-way vote bar segments
  static const voteHome = LinearGradient(
    colors: [Color(0xFFC0E6BA), Color(0xFFA0D4A0)], // Mint gradient
  );
  static const voteDraw = LinearGradient(
    colors: [Color(0xFFFFC107), Color(0xFFD4A000)],
  );
  static const voteAway = LinearGradient(
    colors: [Color(0xFFFF3D57), Color(0xFFCC2D45)],
  );

  // "On fire" — premium badge
  static const fire = LinearGradient(
    colors: [Color(0xFFFF9800), Color(0xFFFF3D57)],
  );

  // Primary CTA - Mint
  static const cta = LinearGradient(
    colors: [Color(0xFFC0E6BA), Color(0xFFA0D4A0)],
  );

  // Fade-out at bottom of feed card image
  static const imageFade = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [Colors.transparent, Color(0xCC0D0B1E)],
  );

  // Pitch overlay (hero section)
  static const pitchOverlay = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    stops: [0.0, 0.6, 1.0],
    colors: [Color(0x000D0B1E), Color(0x800D0B1E), Color(0xFF0D0B1E)],
  );
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 8 ▸ ANIMATION DURATIONS & CURVES
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class FanMotion {
  FanMotion._();

  static const dSnappy = Duration(milliseconds: 120);
  static const dFast = Duration(milliseconds: 200);
  static const dMedium = Duration(milliseconds: 350);
  static const dSlow = Duration(milliseconds: 600);

  static const curveOut = Curves.easeOut;
  static const curveOutCubic = Curves.easeOutCubic;
  static const curveOutBack = Curves.easeOutBack;
  static const curveSpring = Curves.elasticOut;

  static const dPulse = Duration(milliseconds: 1200);
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 9 ▸ COMPONENT TOKENS - SMALLER SIZES
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class FanSizes {
  FanSizes._();

  // Crests
  static const crestLg = 48.0;
  static const crestMd = 36.0;
  static const crestSm = 24.0;

  // Avatar
  static const avatarMd = 32.0;
  static const avatarSm = 24.0;

  // Vote bar
  static const voteBarHeight = 6.0;
  static const voteBarRadius = 3.0;

  // Live dot
  static const liveDot = 6.0;
  static const liveDotOuter = 12.0;

  // Bottom nav pill
  static const navHeight = 44.0;
  static const navIconSize = 16.0;
  static const navActiveSize = 18.0;

  // Stat chip
  static const statChipW = 70.0;
  static const statChipH = 56.0;

  // Touch targets
  static const minTouchTarget = 40.0;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 10 ▸ MATCH STATE TOKENS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
enum MatchState { scheduled, live, halftime, fullTime, postponed, cancelled }

extension MatchStateX on MatchState {
  Color get dotColor => switch (this) {
        MatchState.live => FanColors.live,
        MatchState.halftime => FanColors.draw,
        MatchState.fullTime => FanColors.textTertiary,
        MatchState.postponed => FanColors.draw,
        MatchState.cancelled => FanColors.away,
        MatchState.scheduled => FanColors.textTertiary,
      };

  String get label => switch (this) {
        MatchState.live => 'LIVE',
        MatchState.halftime => 'HT',
        MatchState.fullTime => 'FT',
        MatchState.postponed => 'PPD',
        MatchState.cancelled => 'CANCELLED',
        MatchState.scheduled => 'UPCOMING',
      };

  bool get isPulsing => this == MatchState.live;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 11 ▸ VOTE OUTCOME TOKENS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
enum VoteOutcome { home, draw, away }

extension VoteOutcomeX on VoteOutcome {
  Color get fill => switch (this) {
        VoteOutcome.home => FanColors.primary,
        VoteOutcome.draw => FanColors.draw,
        VoteOutcome.away => FanColors.away,
      };

  Color get dimBg => switch (this) {
        VoteOutcome.home => FanColors.primaryDim,
        VoteOutcome.draw => FanColors.drawDim,
        VoteOutcome.away => FanColors.awayDim,
      };

  Color get glow => switch (this) {
        VoteOutcome.home => FanColors.primaryGlow,
        VoteOutcome.draw => FanColors.drawGlow,
        VoteOutcome.away => FanColors.awayGlow,
      };

  LinearGradient get gradient => switch (this) {
        VoteOutcome.home => FanGradients.voteHome,
        VoteOutcome.draw => FanGradients.voteDraw,
        VoteOutcome.away => FanGradients.voteAway,
      };
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 12 ▸ MATERIALAPP THEME
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ThemeData fanClashTheme() {
  const scheme = ColorScheme.dark(
    surface: FanColors.surface,
    primary: FanColors.primary,
    primaryContainer: FanColors.primaryDim,
    secondary: FanColors.secondary,
    secondaryContainer: FanColors.secondaryDim,
    error: FanColors.away,
    errorContainer: FanColors.awayDim,
    onSurface: FanColors.textPrimary,
    onPrimary: FanColors.textInverse,
    onSecondary: FanColors.textInverse,
    outline: FanColors.border,
    outlineVariant: FanColors.borderActive,
  );

  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: FanColors.background,
    textTheme: const TextTheme(
      displayLarge: FanTypography.scoreHero,
      displayMedium: FanTypography.scoreCompact,
      headlineLarge: FanTypography.headline,
      titleMedium: FanTypography.title,
      bodyMedium: FanTypography.body,
      bodySmall: FanTypography.caption,
      labelSmall: FanTypography.tag,
      labelMedium: FanTypography.button,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: FanColors.background,
      elevation: 0,
      scrolledUnderElevation: 0,
      iconTheme: IconThemeData(color: FanColors.textPrimary),
      titleTextStyle: FanTypography.headline,
      surfaceTintColor: Colors.transparent,
    ),
    cardTheme: CardThemeData(
      color: Colors.transparent,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: FanRadius.lgAll,
        side: const BorderSide(color: FanColors.border, width: 0.5),
      ),
    ),
    chipTheme: ChipThemeData(
      backgroundColor: Colors.transparent,
      selectedColor: FanColors.primaryDim,
      side: const BorderSide(color: FanColors.border),
      labelStyle: FanTypography.caption,
      shape: RoundedRectangleBorder(borderRadius: FanRadius.pillAll),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: FanColors.primary,
        foregroundColor: FanColors.textInverse,
        textStyle: FanTypography.button,
        shape: RoundedRectangleBorder(borderRadius: FanRadius.pillAll),
        padding: const EdgeInsets.symmetric(
          horizontal: FanSpacing.lg,
          vertical: FanSpacing.md,
        ),
        elevation: 0,
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: FanColors.textPrimary,
        textStyle: FanTypography.button,
        side: const BorderSide(color: FanColors.borderActive, width: 1),
        shape: RoundedRectangleBorder(borderRadius: FanRadius.pillAll),
        padding: const EdgeInsets.symmetric(
          horizontal: FanSpacing.lg,
          vertical: FanSpacing.md,
        ),
      ),
    ),
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor: Colors.transparent,
      elevation: 0,
      selectedItemColor: FanColors.primary,
      unselectedItemColor: FanColors.textTertiary,
      showSelectedLabels: false,
      showUnselectedLabels: false,
      type: BottomNavigationBarType.fixed,
    ),
    dividerTheme: const DividerThemeData(
      color: FanColors.border,
      thickness: 0.5,
      space: 1,
    ),
    iconTheme: const IconThemeData(color: FanColors.textSecondary, size: 16),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: FanColors.background,
      hintStyle: FanTypography.body.copyWith(color: FanColors.textTertiary),
      border: OutlineInputBorder(
        borderRadius: FanRadius.lgAll,
        borderSide: const BorderSide(color: FanColors.border),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: FanRadius.lgAll,
        borderSide: const BorderSide(color: FanColors.border),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: FanRadius.lgAll,
        borderSide: const BorderSide(color: FanColors.primary, width: 1),
      ),
      contentPadding: const EdgeInsets.symmetric(
        horizontal: FanSpacing.base,
        vertical: FanSpacing.md,
      ),
    ),
  );
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 13 ▸ REUSABLE WIDGET HELPERS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/// Pulsing LIVE dot with outer ring
class LiveIndicator extends StatefulWidget {
  final String? minuteLabel;

  const LiveIndicator({super.key, this.minuteLabel});

  @override
  State<LiveIndicator> createState() => _LiveIndicatorState();
}

class _LiveIndicatorState extends State<LiveIndicator>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _pulse;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: FanMotion.dPulse)
      ..repeat(reverse: true);
    _pulse = CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        SizedBox(
          width: FanSizes.liveDotOuter,
          height: FanSizes.liveDotOuter,
          child: AnimatedBuilder(
            animation: _pulse,
            builder: (context, _) => Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: FanSizes.liveDotOuter * _pulse.value,
                  height: FanSizes.liveDotOuter * _pulse.value,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: FanColors.live
                        .withValues(alpha: 0.25 * (1 - _pulse.value)),
                  ),
                ),
                Container(
                  width: FanSizes.liveDot,
                  height: FanSizes.liveDot,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: FanColors.live,
                  ),
                ),
              ],
            ),
          ),
        ),
        if (widget.minuteLabel != null) ...[
          const SizedBox(width: FanSpacing.xs),
          Text(
            widget.minuteLabel!,
            style: FanTypography.tag.copyWith(color: FanColors.live),
          ),
        ],
      ],
    );
  }
}

/// Three-segment vote bar
class VoteBar extends StatelessWidget {
  final double homePct;
  final double drawPct;
  final double awayPct;
  final bool showLabels;

  const VoteBar({
    super.key,
    required this.homePct,
    required this.drawPct,
    required this.awayPct,
    this.showLabels = true,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (showLabels) ...[
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '${(homePct * 100).round()}%',
                style: FanTypography.votePct.copyWith(color: FanColors.primary),
              ),
              Text(
                '${(drawPct * 100).round()}%',
                style: FanTypography.votePct.copyWith(color: FanColors.draw),
              ),
              Text(
                '${(awayPct * 100).round()}%',
                style: FanTypography.votePct.copyWith(color: FanColors.away),
              ),
            ],
          ),
          const SizedBox(height: FanSpacing.sm),
        ],
        ClipRRect(
          borderRadius: FanRadius.pillAll,
          child: SizedBox(
            height: FanSizes.voteBarHeight,
            child: Row(
              children: [
                Flexible(
                  flex: (homePct * 1000).round(),
                  child: Container(
                      decoration:
                          const BoxDecoration(gradient: FanGradients.voteHome)),
                ),
                if (drawPct > 0) ...[
                  const SizedBox(width: 1),
                  Flexible(
                    flex: (drawPct * 1000).round(),
                    child: Container(
                        decoration: const BoxDecoration(
                            gradient: FanGradients.voteDraw)),
                  ),
                ],
                const SizedBox(width: 1),
                Flexible(
                  flex: (awayPct * 1000).round(),
                  child: Container(
                      decoration:
                          const BoxDecoration(gradient: FanGradients.voteAway)),
                ),
              ],
            ),
          ),
        ),
        if (showLabels) ...[
          const SizedBox(height: FanSpacing.xs),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('HOME', style: FanTypography.tag),
              Text('DRAW', style: FanTypography.tag),
              Text('AWAY', style: FanTypography.tag),
            ],
          ),
        ],
      ],
    );
  }
}

/// Stat chip
class StatChip extends StatelessWidget {
  final String value;
  final String label;
  final String? delta;
  final Color deltaColor;

  const StatChip({
    super.key,
    required this.value,
    required this.label,
    this.delta,
    this.deltaColor = FanColors.primary,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: FanSizes.statChipW,
      height: FanSizes.statChipH,
      decoration: FanDecorations.statChip,
      padding: const EdgeInsets.symmetric(
          vertical: FanSpacing.sm, horizontal: FanSpacing.md),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(value, style: FanTypography.statValue),
          const SizedBox(height: 2),
          Text(label.toUpperCase(),
              style: FanTypography.tag, textAlign: TextAlign.center),
          if (delta != null) ...[
            const SizedBox(height: 2),
            Text(delta!,
                style: FanTypography.statDelta.copyWith(color: deltaColor)),
          ],
        ],
      ),
    );
  }
}

/// Post action row
class PostActionRow extends StatelessWidget {
  final int commentCount;
  final int predictCount;
  final VoidCallback? onComment;
  final VoidCallback? onPredict;
  final VoidCallback? onShare;

  const PostActionRow({
    super.key,
    this.commentCount = 0,
    this.predictCount = 0,
    this.onComment,
    this.onPredict,
    this.onShare,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _ActionButton(
          icon: Icons.chat_bubble_outline_rounded,
          label: commentCount > 0 ? '$commentCount' : null,
          color: FanColors.textSecondary,
          onTap: onComment,
        ),
        const SizedBox(width: FanSpacing.base),
        _ActionButton(
          icon: Icons.bolt_rounded,
          label: predictCount > 0 ? '$predictCount' : 'PREDICT',
          color: FanColors.reactionPredict,
          onTap: onPredict,
        ),
        const Spacer(),
        _ActionButton(
          icon: Icons.ios_share_rounded,
          color: FanColors.reactionShare,
          onTap: onShare,
        ),
      ],
    );
  }
}

class _ActionButton extends StatelessWidget {
  final IconData icon;
  final String? label;
  final Color color;
  final VoidCallback? onTap;

  const _ActionButton({
    required this.icon,
    required this.color,
    this.label,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 14),
          if (label != null) ...[
            const SizedBox(width: FanSpacing.xs),
            Text(label!, style: FanTypography.caption.copyWith(color: color)),
          ],
        ],
      ),
    );
  }
}

/// Competition header
class CompetitionHeader extends StatelessWidget {
  final String competitionName;
  final String? round;
  final Widget? logo;

  const CompetitionHeader({
    super.key,
    required this.competitionName,
    this.round,
    this.logo,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: FanDecorations.competitionBand,
      padding: const EdgeInsets.symmetric(
          horizontal: FanSpacing.base, vertical: FanSpacing.sm),
      child: Row(
        children: [
          if (logo != null) ...[logo!, const SizedBox(width: FanSpacing.sm)],
          Text(competitionName.toUpperCase(), style: FanTypography.competition),
          if (round != null) ...[
            const SizedBox(width: FanSpacing.sm),
            Container(
              width: 2,
              height: 2,
              decoration: const BoxDecoration(
                  shape: BoxShape.circle, color: FanColors.textTertiary),
            ),
            const SizedBox(width: FanSpacing.sm),
            Text(round!, style: FanTypography.competition),
          ],
        ],
      ),
    );
  }
}
