import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';

// Import the social theme and avatar manager from fixture_page
import '../pages/social_theme.dart';

class ArchivePage extends StatefulWidget {
  const ArchivePage({super.key});

  @override
  State<ArchivePage> createState() => _ArchivePageState();
}

class _ArchivePageState extends State<ArchivePage> {
  List<ArchiveActivity> _activities = [];
  bool _isLoading = true;
  bool _hasError = false;
  String? _userId;
  String? _username;
  final String _apiBaseUrl = 'https://clash-api-m5mr.onrender.com/api';

  // Stats
  int _totalVotes = 0;
  int _totalLikes = 0;
  int _totalComments = 0;

  @override
  void initState() {
    super.initState();
    print('🚀 ArchivePage initState called');
    _initializeData();
  }

  Future<void> _initializeData() async {
    print('🔄 Starting data initialization');
    await _loadUserData();
    await _fetchArchive();
  }

  Future<void> _loadUserData() async {
    print('👤 Loading user data from SharedPreferences...');
    final prefs = await SharedPreferences.getInstance();
    final userString = prefs.getString('user');

    if (userString != null) {
      try {
        final userData = jsonDecode(userString);
        _userId = userData['id'] ?? userData['userId'] ?? userData['_id'] ?? '';
        _username = userData['username'] ?? userData['name'] ?? 'User';
        print('✅ User data loaded successfully');
        print('   User ID: $_userId');
        print('   Username: $_username');
      } catch (e) {
        print('❌ Error parsing user data: $e');
      }
    } else {
      print('❌ No user data found in SharedPreferences');
    }
  }

  Future<void> _fetchArchive() async {
    print('\n📡 Starting archive fetch');

    if (_userId == null) {
      print('❌ User ID is null, cannot fetch archive');
      setState(() {
        _isLoading = false;
        _hasError = true;
      });
      return;
    }

    try {
      final url = Uri.parse('$_apiBaseUrl/archive/user/$_userId');
      print('🌐 Request URL: $url');

      final response = await http.get(
        url,
        headers: {'Content-Type': 'application/json'},
      );

      print('📥 HTTP Status Code: ${response.statusCode}');

      if (response.statusCode == 200) {
        if (response.body.isEmpty) {
          setState(() {
            _activities = [];
            _isLoading = false;
            _hasError = false;
          });
          return;
        }

        try {
          final List<dynamic> data = json.decode(response.body);

          // Parse all activities
          final List<ArchiveActivity> activities = [];
          int voteCount = 0;
          int likeCount = 0;
          int commentCount = 0;

          for (var item in data) {
            try {
              final activity = ArchiveActivity.fromJson(item);
              activities.add(activity);

              switch (activity.activity_type) {
                case ActivityType.vote:
                  voteCount++;
                  break;
                case ActivityType.like:
                  likeCount++;
                  break;
                case ActivityType.comment:
                  commentCount++;
                  break;
              }
            } catch (e) {
              print('❌ Error parsing activity: $e');
            }
          }

          // Sort by timestamp (newest first)
          activities.sort((a, b) => b.timestamp.compareTo(a.timestamp));

          setState(() {
            _activities = activities;
            _totalVotes = voteCount;
            _totalLikes = likeCount;
            _totalComments = commentCount;
            _isLoading = false;
            _hasError = false;
          });

          print('✅ Loaded ${activities.length} activities');
        } catch (e) {
          print('❌ JSON parsing error: $e');
          setState(() {
            _isLoading = false;
            _hasError = true;
          });
        }
      } else {
        print('❌ HTTP Error: ${response.statusCode}');
        setState(() {
          _isLoading = false;
          _hasError = true;
        });
      }
    } catch (e) {
      print('❌ Network/API error: $e');
      setState(() {
        _isLoading = false;
        _hasError = true;
      });
    }
  }

  Future<void> _refreshArchive() async {
    print('\n🔄 Manual refresh triggered');
    setState(() {
      _isLoading = true;
    });
    await _fetchArchive();
  }

  String _formatTimeAgo(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);

    if (difference.inMinutes < 1) return 'Just now';
    if (difference.inHours < 1) return '${difference.inMinutes}m ago';
    if (difference.inDays < 1) return '${difference.inHours}h ago';
    if (difference.inDays == 1) return 'Yesterday';
    if (difference.inDays < 7) return '${difference.inDays}d ago';
    return DateFormat('MMM d, yyyy').format(date);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: SocialTheme.background,
      body: RefreshIndicator(
        onRefresh: _refreshArchive,
        color: SocialTheme.primary,
        backgroundColor: SocialTheme.background,
        child: CustomScrollView(
          slivers: [
            // Header Sliver
            SliverToBoxAdapter(
              child: Container(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: SocialTheme.primary.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(
                            Icons.history,
                            color: SocialTheme.primary,
                            size: 20,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Activity Archive',
                                style: SocialTheme.headline.copyWith(
                                  fontSize: 18,
                                ),
                              ),
                              Text(
                                _username ?? 'User',
                                style: SocialTheme.small.copyWith(
                                  color: SocialTheme.textSecondary,
                                ),
                              ),
                            ],
                          ),
                        ),
                        if (!_isLoading && !_hasError)
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: SocialTheme.surface,
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: Text(
                              '${_activities.length} total',
                              style: SocialTheme.tiny.copyWith(
                                color: SocialTheme.textSecondary,
                              ),
                            ),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            ),

            // Stats Sliver (if not loading/error)
            if (!_isLoading && !_hasError && _activities.isNotEmpty)
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                  child: Row(
                    children: [
                      _buildStatItem(
                        icon: Icons.how_to_vote,
                        count: _totalVotes,
                        label: 'Votes',
                        color: SocialTheme.primary,
                      ),
                      const SizedBox(width: 12),
                      _buildStatItem(
                        icon: Icons.favorite,
                        count: _totalLikes,
                        label: 'Likes',
                        color: Colors.red,
                      ),
                      const SizedBox(width: 12),
                      _buildStatItem(
                        icon: Icons.comment,
                        count: _totalComments,
                        label: 'Comments',
                        color: Colors.blue,
                      ),
                    ],
                  ),
                ),
              ),

            // Content Sliver
            if (_isLoading)
              SliverFillRemaining(
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator(
                        color: SocialTheme.primary,
                        strokeWidth: 2,
                      ),
                      const SizedBox(height: 12),
                      Text(
                        'Loading your archive...',
                        style: SocialTheme.body.copyWith(
                          color: SocialTheme.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ),
              )
            else if (_hasError)
              SliverFillRemaining(
                child: Center(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 80,
                          height: 80,
                          decoration: BoxDecoration(
                            color: SocialTheme.surface,
                            shape: BoxShape.circle,
                          ),
                          child: Center(
                            child: Icon(
                              Icons.error_outline,
                              color: SocialTheme.primary,
                              size: 40,
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),
                        Text(
                          'Failed to load archive',
                          style: SocialTheme.headline.copyWith(fontSize: 16),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          _userId == null
                              ? 'User data not found. Please login again.'
                              : 'Please check your connection and try again',
                          textAlign: TextAlign.center,
                          style: SocialTheme.body.copyWith(
                            color: SocialTheme.textSecondary,
                          ),
                        ),
                        const SizedBox(height: 20),
                        ElevatedButton(
                          onPressed: _refreshArchive,
                          style: SocialTheme.primaryBtn.copyWith(
                            minimumSize: WidgetStateProperty.all(
                              const Size(120, 36),
                            ),
                          ),
                          child: Text(
                            'Retry',
                            style: SocialTheme.body.copyWith(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              )
            else if (_activities.isEmpty)
              SliverFillRemaining(
                child: Center(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 100,
                          height: 100,
                          decoration: BoxDecoration(
                            color: SocialTheme.surface,
                            shape: BoxShape.circle,
                          ),
                          child: Center(
                            child: Icon(
                              Icons.history,
                              color: SocialTheme.primary.withValues(alpha: 0.5),
                              size: 50,
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),
                        Text(
                          'No activities yet',
                          style: SocialTheme.headline.copyWith(fontSize: 18),
                        ),
                        const SizedBox(height: 8),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 40),
                          child: Text(
                            'Start voting, liking, and commenting on fixtures to build your history',
                            textAlign: TextAlign.center,
                            style: SocialTheme.body.copyWith(
                              color: SocialTheme.textSecondary,
                            ),
                          ),
                        ),
                        const SizedBox(height: 24),
                        ElevatedButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          style: SocialTheme.primaryBtn.copyWith(
                            minimumSize: WidgetStateProperty.all(
                              const Size(140, 40),
                            ),
                          ),
                          child: Text(
                            'Browse Fixtures',
                            style: SocialTheme.body.copyWith(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              )
            else
              SliverList(
                delegate: SliverChildBuilderDelegate((context, index) {
                  final activity = _activities[index];
                  return _buildActivityCard(activity);
                }, childCount: _activities.length),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem({
    required IconData icon,
    required int count,
    required String label,
    required Color color,
  }) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: SocialTheme.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withValues(alpha: 0.2), width: 1),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 18),
            const SizedBox(height: 4),
            Text(
              count.toString(),
              style: TextStyle(
                color: color,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              label,
              style: SocialTheme.tiny.copyWith(
                color: SocialTheme.textSecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActivityCard(ArchiveActivity activity) {
    final timeAgo = _formatTimeAgo(activity.timestamp);
    final activityColor = _getActivityColor(activity.activity_type);
    final activityIcon = _getActivityIcon(activity.activity_type);
    final activityTitle = _getActivityTitle(activity);

    return Container(
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      decoration: SocialTheme.fixtureCardDecoration,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header with icon and time
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: activityColor.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(activityIcon, color: activityColor, size: 16),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        activityTitle,
                        style: SocialTheme.body.copyWith(
                          fontWeight: FontWeight.w600,
                          color: activityColor,
                          fontSize: 14,
                        ),
                      ),
                      Text(
                        timeAgo,
                        style: SocialTheme.tiny.copyWith(
                          color: SocialTheme.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ),
                // Match info chip
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: SocialTheme.surface,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        activity.home_team.length >= 2
                            ? activity.home_team.substring(0, 2).toUpperCase()
                            : activity.home_team.toUpperCase(),
                        style: SocialTheme.tiny.copyWith(
                          color: SocialTheme.primary,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        child: Icon(
                          Icons.sports_kabaddi,
                          size: 8,
                          color: SocialTheme.primary.withValues(alpha: 0.3),
                        ),
                      ),
                      Text(
                        activity.away_team.length >= 2
                            ? activity.away_team.substring(0, 2).toUpperCase()
                            : activity.away_team.toUpperCase(),
                        style: SocialTheme.tiny.copyWith(
                          color: SocialTheme.primary,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 12),

            // Teams
            Container(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Expanded(
                    child: Text(
                      activity.home_team,
                      style: SocialTheme.body.copyWith(
                        fontWeight: FontWeight.w600,
                        fontSize: 14,
                      ),
                      textAlign: TextAlign.right,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 12),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: SocialTheme.primary.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      'VS',
                      style: SocialTheme.tiny.copyWith(
                        color: SocialTheme.primary,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Text(
                      activity.away_team,
                      style: SocialTheme.body.copyWith(
                        fontWeight: FontWeight.w600,
                        fontSize: 14,
                      ),
                      textAlign: TextAlign.left,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),

            // Activity specific content
            _buildActivityContent(activity),

            // Full date at bottom
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Icon(
                  Icons.access_time,
                  size: 10,
                  color: SocialTheme.textSecondary,
                ),
                const SizedBox(width: 4),
                Text(
                  DateFormat('MMM d, yyyy • h:mm a').format(activity.timestamp),
                  style: SocialTheme.tiny.copyWith(
                    color: SocialTheme.textSecondary,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActivityContent(ArchiveActivity activity) {
    switch (activity.activity_type) {
      case ActivityType.vote:
        return Container(
          margin: const EdgeInsets.only(top: 8),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: SocialTheme.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: _getVoteColor(activity.selection).withValues(alpha: 0.2),
            ),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: _getVoteColor(
                    activity.selection,
                  ).withValues(alpha: 0.1),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.how_to_vote,
                  color: _getVoteColor(activity.selection),
                  size: 16,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Your Prediction',
                      style: SocialTheme.tiny.copyWith(
                        color: SocialTheme.textSecondary,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      _getVoteText(activity.selection),
                      style: TextStyle(
                        color: _getVoteColor(activity.selection),
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 4,
                ),
                decoration: BoxDecoration(
                  color: _getVoteColor(
                    activity.selection,
                  ).withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Text(
                  'Vote',
                  style: TextStyle(
                    color: _getVoteColor(activity.selection),
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        );

      case ActivityType.like:
        return Container(
          margin: const EdgeInsets.only(top: 8),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: SocialTheme.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: (activity.is_liked == true ? Colors.red : Colors.grey)
                  .withValues(alpha: 0.2),
            ),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: (activity.is_liked == true ? Colors.red : Colors.grey)
                      .withValues(alpha: 0.1),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  activity.is_liked == true
                      ? Icons.favorite
                      : Icons.favorite_border,
                  color: activity.is_liked == true ? Colors.red : Colors.grey,
                  size: 16,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      activity.is_liked == true
                          ? 'You liked this fixture'
                          : 'You unliked this fixture',
                      style: SocialTheme.body.copyWith(
                        fontWeight: FontWeight.w600,
                        fontSize: 13,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 4,
                ),
                decoration: BoxDecoration(
                  color: (activity.is_liked == true ? Colors.red : Colors.grey)
                      .withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Text(
                  activity.is_liked == true ? 'Liked' : 'Unliked',
                  style: TextStyle(
                    color: activity.is_liked == true ? Colors.red : Colors.grey,
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        );

      case ActivityType.comment:
        return Container(
          margin: const EdgeInsets.only(top: 8),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: SocialTheme.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.blue.withValues(alpha: 0.2)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: Colors.blue.withValues(alpha: 0.1),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(Icons.comment, color: Colors.blue, size: 14),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    'Your Comment',
                    style: SocialTheme.tiny.copyWith(
                      color: SocialTheme.textSecondary,
                    ),
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 2,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.blue.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      'Comment',
                      style: TextStyle(
                        color: Colors.blue,
                        fontSize: 9,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: SocialTheme.background,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  activity.comment ?? 'No comment text',
                  style: SocialTheme.body.copyWith(
                    fontSize: 13,
                    color: SocialTheme.text,
                  ),
                ),
              ),
            ],
          ),
        );
    }
  }

  // Helper Methods
  Color _getActivityColor(ActivityType type) {
    switch (type) {
      case ActivityType.vote:
        return SocialTheme.primary;
      case ActivityType.like:
        return Colors.red;
      case ActivityType.comment:
        return Colors.blue;
    }
  }

  Color _getVoteColor(String? selection) {
    switch (selection) {
      case 'home_team':
        return SocialTheme.primary;
      case 'away_team':
        return Colors.blue;
      case 'draw':
        return const Color(0xFF8B5CF6);
      default:
        return Colors.grey;
    }
  }

  IconData _getActivityIcon(ActivityType type) {
    switch (type) {
      case ActivityType.vote:
        return Icons.how_to_vote;
      case ActivityType.like:
        return Icons.favorite;
      case ActivityType.comment:
        return Icons.comment;
    }
  }

  String _getActivityTitle(ArchiveActivity activity) {
    switch (activity.activity_type) {
      case ActivityType.vote:
        return 'Vote Prediction';
      case ActivityType.like:
        return activity.is_liked == true ? 'Liked Fixture' : 'Unliked Fixture';
      case ActivityType.comment:
        return 'Commented on Fixture';
    }
  }

  String _getVoteText(String? selection) {
    switch (selection) {
      case 'home_team':
        return 'Home Win';
      case 'away_team':
        return 'Away Win';
      case 'draw':
        return 'Draw';
      default:
        return 'Unknown';
    }
  }
}

// ========== ACTIVITY TYPE ENUM ==========
enum ActivityType {
  vote,
  like,
  comment;

  @override
  String toString() => name;

  static ActivityType fromString(String value) {
    switch (value.toLowerCase()) {
      case 'vote':
        return ActivityType.vote;
      case 'like':
        return ActivityType.like;
      case 'comment':
        return ActivityType.comment;
      default:
        return ActivityType.vote;
    }
  }
}

// ========== ARCHIVE ACTIVITY MODEL ==========
class ArchiveActivity {
  final String? id;
  final String user_id;
  final String username;
  final String fixture_id;
  final String home_team;
  final String away_team;
  final ActivityType activity_type;
  final String? selection;
  final bool? is_liked;
  final String? comment;
  final DateTime timestamp;
  final DateTime created_at;

  ArchiveActivity({
    this.id,
    required this.user_id,
    required this.username,
    required this.fixture_id,
    required this.home_team,
    required this.away_team,
    required this.activity_type,
    this.selection,
    this.is_liked,
    this.comment,
    required this.timestamp,
    required this.created_at,
  });

  factory ArchiveActivity.fromJson(Map<String, dynamic> json) {
    // Handle MongoDB _id field
    String? id;
    if (json['_id'] != null) {
      if (json['_id'] is Map<String, dynamic>) {
        id = json['_id']['\$oid'] ?? json['_id']['oid'];
      } else if (json['_id'] is String) {
        id = json['_id'];
      }
    }

    // Parse timestamp
    DateTime timestamp;
    try {
      final timestampStr = json['timestamp'];
      if (timestampStr is String) {
        timestamp = DateTime.parse(timestampStr).toLocal();
      } else {
        timestamp = DateTime.now();
      }
    } catch (e) {
      timestamp = DateTime.now();
    }

    // Parse created_at
    DateTime createdAt;
    try {
      final createdStr = json['created_at'];
      if (createdStr is String) {
        createdAt = DateTime.parse(createdStr).toLocal();
      } else {
        createdAt = DateTime.now();
      }
    } catch (e) {
      createdAt = DateTime.now();
    }

    return ArchiveActivity(
      id: id,
      user_id: json['user_id']?.toString() ?? '',
      username: json['username']?.toString() ?? 'Unknown',
      fixture_id: json['fixture_id']?.toString() ?? '',
      home_team: json['home_team']?.toString() ?? '',
      away_team: json['away_team']?.toString() ?? '',
      activity_type: ActivityType.fromString(
        json['activity_type']?.toString() ?? 'vote',
      ),
      selection: json['selection']?.toString(),
      is_liked: json['is_liked'] is bool ? json['is_liked'] as bool? : null,
      comment: json['comment']?.toString(),
      timestamp: timestamp,
      created_at: createdAt,
    );
  }
}
