import 'package:flutter/material.dart';

//Import your FanClash design system
// (assuming it's in a separate file)
import './fan_clash_design.dart';

/// FanClash Social Theme - Built on top of FanClash Design System
/// Uses FanColors and FanTypography from the main design system
/// Redesigned around #0F0E17 primary color with emerald green secondary
class SocialTheme {
  SocialTheme._();

  // ========== MAIN THEME COLORS (Mapped from FanColors) ==========
  static Color get background => FanColors.background;
  static Color get foreground => FanColors.textPrimary;
  static Color get card => FanColors.surface;
  static Color get cardForeground => FanColors.textPrimary;
  static Color get popover => FanColors.surfaceElevated;
  static Color get popoverForeground => FanColors.textPrimary;
  static Color get primary => FanColors.primary;
  static Color get primaryForeground => FanColors.textInverse;
  static Color get secondary => FanColors.secondary;
  static Color get secondaryForeground => FanColors.textInverse;
  static Color get muted => FanColors.textTertiary;
  static Color get mutedForeground => FanColors.textSecondary;
  static Color get accent => FanColors.secondary;
  static Color get accentForeground => FanColors.textInverse;
  static Color get destructive => FanColors.away;
  static Color get destructiveForeground => FanColors.textInverse;
  static Color get success => FanColors.secondary;
  static Color get successForeground => FanColors.textInverse;
  static Color get warning => FanColors.draw;
  static Color get warningForeground => FanColors.textInverse;
  static Color get border => FanColors.border;
  static Color get inputColor => FanColors.borderActive;
  static Color get ring => FanColors.secondary;
  static const double radius = 12.0;

  // ========== SIDEBAR COLORS (Mapped from FanColors) ==========
  static Color get sidebarBackground => FanColors.background;
  static Color get sidebarForeground => FanColors.textPrimary;
  static Color get sidebarPrimary => FanColors.primary;
  static Color get sidebarPrimaryForeground => FanColors.textInverse;
  static Color get sidebarAccent => FanColors.surface;
  static Color get sidebarAccentForeground => FanColors.textPrimary;
  static Color get sidebarBorder => FanColors.border;
  static Color get sidebarRing => FanColors.secondary;

  // ========== COMPATIBILITY GETTERS ==========
  static Color get text => FanColors.textPrimary;
  static Color get textSecondary => FanColors.textSecondary;
  static Color get textTertiary => FanColors.textTertiary;
  static Color get divider => FanColors.border.withValues(alpha: 0.5);
  static const Color shadow = Colors.black26;
  static const Color overlay = Colors.white10;

  // ========== BACKGROUND VARIANTS ==========
  static Color get postCard => FanColors.surface;
  static Color get fixtureCard => FanColors.surface;
  static Color get surface => FanColors.surface;
  static Color get surfaceElevated => FanColors.surfaceElevated;

  // ========== GRAY COLOR HELPERS (Using FanColors equivalents) ==========
  static Color get gray900_solid => const Color(0xFF0F172A); // Darkest slate
  static Color get gray800_solid => const Color(0xFF111827); // Dark slate
  static Color get gray700_solid => const Color(0xFF1F2937); // Lighter slate

  static Color get gray900_30 => gray900_solid.withValues(alpha: 0.3);
  static Color get gray900_50 => gray900_solid.withValues(alpha: 0.5);
  static Color get gray900_80 => gray900_solid.withValues(alpha: 0.8);
  static Color get gray800_30 => gray800_solid.withValues(alpha: 0.3);
  static Color get gray800_50 => gray800_solid.withValues(alpha: 0.5);

  // ========== TEXT STYLES (Using FanTypography) ==========
  static TextStyle get headline => FanTypography.headline;
  static TextStyle get body => FanTypography.body;
  static TextStyle get small => FanTypography.caption;
  static TextStyle get tiny => FanTypography.tag;
  static TextStyle get display => FanTypography.scoreHero;
  static TextStyle get label => FanTypography.tag;
  static TextStyle get numeral => FanTypography.statValue;

  // Fixture-specific styles
  static TextStyle get teamName => FanTypography.title;
  static TextStyle get teamScore => FanTypography.scoreCompact;
  static TextStyle get odds => FanTypography.caption;
  static TextStyle get league => FanTypography.competition;

  // ========== TEXT SCALE BUILDER ==========
  /// Plug into MaterialApp builder to prevent system font size breaking UI.
  /// Clamps text scale between 0.8x and 1.15x.
  static Widget Function(BuildContext, Widget?) get builder =>
      (context, child) {
        final clamped = MediaQuery.of(context).textScaleFactor.clamp(0.8, 1.15);
        return MediaQuery(
          data: MediaQuery.of(
            context,
          ).copyWith(textScaler: TextScaler.linear(clamped)),
          child: child!,
        );
      };

  // ========== BUTTON STYLES ==========
  static ButtonStyle get primaryBtn => ElevatedButton.styleFrom(
        backgroundColor: FanColors.primary,
        foregroundColor: FanColors.textInverse,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
        shape: RoundedRectangleBorder(borderRadius: FanRadius.pillAll),
        elevation: 0,
        shadowColor: Colors.transparent,
        textStyle: FanTypography.button,
      );

  static ButtonStyle get secondaryBtn => OutlinedButton.styleFrom(
        foregroundColor: FanColors.secondary,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
        shape: RoundedRectangleBorder(borderRadius: FanRadius.pillAll),
        side: const BorderSide(color: FanColors.secondary, width: 1),
        textStyle: FanTypography.button,
      );

  static ButtonStyle get accentBtn => ElevatedButton.styleFrom(
        backgroundColor: FanColors.draw,
        foregroundColor: FanColors.textInverse,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
        shape: RoundedRectangleBorder(borderRadius: FanRadius.pillAll),
        elevation: 0,
        shadowColor: Colors.transparent,
        textStyle: FanTypography.button,
      );

  static ButtonStyle get destructiveBtn => ElevatedButton.styleFrom(
        backgroundColor: FanColors.away,
        foregroundColor: FanColors.textInverse,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
        shape: RoundedRectangleBorder(borderRadius: FanRadius.pillAll),
        elevation: 0,
        shadowColor: Colors.transparent,
        textStyle: FanTypography.button,
      );

  static ButtonStyle get pillButton => ElevatedButton.styleFrom(
        backgroundColor: Colors.transparent,
        foregroundColor: FanColors.textSecondary,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        shape: RoundedRectangleBorder(
          borderRadius: FanRadius.pillAll,
          side: BorderSide(
            color: FanColors.border.withValues(alpha: 0.5),
            width: 1,
          ),
        ),
        elevation: 0,
        shadowColor: Colors.transparent,
        textStyle: FanTypography.tag,
      );

  static ButtonStyle get pillButtonActive => pillButton.copyWith(
        backgroundColor: WidgetStateProperty.all(FanColors.primary),
        foregroundColor: WidgetStateProperty.all(FanColors.textInverse),
        side: WidgetStateProperty.all(BorderSide.none),
      );

  // ========== CARD DECORATIONS (Using FanDecorations) ==========
  static BoxDecoration get p2pCardDecoration => BoxDecoration(
        gradient: RadialGradient(
          center: const Alignment(0, -1.2),
          radius: 0.9,
          colors: [
            FanColors.primaryGlow.withValues(alpha: 0.07),
            Colors.transparent,
          ],
        ),
        color: FanColors.surface,
        borderRadius: FanRadius.lgAll,
        border: Border.all(color: FanColors.border, width: 1),
        boxShadow: FanShadows.cardBase,
      );

  static BoxDecoration get cardInnerDecoration => BoxDecoration(
        color: FanColors.surfaceElevated,
        borderRadius: FanRadius.mdAll,
        border: Border.all(color: FanColors.border, width: 1),
      );

  static BoxDecoration get cardInnerDarkerDecoration => BoxDecoration(
        color: FanColors.surface,
        borderRadius: FanRadius.mdAll,
        border: Border.all(color: FanColors.borderActive, width: 1),
      );

  static BoxDecoration get postCardDecoration => FanDecorations.fixtureCard();

  static BoxDecoration get fixtureCardDecoration =>
      FanDecorations.fixtureCard();

  static BoxDecoration get cardDecoration => fixtureCardDecoration;

  static BoxDecoration get surfaceDecoration => BoxDecoration(
        color: FanColors.surface,
        borderRadius: FanRadius.lgAll,
        border: Border.all(color: FanColors.border, width: 1),
      );

  static BoxDecoration get glassCard => BoxDecoration(
        color: FanColors.surface.withValues(alpha: 0.8),
        borderRadius: FanRadius.xlAll,
        border: Border.all(
          color: FanColors.border.withValues(alpha: 0.3),
          width: 1,
        ),
        boxShadow: FanShadows.cardBase,
      );

  static BoxDecoration get glassCardHover => BoxDecoration(
        color: FanColors.surfaceElevated.withValues(alpha: 0.8),
        borderRadius: FanRadius.xlAll,
        border: Border.all(
          color: FanColors.secondary.withValues(alpha: 0.5),
          width: 1,
        ),
        boxShadow: FanShadows.cardPrimary,
      );

  static BoxDecoration get glow =>
      BoxDecoration(boxShadow: FanShadows.primaryGlow);

  static BoxDecoration get avatarDecoration => BoxDecoration(
        color: FanColors.surfaceElevated,
        shape: BoxShape.circle,
        border: Border.all(
          color: FanColors.secondary.withValues(alpha: 0.3),
          width: 1,
        ),
      );

  static BoxDecoration badgeDecoration({required bool isActive}) =>
      BoxDecoration(
        color: isActive ? FanColors.primaryDim : FanColors.drawDim,
        borderRadius: FanRadius.mdAll,
        border: Border.all(
          color: isActive
              ? FanColors.secondary.withValues(alpha: 0.2)
              : FanColors.draw.withValues(alpha: 0.2),
          width: 1,
        ),
      );

  // ========== CAROUSEL SPECIFIC ==========
  static BoxDecoration get carouselCardDecoration => BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF111827), Color(0xFF000000)],
        ),
        borderRadius: FanRadius.lgAll,
        border: Border.all(
          color: FanColors.border.withValues(alpha: 0.5),
          width: 1,
        ),
      );

  static BoxDecoration get carouselAvatarDecoration => BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF111827), Color(0xFF000000)],
        ),
        shape: BoxShape.circle,
        border: Border.all(
          color: FanColors.secondary.withValues(alpha: 0.3),
          width: 1,
        ),
      );

  // ========== INPUT DECORATION ==========
  static InputDecoration get inputDecoration => InputDecoration(
        filled: true,
        fillColor: FanColors.surface,
        hintStyle: FanTypography.body.copyWith(color: FanColors.textTertiary),
        border: OutlineInputBorder(
          borderRadius: FanRadius.mdAll,
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: FanRadius.mdAll,
          borderSide: BorderSide(color: FanColors.borderActive, width: 1),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: FanRadius.mdAll,
          borderSide: const BorderSide(color: FanColors.secondary, width: 2),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: FanRadius.mdAll,
          borderSide: const BorderSide(color: FanColors.away, width: 1),
        ),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        prefixIconColor: FanColors.textTertiary,
      );

  static InputDecoration get input => inputDecoration;

  static InputDecoration get searchInput => inputDecoration.copyWith(
        prefixIcon: const Icon(Icons.search_rounded, size: 16),
        hintText: 'Search teams or users...',
        contentPadding:
            const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
      );

  // ========== SPACING (Using FanSpacing) ==========
  static EdgeInsets get cardPadding => EdgeInsets.all(FanSpacing.md);
  static EdgeInsets get sectionPadding =>
      EdgeInsets.symmetric(vertical: FanSpacing.md);
  static EdgeInsets get buttonPadding => EdgeInsets.symmetric(
        horizontal: FanSpacing.base,
        vertical: FanSpacing.sm,
      );

  // ========== GRADIENTS (Using FanGradients) ==========
  static LinearGradient get primaryGradient => FanGradients.cta;
  static LinearGradient get darkGradient => const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Color(0xFF111827), Color(0xFF0F172A)],
      );

  static RadialGradient get glowGradient => RadialGradient(
        center: Alignment.topCenter,
        radius: 0.5,
        colors: [FanColors.primaryGlow, Colors.transparent],
      );

  static BoxDecoration get bottomNavDecoration => FanDecorations.floatingNav;
}
