// pages/account_deletion.dart
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../social_theme.dart';

class AccountDeletionPage extends StatefulWidget {
  const AccountDeletionPage({super.key});

  @override
  State<AccountDeletionPage> createState() => _AccountDeletionPageState();
}

class _AccountDeletionPageState extends State<AccountDeletionPage> {
  bool _isLoading = false;
  bool _confirmed = false;
  bool _understandsDataLoss = false;
  bool _understandsNoRefunds = false;
  String? _deletionStatus;
  final TextEditingController _reasonController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  final String _deletionUrl =
      "https://fanclash-api.onrender.com/api/user/delete";

  @override
  void dispose() {
    _reasonController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _requestAccountDeletion() async {
    if (!_confirmed || !_understandsDataLoss || !_understandsNoRefunds) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Please confirm all checkboxes'),
          backgroundColor: Colors.red,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    if (_passwordController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Password is required'),
          backgroundColor: Colors.red,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    setState(() {
      _isLoading = true;
      _deletionStatus = null;
    });

    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('usertoken');
      final userData = prefs.getString('user');

      if (token == null || userData == null) {
        throw Exception('Not logged in');
      }

      final user = jsonDecode(userData);

      final response = await http.post(
        Uri.parse(_deletionUrl),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode({
          'userId': user['id'],
          'password': _passwordController.text,
          'reason': _reasonController.text.isEmpty
              ? 'No reason provided'
              : _reasonController.text,
        }),
      );

      final result = jsonDecode(response.body);

      if (response.statusCode == 200) {
        setState(() {
          _deletionStatus = 'success';
        });

        // Clear local storage
        await prefs.clear();

        // Show success message
        _showSuccessDialog();
      } else {
        setState(() {
          _deletionStatus = 'error';
        });
        throw Exception(result['error'] ?? 'Deletion failed');
      }
    } catch (error) {
      setState(() {
        _deletionStatus = 'error';
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: $error'),
          backgroundColor: Colors.red,
          behavior: SnackBarBehavior.floating,
        ),
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _showSuccessDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: SocialTheme.background,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          title: const Icon(Icons.check_circle, color: Colors.green, size: 60),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Account Deletion Requested',
                style: SocialTheme.headline,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 12),
              Text(
                'Your account deletion request has been submitted. You will receive a confirmation email shortly. Your account will be permanently deleted within 30 days.',
                style: SocialTheme.body.copyWith(
                  color: SocialTheme.textSecondary,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context); // Close dialog
                Navigator.pop(context); // Go back to previous page
              },
              style: TextButton.styleFrom(
                backgroundColor: SocialTheme.primary,
                padding: const EdgeInsets.symmetric(
                  horizontal: 24,
                  vertical: 12,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: Text(
                'OK',
                style: SocialTheme.body.copyWith(
                  color: Colors.white,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: SocialTheme.background,
      appBar: AppBar(
        backgroundColor: SocialTheme.background,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: SocialTheme.text),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text('Delete Account', style: SocialTheme.headline),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Warning Card
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.red.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.red.withValues(alpha: 0.5)),
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.red.withValues(alpha: 0.2),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.warning_amber_rounded,
                      color: Colors.red,
                      size: 30,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Warning: This action is permanent',
                          style: SocialTheme.body.copyWith(
                            color: Colors.red,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Once deleted, all your data will be permanently removed and cannot be recovered.',
                          style: SocialTheme.small.copyWith(
                            color: Colors.red.shade900,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // What gets deleted
            Container(
              padding: const EdgeInsets.all(20),
              decoration: SocialTheme.cardDecoration,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'When you delete your account:',
                    style: SocialTheme.headline.copyWith(fontSize: 16),
                  ),
                  const SizedBox(height: 16),
                  _buildDeletionItem(
                    icon: Icons.person,
                    text: 'Profile information',
                    color: Colors.red,
                  ),
                  _buildDeletionItem(
                    icon: Icons.how_to_vote,
                    text: 'All voting history and predictions',
                    color: Colors.red,
                  ),
                  _buildDeletionItem(
                    icon: Icons.comment,
                    text: 'Comments and social interactions',
                    color: Colors.red,
                  ),
                  _buildDeletionItem(
                    icon: Icons.emoji_events,
                    text: 'Points, badges, and achievements',
                    color: Colors.red,
                  ),
                  _buildDeletionItem(
                    icon: Icons.attach_money,
                    text: 'Any unused credits or bonuses',
                    color: Colors.orange,
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // What remains
            Container(
              padding: const EdgeInsets.all(20),
              decoration: SocialTheme.cardDecoration,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.info, color: SocialTheme.primary, size: 20),
                      const SizedBox(width: 8),
                      Text(
                        'Information that may remain:',
                        style: SocialTheme.headline.copyWith(fontSize: 16),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  _buildDeletionItem(
                    icon: Icons.receipt,
                    text: 'Anonymized transaction records (for legal purposes)',
                    color: SocialTheme.primary,
                  ),
                  _buildDeletionItem(
                    icon: Icons.chat,
                    text: 'Public comments may remain but will be anonymized',
                    color: SocialTheme.primary,
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Deletion Form
            Container(
              padding: const EdgeInsets.all(20),
              decoration: SocialTheme.cardDecoration,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Confirm Account Deletion',
                    style: SocialTheme.headline.copyWith(fontSize: 16),
                  ),
                  const SizedBox(height: 20),

                  // Password
                  Text(
                    'Enter your password to confirm',
                    style: SocialTheme.body.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 8),
                  TextFormField(
                    controller: _passwordController,
                    obscureText: true,
                    enabled: !_isLoading,
                    style: SocialTheme.body.copyWith(color: SocialTheme.text),
                    decoration: SocialTheme.input.copyWith(
                      hintText: 'Your password',
                      hintStyle: SocialTheme.body.copyWith(
                        color: SocialTheme.textSecondary,
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  // Reason (optional)
                  Text(
                    'Reason for leaving (optional)',
                    style: SocialTheme.body.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 8),
                  TextFormField(
                    controller: _reasonController,
                    enabled: !_isLoading,
                    maxLines: 3,
                    style: SocialTheme.body.copyWith(color: SocialTheme.text),
                    decoration: SocialTheme.input.copyWith(
                      hintText: 'Tell us why you\'re leaving...',
                      hintStyle: SocialTheme.body.copyWith(
                        color: SocialTheme.textSecondary,
                      ),
                      contentPadding: const EdgeInsets.all(16),
                    ),
                  ),

                  const SizedBox(height: 24),

                  // Confirmation Checkboxes
                  _buildCheckbox(
                    value: _confirmed,
                    onChanged: (value) =>
                        setState(() => _confirmed = value ?? false),
                    text:
                        'I confirm that I want to permanently delete my account',
                  ),
                  const SizedBox(height: 12),
                  _buildCheckbox(
                    value: _understandsDataLoss,
                    onChanged: (value) =>
                        setState(() => _understandsDataLoss = value ?? false),
                    text:
                        'I understand that all my data will be permanently lost',
                  ),
                  const SizedBox(height: 12),
                  _buildCheckbox(
                    value: _understandsNoRefunds,
                    onChanged: (value) =>
                        setState(() => _understandsNoRefunds = value ?? false),
                    text:
                        'I understand that I will not receive any refunds for unused credits',
                  ),

                  const SizedBox(height: 24),

                  // Delete Button
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _isLoading ? null : _requestAccountDeletion,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: _isLoading
                          ? const SizedBox(
                              width: 24,
                              height: 24,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : Text(
                              'Permanently Delete Account',
                              style: SocialTheme.body.copyWith(
                                color: Colors.white,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Alternative Contact
            Container(
              padding: const EdgeInsets.all(20),
              decoration: SocialTheme.cardDecoration,
              child: Column(
                children: [
                  Row(
                    children: [
                      Icon(
                        Icons.headset_mic,
                        color: SocialTheme.primary,
                        size: 24,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Need help?',
                              style: SocialTheme.body.copyWith(
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            Text(
                              'Contact support for assistance',
                              style: SocialTheme.small.copyWith(
                                color: SocialTheme.textSecondary,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () =>
                              _launchURL('mailto:support@clashapp.com'),
                          style: OutlinedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            side: BorderSide(color: SocialTheme.primary),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          child: Text(
                            'Email Support',
                            style: SocialTheme.body.copyWith(
                              color: SocialTheme.primary,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () =>
                              _launchURL('https://www.clashapp.com/support'),
                          style: OutlinedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            side: BorderSide(color: SocialTheme.primary),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          child: Text(
                            'Visit Help Center',
                            style: SocialTheme.body.copyWith(
                              color: SocialTheme.primary,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildDeletionItem({
    required IconData icon,
    required String text,
    required Color color,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Icon(icon, color: color, size: 18),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: SocialTheme.body.copyWith(
                color: SocialTheme.textSecondary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCheckbox({
    required bool value,
    required Function(bool?) onChanged,
    required String text,
  }) {
    return Row(
      children: [
        SizedBox(
          height: 24,
          width: 24,
          child: Checkbox(
            value: value,
            onChanged: onChanged,
            activeColor: Colors.red,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(6),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            text,
            style: SocialTheme.body.copyWith(color: SocialTheme.text),
          ),
        ),
      ],
    );
  }

  Future<void> _launchURL(String url) async {
    final Uri uri = Uri.parse(url);
    try {
      if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
        throw Exception('Could not launch $url');
      }
    } catch (e) {
      debugPrint('Error launching URL: $e');
    }
  }
}
