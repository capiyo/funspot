// pages/terms_conditions.dart
import 'package:flutter/material.dart';
import '../social_theme.dart';

class TermsConditionsPage extends StatelessWidget {
  const TermsConditionsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: SocialTheme.background,
      appBar: AppBar(
        backgroundColor: SocialTheme.background,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: SocialTheme.text),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text('Terms & Conditions', style: SocialTheme.headline),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Effective Date
            Container(
              padding: const EdgeInsets.all(16),
              decoration: SocialTheme.cardDecoration,
              child: Row(
                children: [
                  Icon(Icons.event, color: SocialTheme.primary, size: 20),
                  const SizedBox(width: 8),
                  Text(
                    'Effective Date: February 14, 2026',
                    style: SocialTheme.body.copyWith(
                      color: SocialTheme.textSecondary,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Welcome Message
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    SocialTheme.primary.withValues(alpha: 0.1),
                    SocialTheme.primary.withValues(alpha: 0.05),
                  ],
                ),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: SocialTheme.primary.withValues(alpha: 0.3),
                ),
              ),
              child: Column(
                children: [
                  Icon(Icons.gavel, color: SocialTheme.primary, size: 40),
                  const SizedBox(height: 12),
                  Text(
                    'Welcome to Clash',
                    style: SocialTheme.headline.copyWith(fontSize: 20),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Please read these terms carefully before using our social media, fixture viewing, and voting platform.',
                    textAlign: TextAlign.center,
                    style: SocialTheme.body.copyWith(
                      color: SocialTheme.textSecondary,
                      height: 1.6,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Terms Sections
            _buildTermSection(
              title: '1. Acceptance of Terms',
              icon: Icons.check_circle,
              content:
                  'By accessing or using Clash, you agree to be bound by these Terms and Conditions. If you disagree with any part, you may not access the service. You must be at least 13 years old to use this app.',
            ),

            _buildTermSection(
              title: '2. User Accounts',
              icon: Icons.person,
              content:
                  'You are responsible for maintaining the confidentiality of your account credentials. You must notify us immediately of any unauthorized use. You are liable for all activities under your account.',
            ),

            _buildTermSection(
              title: '3. User Conduct',
              icon: Icons.rule,
              content:
                  'You agree not to:\n• Post offensive, harmful, or inappropriate content\n• Harass or bully other users\n• Impersonate others\n• Violate any laws\n• Spam or advertise without permission\n• Share false or misleading information',
            ),

            _buildTermSection(
              title: '4. Fixture Voting Rules',
              icon: Icons.how_to_vote,
              content:
                  '• One vote per fixture per user\n• Votes cannot be changed after submission\n• Manipulation of votes is prohibited\n• Results are final after fixture completion\n• Bonus credits are subject to fair use policy',
            ),

            _buildTermSection(
              title: '5. Social Features',
              icon: Icons.people,
              content:
                  'Your interactions on our platform must be respectful. We reserve the right to remove content that violates our guidelines. Users can block and report inappropriate behavior.',
            ),

            _buildTermSection(
              title: '6. Intellectual Property',
              icon: Icons.copyright,
              content:
                  'All content on Clash, including logos, designs, and software, is owned by us. You retain rights to your posts but grant us license to display them. You may not copy or distribute app content without permission.',
            ),

            _buildTermSection(
              title: '7. Bonuses and Credits',
              icon: Icons.monetization_on,
              content:
                  '• Ksh 100 welcome bonus for new users\n• Bonuses have no cash value\n• Credits can only be used for predictions\n• We reserve the right to modify bonus terms\n• Fraudulent activity voids bonuses',
            ),

            _buildTermSection(
              title: '8. Termination',
              icon: Icons.cancel,
              content:
                  'We may terminate or suspend accounts for violations. You can delete your account anytime. Certain provisions survive termination.',
            ),

            _buildTermSection(
              title: '9. Limitation of Liability',
              icon: Icons.warning,
              content:
                  'Clash is provided "as is" without warranties. We are not liable for indirect damages. Our liability is limited to the maximum extent permitted by law.',
            ),

            _buildTermSection(
              title: '10. Changes to Terms',
              icon: Icons.update,
              content:
                  'We may modify these terms. Continued use after changes constitutes acceptance. Material changes will be notified via app.',
              isLast: true,
            ),

            const SizedBox(height: 24),

            // Agreement Box
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: SocialTheme.primary.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: SocialTheme.primary),
              ),
              child: Column(
                children: [
                  Icon(Icons.handshake, color: SocialTheme.primary, size: 40),
                  const SizedBox(height: 12),
                  Text(
                    'By using Clash, you acknowledge that you have read, understood, and agree to be bound by these Terms and Conditions.',
                    textAlign: TextAlign.center,
                    style: SocialTheme.body.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        style: TextButton.styleFrom(
                          backgroundColor: SocialTheme.surface,
                          padding: const EdgeInsets.symmetric(
                            horizontal: 24,
                            vertical: 12,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: Text(
                          'Decline',
                          style: SocialTheme.body.copyWith(
                            color: SocialTheme.textSecondary,
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      ElevatedButton(
                        onPressed: () => Navigator.pop(context),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: SocialTheme.primary,
                          padding: const EdgeInsets.symmetric(
                            horizontal: 24,
                            vertical: 12,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: Text(
                          'Accept',
                          style: SocialTheme.body.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildTermSection({
    required String title,
    required IconData icon,
    required String content,
    bool isLast = false,
  }) {
    return Container(
      margin: EdgeInsets.only(bottom: isLast ? 0 : 16),
      padding: const EdgeInsets.all(20),
      decoration: SocialTheme.cardDecoration,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: SocialTheme.primary, size: 22),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  title,
                  style: SocialTheme.headline.copyWith(fontSize: 16),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            content,
            style: SocialTheme.body.copyWith(
              color: SocialTheme.textSecondary,
              height: 1.6,
            ),
          ),
        ],
      ),
    );
  }
}
